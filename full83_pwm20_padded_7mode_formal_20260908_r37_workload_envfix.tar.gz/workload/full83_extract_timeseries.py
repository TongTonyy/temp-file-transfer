#!/usr/bin/env python3
"""Build full-83 time-series parquet tables from collector and profiler evidence."""

from __future__ import annotations

import argparse
import json
import math
from pathlib import Path
from statistics import fmean
from typing import Any, Iterator, Mapping, Sequence

import pyarrow as pa
import pyarrow.parquet as pq

from full83_common import (
    atomic_json,
    atomic_text,
    load_json,
    load_metric_specs,
    phase_for_t_idx,
    specs_by_metric,
    value_from_observation,
    write_csv,
    write_parquet,
)


def _compression_from_path(path: Path) -> str:
    if path.suffix == ".zst":
        return "zstd"
    if path.suffix == ".gz":
        return "gzip"
    return "uncompressed"


def iter_jsonl(path: Path) -> Iterator[dict[str, Any]]:
    raw_stream = pa.OSFile(str(path), "rb")
    compression = _compression_from_path(path)
    stream: pa.NativeFile
    if compression == "uncompressed":
        stream = raw_stream
    else:
        stream = pa.CompressedInputStream(raw_stream, compression)
    buffer = b""
    try:
        while True:
            chunk = stream.read(1024 * 1024)
            if not chunk:
                break
            buffer += chunk
            lines = buffer.split(b"\n")
            buffer = lines.pop()
            for line in lines:
                if line:
                    yield json.loads(line)
        if buffer:
            yield json.loads(buffer)
    finally:
        stream.close()
        if not raw_stream.closed:
            raw_stream.close()


def _json_text(value: Any) -> str:
    return json.dumps(value, ensure_ascii=False, sort_keys=True)


def _value_fields(value: Any) -> dict[str, Any]:
    result = {
        "value_f64": None,
        "value_i64": None,
        "value_text": None,
        "value_bool": None,
    }
    if isinstance(value, bool):
        result["value_bool"] = value
    elif isinstance(value, int) and not isinstance(value, bool):
        result["value_i64"] = value
        result["value_f64"] = float(value)
    elif isinstance(value, float):
        result["value_f64"] = value if math.isfinite(value) else None
    elif value is not None:
        result["value_text"] = str(value)
    return result


def _host_from_manifest(path: Path) -> str:
    try:
        manifest = load_json(path / "manifest.json")
        return str(manifest.get("host_id") or "host")
    except Exception:  # noqa: BLE001
        return "host"


def _phase_config(entry: Mapping[str, Any], telemetry_root: Path) -> tuple[float, float, float]:
    sample_plan = entry.get("sample_plan")
    if sample_plan:
        try:
            payload = load_json(Path(str(sample_plan)))
            return (
                float(payload.get("duration_s", 0)),
                float(payload.get("baseline_s", 0)),
                float(payload.get("release_at_s", 0)),
            )
        except Exception:  # noqa: BLE001
            pass
    try:
        manifest = load_json(telemetry_root / "manifest.json")
        config = manifest.get("config", {})
        boundaries = config.get("phase_boundaries_s", []) if isinstance(config, Mapping) else []
        if len(boundaries) >= 5:
            return float(boundaries[-1]), float(boundaries[1]), float(boundaries[3])
        return float(manifest.get("duration_s", 0)), 0.0, float(manifest.get("duration_s", 0))
    except Exception:  # noqa: BLE001
        return 0.0, 0.0, 0.0


def load_preflight(path: Path | None) -> Mapping[str, Any]:
    if path is None or not path.is_file():
        return {}
    try:
        return load_json(path)
    except Exception:  # noqa: BLE001
        return {}


def preflight_by_metric(preflight: Mapping[str, Any]) -> dict[str, Mapping[str, Any]]:
    rows = preflight.get("metrics", [])
    if not isinstance(rows, list):
        return {}
    return {
        str(row.get("metric_id")): row
        for row in rows
        if isinstance(row, Mapping) and row.get("metric_id")
    }


def iter_collector_rows(
    *,
    entry: Mapping[str, Any],
    telemetry_root: Path,
    metric_specs: Mapping[str, Any],
) -> Iterator[dict[str, Any]]:
    host_id = _host_from_manifest(telemetry_root)
    duration_s, baseline_s, release_at_s = _phase_config(entry, telemetry_root)
    run_id = str(entry["run_id"])
    group_key = str(entry.get("key", ""))
    observations_root = telemetry_root / "raw" / "observations"
    if not observations_root.is_dir():
        return
    manifest = load_json(telemetry_root / "manifest.json")
    start_mono_ns = int(manifest.get("run_start_mono_ns", 0))
    for path in sorted(observations_root.glob("collector=*/part-*.jsonl.*")):
        if path.name.endswith(".tmp"):
            continue
        for row in iter_jsonl(path):
            metric_id = str(row.get("metric_id", ""))
            spec = metric_specs.get(metric_id)
            if spec is None:
                continue
            ts_mono = int(row.get("ts_mono_ns", 0) or 0)
            t_idx = int((ts_mono - start_mono_ns) // 1_000_000_000) if start_mono_ns else None
            value = value_from_observation(row)
            yield {
                "schema_version": "full83.timeseries.v1",
                "run_id": run_id,
                "group_key": group_key,
                "condition": str(entry.get("condition", "")),
                "metric_family": str(entry.get("metric", "")),
                "record_source": "collector_raw",
                "node_type": spec.node_type,
                "node_id": str(row.get("node_id") or f"{host_id}/{spec.node_type}/unknown"),
                "metric_id": metric_id,
                "metric_kind": spec.kind,
                "unit": str(row.get("unit") or spec.unit),
                "required_capability": spec.required_capability,
                "expected_source": spec.expected_source,
                "expected_raw_hz": spec.raw_hz,
                "run_duration_s": duration_s,
                "t_idx": t_idx,
                "phase": phase_for_t_idx(t_idx, duration_s, baseline_s, release_at_s),
                "segment_id": "",
                "ts_utc_ns": row.get("ts_utc_ns"),
                "ts_mono_ns": row.get("ts_mono_ns"),
                "profiler_time_bin_us": None,
                "observed": bool(row.get("observed") is True and row.get("status") == "ok"),
                "status": str(row.get("status", "unknown")),
                "quality_flags_json": _json_text(row.get("quality_flags", [])),
                "attributes_json": _json_text(row.get("attributes", {})),
                "source_file": str(path),
                **_value_fields(value),
            }


def _profiler_node_id(host_id: str, run_id: str, node_type: str, rank: int) -> str:
    if node_type in {"npu", "hbm"}:
        return f"{host_id}/{node_type}/{rank}"
    return f"{host_id}/global_task/{run_id}"


def iter_profiler_rows(
    *,
    entry: Mapping[str, Any],
    extraction_root: Path,
    telemetry_root: Path,
    metric_specs: Mapping[str, Any],
) -> Iterator[dict[str, Any]]:
    run_id = str(entry["run_id"])
    host_id = _host_from_manifest(telemetry_root)
    duration_s, baseline_s, release_at_s = _phase_config(entry, telemetry_root)
    run_root = extraction_root / run_id
    if not run_root.is_dir():
        return
    for path in sorted(run_root.glob("*/rank_*/canonical_profiler_metrics.parquet")):
        try:
            table = pq.read_table(path)
        except Exception:  # noqa: BLE001
            continue
        parts = path.parts
        segment_id = path.parent.parent.name if len(parts) >= 3 else ""
        rank_text = path.parent.name.removeprefix("rank_")
        try:
            rank = int(rank_text)
        except ValueError:
            rank = -1
        for row in table.to_pylist():
            metric_id = str(row.get("metric_id", ""))
            spec = metric_specs.get(metric_id)
            if spec is None:
                continue
            bin_us = row.get("profiler_time_bin_us")
            try:
                t_idx = int(int(bin_us) // 1_000_000) if bin_us is not None else None
            except (TypeError, ValueError):
                t_idx = None
            value = row.get("value")
            yield {
                "schema_version": "full83.timeseries.v1",
                "run_id": run_id,
                "group_key": str(entry.get("key", "")),
                "condition": str(entry.get("condition", "")),
                "metric_family": str(entry.get("metric", "")),
                "record_source": "profiler_segment",
                "node_type": spec.node_type,
                "node_id": _profiler_node_id(host_id, run_id, spec.node_type, rank),
                "metric_id": metric_id,
                "metric_kind": spec.kind,
                "unit": str(row.get("unit") or spec.unit),
                "required_capability": spec.required_capability,
                "expected_source": spec.expected_source,
                "expected_raw_hz": spec.raw_hz,
                "run_duration_s": duration_s,
                "t_idx": t_idx,
                "phase": phase_for_t_idx(t_idx, duration_s, baseline_s, release_at_s),
                "segment_id": segment_id,
                "ts_utc_ns": None,
                "ts_mono_ns": None,
                "profiler_time_bin_us": bin_us,
                "observed": value is not None,
                "status": "ok" if value is not None else "missing",
                "quality_flags_json": _json_text(row.get("quality_flags", [])),
                "attributes_json": _json_text(
                    {
                        "rank": rank,
                        "source_field": row.get("source_field"),
                        "derivation": row.get("derivation"),
                    }
                ),
                "source_file": str(path),
                **_value_fields(value),
            }


def availability_rows(
    *,
    entries: Sequence[Mapping[str, Any]],
    specs: Sequence[Any],
    observed_counts: Mapping[tuple[str, str], int],
    preflight_rows: Mapping[str, Mapping[str, Any]],
) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for entry in entries:
        run_id = str(entry["run_id"])
        telemetry_root = Path(str(entry.get("telemetry_root", "")))
        duration_s, _baseline_s, _release_at_s = _phase_config(entry, telemetry_root)
        for spec in specs:
            if observed_counts.get((run_id, spec.metric_id), 0) > 0:
                continue
            preflight = preflight_rows.get(spec.metric_id, {})
            rows.append(
                {
                    "schema_version": "full83.timeseries.v1",
                    "run_id": run_id,
                    "group_key": str(entry.get("key", "")),
                    "condition": str(entry.get("condition", "")),
                    "metric_family": str(entry.get("metric", "")),
                    "record_source": "availability_placeholder",
                    "node_type": spec.node_type,
                    "node_id": f"unobserved/{spec.node_type}/{spec.metric_id}",
                    "metric_id": spec.metric_id,
                    "metric_kind": spec.kind,
                    "unit": spec.unit,
                    "required_capability": spec.required_capability,
                    "expected_source": spec.expected_source,
                    "expected_raw_hz": spec.raw_hz,
                    "run_duration_s": duration_s,
                    "t_idx": None,
                    "phase": "unobserved",
                    "segment_id": "",
                    "ts_utc_ns": None,
                    "ts_mono_ns": None,
                    "profiler_time_bin_us": None,
                    "observed": False,
                    "status": str(preflight.get("preflight_status", "missing")),
                    "quality_flags_json": _json_text(["NO_OBSERVED_TIMESERIES"]),
                    "attributes_json": _json_text(
                        {
                            "preflight_reason": preflight.get("preflight_reason", ""),
                            "collection_solution": preflight.get("collection_solution", spec.support_solution),
                        }
                    ),
                    "source_file": "",
                    "value_f64": None,
                    "value_i64": None,
                    "value_text": None,
                    "value_bool": None,
                }
            )
    return rows


def build_coverage(
    *,
    specs: Sequence[Any],
    rows: Sequence[Mapping[str, Any]],
    preflight_rows: Mapping[str, Mapping[str, Any]],
) -> Mapping[str, Any]:
    coverage_rows: list[dict[str, Any]] = []
    for spec in specs:
        metric_rows = [row for row in rows if row.get("metric_id") == spec.metric_id]
        observed = [row for row in metric_rows if row.get("observed") is True]
        non_ok = [
            row
            for row in metric_rows
            if row.get("record_source") != "availability_placeholder"
            and row.get("status") != "ok"
        ]
        preflight = preflight_rows.get(spec.metric_id, {})
        if observed:
            status = "observed"
        elif non_ok:
            status = "seen_but_not_ok"
        else:
            status = str(preflight.get("preflight_status", "missing"))
        series_counts: dict[tuple[str, str], dict[str, float]] = {}
        for row in observed:
            key = (str(row.get("run_id", "")), str(row.get("node_id", "")))
            item = series_counts.setdefault(
                key,
                {
                    "samples": 0.0,
                    "duration_s": float(row.get("run_duration_s") or 0.0),
                },
            )
            item["samples"] += 1.0
            item["duration_s"] = max(
                item["duration_s"], float(row.get("run_duration_s") or 0.0)
            )
        effective_hz = [
            item["samples"] / item["duration_s"]
            for item in series_counts.values()
            if item["duration_s"] > 0
        ]
        min_effective_hz = min(effective_hz) if effective_hz else 0.0
        mean_effective_hz = fmean(effective_hz) if effective_hz else 0.0
        frequency_threshold_hz = (
            spec.raw_hz * 0.8
            if spec.raw_hz > 0
            else 0.0
        )
        if spec.raw_hz <= 0:
            frequency_status = "event_metric_observed" if observed else "event_metric_not_observed"
        elif not observed:
            frequency_status = "no_observed_series"
        elif min_effective_hz + 1e-12 >= frequency_threshold_hz:
            frequency_status = "meets_required_frequency"
        else:
            frequency_status = "below_required_frequency"
        coverage_rows.append(
            {
                "metric_id": spec.metric_id,
                "node_type": spec.node_type,
                "kind": spec.kind,
                "unit": spec.unit,
                "raw_hz": spec.raw_hz,
                "required_capability": spec.required_capability,
                "expected_source": spec.expected_source,
                "status": status,
                "observed": bool(observed),
                "observed_rows": len(observed),
                "non_ok_rows": len(non_ok),
                "observed_series_count": len(series_counts),
                "min_effective_hz": min_effective_hz,
                "mean_effective_hz": mean_effective_hz,
                "frequency_threshold_hz": frequency_threshold_hz,
                "frequency_status": frequency_status,
                "preflight_status": preflight.get("preflight_status"),
                "preflight_reason": preflight.get("preflight_reason"),
                "quality_flags": sorted(
                    {
                        flag
                        for row in metric_rows
                        for flag in json.loads(str(row.get("quality_flags_json") or "[]"))
                    }
                ),
            }
        )
    counts: dict[str, int] = {}
    for row in coverage_rows:
        counts[str(row["status"])] = counts.get(str(row["status"]), 0) + 1
    return {
        "schema_version": "full83.metric_coverage.v1",
        "status": "complete_with_explicit_missing_metrics",
        "metric_count": len(coverage_rows),
        "status_counts": counts,
        "metrics": coverage_rows,
    }


def build_wide_rows(rows: Sequence[Mapping[str, Any]]) -> list[dict[str, Any]]:
    grouped: dict[tuple[Any, ...], dict[str, Any]] = {}
    for row in rows:
        if row.get("record_source") == "availability_placeholder":
            continue
        key = (
            row.get("run_id"),
            row.get("group_key"),
            row.get("condition"),
            row.get("t_idx"),
            row.get("phase"),
            row.get("segment_id"),
            row.get("node_id"),
            row.get("node_type"),
        )
        target = grouped.setdefault(
            key,
            {
                "run_id": row.get("run_id"),
                "group_key": row.get("group_key"),
                "condition": row.get("condition"),
                "t_idx": row.get("t_idx"),
                "phase": row.get("phase"),
                "segment_id": row.get("segment_id"),
                "node_id": row.get("node_id"),
                "node_type": row.get("node_type"),
            },
        )
        metric_id = str(row.get("metric_id"))
        value = row.get("value_f64")
        if value is None:
            value = row.get("value_i64")
        if value is None:
            value = row.get("value_bool")
        if value is None:
            value = row.get("value_text")
        target[metric_id] = value
        target[f"{metric_id}__status"] = row.get("status")
    return sorted(grouped.values(), key=lambda item: tuple(str(v) for v in item.values()))


def write_docs(output_root: Path, specs: Sequence[Any], coverage: Mapping[str, Any]) -> None:
    metadata = output_root / "metadata"
    counts = coverage.get("status_counts", {})
    dictionary_lines = [
        "# Full-83 指标字典",
        "",
        "本文件由 full83 提取脚本生成，指标定义来自 `node_features.yaml`。",
        "",
        f"- 指标总数：{len(specs)}",
        f"- 状态统计：`{json.dumps(counts, ensure_ascii=False, sort_keys=True)}`",
        "",
        "| metric_id | node_type | unit | raw_hz | source | capability | status | frequency_status | mean_effective_hz |",
        "|---|---|---:|---:|---|---|---|---|---:|",
    ]
    coverage_by_id = {str(row["metric_id"]): row for row in coverage.get("metrics", [])}
    for spec in specs:
        row = coverage_by_id.get(spec.metric_id, {})
        dictionary_lines.append(
            "| "
            + " | ".join(
                [
                    spec.metric_id,
                    spec.node_type,
                    spec.unit,
                    str(spec.raw_hz),
                    spec.expected_source,
                    spec.required_capability,
                    str(row.get("status", "")),
                    str(row.get("frequency_status", "")),
                    str(row.get("mean_effective_hz", "")),
                ]
            )
            + " |"
        )
    atomic_text(metadata / "full83_metric_dictionary_zh.md", "\n".join(dictionary_lines) + "\n")
    protocol = """# Full-83 数据采集协议

本数据集不从既有 v1/v2 中补挖，而是重新执行 910C 采集。每个 run 的真实采集时长、故障注入点和释放点以随包 manifest/sample_plan 为准；测试版可按比例压缩正式时序，正式版保留完整故障窗口用于热响应与性能退化分析。

采集脚本持续输出每个指标的状态。单项指标不可采集不会中断任务，而是写入 `contract/metric_coverage_83.json` 和 `processed/time_series_83.parquet` 的状态字段；只有训练无法启动、风扇安全回滚失败、磁盘不足等系统级错误才会中断。

输出核心文件：

- `processed/time_series_83.parquet`：完整时序长表，包含 collector、profiler 和显式不可观测占位记录。
- `processed/features_long.parquet`：与时序表同源的分析长表。
- `processed/features_wide.parquet`：按 run、节点、时间桶展开的宽表。
- `contract/metric_coverage_83.json`：83 指标逐项覆盖、质量和证据报告。
"""
    atomic_text(metadata / "data_collection_protocol_zh.md", protocol)


def extract_dataset(
    *,
    dataset_manifest: Path,
    extraction_root: Path,
    node_schema: Path,
    metric_support: Path,
    preflight_report: Path | None,
) -> Mapping[str, Any]:
    manifest = load_json(dataset_manifest.resolve(strict=True))
    entries = manifest.get("entries", [])
    if not isinstance(entries, list) or not entries:
        raise SystemExit("dataset manifest entries missing")
    specs = load_metric_specs(node_schema, metric_support)
    metric_specs = specs_by_metric(specs)
    preflight = load_preflight(preflight_report)
    preflight_rows = preflight_by_metric(preflight)
    rows: list[dict[str, Any]] = []
    for entry in entries:
        if not isinstance(entry, Mapping):
            continue
        telemetry_root = Path(str(entry.get("telemetry_root", "")))
        rows.extend(
            iter_collector_rows(
                entry=entry,
                telemetry_root=telemetry_root,
                metric_specs=metric_specs,
            )
        )
        rows.extend(
            iter_profiler_rows(
                entry=entry,
                extraction_root=extraction_root,
                telemetry_root=telemetry_root,
                metric_specs=metric_specs,
            )
        )
    observed_counts: dict[tuple[str, str], int] = {}
    for row in rows:
        if row.get("observed") is True:
            key = (str(row["run_id"]), str(row["metric_id"]))
            observed_counts[key] = observed_counts.get(key, 0) + 1
    rows.extend(
        availability_rows(
            entries=entries,
            specs=specs,
            observed_counts=observed_counts,
            preflight_rows=preflight_rows,
        )
    )
    processed = extraction_root / "processed"
    contract = extraction_root / "contract"
    write_parquet(processed / "time_series_83.parquet", rows)
    write_parquet(processed / "features_long.parquet", rows)
    write_csv(processed / "features_long.csv", rows)
    wide_rows = build_wide_rows(rows)
    write_parquet(processed / "features_wide.parquet", wide_rows)
    coverage = build_coverage(specs=specs, rows=rows, preflight_rows=preflight_rows)
    atomic_json(contract / "metric_coverage_83.json", coverage)
    write_docs(extraction_root, specs, coverage)
    report = {
        "schema_version": "full83.extraction.v1",
        "status": "complete",
        "dataset_manifest": str(dataset_manifest.resolve(strict=True)),
        "entry_count": len(entries),
        "time_series_rows": len(rows),
        "wide_rows": len(wide_rows),
        "metric_count": len(specs),
        "coverage": coverage.get("status_counts", {}),
        "outputs": {
            "time_series_83": str(processed / "time_series_83.parquet"),
            "features_long": str(processed / "features_long.parquet"),
            "features_wide": str(processed / "features_wide.parquet"),
            "metric_coverage": str(contract / "metric_coverage_83.json"),
        },
    }
    atomic_json(extraction_root / "full83_extraction_report.json", report)
    atomic_json(
        extraction_root / "dataset_extraction_manifest.json",
        {
            "schema_version": "full83.dataset_extraction_manifest.v1",
            "status": "complete",
            "time_series_rows": len(rows),
            "metric_count": len(specs),
            "processed": report["outputs"],
        },
    )
    print(f"FULL83_TIME_SERIES={processed / 'time_series_83.parquet'}")
    print(f"FULL83_FEATURES_LONG={processed / 'features_long.parquet'}")
    print(f"FULL83_FEATURES_WIDE={processed / 'features_wide.parquet'}")
    print(f"FULL83_METRIC_COVERAGE={contract / 'metric_coverage_83.json'}")
    return report


def main(argv: Sequence[str] | None = None) -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--dataset-manifest", type=Path, required=True)
    parser.add_argument("--extraction-root", type=Path, required=True)
    parser.add_argument("--node-schema", type=Path, required=True)
    parser.add_argument("--metric-support", type=Path, required=True)
    parser.add_argument("--preflight-report", type=Path)
    args = parser.parse_args(argv)
    extract_dataset(
        dataset_manifest=args.dataset_manifest,
        extraction_root=args.extraction_root.resolve(strict=False),
        node_schema=args.node_schema.resolve(strict=True),
        metric_support=args.metric_support.resolve(strict=True),
        preflight_report=args.preflight_report,
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
