#!/usr/bin/env python3
"""Tee training output and atomically mark the first completed iteration."""

from __future__ import annotations

import argparse
import json
import os
import re
import sys
import time
from pathlib import Path


ITERATION = re.compile(r"\biteration\s+([1-9][0-9]*)\s*/")


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--log", type=Path, required=True)
    args = parser.parse_args()

    run_id = os.environ.get("HGNN_RUN_ID", "")
    marker_raw = os.environ.get("HGNN_TRAINING_READY_MARKER", "")
    if not run_id or not marker_raw:
        raise SystemExit(
            "HGNN_RUN_ID and HGNN_TRAINING_READY_MARKER are required"
        )

    log = args.log.resolve(strict=False)
    marker = Path(marker_raw).resolve(strict=False)
    log.parent.mkdir(parents=True, exist_ok=True)
    marker.parent.mkdir(parents=True, exist_ok=True)
    marked = marker.is_file()

    with log.open("w", encoding="utf-8", buffering=1) as stream:
        for line in sys.stdin:
            stream.write(line)
            try:
                sys.stdout.write(line)
                sys.stdout.flush()
            except BrokenPipeError:
                return 0

            match = ITERATION.search(line)
            if marked or match is None:
                continue
            payload = {
                "schema_version": "1.0",
                "record_type": "training_first_iteration",
                "run_id": run_id,
                "iteration": int(match.group(1)),
                "ts_mono_ns": time.monotonic_ns(),
                "ts_utc_ns": time.time_ns(),
            }
            temporary = marker.with_suffix(marker.suffix + ".tmp")
            temporary.write_text(
                json.dumps(payload, ensure_ascii=False, sort_keys=True) + "\n",
                encoding="utf-8",
            )
            temporary.replace(marker)
            marked = True
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
