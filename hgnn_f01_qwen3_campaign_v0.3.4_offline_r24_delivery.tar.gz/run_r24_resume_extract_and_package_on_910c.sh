#!/usr/bin/env bash
set -Eeuo pipefail
umask 077

ROOT="${HGNN_ROOT:-/root/hgnn_910c_readiness/hgnn_f01_qwen3_campaign_v0.3.4}"
PACKAGE="hgnn_f01_qwen3_campaign_v0.3.4_offline_r24.tar.gz"
CAMPAIGN_ID="${HGNN_R24_CAMPAIGN_ID:-20260814T041544Z-r13-full-dataset}"
DATASET_MANIFEST="${HGNN_R24_DATASET_MANIFEST:-$ROOT/runtime/manifests/$CAMPAIGN_ID/r13_dataset_manifest.json}"
EXTRACT_ROOT="${HGNN_R24_EXTRACT_ROOT:-$ROOT/runtime/extracted_targets_r23/$CAMPAIGN_ID}"
OUTPUT_DIR="${HGNN_R24_OUTPUT_DIR:-$ROOT/runtime/return_bundles}"
MAX_WORKERS="${HGNN_R24_MAX_WORKERS:-64}"
MIN_FREE_GIB="${HGNN_R24_MIN_FREE_GIB:-100}"

[[ -d "$ROOT" ]] || { echo "campaign目录不存在: $ROOT" >&2; exit 2; }
cd "$ROOT"
mkdir -p runtime/logs "$EXTRACT_ROOT" "$OUTPUT_DIR"
STAMP="$(date -u +%Y%m%dT%H%M%SZ)"
LOG="$ROOT/runtime/logs/r24_resume_extract_${STAMP}.log"
PID_FILE="$ROOT/runtime/logs/r24_resume_extract.pid"
exec > >(tee -a "$LOG") 2>&1

r24_stage() {
  local current="$1" name="$2"
  echo "============================================================"
  echo "R24_STAGE=$current/10"
  echo "R24_STAGE_NAME=$name"
  echo "R24_STAGE_UTC=$(date -u +%Y%m%dT%H%M%SZ)"
  echo "============================================================"
}

cleanup_pid_file() {
  if [[ -f "$PID_FILE" ]] && [[ "$(cat "$PID_FILE")" == "$$" ]]; then
    rm -f "$PID_FILE"
  fi
}
trap cleanup_pid_file EXIT

r24_stage 1 "启动、PID与遗留解析进程检查"
echo "R24_STARTED=$STAMP"
echo "DATASET_MANIFEST=$DATASET_MANIFEST"
echo "EXTRACT_ROOT=$EXTRACT_ROOT"
echo "MAX_WORKERS_LIMIT=$MAX_WORKERS"
[[ "$MAX_WORKERS" =~ ^[1-9][0-9]*$ ]] &&
  ((MAX_WORKERS >= 4 && MAX_WORKERS <= 64)) || {
  echo "HGNN_R24_MAX_WORKERS必须在4到64之间" >&2
  exit 2
}
[[ "$MIN_FREE_GIB" =~ ^[0-9]+$ ]] || {
  echo "HGNN_R24_MIN_FREE_GIB必须是非负整数" >&2
  exit 2
}
if [[ -f "$PID_FILE" ]]; then
  OLD_PID="$(cat "$PID_FILE" 2>/dev/null || true)"
  if [[ "$OLD_PID" =~ ^[0-9]+$ ]] && kill -0 "$OLD_PID" 2>/dev/null; then
    echo "检测到仍运行的r24 runner: pid=$OLD_PID" >&2
    exit 2
  fi
  rm -f "$PID_FILE"
fi
echo "$$" >"$PID_FILE"
if pgrep -af \
  'analyse_torch_npu_profiles|export_torch_npu_summary_parallel|extract_r23_profiler_targets|msprof.py.*export' \
  >runtime/logs/r24_process_check.txt; then
  echo "检测到遗留Profiler解析进程，拒绝叠加启动：" >&2
  while IFS= read -r process; do echo "$process" >&2; done \
    <runtime/logs/r24_process_check.txt
  exit 2
fi

r24_stage 2 "r24工具包完整性校验与部署"
[[ -f "$PACKAGE" && ! -L "$PACKAGE" ]] || {
  echo "缺少r24工具包: $ROOT/$PACKAGE" >&2
  exit 2
}
[[ -f "$PACKAGE.sha256" && ! -L "$PACKAGE.sha256" ]] || {
  echo "缺少r24工具包校验: $ROOT/$PACKAGE.sha256" >&2
  exit 2
}
sha256sum -c "$PACKAGE.sha256"
tar -xzf "$PACKAGE"
sha256sum -c r24_SHA256SUMS

r24_stage 3 "Conda、Ascend与CANN环境初始化"
if [[ -f /root/miniconda3/etc/profile.d/conda.sh ]]; then
  # shellcheck disable=SC1091
  source /root/miniconda3/etc/profile.d/conda.sh
elif command -v conda >/dev/null 2>&1; then
  eval "$(conda shell.bash hook)"
else
  echo "未找到conda初始化脚本" >&2
  exit 2
fi
conda activate llm_env
export LD_LIBRARY_PATH="${LD_LIBRARY_PATH:-}"
export PYTHONPATH="${PYTHONPATH:-}"
export CMAKE_PREFIX_PATH="${CMAKE_PREFIX_PATH:-}"
ASCEND_ENV=""
for candidate in \
  /usr/local/Ascend/ascend-toolkit/set_env.sh \
  /usr/local/Ascend/ascend-toolkit/latest/set_env.sh \
  /usr/local/Ascend/ascend-toolkit/latest/bin/setenv.bash
do
  if [[ -f "$candidate" ]]; then ASCEND_ENV="$candidate"; break; fi
done
[[ -n "$ASCEND_ENV" ]] || { echo "未找到Ascend Toolkit环境脚本" >&2; exit 2; }
set +u
# shellcheck disable=SC1090
source "$ASCEND_ENV"
set -u
python - <<'PY'
import pyarrow
import yaml
print(
    "R24_DEPENDENCY_PREFLIGHT=PASS "
    f"pyarrow={pyarrow.__version__} yaml={yaml.__version__}"
)
PY
MSPROF_PY="${HGNN_MSPROF_PY:-}"
if [[ -z "$MSPROF_PY" ]]; then
  MSPROF_PY="$(python - <<'PY'
import shutil
from pathlib import Path
command = shutil.which("msprof.py")
if command:
    print(Path(command).resolve())
    raise SystemExit
for root in (
    Path("/usr/local/Ascend/ascend-toolkit/latest/tools/profiler"),
    Path("/usr/local/Ascend/ascend-toolkit/tools/profiler"),
):
    if root.is_dir():
        for path in root.rglob("msprof.py"):
            if path.is_file():
                print(path.resolve())
                raise SystemExit
raise SystemExit("cannot locate msprof.py")
PY
)"
fi
[[ -f "$MSPROF_PY" ]] || { echo "msprof.py不存在: $MSPROF_PY" >&2; exit 2; }
echo "MSPROF_PY=$MSPROF_PY"
python "$MSPROF_PY" export summary --help >/dev/null

r24_stage 4 "四Run输入、磁盘与83指标合同校验"
FREE_GIB="$(python - "$ROOT" <<'PY'
import shutil
import sys
print(shutil.disk_usage(sys.argv[1]).free // (1024 ** 3))
PY
)"
echo "FREE_GIB=$FREE_GIB"
if ((FREE_GIB < MIN_FREE_GIB)); then
  echo "可用空间不足${MIN_FREE_GIB}GiB，拒绝开始解析" >&2
  exit 2
fi
{
  echo "captured_utc=$STAMP"
  echo "python=$(python --version 2>&1)"
  echo "python_executable=$(command -v python)"
  echo "ascend_env=$ASCEND_ENV"
  echo "msprof_py=$MSPROF_PY"
  echo "max_workers_limit=$MAX_WORKERS"
  echo "cpu_count=$(nproc)"
  python -m pip show torch torch-npu pyarrow pyyaml 2>/dev/null || true
} >"$EXTRACT_ROOT/environment_lock_r24.txt"
python workload/prepare_r23_extraction_contract.py \
  --dataset-manifest "$DATASET_MANIFEST" \
  --node-schema "$ROOT/app/schemas/node_features.yaml" \
  --output-root "$EXTRACT_ROOT"

r24_stage 5 "中断产物dry-run审计与安全清理"
AUDIT_DIR="$ROOT/runtime/logs/r24_resume_audit_${STAMP}"
mkdir -p "$AUDIT_DIR"
python workload/r24_resume_audit.py \
  --selection-manifest "$EXTRACT_ROOT/r23_selection_manifest.json" \
  --output-root "$EXTRACT_ROOT" \
  --report "$AUDIT_DIR/dry_run.json"
python workload/r24_resume_audit.py \
  --selection-manifest "$EXTRACT_ROOT/r23_selection_manifest.json" \
  --output-root "$EXTRACT_ROOT" \
  --report "$AUDIT_DIR/applied.json" \
  --apply \
  --confirm "$CAMPAIGN_ID"

# 阶段6/7/8由提取器打印：任务清点、rank0试跑和剩余session并行。
python workload/extract_r23_profiler_targets.py \
  --selection-manifest "$EXTRACT_ROOT/r23_selection_manifest.json" \
  --metric-coverage "$EXTRACT_ROOT/metric_coverage_83.json" \
  --output-root "$EXTRACT_ROOT" \
  --msprof-py "$MSPROF_PY" \
  --max-workers "$MAX_WORKERS" \
  --stage-start 6

r24_stage 9 "64个Session验收与四Run小型数据包打包"
python - "$EXTRACT_ROOT" <<'PY'
import json
import sys
from pathlib import Path
root = Path(sys.argv[1])
extraction = json.loads((root / "dataset_extraction_manifest.json").read_text())
coverage = json.loads((root / "metric_coverage_83.json").read_text())
if extraction.get("status") != "complete":
    raise SystemExit("r24 extraction manifest is incomplete")
if extraction.get("run_count") != 4:
    raise SystemExit("r24 extraction does not cover four runs")
if extraction.get("complete_session_count") != 64:
    raise SystemExit("r24 extraction does not cover 64 sessions")
if coverage.get("metric_count") != 83 or len(coverage.get("metrics", [])) != 83:
    raise SystemExit("r24 metric coverage is not exactly 83")
print(
    "R24_EXTRACTION_VALIDATED=PASS "
    f"profiler_metrics={coverage.get('profiler_metrics_present', [])}"
)
PY
PACKAGE_OUTPUT="$(
  python workload/package_extracted_dataset.py \
    --dataset-manifest "$DATASET_MANIFEST" \
    --extraction-root "$EXTRACT_ROOT" \
    --output-dir "$OUTPUT_DIR" \
    --bundle-label r24-resumable-core-metrics-dataset
)"
echo "$PACKAGE_OUTPUT"
BUNDLE="$(printf '%s\n' "$PACKAGE_OUTPUT" | awk -F= '$1=="DATASET_BUNDLE"{print substr($0,index($0,"=")+1)}')"
BUNDLE_SUM="$(printf '%s\n' "$PACKAGE_OUTPUT" | awk -F= '$1=="DATASET_BUNDLE_SHA256"{print substr($0,index($0,"=")+1)}')"
[[ -f "$BUNDLE" && -f "$BUNDLE_SUM" ]] || {
  echo "最终压缩包或校验文件缺失" >&2
  exit 2
}
(cd "$(dirname "$BUNDLE")" && sha256sum -c "$(basename "$BUNDLE_SUM")")

r24_stage 10 "CSV缓存、压缩包与安全边界最终校验"
python - "$BUNDLE" "$EXTRACT_ROOT/r23_selection_manifest.json" <<'PY'
import json
import sys
import tarfile
from pathlib import Path
bundle = Path(sys.argv[1])
selection = json.loads(Path(sys.argv[2]).read_text())
markers = 0
for entry in selection["entries"]:
    for session in entry["rank_sessions"].values():
        marker = Path(session) / ".hgnn_r24_cann_summary_complete.json"
        report = Path(sys.argv[2]).parent / entry["run_id"] / (
            "rank_" + Path(session).name.split("_")[1]
        ) / "r23_session_report.json"
        if marker.is_file() or report.is_file():
            markers += 1
if markers != 64:
    raise SystemExit(f"only {markers}/64 sessions have cache or extraction evidence")
with tarfile.open(bundle, "r:gz") as archive:
    names = archive.getnames()
for name in names:
    lowered = name.lower()
    if "_ascend_pt/" in lowered or "/prof_" in lowered:
        raise SystemExit(f"raw profiler member leaked into bundle: {name}")
print(f"R24_BUNDLE_VALIDATED=PASS members={len(names)} cached_sessions={markers}")
PY
echo "R24_COMPLETE=$STAMP"
echo "R24_LOG=$LOG"
echo "R24_DATASET_BUNDLE=$BUNDLE"
echo "R24_DATASET_BUNDLE_SHA256=$BUNDLE_SUM"
