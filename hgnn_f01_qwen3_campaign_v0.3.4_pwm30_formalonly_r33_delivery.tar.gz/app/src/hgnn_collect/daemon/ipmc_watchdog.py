"""Independent fail-closed iBMC fan-mode watchdog.

The child process accepts only a strict JSON contract and can issue only the
strongly typed ``set_auto`` and ``read_faninfo`` operations.
"""

from __future__ import annotations

import argparse
import json
import os
import signal
import stat
import subprocess
import sys
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Callable, Mapping, Optional, Sequence

from hgnn_collect.daemon.ipmc_fan_backend import (
    FanMode,
    SshIpmcConfig,
    SshIpmcTransport,
)


DEFAULT_STALE_AFTER_S = 15.0
DEFAULT_POLL_INTERVAL_S = 0.25
_CONFIG_KEYS = {
    "schema_version",
    "parent_pid",
    "lease_path",
    "ready_path",
    "stop_path",
    "evidence_path",
    "stale_after_s",
    "poll_interval_s",
    "ssh",
}
_SSH_KEYS = {
    "host",
    "port",
    "username",
    "known_hosts_path",
    "expected_host_key_sha256",
    "identity_file",
    "password_env",
    "connect_timeout_s",
    "command_timeout_s",
}


def _exact_mapping(
    value: Any, expected: set[str], label: str
) -> Mapping[str, Any]:
    if not isinstance(value, Mapping):
        raise ValueError("%s must be a mapping" % label)
    unknown = set(value) - expected
    missing = expected - set(value)
    if unknown or missing:
        raise ValueError(
            "%s keys differ; missing=%s unknown=%s"
            % (label, sorted(missing), sorted(unknown))
        )
    return value


def _absolute_path(value: Any, label: str) -> Path:
    if not isinstance(value, str) or not value:
        raise ValueError("%s must be a non-empty path" % label)
    path = Path(value)
    if not path.is_absolute():
        raise ValueError("%s must be absolute" % label)
    return path


@dataclass(frozen=True)
class IpmcWatchdogConfig:
    parent_pid: int
    lease_path: Path
    ready_path: Path
    stop_path: Path
    evidence_path: Path
    stale_after_s: float
    poll_interval_s: float
    ssh: SshIpmcConfig

    @classmethod
    def from_mapping(cls, value: Any) -> "IpmcWatchdogConfig":
        raw = _exact_mapping(value, _CONFIG_KEYS, "watchdog config")
        if raw["schema_version"] != "1.0":
            raise ValueError("watchdog schema_version must be 1.0")
        parent_pid = raw["parent_pid"]
        if isinstance(parent_pid, bool) or not isinstance(parent_pid, int):
            raise ValueError("parent_pid must be an integer")
        if parent_pid <= 1:
            raise ValueError("parent_pid must be greater than one")
        stale_after_s = float(raw["stale_after_s"])
        poll_interval_s = float(raw["poll_interval_s"])
        if stale_after_s <= 0 or poll_interval_s <= 0:
            raise ValueError("watchdog intervals must be positive")
        if poll_interval_s >= stale_after_s:
            raise ValueError("poll_interval_s must be less than stale_after_s")

        ssh_raw = _exact_mapping(raw["ssh"], _SSH_KEYS, "watchdog ssh")
        password_env = ssh_raw["password_env"]
        if password_env is not None and not isinstance(password_env, str):
            raise ValueError("password_env must be a string or null")
        identity_raw = ssh_raw["identity_file"]
        identity_file = (
            None
            if identity_raw is None
            else _absolute_path(identity_raw, "identity_file")
        )
        ssh = SshIpmcConfig(
            host=str(ssh_raw["host"]),
            port=int(ssh_raw["port"]),
            username=str(ssh_raw["username"]),
            known_hosts_path=_absolute_path(
                ssh_raw["known_hosts_path"], "known_hosts_path"
            ),
            expected_host_key_sha256=str(
                ssh_raw["expected_host_key_sha256"]
            ),
            identity_file=identity_file,
            password_env=password_env,
            connect_timeout_s=int(ssh_raw["connect_timeout_s"]),
            command_timeout_s=int(ssh_raw["command_timeout_s"]),
        )
        return cls(
            parent_pid=parent_pid,
            lease_path=_absolute_path(raw["lease_path"], "lease_path"),
            ready_path=_absolute_path(raw["ready_path"], "ready_path"),
            stop_path=_absolute_path(raw["stop_path"], "stop_path"),
            evidence_path=_absolute_path(
                raw["evidence_path"], "evidence_path"
            ),
            stale_after_s=stale_after_s,
            poll_interval_s=poll_interval_s,
            ssh=ssh,
        )

    def to_mapping(self) -> Mapping[str, Any]:
        return {
            "schema_version": "1.0",
            "parent_pid": self.parent_pid,
            "lease_path": str(self.lease_path),
            "ready_path": str(self.ready_path),
            "stop_path": str(self.stop_path),
            "evidence_path": str(self.evidence_path),
            "stale_after_s": self.stale_after_s,
            "poll_interval_s": self.poll_interval_s,
            "ssh": {
                "host": self.ssh.host,
                "port": self.ssh.port,
                "username": self.ssh.username,
                "known_hosts_path": str(self.ssh.known_hosts_path),
                "expected_host_key_sha256": (
                    self.ssh.expected_host_key_sha256
                ),
                "identity_file": (
                    str(self.ssh.identity_file)
                    if self.ssh.identity_file is not None
                    else None
                ),
                "password_env": self.ssh.password_env,
                "connect_timeout_s": self.ssh.connect_timeout_s,
                "command_timeout_s": self.ssh.command_timeout_s,
            },
        }


def secure_atomic_json(path: Path, value: Mapping[str, Any]) -> None:
    """Atomically replace a JSON file with owner-only permissions."""

    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name("%s.tmp.%d" % (path.name, os.getpid()))
    flags = os.O_CREAT | os.O_EXCL | os.O_WRONLY
    descriptor = os.open(str(temporary), flags, 0o600)
    try:
        encoded = (
            json.dumps(
                value,
                ensure_ascii=False,
                sort_keys=True,
                separators=(",", ":"),
            )
            + "\n"
        ).encode("utf-8")
        os.write(descriptor, encoded)
        os.fsync(descriptor)
    finally:
        os.close(descriptor)
    try:
        os.replace(str(temporary), str(path))
        os.chmod(str(path), 0o600)
    finally:
        try:
            temporary.unlink()
        except FileNotFoundError:
            pass


def _latched_json(path: Path, value: Mapping[str, Any]) -> None:
    """Create evidence once; an existing latch is never replaced."""

    path.parent.mkdir(parents=True, exist_ok=True)
    descriptor = os.open(
        str(path), os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600
    )
    try:
        encoded = (
            json.dumps(
                value,
                ensure_ascii=False,
                sort_keys=True,
                separators=(",", ":"),
            )
            + "\n"
        ).encode("utf-8")
        os.write(descriptor, encoded)
        os.fsync(descriptor)
    finally:
        os.close(descriptor)
    os.chmod(str(path), 0o600)


def _read_owner_json(path: Path, label: str) -> Mapping[str, Any]:
    file_stat = path.stat()
    if stat.S_IMODE(file_stat.st_mode) != 0o600:
        raise ValueError("%s permissions must be 0600" % label)
    with path.open(encoding="utf-8") as stream:
        value = json.load(stream)
    if not isinstance(value, Mapping):
        raise ValueError("%s must contain a JSON object" % label)
    return value


def load_watchdog_config(path: Path) -> IpmcWatchdogConfig:
    return IpmcWatchdogConfig.from_mapping(
        _read_owner_json(Path(path), "watchdog config")
    )


def _parent_alive(pid: int) -> bool:
    try:
        os.kill(pid, 0)
    except ProcessLookupError:
        return False
    except PermissionError:
        return True
    return True


def _redact_error(error: BaseException, config: IpmcWatchdogConfig) -> str:
    text = "%s: %s" % (type(error).__name__, error)
    env_name = config.ssh.password_env
    secret = os.environ.get(env_name, "") if env_name else ""
    return text.replace(secret, "<redacted>") if secret else text


def _lease_age_s(
    config: IpmcWatchdogConfig, monotonic_ns: Callable[[], int]
) -> float:
    lease = _read_owner_json(config.lease_path, "watchdog lease")
    if set(lease) != {"schema_version", "sequence", "state", "ts_mono_ns"}:
        raise ValueError("watchdog lease has unsupported fields")
    if lease["schema_version"] != "1.0":
        raise ValueError("watchdog lease schema_version must be 1.0")
    sequence = lease["sequence"]
    timestamp = lease["ts_mono_ns"]
    if (
        isinstance(sequence, bool)
        or not isinstance(sequence, int)
        or sequence < 0
        or isinstance(timestamp, bool)
        or not isinstance(timestamp, int)
        or timestamp < 0
    ):
        raise ValueError("watchdog lease counters must be non-negative integers")
    state = lease["state"]
    if not isinstance(state, str) or not state:
        raise ValueError("watchdog lease state must be a non-empty string")
    age_ns = monotonic_ns() - timestamp
    if age_ns < 0:
        raise ValueError("watchdog lease timestamp is in the future")
    return age_ns / 1_000_000_000.0


def _recover_and_latch(
    config: IpmcWatchdogConfig,
    cause: str,
    transport_factory: Callable[[SshIpmcConfig], Any],
    monotonic_ns: Callable[[], int],
) -> int:
    attempted = False
    auto_verified = False
    error_text: Optional[str] = None
    transport: Any = None
    try:
        transport = transport_factory(config.ssh)
        attempted = True
        transport.set_auto()
        auto_verified = transport.read_faninfo().mode is FanMode.AUTO
        if not auto_verified:
            error_text = "read_faninfo did not confirm auto mode"
    except BaseException as error:
        error_text = _redact_error(error, config)
    finally:
        close = getattr(transport, "close", None)
        if callable(close):
            try:
                close()
            except BaseException as error:
                if error_text is None:
                    error_text = _redact_error(error, config)
    _latched_json(
        config.evidence_path,
        {
            "schema_version": "1.0",
            "status": "latched_auto_recovery",
            "cause": cause,
            "set_auto_attempted": attempted,
            "auto_readback_verified": auto_verified,
            "normal_stop_auto_verified": False,
            "error": error_text,
            "ts_mono_ns": monotonic_ns(),
        },
    )
    return 0 if auto_verified else 1


def run_watchdog(
    config: IpmcWatchdogConfig,
    *,
    transport_factory: Callable[[SshIpmcConfig], Any] = SshIpmcTransport,
    monotonic_ns: Callable[[], int] = time.monotonic_ns,
    sleep: Callable[[float], None] = time.sleep,
    parent_alive: Callable[[int], bool] = _parent_alive,
) -> int:
    """Monitor one lease until normal stop or a latched auto recovery."""

    try:
        initial_age = _lease_age_s(config, monotonic_ns)
    except BaseException as error:
        return _recover_and_latch(
            config,
            "invalid_initial_lease:%s" % _redact_error(error, config),
            transport_factory,
            monotonic_ns,
        )
    if initial_age > config.stale_after_s:
        return _recover_and_latch(
            config, "stale_heartbeat", transport_factory, monotonic_ns
        )

    secure_atomic_json(
        config.ready_path,
        {
            "schema_version": "1.0",
            "status": "ready",
            "watchdog_pid": os.getpid(),
            "ts_mono_ns": monotonic_ns(),
        },
    )
    while True:
        if config.stop_path.exists():
            try:
                stop = _read_owner_json(config.stop_path, "watchdog stop")
                valid_stop = (
                    set(stop)
                    == {"schema_version", "auto_readback_verified", "ts_mono_ns"}
                    and stop["schema_version"] == "1.0"
                    and stop["auto_readback_verified"] is True
                )
            except BaseException:
                valid_stop = False
            if valid_stop:
                _latched_json(
                    config.evidence_path,
                    {
                        "schema_version": "1.0",
                        "status": "normal_stop_auto_verified",
                        "cause": "normal_stop",
                        "set_auto_attempted": False,
                        "auto_readback_verified": True,
                        "normal_stop_auto_verified": True,
                        "error": None,
                        "ts_mono_ns": monotonic_ns(),
                    },
                )
                return 0
            return _recover_and_latch(
                config,
                "stop_without_auto_confirmation",
                transport_factory,
                monotonic_ns,
            )
        if not parent_alive(config.parent_pid):
            return _recover_and_latch(
                config, "parent_process_missing", transport_factory, monotonic_ns
            )
        try:
            age_s = _lease_age_s(config, monotonic_ns)
        except BaseException as error:
            return _recover_and_latch(
                config,
                "invalid_heartbeat:%s" % _redact_error(error, config),
                transport_factory,
                monotonic_ns,
            )
        if age_s > config.stale_after_s:
            return _recover_and_latch(
                config, "stale_heartbeat", transport_factory, monotonic_ns
            )
        sleep(config.poll_interval_s)


class WatchdogProcessManager:
    """Launch and manage only the watchdog process group created here."""

    def __init__(
        self,
        ssh: SshIpmcConfig,
        output_dir: Path,
        *,
        environment: Optional[Mapping[str, str]] = None,
        parent_pid: Optional[int] = None,
        stale_after_s: float = DEFAULT_STALE_AFTER_S,
        poll_interval_s: float = DEFAULT_POLL_INTERVAL_S,
        ready_timeout_s: float = 10.0,
        stop_timeout_s: float = 30.0,
        popen_factory: Callable[..., Any] = subprocess.Popen,
        monotonic: Callable[[], float] = time.monotonic,
        monotonic_ns: Callable[[], int] = time.monotonic_ns,
        sleep: Callable[[float], None] = time.sleep,
        group_signal: Callable[[int, int], None] = os.killpg,
    ) -> None:
        root = Path(output_dir).expanduser().resolve()
        self.config_path = root / "watchdog_config.json"
        self.config = IpmcWatchdogConfig(
            parent_pid=os.getpid() if parent_pid is None else parent_pid,
            lease_path=root / "watchdog_heartbeat_lease.json",
            ready_path=root / "watchdog_ready.json",
            stop_path=root / "watchdog_stop.json",
            evidence_path=root / "watchdog_evidence.json",
            stale_after_s=float(stale_after_s),
            poll_interval_s=float(poll_interval_s),
            ssh=ssh,
        )
        self.environment = dict(os.environ if environment is None else environment)
        self.ready_timeout_s = float(ready_timeout_s)
        self.stop_timeout_s = float(stop_timeout_s)
        self._popen = popen_factory
        self._monotonic = monotonic
        self._monotonic_ns = monotonic_ns
        self._sleep = sleep
        self._group_signal = group_signal
        self._process: Any = None
        self._ready = False
        self._sequence = 0
        self._stopped = False
        self._evidence: Optional[Mapping[str, Any]] = None

    @property
    def ready(self) -> bool:
        return self._ready

    def start(self) -> None:
        if self._process is not None:
            raise RuntimeError("watchdog has already been started")
        self.heartbeat({"state": "STARTING"})
        secure_atomic_json(self.config_path, self.config.to_mapping())
        child_env = {
            name: self.environment[name]
            for name in ("PATH", "LANG", "LC_ALL")
            if name in self.environment
        }
        if ssh_password_env := self.config.ssh.password_env:
            if ssh_password_env in self.environment:
                child_env[ssh_password_env] = self.environment[ssh_password_env]
        source_root = str(Path(__file__).resolve().parents[2])
        existing_pythonpath = child_env.get("PYTHONPATH", "")
        child_env["PYTHONPATH"] = (
            source_root
            if not existing_pythonpath
            else source_root + os.pathsep + existing_pythonpath
        )
        self._process = self._popen(
            [
                sys.executable,
                "-m",
                "hgnn_collect.daemon.ipmc_watchdog",
                "--config",
                str(self.config_path),
            ],
            stdin=subprocess.DEVNULL,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            shell=False,
            start_new_session=True,
            env=child_env,
        )
        deadline = self._monotonic() + self.ready_timeout_s
        try:
            while self._monotonic() < deadline:
                if self._process.poll() is not None:
                    raise RuntimeError("watchdog exited before ready")
                if self.config.ready_path.exists():
                    ready = _read_owner_json(
                        self.config.ready_path, "watchdog ready"
                    )
                    if ready.get("status") == "ready":
                        self._ready = True
                        self.ensure_ready()
                        return
                self._sleep(0.05)
            raise TimeoutError("watchdog did not become ready")
        except BaseException:
            self._terminate_owned_group()
            raise

    def ensure_ready(self) -> None:
        if not self._ready or self._process is None:
            raise RuntimeError("watchdog is not ready")
        returncode = self._process.poll()
        if returncode is not None:
            self._ready = False
            if self.config.evidence_path.exists():
                evidence = _read_owner_json(
                    self.config.evidence_path, "watchdog evidence"
                )
                self._evidence = dict(evidence)
                if (
                    returncode == 0
                    and evidence.get("status") == "normal_stop_auto_verified"
                    and evidence.get("normal_stop_auto_verified") is True
                    and evidence.get("auto_readback_verified") is True
                ):
                    self._stopped = True
                    return
                raise RuntimeError(
                    "watchdog exited with rc %s evidence_status=%s cause=%s"
                    % (
                        returncode,
                        evidence.get("status"),
                        evidence.get("cause"),
                    )
                )
            raise RuntimeError("watchdog exited unexpectedly with rc %s" % returncode)
        if self.config.evidence_path.exists():
            self._ready = False
            raise RuntimeError("watchdog recovery is already latched")

    def heartbeat(self, event: Mapping[str, Any]) -> None:
        if self._stopped:
            return
        if self._process is not None:
            self.ensure_ready()
        self._sequence += 1
        state = event.get("state", "UNKNOWN")
        secure_atomic_json(
            self.config.lease_path,
            {
                "schema_version": "1.0",
                "sequence": self._sequence,
                "state": str(state),
                "ts_mono_ns": self._monotonic_ns(),
            },
        )

    def stop(self, auto_readback_verified: bool) -> None:
        if self._stopped:
            return
        self._stopped = True
        if self._process is None:
            return
        secure_atomic_json(
            self.config.stop_path,
            {
                "schema_version": "1.0",
                "auto_readback_verified": bool(auto_readback_verified),
                "ts_mono_ns": self._monotonic_ns(),
            },
        )

    def wait(self) -> Mapping[str, Any]:
        if self._evidence is not None:
            return self._evidence
        if self._process is None:
            raise RuntimeError("watchdog was not started")
        try:
            returncode = self._process.wait(timeout=self.stop_timeout_s)
        except (subprocess.TimeoutExpired, TimeoutError):
            self._terminate_owned_group()
            raise RuntimeError("watchdog did not stop in time")
        if not self.config.evidence_path.exists():
            raise RuntimeError(
                "watchdog exited with rc %s without evidence" % returncode
            )
        evidence = _read_owner_json(
            self.config.evidence_path, "watchdog evidence"
        )
        self._evidence = dict(evidence)
        return self._evidence

    def _terminate_owned_group(self) -> None:
        process = self._process
        if process is None or process.poll() is not None:
            return
        pgid = int(process.pid)
        try:
            self._group_signal(pgid, signal.SIGTERM)
        except ProcessLookupError:
            return
        try:
            process.wait(timeout=2.0)
            return
        except (subprocess.TimeoutExpired, TimeoutError):
            pass
        try:
            self._group_signal(pgid, signal.SIGKILL)
        except ProcessLookupError:
            return
        try:
            process.wait(timeout=2.0)
        except (subprocess.TimeoutExpired, TimeoutError):
            pass


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="ipmc_watchdog")
    parser.add_argument("--config", type=Path, required=True)
    return parser


def main(argv: Optional[Sequence[str]] = None) -> int:
    args = build_parser().parse_args(argv)
    config = load_watchdog_config(args.config)
    return run_watchdog(config)


if __name__ == "__main__":
    raise SystemExit(main())
