"""Typed and fail-closed iBMC fan control for Ascend 910C drawers.

The public transport boundary deliberately exposes four operations and never
accepts command text.  The SSH implementation pins the server key, tries an
OpenSSH BatchMode exec first, and only uses a non-logging pexpect session when
an environment-sourced password fallback is explicitly configured.
"""

from __future__ import annotations

import base64
import hashlib
import os
import re
import subprocess
import time
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from types import MappingProxyType
from typing import (
    Any,
    Callable,
    Dict,
    List,
    Mapping,
    Optional,
    Protocol,
    Sequence,
    Tuple,
)

from hgnn_collect.daemon.intervention_controller import InterventionManifest


MIN_FAN_PWM = 20
MAX_FAN_PWM = 100
ALL_FAN_IDS = tuple(range(1, 16))


class FanMode(str, Enum):
    AUTO = "auto"
    MANUAL = "manual"


@dataclass(frozen=True)
class DrawerTopology:
    drawer: str
    fan_ids: Tuple[int, ...]
    compute_kind: str
    compute_ids: Tuple[int, ...]

    @property
    def logical_npu_ids(self) -> Tuple[int, ...]:
        if self.compute_kind != "npu":
            return ()
        return tuple(
            die_id
            for card_id in self.compute_ids
            for die_id in (2 * (card_id - 1), 2 * (card_id - 1) + 1)
        )


DRAWER_TOPOLOGY: Mapping[str, DrawerTopology] = MappingProxyType(
    {
        "drawer0": DrawerTopology(
            "drawer0", (1, 2, 3, 4, 13), "npu", (3, 4, 7, 8)
        ),
        "drawer1": DrawerTopology(
            "drawer1", (5, 6, 7, 8, 14), "cpu", (1, 2, 3, 4)
        ),
        "drawer2": DrawerTopology(
            "drawer2", (9, 10, 11, 12, 15), "npu", (1, 2, 5, 6)
        ),
    }
)


class IpmcFanError(RuntimeError):
    """Base class for typed iBMC fan failures."""


class FanInfoParseError(IpmcFanError):
    """The iBMC faninfo response is missing or ambiguous."""


class TransportError(IpmcFanError):
    """The pinned SSH transport could not complete an operation."""


class SafetyViolation(IpmcFanError):
    """A fan or thermal safety invariant was violated."""


@dataclass(frozen=True)
class FanInfo:
    mode: FanMode
    timeout_s: Optional[int]
    levels: Mapping[int, int]

    def __post_init__(self) -> None:
        normalized = dict(self.levels)
        for fan_id, pwm in normalized.items():
            _validate_fan_id(fan_id)
            _validate_pwm(pwm)
        if self.mode is FanMode.AUTO and self.timeout_s is not None:
            if self.timeout_s < 0:
                raise ValueError("fan timeout must be non-negative")
        if self.mode is FanMode.MANUAL:
            if self.timeout_s is None or self.timeout_s <= 0:
                raise ValueError("manual fan mode requires a positive timeout")
        object.__setattr__(self, "levels", MappingProxyType(normalized))

    def require_all_fans(self) -> None:
        observed = set(self.levels)
        expected = set(ALL_FAN_IDS)
        if observed != expected:
            missing = sorted(expected - observed)
            extra = sorted(observed - expected)
            raise FanInfoParseError(
                "faninfo must contain exactly Fan1-Fan15; missing=%s extra=%s"
                % (missing, extra)
            )


@dataclass(frozen=True)
class CommandReceipt:
    operation: str
    output: str = field(default="", repr=False)


class IpmcFanTransport(Protocol):
    """Only these four strongly typed operations may reach iBMC."""

    def read_faninfo(self) -> FanInfo:
        ...

    def set_manual(self, timeout_s: int) -> CommandReceipt:
        ...

    def set_level(self, fan_id: int, pwm: int) -> CommandReceipt:
        ...

    def set_auto(self) -> CommandReceipt:
        ...


_MODE_RE = re.compile(
    r"\bcurrent\s+mode\s*:\s*(auto(?:matic)?|manual)\b", re.IGNORECASE
)
_TIMEOUT_RE = re.compile(
    r"\btime\s*out\b\s*(?::|=)?\s*(\d+)\s*(?:s|sec(?:ond)?s?)?\b",
    re.IGNORECASE,
)
_FAN_RE = re.compile(
    r"\bfan\s*(\d{1,2})\s*"
    r"(?:(?:manual\s+)?(?:fan\s+)?(?:speed\s+)?level|speed)?"
    r"\s*(?::|=)\s*(\d{1,3})\s*%?",
    re.IGNORECASE,
)
_ANSI_RE = re.compile(r"\x1b\[[0-?]*[ -/]*[@-~]")


def parse_faninfo(text: str) -> FanInfo:
    """Parse auto/manual mode, timeout, and per-fan PWM from faninfo text."""

    if not isinstance(text, str) or not text.strip():
        raise FanInfoParseError("faninfo response is empty")
    clean = _ANSI_RE.sub("", text).replace("\r", "")
    modes = {match.group(1).lower() for match in _MODE_RE.finditer(clean)}
    normalized_modes = {
        "auto" if value in {"auto", "automatic"} else value for value in modes
    }
    if len(normalized_modes) != 1:
        raise FanInfoParseError("faninfo must contain one unambiguous current mode")
    mode = FanMode(next(iter(normalized_modes)))

    timeout_values = [int(match.group(1)) for match in _TIMEOUT_RE.finditer(clean)]
    timeout_s: Optional[int] = None
    if mode is FanMode.MANUAL:
        if not timeout_values:
            raise FanInfoParseError("manual faninfo is missing timeout")
        if len(set(timeout_values)) != 1:
            raise FanInfoParseError("faninfo contains conflicting timeouts")
        timeout_s = timeout_values[0]
        if timeout_s <= 0:
            raise FanInfoParseError("manual faninfo timeout must be positive")

    levels: Dict[int, int] = {}
    for match in _FAN_RE.finditer(clean):
        fan_id = int(match.group(1))
        pwm = int(match.group(2))
        try:
            _validate_fan_id(fan_id)
            _validate_pwm(pwm)
        except (TypeError, ValueError) as error:
            raise FanInfoParseError(str(error)) from error
        if fan_id in levels and levels[fan_id] != pwm:
            raise FanInfoParseError("faninfo contains conflicting Fan%d levels" % fan_id)
        levels[fan_id] = pwm
    try:
        return FanInfo(mode=mode, timeout_s=timeout_s, levels=levels)
    except ValueError as error:
        raise FanInfoParseError(str(error)) from error


def _require_plain_int(value: Any, name: str) -> int:
    if isinstance(value, bool) or not isinstance(value, int):
        raise TypeError("%s must be an integer" % name)
    return value


def _validate_fan_id(fan_id: Any) -> int:
    value = _require_plain_int(fan_id, "fan_id")
    if value not in ALL_FAN_IDS:
        raise ValueError("fan_id must be in [1, 15]")
    return value


def _validate_pwm(pwm: Any) -> int:
    value = _require_plain_int(pwm, "pwm")
    if value < MIN_FAN_PWM or value > MAX_FAN_PWM:
        raise ValueError("pwm must be in [20, 100]")
    return value


def _validate_timeout(timeout_s: Any) -> int:
    value = _require_plain_int(timeout_s, "timeout_s")
    if value <= 0 or value > 86400:
        raise ValueError("timeout_s must be in [1, 86400]")
    return value


@dataclass(frozen=True)
class SshIpmcConfig:
    host: str
    username: str
    known_hosts_path: Path
    expected_host_key_sha256: str
    port: int = 22
    identity_file: Optional[Path] = None
    password_env: Optional[str] = None
    connect_timeout_s: int = 5
    command_timeout_s: int = 10
    prompt_pattern: str = r"(?m)^iBMC:[^\r\n]*?->\s*$"

    def __post_init__(self) -> None:
        if not re.fullmatch(r"[A-Za-z0-9._:-]+", self.host):
            raise ValueError("host contains unsupported characters")
        if not re.fullmatch(r"[A-Za-z0-9._-]+", self.username):
            raise ValueError("username contains unsupported characters")
        if isinstance(self.port, bool) or not 1 <= self.port <= 65535:
            raise ValueError("port must be in [1, 65535]")
        if self.connect_timeout_s <= 0 or self.command_timeout_s <= 0:
            raise ValueError("SSH timeouts must be positive")
        known_hosts = Path(self.known_hosts_path)
        if not known_hosts.is_absolute():
            raise ValueError("known_hosts_path must be absolute")
        object.__setattr__(self, "known_hosts_path", known_hosts)
        if self.identity_file is not None:
            identity = Path(self.identity_file)
            if not identity.is_absolute():
                raise ValueError("identity_file must be absolute")
            object.__setattr__(self, "identity_file", identity)
        if not re.fullmatch(
            r"SHA256:[A-Za-z0-9+/]{43}=?", self.expected_host_key_sha256
        ):
            raise ValueError("expected_host_key_sha256 must be an SHA256 fingerprint")
        if self.password_env is not None and not re.fullmatch(
            r"[A-Z_][A-Z0-9_]*", self.password_env
        ):
            raise ValueError("password_env must be an uppercase environment name")


class SshIpmcTransport:
    """Pinned OpenSSH transport with an optional pexpect password fallback."""

    _READ_FANINFO = ("ipmcget", "-d", "faninfo")
    _SET_AUTO = ("ipmcset", "-d", "fanmode", "-v", "0")

    def __init__(
        self,
        config: SshIpmcConfig,
        runner: Callable[..., Any] = subprocess.run,
        spawn_factory: Optional[Callable[..., Any]] = None,
        environment: Optional[Mapping[str, str]] = None,
    ) -> None:
        self.config = config
        self._runner = runner
        self._spawn_factory = spawn_factory
        self._environment = os.environ if environment is None else environment
        self._interactive: Optional[Any] = None
        self._pin_verified = False

    def read_faninfo(self) -> FanInfo:
        return parse_faninfo(self._execute(self._READ_FANINFO))

    def set_manual(self, timeout_s: int) -> CommandReceipt:
        timeout = _validate_timeout(timeout_s)
        output = self._execute(
            ("ipmcset", "-d", "fanmode", "-v", "1", str(timeout))
        )
        return CommandReceipt("set_manual", output)

    def set_level(self, fan_id: int, pwm: int) -> CommandReceipt:
        checked_fan = _validate_fan_id(fan_id)
        checked_pwm = _validate_pwm(pwm)
        # iBMC syntax is fanlevel first, then the optional fan ID.
        output = self._execute(
            (
                "ipmcset",
                "-d",
                "fanlevel",
                "-v",
                str(checked_pwm),
                str(checked_fan),
            )
        )
        return CommandReceipt("set_level", output)

    def set_auto(self) -> CommandReceipt:
        return CommandReceipt("set_auto", self._execute(self._SET_AUTO))

    def close(self) -> None:
        child = self._interactive
        self._interactive = None
        if child is not None:
            try:
                child.close(force=True)
            except BaseException:
                pass

    def __enter__(self) -> "SshIpmcTransport":
        return self

    def __exit__(self, *_exc: Any) -> None:
        self.close()

    def _execute(self, command: Sequence[str]) -> str:
        self._verify_pinned_host_key()
        if self._interactive is not None:
            return self._interactive_execute(command)
        argv = self._ssh_argv(batch_mode=True) + list(command)
        try:
            completed = self._runner(
                argv,
                stdin=subprocess.DEVNULL,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True,
                timeout=self.config.command_timeout_s,
                check=False,
                shell=False,
            )
        except (OSError, subprocess.TimeoutExpired) as error:
            raise TransportError("BatchMode SSH execution failed") from error
        if completed.returncode == 0:
            return str(completed.stdout)
        if completed.returncode == 255 and self.config.password_env:
            return self._interactive_execute(command)
        raise TransportError(
            "BatchMode SSH operation failed with status %d" % completed.returncode
        )

    def _ssh_argv(self, batch_mode: bool) -> List[str]:
        argv = [
            "ssh",
            "-T",
            "-p",
            str(self.config.port),
            "-o",
            "BatchMode=%s" % ("yes" if batch_mode else "no"),
            "-o",
            "StrictHostKeyChecking=yes",
            "-o",
            "UserKnownHostsFile=%s" % self.config.known_hosts_path,
            "-o",
            "GlobalKnownHostsFile=/dev/null",
            "-o",
            "CheckHostIP=yes",
            "-o",
            "ConnectTimeout=%d" % self.config.connect_timeout_s,
        ]
        if self.config.identity_file is not None:
            argv.extend(
                [
                    "-o",
                    "IdentitiesOnly=yes",
                    "-i",
                    str(self.config.identity_file),
                ]
            )
        if not batch_mode:
            argv.extend(
                [
                    "-tt",
                    "-o",
                    "PreferredAuthentications=password",
                    "-o",
                    "PubkeyAuthentication=no",
                ]
            )
        argv.extend(["--", "%s@%s" % (self.config.username, self.config.host)])
        return argv

    def _verify_pinned_host_key(self) -> None:
        if self._pin_verified:
            return
        path = self.config.known_hosts_path
        try:
            lines = path.read_text(encoding="utf-8").splitlines()
        except OSError as error:
            raise TransportError("fixed known_hosts file is unavailable") from error
        expected_names = {self.config.host}
        expected_names.add("[%s]:%d" % (self.config.host, self.config.port))
        matching_fingerprints = set()
        for line in lines:
            stripped = line.strip()
            if not stripped or stripped.startswith("#") or stripped.startswith("@"):
                continue
            fields = stripped.split()
            if len(fields) < 3:
                continue
            hosts, _algorithm, encoded_key = fields[:3]
            if not expected_names.intersection(hosts.split(",")):
                continue
            try:
                key_bytes = base64.b64decode(encoded_key.encode("ascii"), validate=True)
            except (ValueError, UnicodeError) as error:
                raise TransportError("known_hosts contains an invalid host key") from error
            digest = base64.b64encode(hashlib.sha256(key_bytes).digest()).decode(
                "ascii"
            )
            matching_fingerprints.add("SHA256:" + digest.rstrip("="))
        expected = self.config.expected_host_key_sha256.rstrip("=")
        if expected not in matching_fingerprints:
            raise TransportError("known_hosts does not contain the pinned host key")
        self._pin_verified = True

    def _interactive_execute(self, command: Sequence[str]) -> str:
        child = self._ensure_interactive()
        command_text = " ".join(command)
        child.sendline(command_text)
        try:
            index = child.expect(
                [
                    self.config.prompt_pattern,
                    r"(?i)(?:permission denied|authentication failed)",
                    r"(?i)(?:unknown command|invalid parameter|failed)",
                ],
                timeout=self.config.command_timeout_s,
            )
        except BaseException as error:
            self.close()
            raise TransportError("interactive iBMC operation timed out") from error
        output = str(getattr(child, "before", ""))
        if index != 0:
            self.close()
            excerpt = " ".join(output.replace("\r", "\n").split())
            if excerpt:
                raise TransportError(
                    "interactive iBMC operation failed: " + excerpt[-500:]
                )
            raise TransportError("interactive iBMC operation failed")
        return output

    def _ensure_interactive(self) -> Any:
        if self._interactive is not None:
            return self._interactive
        env_name = self.config.password_env
        if not env_name:
            raise TransportError("password fallback is not configured")
        password = self._environment.get(env_name)
        if password is None or password == "":
            raise TransportError("password environment variable is unavailable")
        try:
            if self._spawn_factory is None:
                import pexpect  # type: ignore

                spawn_factory = pexpect.spawn
                eof_type = pexpect.EOF
                timeout_type = pexpect.TIMEOUT
            else:
                spawn_factory = self._spawn_factory
                eof_type = object()
                timeout_type = object()
            argv = self._ssh_argv(batch_mode=False)
            child = spawn_factory(
                argv[0],
                args=argv[1:],
                encoding="utf-8",
                timeout=self.config.command_timeout_s,
            )
            child.logfile = None
            child.logfile_read = None
            child.logfile_send = None
            index = child.expect(
                [
                    r"(?i)password:\s*$",
                    self.config.prompt_pattern,
                    r"(?i)(?:permission denied|authentication failed)",
                    r"(?i)(?:host key verification failed|remote host identification)",
                    eof_type,
                    timeout_type,
                ],
                timeout=self.config.command_timeout_s,
            )
            if index == 0:
                child.sendline(password)
                index = child.expect(
                    [
                        self.config.prompt_pattern,
                        r"(?i)(?:permission denied|authentication failed)",
                        eof_type,
                        timeout_type,
                    ],
                    timeout=self.config.command_timeout_s,
                )
                if index != 0:
                    child.close(force=True)
                    raise TransportError("interactive SSH authentication failed")
            elif index != 1:
                child.close(force=True)
                raise TransportError("interactive SSH connection failed")
        except TransportError:
            raise
        except (ImportError, OSError) as error:
            raise TransportError("pexpect password fallback is unavailable") from error
        self._interactive = child
        return child


# Readable compatibility alias without exposing any extra operation.
IpmcSshTransport = SshIpmcTransport


@dataclass(frozen=True)
class TemperatureSnapshot:
    npu_max_c: float
    hbm_max_c: float
    npu_by_device_c: Mapping[int, float] = field(default_factory=dict)
    hbm_by_device_c: Mapping[int, float] = field(default_factory=dict)


class TemperatureProvider(Protocol):
    def __call__(self) -> TemperatureSnapshot:
        ...


class WatchdogHeartbeatSink(Protocol):
    def __call__(self, event: Mapping[str, Any]) -> None:
        ...


class IpmcFanBackend:
    """Single-drawer F01 backend with explicit readback and auto rollback."""

    _TEMPERATURE_RISE_WINDOW_S = 60.0
    _TEMPERATURE_RISE_CONFIRMATIONS = 2

    def __init__(
        self,
        transport: IpmcFanTransport,
        target_drawer: Optional[str] = None,
        allow_cpu_drawer: bool = False,
        manual_timeout_s: int = 600,
        boost_pwm: int = 95,
        baseline_pwm: int = 80,
        s1_pwm: int = 75,
        boost_deadline_s: float = 30.0,
        control_step_s: float = 5.0,
        faninfo_read_deadline_s: float = 10.0,
        npu_hard_stop_c: float = 75.0,
        hbm_hard_stop_c: float = 85.0,
        max_temperature_rise_c_per_min: float = 3.0,
        clock: Callable[[], float] = time.monotonic,
        sleep: Callable[[float], None] = time.sleep,
        temperature_provider: Optional[Callable[[], Any]] = None,
        watchdog_heartbeat_sink: Optional[WatchdogHeartbeatSink] = None,
    ) -> None:
        self.transport = transport
        self.target_drawer = (
            self._normalize_drawer(target_drawer)
            if target_drawer is not None
            else None
        )
        self.allow_cpu_drawer = bool(allow_cpu_drawer)
        self.manual_timeout_s = _validate_timeout(manual_timeout_s)
        self.boost_pwm = _validate_pwm(boost_pwm)
        self.baseline_pwm = _validate_pwm(baseline_pwm)
        self.s1_pwm = _validate_pwm(s1_pwm)
        if not (
            self.boost_pwm >= self.baseline_pwm >= self.s1_pwm >= MIN_FAN_PWM
        ):
            raise ValueError("PWM levels must satisfy boost >= baseline >= S1 >= 20")
        if (self.boost_pwm - self.baseline_pwm) % 5:
            raise ValueError("boost-to-baseline difference must use five-point steps")
        if (self.baseline_pwm - self.s1_pwm) % 5:
            raise ValueError("baseline-to-S1 difference must use five-point steps")
        if (
            boost_deadline_s <= 0
            or control_step_s < 5.0
            or faninfo_read_deadline_s <= 0
        ):
            raise ValueError(
                "boost/faninfo deadlines must be positive and control step >= 5s"
            )
        if npu_hard_stop_c <= 0 or hbm_hard_stop_c <= 0:
            raise ValueError("thermal hard stops must be positive")
        if max_temperature_rise_c_per_min <= 0:
            raise ValueError("temperature rise limit must be positive")
        self.boost_deadline_s = float(boost_deadline_s)
        self.control_step_s = float(control_step_s)
        self.faninfo_read_deadline_s = float(faninfo_read_deadline_s)
        self.npu_hard_stop_c = float(npu_hard_stop_c)
        self.hbm_hard_stop_c = float(hbm_hard_stop_c)
        self.max_temperature_rise_c_per_min = float(
            max_temperature_rise_c_per_min
        )
        self._clock = clock
        self._sleep = sleep
        self._temperature_provider = temperature_provider
        self._watchdog_sink = watchdog_heartbeat_sink
        self._heartbeat_sequence = 0
        self._last_temperature: Optional[Tuple[float, TemperatureSnapshot]] = None
        self._temperature_rise_breach_count = 0
        self._baseline_target_thermal: Dict[str, Mapping[str, Any]] = {}
        self._release_count = 0
        self._last_rollback_verified = False

    def precheck(self, manifest: InterventionManifest) -> Mapping[str, Any]:
        drawers = self._drawers_for_manifest(manifest)
        drawer = self._drawer_label(drawers)
        self._heartbeat("PRECHECK", drawer)
        thermal = self._check_thermal()
        if thermal is not None:
            for target_drawer in drawers:
                self._baseline_target_thermal[target_drawer] = self._target_thermal(
                    target_drawer, thermal, include_delta=False
                )
        info = self._read_faninfo()
        if info.mode is not FanMode.AUTO:
            raise SafetyViolation("precheck requires fan mode auto")
        return self._audit(
            "precheck",
            drawer,
            info,
            target_drawers=drawers,
            thermal=thermal,
            rollback_verified=self._last_rollback_verified,
        )

    def arm_intervention_thermal_baseline(
        self, manifest: InterventionManifest
    ) -> Optional[TemperatureSnapshot]:
        """Reset rise-rate comparison after the training warmup baseline."""

        drawers = self._drawers_for_manifest(manifest)
        drawer = self._drawer_label(drawers)
        self._last_temperature = None
        self._temperature_rise_breach_count = 0
        thermal = self._check_thermal()
        if thermal is not None:
            thermal_response = {
                target_drawer: self._target_thermal(
                    target_drawer, thermal, include_delta=False
                )
                for target_drawer in drawers
            }
            for target_drawer, response in thermal_response.items():
                self._baseline_target_thermal[target_drawer] = response
            self._heartbeat(
                "INTERVENTION_THERMAL_BASELINE",
                drawer,
                {"thermal_response": thermal_response},
            )
        return thermal

    def apply(self, manifest: InterventionManifest) -> Mapping[str, Any]:
        drawers = self._drawers_for_manifest(manifest)
        drawer = self._drawer_label(drawers)
        target_fan_ids = self._target_fan_ids(drawers)
        self._heartbeat("APPLY", drawer)
        self._check_thermal()
        manual_started = False
        try:
            # A lost response can occur after iBMC has changed mode, so an
            # attempted manual transition is always treated as partially applied.
            manual_started = True
            self.transport.set_manual(self.manual_timeout_s)
            self._heartbeat("APPLY_MANUAL", drawer)
            started = self._clock()
            for fan_id in ALL_FAN_IDS:
                self._heartbeat("APPLY_BOOST", drawer)
                self.transport.set_level(fan_id, self.boost_pwm)
            boosted = self._read_faninfo()
            boosted.require_all_fans()
            self._require_mode_and_levels(
                boosted,
                {fan_id: self.boost_pwm for fan_id in ALL_FAN_IDS},
            )
            elapsed = self._clock() - started
            if elapsed > self.boost_deadline_s:
                raise SafetyViolation(
                    "all-fan boost and readback exceeded %.1fs" % self.boost_deadline_s
                )

            current = self.boost_pwm
            while current > self.baseline_pwm:
                self._sleep(self.control_step_s)
                self._heartbeat("APPLY_BASELINE", drawer)
                self._check_thermal()
                current -= 5
                for fan_id in ALL_FAN_IDS:
                    self._heartbeat("APPLY_BASELINE", drawer)
                    self.transport.set_level(fan_id, current)

            current = self.baseline_pwm
            while current > self.s1_pwm:
                self._sleep(self.control_step_s)
                self._heartbeat("APPLY_TARGET", drawer)
                self._check_thermal()
                current -= 5
                for fan_id in target_fan_ids:
                    self._heartbeat("APPLY_TARGET", drawer)
                    self.transport.set_level(fan_id, current)
            return {
                "ok": True,
                "operation": "apply",
                "target_drawer": drawer,
                "target_drawers": list(drawers),
                "target_fan_ids": list(target_fan_ids),
                "boost_pwm": self.boost_pwm,
                "baseline_pwm": self.baseline_pwm,
                "target_pwm": self.s1_pwm,
                "manual_timeout_s": self.manual_timeout_s,
                "boost_readback_elapsed_s": elapsed,
                "rollback_verified": False,
            }
        except BaseException:
            if manual_started:
                self._last_rollback_verified = self._best_effort_auto()
            raise

    def verify(self, manifest: InterventionManifest) -> Mapping[str, Any]:
        drawers = self._drawers_for_manifest(manifest)
        drawer = self._drawer_label(drawers)
        target_fan_ids = self._target_fan_ids(drawers)
        self._heartbeat("VERIFY", drawer)
        thermal = self._check_thermal_with_rollback()
        try:
            info = self._read_faninfo()
            info.require_all_fans()
            expected = {fan_id: self.baseline_pwm for fan_id in ALL_FAN_IDS}
            expected.update({fan_id: self.s1_pwm for fan_id in target_fan_ids})
            self._require_mode_and_levels(info, expected)
            return self._audit(
                "verify", drawer, info, target_drawers=drawers, thermal=thermal
            )
        except BaseException:
            self._last_rollback_verified = self._best_effort_auto()
            raise

    def hold(self, manifest: InterventionManifest) -> Mapping[str, Any]:
        """Continuously verify temperatures and PWM readback during HOLD."""

        drawers = self._drawers_for_manifest(manifest)
        drawer = self._drawer_label(drawers)
        target_fan_ids = self._target_fan_ids(drawers)
        expected = {fan_id: self.baseline_pwm for fan_id in ALL_FAN_IDS}
        expected.update({fan_id: self.s1_pwm for fan_id in target_fan_ids})
        duration_s = float(manifest.hold_seconds)
        started = self._clock()
        last_info: Optional[FanInfo] = None
        last_thermal: Optional[TemperatureSnapshot] = None
        samples = 0
        try:
            while True:
                self._heartbeat("HOLD", drawer)
                last_thermal = self._check_thermal()
                if last_thermal is not None:
                    self._heartbeat(
                        "HOLD_SAMPLE",
                        drawer,
                        {
                            "thermal_response": {
                                target_drawer: self._target_thermal(
                                    target_drawer, last_thermal
                                )
                                for target_drawer in drawers
                            }
                        },
                    )
                last_info = self._read_faninfo()
                last_info.require_all_fans()
                self._require_mode_and_levels(last_info, expected)
                samples += 1
                remaining = duration_s - (self._clock() - started)
                if remaining <= 0:
                    break
                self._sleep(min(self.control_step_s, remaining))
        except BaseException:
            self._last_rollback_verified = self._best_effort_auto()
            raise
        assert last_info is not None
        return self._audit(
            "hold",
            drawer,
            last_info,
            target_drawers=drawers,
            thermal=last_thermal,
            hold_seconds=duration_s,
            monitor_samples=samples,
        )

    def release(self, manifest: InterventionManifest) -> Mapping[str, Any]:
        drawers = self._drawers_for_manifest(manifest)
        drawer = self._drawer_label(drawers)
        self._heartbeat("RELEASE", drawer)
        self._release_count += 1
        try:
            self.transport.set_auto()
            info = self._read_faninfo()
            if info.mode is not FanMode.AUTO:
                raise SafetyViolation("release readback did not confirm auto mode")
        except BaseException:
            self._last_rollback_verified = self._best_effort_auto()
            raise
        self._last_rollback_verified = True
        return self._audit(
            "release",
            drawer,
            info,
            target_drawers=drawers,
            release_count=self._release_count,
            rollback_verified=True,
        )

    def recovery_verify(
        self, manifest: InterventionManifest
    ) -> Mapping[str, Any]:
        drawers = self._drawers_for_manifest(manifest)
        drawer = self._drawer_label(drawers)
        self._heartbeat("RECOVERY_VERIFY", drawer)
        info = self._read_faninfo()
        if info.mode is not FanMode.AUTO:
            self._last_rollback_verified = self._best_effort_auto()
            raise SafetyViolation("recovery readback did not confirm auto mode")
        self._last_rollback_verified = True
        return self._audit(
            "recovery_verify",
            drawer,
            info,
            target_drawers=drawers,
            rollback_verified=True,
        )

    def _read_faninfo(self) -> FanInfo:
        started = self._clock()
        value = self.transport.read_faninfo()
        elapsed = self._clock() - started
        if elapsed > self.faninfo_read_deadline_s:
            raise SafetyViolation(
                "faninfo read exceeded %.1fs staleness limit"
                % self.faninfo_read_deadline_s
            )
        if isinstance(value, str):
            return parse_faninfo(value)
        if not isinstance(value, FanInfo):
            raise TypeError("read_faninfo must return FanInfo")
        return value

    def _best_effort_auto(self) -> bool:
        try:
            self.transport.set_auto()
        except BaseException:
            return False
        try:
            return self._read_faninfo().mode is FanMode.AUTO
        except BaseException:
            return False

    def _check_thermal_with_rollback(self) -> Optional[TemperatureSnapshot]:
        try:
            return self._check_thermal()
        except BaseException:
            self._last_rollback_verified = self._best_effort_auto()
            raise

    def _check_thermal(self) -> Optional[TemperatureSnapshot]:
        if self._temperature_provider is None:
            return None
        raw = self._temperature_provider()
        snapshot = self._coerce_temperature(raw)
        now = self._clock()
        if snapshot.npu_max_c >= self.npu_hard_stop_c:
            raise SafetyViolation(
                "NPU temperature %.1fC reached hard stop %.1fC"
                % (snapshot.npu_max_c, self.npu_hard_stop_c)
            )
        if snapshot.hbm_max_c >= self.hbm_hard_stop_c:
            raise SafetyViolation(
                "HBM temperature %.1fC reached hard stop %.1fC"
                % (snapshot.hbm_max_c, self.hbm_hard_stop_c)
            )
        previous = self._last_temperature
        if previous is None:
            self._last_temperature = (now, snapshot)
            return snapshot
        previous_time, previous_snapshot = previous
        elapsed = now - previous_time
        if elapsed < self._TEMPERATURE_RISE_WINDOW_S:
            return snapshot
        npu_rise = (
            (snapshot.npu_max_c - previous_snapshot.npu_max_c)
            * 60.0
            / elapsed
        )
        hbm_rise = (
            (snapshot.hbm_max_c - previous_snapshot.hbm_max_c)
            * 60.0
            / elapsed
        )
        observed_rise = max(npu_rise, hbm_rise)
        if observed_rise > self.max_temperature_rise_c_per_min:
            self._temperature_rise_breach_count += 1
        else:
            self._temperature_rise_breach_count = 0
        self._last_temperature = (now, snapshot)
        if (
            self._temperature_rise_breach_count
            >= self._TEMPERATURE_RISE_CONFIRMATIONS
        ):
            raise SafetyViolation(
                "sustained temperature rise %.2fC/min exceeds %.2fC/min "
                "for %d consecutive %.0fs windows"
                % (
                    observed_rise,
                    self.max_temperature_rise_c_per_min,
                    self._temperature_rise_breach_count,
                    self._TEMPERATURE_RISE_WINDOW_S,
                )
            )
        return snapshot

    @staticmethod
    def _coerce_temperature(value: Any) -> TemperatureSnapshot:
        if isinstance(value, TemperatureSnapshot):
            return value
        if isinstance(value, Mapping):
            npu = value.get("npu_max_c", value.get("npu_temperature_c"))
            hbm = value.get("hbm_max_c", value.get("hbm_temperature_c"))
            if npu is None or hbm is None:
                raise SafetyViolation("temperature provider omitted NPU or HBM value")
            try:
                return TemperatureSnapshot(float(npu), float(hbm))
            except (TypeError, ValueError) as error:
                raise SafetyViolation("temperature values must be numeric") from error
        raise TypeError("temperature provider must return TemperatureSnapshot or mapping")

    def _heartbeat(
        self,
        state: str,
        drawer: str,
        extra: Optional[Mapping[str, Any]] = None,
    ) -> None:
        if self._watchdog_sink is None:
            return
        self._heartbeat_sequence += 1
        record: Dict[str, Any] = {
            "record_type": "ipmc_fan_watchdog_heartbeat",
            "sequence": self._heartbeat_sequence,
            "state": state,
            "target_drawer": drawer,
            "ts_mono_s": self._clock(),
        }
        if extra:
            record.update(extra)
        self._watchdog_sink(record)

    def _target_thermal(
        self,
        drawer: str,
        thermal: TemperatureSnapshot,
        include_delta: bool = True,
    ) -> Mapping[str, Any]:
        logical_npu_ids = DRAWER_TOPOLOGY[drawer].logical_npu_ids
        npu_values = [
            thermal.npu_by_device_c[device_id]
            for device_id in logical_npu_ids
            if device_id in thermal.npu_by_device_c
        ]
        hbm_values = [
            thermal.hbm_by_device_c[device_id]
            for device_id in logical_npu_ids
            if device_id in thermal.hbm_by_device_c
        ]
        mapped = (
            bool(logical_npu_ids)
            and len(npu_values) == len(logical_npu_ids)
            and len(hbm_values) == len(logical_npu_ids)
        )
        result: Dict[str, Any] = {
            "mapping_status": "target_drawer" if mapped else "global_fallback",
            "logical_npu_ids": list(logical_npu_ids),
            "npu_max_c": max(npu_values) if mapped else thermal.npu_max_c,
            "hbm_max_c": max(hbm_values) if mapped else thermal.hbm_max_c,
        }
        if mapped:
            result["npu_mean_c"] = sum(npu_values) / len(npu_values)
            result["hbm_mean_c"] = sum(hbm_values) / len(hbm_values)
        baseline = self._baseline_target_thermal.get(drawer)
        if include_delta and baseline is not None:
            result["delta_from_precheck_c"] = {
                "npu_max_c": result["npu_max_c"] - baseline["npu_max_c"],
                "hbm_max_c": result["hbm_max_c"] - baseline["hbm_max_c"],
            }
            if mapped and baseline.get("mapping_status") == "target_drawer":
                result["delta_from_precheck_c"].update(
                    {
                        "npu_mean_c": result["npu_mean_c"]
                        - baseline["npu_mean_c"],
                        "hbm_mean_c": result["hbm_mean_c"]
                        - baseline["hbm_mean_c"],
                    }
                )
        return result

    def _drawers_for_manifest(self, manifest: InterventionManifest) -> Tuple[str, ...]:
        if not isinstance(manifest, InterventionManifest):
            raise TypeError("IpmcFanBackend accepts InterventionManifest only")
        candidates: List[str] = []
        target = manifest.target
        for key in ("drawer", "cooling_zone"):
            value = target.get(key)
            if value is not None:
                if not isinstance(value, str):
                    raise ValueError("%s target must be a string" % key)
                candidates.append(self._normalize_drawer(value))
        entities = target.get("physical_entity_ids")
        if entities is not None:
            if (
                not isinstance(entities, (list, tuple))
                or not entities
                or any(not isinstance(entity, str) for entity in entities)
            ):
                raise ValueError("drawer physical_entity_ids must be non-empty strings")
            candidates.extend(self._normalize_drawer(entity) for entity in entities)
        drawers = tuple(dict.fromkeys(candidates))
        if not candidates and self.target_drawer is not None:
            drawers = (self.target_drawer,)
        if not drawers:
            raise ValueError("at least one consistent drawer target is required")
        if self.target_drawer is not None and len(drawers) == 1:
            if drawers[0] != self.target_drawer:
                raise ValueError("manifest drawer differs from configured drawer")
        for drawer in drawers:
            if (
                DRAWER_TOPOLOGY[drawer].compute_kind == "cpu"
                and not self.allow_cpu_drawer
            ):
                raise ValueError(
                    "CPU drawer interventions are disabled for the current NPU F01 campaign"
                )
        return drawers

    def _drawer_for_manifest(self, manifest: InterventionManifest) -> str:
        drawers = self._drawers_for_manifest(manifest)
        if len(drawers) != 1:
            raise ValueError("exactly one drawer target is required")
        return drawers[0]

    @staticmethod
    def _drawer_label(drawers: Sequence[str]) -> str:
        return "+".join(drawers)

    @staticmethod
    def _target_fan_ids(drawers: Sequence[str]) -> Tuple[int, ...]:
        fan_ids: List[int] = []
        for drawer in drawers:
            fan_ids.extend(DRAWER_TOPOLOGY[drawer].fan_ids)
        return tuple(sorted(dict.fromkeys(fan_ids)))

    @staticmethod
    def _normalize_drawer(value: str) -> str:
        normalized = value.strip().lower()
        suffix = "_cooling_zone"
        if normalized.endswith(suffix):
            normalized = normalized[: -len(suffix)]
        if normalized not in DRAWER_TOPOLOGY:
            raise ValueError("drawer must be one of drawer0, drawer1, drawer2")
        return normalized

    @staticmethod
    def _require_mode_and_levels(
        info: FanInfo, expected: Mapping[int, int]
    ) -> None:
        if info.mode is not FanMode.MANUAL:
            raise SafetyViolation("fan readback is not manual")
        if info.timeout_s is None or info.timeout_s <= 0:
            raise SafetyViolation("manual fan timeout is not active")
        mismatches = {
            fan_id: {"expected": pwm, "observed": info.levels.get(fan_id)}
            for fan_id, pwm in expected.items()
            if info.levels.get(fan_id) != pwm
        }
        if mismatches:
            raise SafetyViolation("fan level readback mismatch: %s" % mismatches)

    def _audit(
        self,
        operation: str,
        drawer: str,
        info: FanInfo,
        target_drawers: Sequence[str] = (),
        thermal: Optional[TemperatureSnapshot] = None,
        **extra: Any,
    ) -> Mapping[str, Any]:
        drawers = tuple(target_drawers) or tuple(drawer.split("+"))
        result: Dict[str, Any] = {
            "ok": True,
            "operation": operation,
            "target_drawer": drawer,
            "target_drawers": list(drawers),
            "target_fan_ids": list(self._target_fan_ids(drawers)),
            "mode": info.mode.value,
            "timeout_s": info.timeout_s,
            "fan_levels": {
                "Fan%d" % fan_id: info.levels[fan_id]
                for fan_id in sorted(info.levels)
            },
        }
        if thermal is not None:
            result["temperature"] = {
                "npu_max_c": thermal.npu_max_c,
                "hbm_max_c": thermal.hbm_max_c,
            }
            result["target_drawer_temperature"] = {
                target_drawer: self._target_thermal(target_drawer, thermal)
                for target_drawer in drawers
            }
        result.update(extra)
        return result
