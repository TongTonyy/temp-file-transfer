#!/usr/bin/env bash
set -Eeuo pipefail
umask 077

PACKAGE_NAME="hgnn_f01_qwen3_campaign_v0.3.4"
EXPECTED_ROOT="${HGNN_CAMPAIGN_ROOT_OVERRIDE:-/root/hgnn_910c_readiness/hgnn_f01_qwen3_campaign_v0.3.4}"
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd -P)"
RUNTIME="$ROOT/runtime"
CREDENTIALS="$ROOT/config/credentials.env"
RUNNER="$ROOT/app/bin/run_hsh_f01_active.py"
COLLECTOR_CONFIG="$ROOT/app/configs/hsh_f01_active_smoke_collector.yaml"

require_campaign_root() {
  [[ "$ROOT" == "$EXPECTED_ROOT" && "$PWD" == "$EXPECTED_ROOT" ]] || {
    echo "必须在 $EXPECTED_ROOT 目录内直接执行（当前 ROOT=$ROOT, PWD=$PWD）" >&2
    exit 2
  }
}

assert_runtime_path() {
  local candidate="$1"
  [[ "$candidate" == "$RUNTIME" || "$candidate" == "$RUNTIME/"* ]] || {
    echo "拒绝 campaign runtime 之外的路径: $candidate" >&2
    exit 2
  }
}

resolve_llm_python() {
  if [[ -n "${HGNN_PYTHON:-}" && -x "$HGNN_PYTHON" ]]; then
    export HGNN_PYTHON
    export PATH="$(dirname "$HGNN_PYTHON"):$PATH"
    return 0
  fi
  local conda_cmd version
  if [[ -n "${HGNN_CONDA_EXE:-}" && -x "$HGNN_CONDA_EXE" ]]; then
    conda_cmd="$HGNN_CONDA_EXE"
  elif [[ -n "${CONDA_EXE:-}" && -x "$CONDA_EXE" ]]; then
    conda_cmd="$CONDA_EXE"
  else
    conda_cmd="$(command -v conda || true)"
  fi
  [[ -n "$conda_cmd" && -x "$conda_cmd" ]] || {
    echo "未找到 conda；请先加载已存在的 llm_env" >&2
    exit 2
  }
  HGNN_PYTHON="$("$conda_cmd" run -n llm_env python -c 'import sys; print(sys.executable)' | tail -n 1)"
  [[ -x "$HGNN_PYTHON" ]] || {
    echo "llm_env Python 解析失败" >&2
    exit 2
  }
  version="$("$HGNN_PYTHON" -c 'import sys; print(f"{sys.version_info.major}.{sys.version_info.minor}")')"
  [[ "$version" == "3.10" ]] || {
    echo "llm_env 必须是 Python 3.10，当前为 $version" >&2
    exit 2
  }
  "$HGNN_PYTHON" -c \
    'import numpy, pyarrow, psutil, yaml, pexpect, pydantic; assert int(pydantic.__version__.split(".", 1)[0]) >= 2'
  HGNN_CONDA_EXE="$conda_cmd"
  export HGNN_PYTHON HGNN_CONDA_EXE
  export PATH="$(dirname "$HGNN_PYTHON"):$PATH"
}

load_credentials() {
  [[ -f "$CREDENTIALS" && ! -L "$CREDENTIALS" ]] || {
    echo "缺少普通文件 $CREDENTIALS" >&2
    exit 2
  }
  [[ "$(stat -c '%a' "$CREDENTIALS")" == "600" ]] || {
    echo "credentials.env 权限必须为 0600" >&2
    exit 2
  }
  set -a
  # shellcheck disable=SC1090
  . "$CREDENTIALS"
  set +a
  : "${HGNN_BMC_ENDPOINT:?credentials.env 缺少 HGNN_BMC_ENDPOINT}"
  : "${HGNN_BMC_USERNAME:?credentials.env 缺少 HGNN_BMC_USERNAME}"
  : "${HGNN_BMC_PASSWORD:?credentials.env 缺少 HGNN_BMC_PASSWORD}"
  if [[ -z "${HGNN_IPMC_PASSWORD:-}" ]]; then
    export HGNN_IPMC_PASSWORD="$HGNN_BMC_PASSWORD"
  fi
  : "${HGNN_F01_ACTIVE_APPROVAL:?credentials.env 缺少审批 token}"
}

prepare_runtime_dirs() {
  local path
  for path in \
    "$RUNTIME/outputs" "$RUNTIME/data" "$RUNTIME/traces" "$RUNTIME/profiles" \
    "$RUNTIME/logs" "$RUNTIME/ckpt" "$RUNTIME/gates" \
    "$RUNTIME/manifests" "$RUNTIME/normalized" "$RUNTIME/return_bundles" \
    "$RUNTIME/tmp"; do
    assert_runtime_path "$path"
    mkdir -p "$path"
  done
}

campaign_init() {
  require_campaign_root
  resolve_llm_python
  load_credentials
  prepare_runtime_dirs
  export PYTHONPATH="$ROOT/app/src${PYTHONPATH:+:$PYTHONPATH}"
}

workload_init() {
  require_campaign_root
  resolve_llm_python
  prepare_runtime_dirs
  export PYTHONPATH="$ROOT/app/src${PYTHONPATH:+:$PYTHONPATH}"
  unset HGNN_BMC_ENDPOINT HGNN_BMC_USERNAME HGNN_BMC_PASSWORD
  unset HGNN_IPMC_PASSWORD HGNN_F01_ACTIVE_APPROVAL
}

site_for_drawer() {
  if [[ -n "${HGNN_SITE_CONFIG_OVERRIDE:-}" ]]; then
    printf '%s\n' "$HGNN_SITE_CONFIG_OVERRIDE"
    return 0
  fi
  case "$1" in
    drawer0) printf '%s\n' "$ROOT/config/site.drawer0.local.yaml" ;;
    drawer1) printf '%s\n' "$ROOT/config/site.drawer1.local.yaml" ;;
    drawer2) printf '%s\n' "$ROOT/config/site.drawer2.local.yaml" ;;
    multi_npu|all_drawers) printf '%s\n' "$ROOT/config/site.drawer0.local.yaml" ;;
    *) echo "未知 drawer: $1" >&2; return 2 ;;
  esac
}

require_smoke_gate() {
  local drawer="$1" report="$RUNTIME/gates/${1}_smoke_protocol.json"
  [[ -f "$report" ]] || {
    echo "缺少 $drawer 的 smoke gate: $report" >&2
    exit 2
  }
  "$HGNN_PYTHON" - "$report" "$drawer" <<'PY'
import json
import sys
from pathlib import Path

report = json.loads(Path(sys.argv[1]).read_text(encoding="utf-8"))
drawer = sys.argv[2]
expected = f"{drawer}_s1"
checks = {
    "condition": report.get("condition") == expected,
    "passed": report.get("passed") is True,
    "intervention_control_verified": (
        report.get("intervention_control_verified") is True
    ),
    "thermal_effect_not_claimed_by_smoke": (
        report.get("thermal_effect_status") == "not_evaluated_safety_smoke"
        and report.get("subhealth_confirmed") is False
        and report.get("hardware_evidence") is False
    ),
    "collector_rc0": report.get("collector_returncode") == 0,
    "auto": report.get("auto_readback_verified") is True,
    "watchdog_ready": report.get("watchdog_ready_before_active") is True,
    "watchdog_normal": report.get("watchdog_normal_stop_auto_verified") is True,
}
failed = sorted(key for key, value in checks.items() if not value)
if failed:
    raise SystemExit("smoke gate failed: " + ", ".join(failed))
PY
}

make_manifest() {
  local run_id="$1" output="$RUNTIME/manifests/$run_id/workload_manifest.json"
  assert_runtime_path "$output"
  mkdir -p "$(dirname "$output")"
  "$HGNN_PYTHON" "$ROOT/workload/make_workload_manifest.py" \
    --root "$ROOT" --run-id "$run_id" --output "$output"
  printf '%s\n' "$output"
}

run_formal() {
  local condition="$1" drawer="$2" run_id="$3"
  local site output manifest rc
  local duration baseline release_at inventory_mode
  duration="${HGNN_FORMAL_DURATION:-600}"
  baseline="${HGNN_FORMAL_BASELINE:-120}"
  release_at="${HGNN_FORMAL_RELEASE_AT:-420}"
  inventory_mode="${HGNN_PROFILE_INVENTORY_MODE:-formal}"
  site="$(site_for_drawer "$drawer")"
  output="$RUNTIME/outputs/formal/$run_id"
  assert_runtime_path "$output"
  mkdir -p "$output"
  manifest="$(make_manifest "$run_id")"
  export HGNN_RUN_ID="$run_id"
  export HGNN_TRAINING_READY_MARKER="$RUNTIME/manifests/$run_id/training_ready.json"
  export HGNN_TORCH_NPU_PROFILE_DIR="$RUNTIME/profiles/$run_id"
  export HGNN_PROFILE_CONTROL_PATH="$RUNTIME/manifests/$run_id/profile_control.json"
  export HGNN_TORCH_NPU_AIC_METRIC="${HGNN_TORCH_NPU_AIC_METRIC:-ResourceConflictRatio}"
  assert_runtime_path "$HGNN_TRAINING_READY_MARKER"
  assert_runtime_path "$HGNN_TORCH_NPU_PROFILE_DIR"
  assert_runtime_path "$HGNN_PROFILE_CONTROL_PATH"
  case "$HGNN_TORCH_NPU_AIC_METRIC" in
    ResourceConflictRatio|MemoryAccess) ;;
    *)
      echo "HGNN_TORCH_NPU_AIC_METRIC必须是ResourceConflictRatio或MemoryAccess" >&2
      return 2
      ;;
  esac
  case "$inventory_mode" in
    formal|canary) ;;
    *)
      echo "HGNN_PROFILE_INVENTORY_MODE必须是formal或canary" >&2
      return 2
      ;;
  esac
  rm -f "$HGNN_TRAINING_READY_MARKER" "$HGNN_PROFILE_CONTROL_PATH"
  set +e
  "$HGNN_PYTHON" "$RUNNER" run \
    --condition "$condition" \
    --site-config "$site" \
    --credentials-env-file "$CREDENTIALS" \
    --collector-config "$COLLECTOR_CONFIG" \
    --duration "$duration" --baseline "$baseline" --release-at "$release_at" \
    --run-id "$run_id" \
    --data-root "$RUNTIME/data" \
    --output-dir "$output" \
    --workload-manifest "$manifest"
  rc=$?
  set -e
  [[ "$rc" -eq 0 ]] || {
    echo "formal runner 失败，rc=$rc；rc=2 也视为批次失败" >&2
    return "$rc"
  }
  if [[ -n "${HGNN_R29_SAMPLE_PLAN_PATH:-}" ]]; then
    printf 'RUN_OUTPUT=%s\n' "$output"
    return 0
  fi
  "$HGNN_PYTHON" "$ROOT/workload/inventory_torch_npu_profile.py" \
    --input-root "$HGNN_TORCH_NPU_PROFILE_DIR" \
    --output "$RUNTIME/manifests/$run_id/profile_inventory.json" \
    --metric "$HGNN_TORCH_NPU_AIC_METRIC" \
    --expected-ranks 16 \
    --mode "$inventory_mode"
  printf 'RUN_OUTPUT=%s\n' "$output"
}
