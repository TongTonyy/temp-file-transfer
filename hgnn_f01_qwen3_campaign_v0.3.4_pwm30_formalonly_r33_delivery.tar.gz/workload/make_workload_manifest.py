#!/usr/bin/env python3
"""Create one run-specific shell-free ExternalWorkloadLifecycle manifest."""

from __future__ import annotations

import argparse
import csv
import json
import os
from pathlib import Path

PACKAGE_NAME = "hgnn_f01_qwen3_campaign_v0.3.4"
DEFAULT_EXPECTED_NPU_IDS = list(range(16))
ENV_ALLOWLIST = [
    "PATH", "PYTHONPATH", "LD_LIBRARY_PATH", "HOME", "USER", "LOGNAME",
    "SHELL", "LANG", "LC_ALL", "CONDA_EXE", "HGNN_CONDA_EXE",
    "HGNN_PYTHON", "HGNN_RUN_ID", "ASCEND_HOME_PATH",
    "ASCEND_TOOLKIT_HOME", "ASCEND_OPP_PATH", "ASCEND_AICPU_PATH",
    "HGNN_MSPROF_BIN", "HGNN_TRAINING_READY_MARKER",
    "HGNN_TORCH_NPU_PROFILE_DIR",
    "HGNN_PROFILE_CONTROL_PATH", "HGNN_TORCH_NPU_AIC_METRIC",
    "HCCL_CONNECT_TIMEOUT", "HCCL_EXEC_TIMEOUT", "HCCL_IF_BASE_PORT",
    "HCCL_NPU_SOCKET_PORT_RANGE",
    "PYTORCH_NPU_ALLOC_CONF", "CUDA_DEVICE_MAX_CONNECTIONS",
    "ASCEND_RT_VISIBLE_DEVICES", "ASCEND_VISIBLE_DEVICES",
    "HGNN_EXPECTED_NPU_IDS", "HGNN_EXPECTED_PROFILE_RANKS",
    "HGNN_ASCEND_RT_VISIBLE_DEVICES", "HGNN_NPUS_PER_NODE", "HGNN_TP", "HGNN_PP",
]


def expected_npu_ids() -> list[int]:
    raw = os.environ.get("HGNN_EXPECTED_NPU_IDS")
    if not raw:
        return DEFAULT_EXPECTED_NPU_IDS
    values: list[int] = []
    for item in raw.split(","):
        item = item.strip()
        if not item:
            continue
        if not item.isdigit():
            raise SystemExit("HGNN_EXPECTED_NPU_IDS must be comma-separated integers")
        values.append(int(item))
    if not values or len(set(values)) != len(values):
        raise SystemExit("HGNN_EXPECTED_NPU_IDS must be non-empty and unique")
    return values


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", type=Path, required=True)
    parser.add_argument("--run-id", required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    root = args.root.resolve(strict=True)
    expected_root = Path("/root/hgnn_910c_readiness") / PACKAGE_NAME
    if root != expected_root:
        raise SystemExit(f"root must be {expected_root}")
    runtime = root / "runtime"
    output = args.output.resolve(strict=False)
    if not output.is_relative_to(runtime):
        raise SystemExit("manifest output must stay under runtime")
    if not args.run_id or any(
        not (character.isalnum() or character in "_.-")
        for character in args.run_id
    ):
        raise SystemExit("invalid run-id")
    trace_root = runtime / "profiles" / args.run_id
    trace_root.mkdir(parents=True, exist_ok=True)
    payload = {
        "schema_version": "1.0",
        "run_id": args.run_id,
        "executable": "/usr/bin/bash",
        "argv": [str(root / "workload/run_torch_npu_training.sh")],
        "cwd": str(root),
        "env_allowlist": ENV_ALLOWLIST,
        "expected_npu_ids": expected_npu_ids(),
        "trace_output_root": str(trace_root),
        "stop_timings": {
            "sigint_timeout_s": 180,
            "sigterm_timeout_s": 60,
            "sigkill_timeout_s": 15,
            "trace_flush_timeout_s": 300,
            "trace_poll_interval_s": 2,
        },
    }
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(
        json.dumps(payload, indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )
    output.chmod(0o600)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
