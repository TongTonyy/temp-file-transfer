# full83 PWM30 formal-only combined 六组采集执行说明

## 本版本做什么

- 固化全局硬件拓扑：`config/hardware_topology.global.yaml`。
- 采集计划为 6 组：1 组 `manual_baseline_sham` 对照 + 5 组 PWM30 注入。
- 每个 run 不再拆分 `MemoryAccess` 与 `ResourceConflictRatio` 两类 run。
- 同一个 run 内保留 full83/BMC/NPU/HBM 时序，并用 torch_npu profiler 采集 `ResourceConflictRatio`；HBM 温度、带宽、容量和硬件内存类指标来自 full83 collector 与 msprof system hardware memory。
- 本版本禁用 test mode；`full` 和 `resume` 都按 formal 参数运行。
- 训练保持 `TP=4, PP=2`，并改为 8 rank：`NPUS_PER_NODE=8, TP=4, PP=2`，默认 logical NPU ids 为 `0,1,2,3,4,5,6,7`。
- 监测对象仍是全部 NPU/CPU；训练只使用上述 8 个 logical NPU。

## 全局抽屉映射

| drawer | role | fan ids | compute ids | logical NPU ids |
|---|---|---|---|---|
| drawer0 | NPU drawer | 1,2,3,4,13 | NPU card 3,4,7,8 | 4,5,6,7,12,13,14,15 |
| drawer1 | CPU drawer | 5,6,7,8,14 | CPU 1,2,3,4 | 无 |
| drawer2 | NPU drawer | 9,10,11,12,15 | NPU card 1,2,5,6 | 0,1,2,3,8,9,10,11 |

四卡训练默认使用 physical NPU card `1,2,3,4`，即 logical NPU id `0..7`：drawer2 取 card 1/2，drawer0 取 card 3/4，避开 physical card 5/logical id 8-9。

## 六组采集计划

| group key | condition | 注入对象 |
|---|---|---|
| pwm30_control_combined | manual_baseline_sham | 无故障，所有风扇保持 PWM80 |
| pwm30_drawer0_combined | drawer0_pwm30 | drawer0 风扇 PWM30，其余 PWM80 |
| pwm30_drawer1_cpu_combined | drawer1_pwm30 | drawer1 CPU 抽屉风扇 PWM30，其余 PWM80 |
| pwm30_drawer2_combined | drawer2_pwm30 | drawer2 风扇 PWM30，其余 PWM80 |
| pwm30_two_npu_drawers_combined | drawer0_drawer2_pwm30 | drawer0+drawer2 风扇 PWM30，drawer1 PWM80 |
| pwm30_all_drawers_combined | all_drawers_pwm30 | drawer0+drawer1+drawer2 全部风扇 PWM30 |

## 910C 安装

```bash
cd /root/hgnn_910c_readiness
rm -rf /root/hgnn_910c_readiness/temp-file-transfer
GIT_TERMINAL_PROMPT=0 timeout 900 git -c http.version=HTTP/1.1 clone --progress --depth 1 --single-branch --no-tags --filter=blob:none --sparse -b main https://github.com/TongTonyy/temp-file-transfer.git /root/hgnn_910c_readiness/temp-file-transfer
cd /root/hgnn_910c_readiness/temp-file-transfer
git sparse-checkout init --no-cone
git sparse-checkout set hgnn_f01_qwen3_campaign_v0.3.4_pwm30_formalonly_r33_delivery.tar.gz hgnn_f01_qwen3_campaign_v0.3.4_pwm30_formalonly_r33_delivery.tar.gz.sha256
cp hgnn_f01_qwen3_campaign_v0.3.4_pwm30_formalonly_r33_delivery.tar.gz* /root/hgnn_910c_readiness/hgnn_f01_qwen3_campaign_v0.3.4/
cd /root/hgnn_910c_readiness/hgnn_f01_qwen3_campaign_v0.3.4
sha256sum -c hgnn_f01_qwen3_campaign_v0.3.4_pwm30_formalonly_r33_delivery.tar.gz.sha256
tar -xzf hgnn_f01_qwen3_campaign_v0.3.4_pwm30_formalonly_r33_delivery.tar.gz
sha256sum -c r33_pwm30_formalonly_SHA256SUMS
chmod 755 tools/offline/full83_910c/run_full83_pwm30_combined_910c_collection.sh tools/offline/full83_910c/run_full83_910c_collection.sh
```

## Test Mode

本版本禁用 test mode，避免误把短时测试数据当作 formal 数据。

## 正式采集

```bash
cd /root/hgnn_910c_readiness/hgnn_f01_qwen3_campaign_v0.3.4
export HGNN_CAMPAIGN_ROOT_APPROVAL=I_ACKNOWLEDGE_HARDENED_ROOT_EXECUTION
export FULL83_CAMPAIGN_ID="$(date -u +%Y%m%dT%H%M%SZ)-full83-pwm30-formal-r33"
setsid nohup bash tools/offline/full83_910c/run_full83_pwm30_combined_910c_collection.sh full \
  > "runtime/logs/${FULL83_CAMPAIGN_ID}.nohup.log" 2>&1 < /dev/null &
echo "PID=$!"
echo "CAMPAIGN_ID=$FULL83_CAMPAIGN_ID"
```

## 断开终端后查询进度

```bash
cd /root/hgnn_910c_readiness/hgnn_f01_qwen3_campaign_v0.3.4
export FULL83_CAMPAIGN_ID="<上面打印的CAMPAIGN_ID>"
bash tools/offline/full83_910c/run_full83_pwm30_combined_910c_collection.sh status
pgrep -af "$FULL83_CAMPAIGN_ID|run_full83|run_hsh_f01_active.py|full83_monitor.py|torchrun|posttrain_gpt|msprof" || true
ls -lh runtime/logs/*"${FULL83_CAMPAIGN_ID}"* 2>/dev/null || true
```

