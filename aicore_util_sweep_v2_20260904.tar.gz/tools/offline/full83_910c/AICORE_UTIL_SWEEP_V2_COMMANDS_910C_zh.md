# AICore 高占用训练配置 V2 短测命令

## 目标

在上一轮最优配置 `mbs2_seq2048_gbs16` 基础上继续提高训练计算强度，目标是寻找更接近 AICore 平均值 90% 以上、持续高位的正常模型训练负载。

本测试仍然使用 Qwen3 正常训练入口，不插入无效张量计算，不做风扇故障注入。

默认配置：

```text
mbs2_seq2048_gbs32
mbs3_seq2048_gbs24
mbs4_seq2048_gbs32
mbs2_seq3072_gbs24
mbs2_seq2048_gbs32_padded
```

其中 `mbs2_seq2048_gbs32_padded` 会移除 `--no-pad-to-seq-lengths`，用于判断更饱满的序列计算是否能显著提高 AICore。

## 1. 在 910C 拉取并覆盖脚本

前提：你已经把 `aicore_util_sweep_v2_20260904.tar.gz` 和 `.sha256` 上传到 `TongTonyy/temp-file-transfer` 仓库根目录。

```bash
cd /root/hgnn_910c_readiness

rm -rf /root/hgnn_910c_readiness/temp-file-transfer

GIT_TERMINAL_PROMPT=0 timeout 900 git -c http.version=HTTP/1.1 \
  clone --progress --depth 1 --single-branch --no-tags --filter=blob:none --sparse \
  -b main https://github.com/TongTonyy/temp-file-transfer.git \
  /root/hgnn_910c_readiness/temp-file-transfer

cd /root/hgnn_910c_readiness/temp-file-transfer
git sparse-checkout init --no-cone
git sparse-checkout set \
  aicore_util_sweep_v2_20260904.tar.gz \
  aicore_util_sweep_v2_20260904.tar.gz.sha256

command cp -f \
  aicore_util_sweep_v2_20260904.tar.gz \
  aicore_util_sweep_v2_20260904.tar.gz.sha256 \
  /root/hgnn_910c_readiness/hgnn_f01_qwen3_campaign_v0.3.4/

cd /root/hgnn_910c_readiness/hgnn_f01_qwen3_campaign_v0.3.4
sha256sum -c aicore_util_sweep_v2_20260904.tar.gz.sha256
tar -xzf aicore_util_sweep_v2_20260904.tar.gz

chmod +x \
  tools/offline/full83_910c/run_aicore_util_sweep_910c.sh \
  tools/offline/full83_910c/run_aicore_util_sweep_v2_910c.sh \
  workload/aicore_util_sampler.py \
  workload/aicore_sweep_summarize.py \
  workload/reference/tune_qwen3_14b_4K_full_ptd.sh
```

## 2. 执行 V2 默认短测

```bash
cd /root/hgnn_910c_readiness/hgnn_f01_qwen3_campaign_v0.3.4

bash tools/offline/full83_910c/run_aicore_util_sweep_v2_910c.sh
```

## 3. 快速缩短测试

如果只想先摸底，可以把每组 iteration 降到 40：

```bash
cd /root/hgnn_910c_readiness/hgnn_f01_qwen3_campaign_v0.3.4

export AICORE_SWEEP_TRAIN_ITERS=40
bash tools/offline/full83_910c/run_aicore_util_sweep_v2_910c.sh
```

## 4. 输出位置

脚本结束时会打印：

```text
AICORE_SWEEP_SUMMARY=runtime/outputs/aicore_sweep/<sweep_id>/aicore_sweep_summary.csv
```

主要文件：

```text
runtime/outputs/aicore_sweep/<sweep_id>/aicore_sweep_summary.csv
runtime/outputs/aicore_sweep/<sweep_id>/<config_label>/aicore_timeseries.csv
runtime/outputs/aicore_sweep/<sweep_id>/<config_label>/aicore_summary.json
runtime/outputs/aicore_sweep/<sweep_id>/<config_label>/training.log
```

优先选择：

- 稳定阶段 AICore mean 高
- AICore >=90% 样本占比高
- step time 稳定
- HBM 不接近 OOM
- 温度不接近 hard stop
