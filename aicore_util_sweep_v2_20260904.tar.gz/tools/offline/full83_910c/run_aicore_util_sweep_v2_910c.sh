#!/usr/bin/env bash
set -Eeuo pipefail
umask 077

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd -P)"

export AICORE_SWEEP_ID="${AICORE_SWEEP_ID:-$(date -u +%Y%m%dT%H%M%SZ)-aicore-util-sweep-v2}"
export AICORE_SWEEP_TRAIN_ITERS="${AICORE_SWEEP_TRAIN_ITERS:-80}"

# Format: label:micro_batch_size:seq_length:global_batch_size:no_pad_to_seq_lengths
# no_pad_to_seq_lengths=1 keeps the original no-pad SFT behavior.
# no_pad_to_seq_lengths=0 removes --no-pad-to-seq-lengths for one padded comparison.
export AICORE_SWEEP_CONFIGS="${AICORE_SWEEP_CONFIGS:-mbs2_seq2048_gbs32:2:2048:32:1 mbs3_seq2048_gbs24:3:2048:24:1 mbs4_seq2048_gbs32:4:2048:32:1 mbs2_seq3072_gbs24:2:3072:24:1 mbs2_seq2048_gbs32_padded:2:2048:32:0}"

exec "$SCRIPT_DIR/run_aicore_util_sweep_910c.sh"
