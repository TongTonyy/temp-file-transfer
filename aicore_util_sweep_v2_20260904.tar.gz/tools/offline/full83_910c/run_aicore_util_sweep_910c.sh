#!/usr/bin/env bash
set -Eeuo pipefail
umask 077

PACKAGE_NAME="hgnn_f01_qwen3_campaign_v0.3.4"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd -P)"
REPO_ROOT="$(cd "$SCRIPT_DIR/../../.." && pwd -P)"
if [[ -n "${HGNN_ROOT:-}" ]]; then
  ROOT="$HGNN_ROOT"
elif [[ -d "$REPO_ROOT/campaigns/$PACKAGE_NAME/workload" ]]; then
  ROOT="$REPO_ROOT/campaigns/$PACKAGE_NAME"
elif [[ -d "$PWD/workload" && -d "$PWD/app" ]]; then
  ROOT="$(pwd -P)"
else
  ROOT="/root/hgnn_910c_readiness/$PACKAGE_NAME"
fi
ROOT="$(cd "$ROOT" && pwd -P)"
cd "$ROOT"
export HGNN_CAMPAIGN_ROOT_OVERRIDE="$ROOT"

# shellcheck disable=SC1091
. "$ROOT/workload/common.sh"
workload_init

ASCEND_ENV=""
for candidate in /usr/local/Ascend/ascend-toolkit/set_env.sh /usr/local/Ascend/ascend-toolkit/latest/set_env.sh; do
  [[ -f "$candidate" ]] && { ASCEND_ENV="$candidate"; break; }
done
[[ -n "$ASCEND_ENV" ]] || { echo "未找到Ascend环境脚本" >&2; exit 2; }
set +u
# shellcheck disable=SC1090
source "$ASCEND_ENV"
set -u

SWEEP_ID="${AICORE_SWEEP_ID:-$(date -u +%Y%m%dT%H%M%SZ)-aicore-util-sweep}"
OUTPUT_ROOT="$RUNTIME/outputs/aicore_sweep/$SWEEP_ID"
mkdir -p "$OUTPUT_ROOT" "$RUNTIME/manifests" "$RUNTIME/profiles" "$RUNTIME/logs"

export HGNN_NPUS_PER_NODE="${HGNN_NPUS_PER_NODE:-8}"
export HGNN_TP="${HGNN_TP:-4}"
export HGNN_PP="${HGNN_PP:-2}"
export HGNN_ASCEND_RT_VISIBLE_DEVICES="${HGNN_ASCEND_RT_VISIBLE_DEVICES:-0,1,2,3,4,5,6,7}"
export HGNN_EXPECTED_PROFILE_RANKS="${HGNN_EXPECTED_PROFILE_RANKS:-8}"
export HGNN_TORCH_NPU_AIC_METRIC="${HGNN_TORCH_NPU_AIC_METRIC:-ResourceConflictRatio}"
export AICORE_SWEEP_TRAIN_ITERS="${AICORE_SWEEP_TRAIN_ITERS:-80}"
export AICORE_SWEEP_SAMPLE_INTERVAL_S="${AICORE_SWEEP_SAMPLE_INTERVAL_S:-2}"
export AICORE_SWEEP_WARMUP_S="${AICORE_SWEEP_WARMUP_S:-60}"

DEFAULT_CONFIGS=(
  "mbs1_seq2048_gbs16:1:2048:16:1"
  "mbs2_seq2048_gbs16:2:2048:16:1"
  "mbs1_seq4096_gbs16:1:4096:16:1"
  "mbs2_seq4096_gbs16:2:4096:16:1"
)

if [[ -n "${AICORE_SWEEP_CONFIGS:-}" ]]; then
  IFS=' ' read -r -a CONFIGS <<< "$AICORE_SWEEP_CONFIGS"
else
  CONFIGS=("${DEFAULT_CONFIGS[@]}")
fi

echo "AICORE_SWEEP_ID=$SWEEP_ID"
echo "AICORE_SWEEP_OUTPUT_ROOT=$OUTPUT_ROOT"
echo "AICORE_SWEEP_CONFIG_COUNT=${#CONFIGS[@]}"
echo "AICORE_SWEEP_VISIBLE_DEVICES=$HGNN_ASCEND_RT_VISIBLE_DEVICES"
echo "AICORE_SWEEP_TP=$HGNN_TP"
echo "AICORE_SWEEP_PP=$HGNN_PP"
echo "AICORE_SWEEP_TRAIN_ITERS=$AICORE_SWEEP_TRAIN_ITERS"

index=0
for config in "${CONFIGS[@]}"; do
  index=$((index + 1))
  IFS=':' read -r label mbs seq_len gbs no_pad <<< "$config"
  no_pad="${no_pad:-1}"
  if [[ -z "$label" || -z "$mbs" || -z "$seq_len" || -z "$gbs" ]]; then
    echo "跳过非法配置: $config" >&2
    continue
  fi

  RUN_ID="${SWEEP_ID}-${index}-${label}"
  RUN_DIR="$OUTPUT_ROOT/$label"
  STOP_FILE="$RUN_DIR/sampler.stop"
  mkdir -p "$RUN_DIR" "$RUNTIME/manifests/$RUN_ID" "$RUNTIME/profiles/$RUN_ID"
  rm -f "$STOP_FILE" "$RUNTIME/manifests/$RUN_ID/training_ready.json"

  export HGNN_RUN_ID="$RUN_ID"
  export HGNN_TRAINING_READY_MARKER="$RUNTIME/manifests/$RUN_ID/training_ready.json"
  export HGNN_TORCH_NPU_PROFILE_DIR="$RUNTIME/profiles/$RUN_ID"
  export HGNN_PROFILE_CONTROL_PATH="$RUNTIME/manifests/$RUN_ID/profile_control.json"
  export HGNN_MBS="$mbs"
  export HGNN_GBS="$gbs"
  export HGNN_SEQ_LENGTH="$seq_len"
  export HGNN_TRAIN_ITERS="$AICORE_SWEEP_TRAIN_ITERS"
  export HGNN_MASTER_PORT="$((6215 + index))"
  export HGNN_NO_PAD_TO_SEQ_LENGTHS="$no_pad"

  "$HGNN_PYTHON" - "$RUN_ID" "$HGNN_PROFILE_CONTROL_PATH" "$RUN_DIR/config.json" "$label" "$mbs" "$seq_len" "$gbs" "$AICORE_SWEEP_TRAIN_ITERS" "$no_pad" <<'PY'
import json
import sys
from pathlib import Path

run_id, control_path, config_path, label, mbs, seq_len, gbs, train_iters, no_pad = sys.argv[1:]
Path(control_path).write_text(
    json.dumps({"run_id": run_id, "commands": []}, indent=2, sort_keys=True) + "\n",
    encoding="utf-8",
)
Path(config_path).write_text(
    json.dumps(
        {
            "run_id": run_id,
            "label": label,
            "micro_batch_size": int(mbs),
            "seq_length": int(seq_len),
            "global_batch_size": int(gbs),
            "train_iters": int(train_iters),
            "no_pad_to_seq_lengths": int(no_pad),
            "status": "running",
            "rc": None,
        },
        indent=2,
        sort_keys=True,
    ) + "\n",
    encoding="utf-8",
)
PY

  echo "============================================================"
  echo "AICORE_SWEEP_CONFIG=${index}/${#CONFIGS[@]} label=$label mbs=$mbs seq=$seq_len gbs=$gbs no_pad=$no_pad run_id=$RUN_ID"
  echo "============================================================"

  "$HGNN_PYTHON" "$ROOT/workload/aicore_util_sampler.py" \
    --output-csv "$RUN_DIR/aicore_timeseries.csv" \
    --summary-json "$RUN_DIR/aicore_summary.json" \
    --stop-file "$STOP_FILE" \
    --interval-s "$AICORE_SWEEP_SAMPLE_INTERVAL_S" \
    --max-duration-s 900 \
    --warmup-s "$AICORE_SWEEP_WARMUP_S" &
  sampler_pid=$!

  set +e
  bash "$ROOT/workload/launch_training.sh" > "$RUN_DIR/training.log" 2>&1
  rc=$?
  set -e

  touch "$STOP_FILE"
  wait "$sampler_pid" 2>/dev/null || true

  "$HGNN_PYTHON" - "$RUN_DIR/config.json" "$rc" <<'PY'
import json
import sys
from pathlib import Path

path = Path(sys.argv[1])
rc = int(sys.argv[2])
payload = json.loads(path.read_text(encoding="utf-8"))
payload["rc"] = rc
payload["status"] = "complete" if rc == 0 else "failed"
path.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")
PY

  echo "AICORE_SWEEP_CONFIG_COMPLETE label=$label rc=$rc output=$RUN_DIR"
done

"$HGNN_PYTHON" "$ROOT/workload/aicore_sweep_summarize.py" \
  --sweep-root "$OUTPUT_ROOT" \
  --output-csv "$OUTPUT_ROOT/aicore_sweep_summary.csv" \
  --warmup-steps 10

echo "AICORE_SWEEP_COMPLETE=1"
echo "AICORE_SWEEP_SUMMARY=$OUTPUT_ROOT/aicore_sweep_summary.csv"
