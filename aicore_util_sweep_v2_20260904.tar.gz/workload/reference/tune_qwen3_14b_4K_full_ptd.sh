#!/bin/bash
set -Eeo pipefail

export HCCL_CONNECT_TIMEOUT=3600
export HCCL_EXEC_TIMEOUT=3600

export CUDA_DEVICE_MAX_CONNECTIONS=1
export PYTORCH_NPU_ALLOC_CONF=expandable_segments:True
: "${HGNN_TORCH_NPU_PROFILE_DIR:?HGNN_TORCH_NPU_PROFILE_DIR 未设置}"
: "${HGNN_PROFILE_CONTROL_PATH:?HGNN_PROFILE_CONTROL_PATH 未设置}"
: "${HGNN_TORCH_NPU_AIC_METRIC:?HGNN_TORCH_NPU_AIC_METRIC 未设置}"

# Change for multinode config
NPUS_PER_NODE="${HGNN_NPUS_PER_NODE:-16}"
MASTER_ADDR=localhost
MASTER_PORT="${HGNN_MASTER_PORT:-6015}"
NNODES=1
NODE_RANK=0
WORLD_SIZE=$(($NPUS_PER_NODE*$NNODES))
if [[ -n "${HGNN_ASCEND_RT_VISIBLE_DEVICES:-}" ]]; then
    export ASCEND_RT_VISIBLE_DEVICES="$HGNN_ASCEND_RT_VISIBLE_DEVICES"
    export ASCEND_VISIBLE_DEVICES="$HGNN_ASCEND_RT_VISIBLE_DEVICES"
fi

# please fill these path configurations
CKPT_LOAD_DIR="./model_from_hf/qwen3-14b-hf/megatron_cache_tp4pp2ep1"
CKPT_SAVE_DIR="./ckpt/qwen3-14b/"
DATA_PATH="./finetune_dataset/alpaca"
TOKENIZER_PATH="./model_from_hf/qwen3-14b-hf/"

TP="${HGNN_TP:-4}"
PP="${HGNN_PP:-2}"
MBS="${HGNN_MBS:-1}"
GBS="${HGNN_GBS:-16}"
SEQ_LENGTH="${HGNN_SEQ_LENGTH:-2048}"
TRAIN_ITERS="${HGNN_TRAIN_ITERS:-100000}"

DISTRIBUTED_ARGS="
    --nproc_per_node $NPUS_PER_NODE \
    --nnodes $NNODES \
    --node_rank $NODE_RANK \
    --master_addr $MASTER_ADDR \
    --master_port $MASTER_PORT
"

GPT_ARGS="
    --use-mcore-models \
    --tensor-model-parallel-size ${TP} \
    --pipeline-model-parallel-size ${PP} \
    --spec mindspeed_llm.tasks.models.spec.qwen3_spec layer_spec \
    --kv-channels 128 \
    --qk-layernorm \
    --num-layers 40 \
    --hidden-size 5120 \
    --use-rotary-position-embeddings \
    --untie-embeddings-and-output-weights \
    --num-attention-heads 40 \
    --ffn-hidden-size 17408 \
    --max-position-embeddings 40960 \
    --seq-length ${SEQ_LENGTH} \
    --train-iters ${TRAIN_ITERS} \
    --micro-batch-size ${MBS} \
    --global-batch-size ${GBS} \
    --make-vocab-size-divisible-by 1 \
    --use-flash-attn \
    --padded-vocab-size 151936 \
    --rotary-base 1000000 \
    --disable-bias-linear \
    --swiglu \
    --tokenizer-type PretrainedFromHF \
    --tokenizer-name-or-path ${TOKENIZER_PATH} \
    --normalization RMSNorm \
    --position-embedding-type rope \
    --norm-epsilon 1e-6 \
    --hidden-dropout 0 \
    --attention-dropout 0 \
    --no-gradient-accumulation-fusion \
    --attention-softmax-in-fp32 \
    --exit-on-missing-checkpoint \
    --no-masked-softmax-fusion \
    --group-query-attention \
    --num-query-groups 8 \
    --seed 42 \
    --bf16 \
    --min-lr 1.25e-7 \
    --weight-decay 1e-1 \
    --lr-warmup-fraction 0.01 \
    --clip-grad 1.0 \
    --adam-beta1 0.9 \
    --adam-beta2 0.95 \
    --no-load-optim \
    --no-load-rng \
    --lr 1.25e-6 \
    --sequence-parallel \
    --ckpt-format torch
"

DATA_ARGS="
    --data-path $DATA_PATH \
    --handler-name AlpacaStyleInstructionHandler \
    --split 100,0,0
"

OUTPUT_ARGS="
    --log-interval 1 \
    --save-interval ${TRAIN_ITERS} \
    --eval-interval ${TRAIN_ITERS} \
    --eval-iters 0 \
    --log-throughput
"

PROFILE_ARGS="
    --profile \
    --profile-ranks -1 \
    --profile-level level1 \
    --profile-export-type text \
    --profile-data-simplification \
    --profile-save-path ${HGNN_TORCH_NPU_PROFILE_DIR}
"

NO_PAD_ARG=""
if [[ "${HGNN_NO_PAD_TO_SEQ_LENGTHS:-1}" == "1" ]]; then
    NO_PAD_ARG="--no-pad-to-seq-lengths"
fi

TUNE_ARGS="
    --finetune \
    --stage sft \
    --is-instruction-dataset \
    --prompt-type qwen3 \
    ${NO_PAD_ARG}
"

torchrun $DISTRIBUTED_ARGS posttrain_gpt.py \
    $GPT_ARGS \
    $DATA_ARGS \
    $OUTPUT_ARGS \
    $PROFILE_ARGS \
    $TUNE_ARGS \
    $CKPT_ARGS \
    --distributed-backend nccl \
    --load ${CKPT_LOAD_DIR} \
    --save ${CKPT_SAVE_DIR} \
    --transformer-impl local \
    2>&1 | python ./workload/mark_training_ready.py \
      --log ./logs/tune_qwen3_14b_full.log
