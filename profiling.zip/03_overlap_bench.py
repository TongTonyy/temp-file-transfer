# 03_overlap_bench.py — 计算-通信并发互相拖慢系数（昇腾版 "Galvatron 1.3x"）
# 目的：标定 overlap 减速系数 = (并发时计算耗时 / 独占时计算耗时)
# 用法：torchrun --nproc_per_node=2 03_overlap_bench.py
import os
import csv
import torch
import torch.distributed as dist
import torch_npu  # noqa: F401

WARMUP, REPEAT = 5, 20
TOKENS, IN_F, OUT_F = 4096 * 4, 5120, 5120 * 3  # 典型 qkv shape, b=4
COMM_MB = 256

def timed(fn):
    for _ in range(WARMUP):
        fn()
    torch.npu.synchronize()
    s, e = torch.npu.Event(True), torch.npu.Event(True)
    s.record()
    for _ in range(REPEAT):
        fn()
    e.record(); torch.npu.synchronize()
    return s.elapsed_time(e) / REPEAT

def main():
    dist.init_process_group(backend="hccl")
    rank = dist.get_rank()
    torch.npu.set_device(rank)
    dev = f"npu:{rank}"

    lin = torch.nn.Linear(IN_F, OUT_F, bias=False).to(dev).to(torch.bfloat16)
    x = torch.randn(TOKENS, IN_F, device=dev, dtype=torch.bfloat16, requires_grad=True)
    cbuf = torch.randn(COMM_MB * 1024 * 1024 // 2, device=dev, dtype=torch.bfloat16)

    def compute():
        y = lin(x); y.sum().backward(); x.grad = None

    def comm():
        dist.all_reduce(cbuf)

    t_comp_alone = timed(compute)
    t_comm_alone = timed(comm)

    # 并发：通信放侧流，与计算并发
    side = torch.npu.Stream()
    def overlapped():
        with torch.npu.stream(side):
            comm()
        compute()
        torch.npu.current_stream().wait_stream(side)

    t_overlap = timed(overlapped)
    serial = t_comp_alone + t_comm_alone
    # slowdown 定义：并发时总耗时 / max(计算, 通信) 的"理想掩盖"之比
    ideal = max(t_comp_alone, t_comm_alone)
    slowdown = t_overlap / ideal
    hidden_ratio = (serial - t_overlap) / serial

    if rank == 0:
        rows = [
            ["t_comp_alone_ms", round(t_comp_alone, 4)],
            ["t_comm_alone_ms", round(t_comm_alone, 4)],
            ["t_overlap_ms", round(t_overlap, 4)],
            ["slowdown_vs_ideal", round(slowdown, 4)],
            ["comm_hidden_ratio", round(hidden_ratio, 4)],
        ]
        os.makedirs("profiling_out", exist_ok=True)
        with open("profiling_out/overlap.csv", "w", newline="") as f:
            csv.writer(f).writerows([["metric", "value"]] + rows)
        for r in rows:
            print(r)
    dist.destroy_process_group()

if __name__ == "__main__":
    main()
