#!/bin/bash
# 04_power_sampler.sh — npu-smi 功耗连续采样（伴随真实训练运行）
# 用法：bash 04_power_sampler.sh <输出文件前缀> [采样间隔秒，默认1]
# 例：bash 04_power_sampler.sh run_p2t2d4z2 1 &
PREFIX=${1:-run}
INTERVAL=${2:-1}
OUT=profiling_out/${PREFIX}_power.log
mkdir -p profiling_out
echo "timestamp,chip_id,power_w" > $OUT
while true; do
  TS=$(date +%s.%N)
  # npu-smi info 主表含 Power(W) 列；不同固件列位置可能不同，首次使用请人工核对
  npu-smi info | awk -v ts="$TS" '/W/ && /[0-9]+\.[0-9]/ {print}' >> ${OUT}.raw
  echo "--- $TS ---" >> ${OUT}.raw
  sleep $INTERVAL
done
