# 02_hccl_bench.py — HCCL 集合通信带宽曲线（含 910C 两级拓扑）
# 目的：标定 g（跨卡 HCCS）、g0（同卡双 die 封装内）、q（成员数拥塞衰减）
# 用法：torchrun --nproc_per_node=16 02_hccl_bench.py
import csv
import os
import torch
import torch.distributed as dist
import torch_npu  # noqa: F401

WARMUP, REPEAT = 5, 20
SIZES_MB = [1, 4, 16, 64, 256, 1024]  # 消息大小扫描

def bench_group(group, tag, size_mb, rank):
    n = len(group) if isinstance(group, list) else None
    nbytes = size_mb * 1024 * 1024
    nelem = nbytes // 2  # bf16
    x = torch.randn(nelem, device=f"npu:{rank % 8}", dtype=torch.bfloat16)
    g = dist.new_group(ranks=group) if isinstance(group, list) else None
    res = {}
    for prim in ("all_reduce", "all_gather", "reduce_scatter"):
        try:
            def op():
                if prim == "all_reduce":
                    dist.all_reduce(x, group=g)
                elif prim == "all_gather":
                    out = [torch.empty_like(x) for _ in range(dist.get_group_size(g) if g else 16)]
                    dist.all_gather(out, x, group=g)
                else:
                    chunks = dist.get_group_size(g) if g else 16
                    dist.reduce_scatter(x, [torch.empty_like(x) for _ in range(chunks)], group=g)
            for _ in range(WARMUP):
                op()
            torch.npu.synchronize()
            s_ev, e_ev = torch.npu.Event(True), torch.npu.Event(True)
            s_ev.record()
            for _ in range(REPEAT):
                op()
            e_ev.record(); torch.npu.synchronize()
            ms = s_ev.elapsed_time(e_ev) / REPEAT
            # 有效带宽（algbw）：消息量/时间
            res[prim] = (round(ms, 4), round(nbytes / (ms / 1e3) / 1e9, 2))
        except Exception as e:
            res[prim] = ("ERR", str(e)[:60])
    return res

def main():
    dist.init_process_group(backend="hccl")
    rank = dist.get_rank()
    torch.npu.set_device(rank % 8)
    # 假设 rank 排布：同卡双 die 为相邻 rank（0,1）（2,3）…，需按 00_env_probe 实测修正
    group_specs = {
        "intra_pkg_pair": [0, 1],          # 同卡双 die（Level-0）
        "cross_pkg_pair": [0, 2],          # 跨卡相邻 die（Level-1）
        "cross_pkg_far":  [0, 14],         # 跨卡远端
        "quad_packed":    [0, 1, 2, 3],    # 4 rank 打包进 2 卡
        "quad_spread":    [0, 2, 4, 6],    # 4 rank 摊开 4 卡
        "all16":          list(range(16)),
    }
    rows = []
    for tag, grp in group_specs.items():
        for mb in SIZES_MB:
            r = bench_group(grp, tag, mb, rank)
            if rank == grp[0]:
                for prim, (ms, bw) in r.items():
                    rows.append([prim, tag, len(grp), mb, ms, bw])
                    print(rows[-1], flush=True)
        dist.barrier()
    if rank == 0:
        with open("profiling_out/hccl_bw.csv", "w", newline="") as f:
            w = csv.writer(f)
            w.writerow(["primitive", "group", "n_ranks", "msg_mb", "ms", "algbw_gbps"])
            w.writerows(rows)
    dist.destroy_process_group()

if __name__ == "__main__":
    main()
