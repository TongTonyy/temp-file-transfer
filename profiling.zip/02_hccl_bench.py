# 02_hccl_bench.py v2 — HCCL 集合通信带宽曲线（含 910C 两级拓扑）
# 修复：1) set_device(rank % 8) -> set_device(rank)（本机 16 个逻辑设备）
#       2) dist.get_group_size 不存在 -> 用 len(members)
#       3) 建组为集合操作：所有 rank 开局统一创建；计时仅组内成员参与
# 用法：torchrun --nproc_per_node=16 02_hccl_bench.py
import os
import csv
import torch
import torch.distributed as dist
import torch_npu  # noqa: F401

WARMUP, REPEAT = 5, 20
SIZES_MB = [1, 4, 16, 64, 256, 1024]

# rank 排布假设：同卡双 die = 相邻 rank (0,1)(2,3)...（已获 npu-smi 拓扑支持）
GROUPS = {
    "intra_pkg_pair": [0, 1],            # 同卡双 die（SIO）
    "cross_pkg_pair": [0, 2],            # 跨卡（HCCS_SW）
    "cross_pkg_far":  [0, 14],           # 跨卡远端（验证对称性）
    "quad_packed":    [0, 1, 2, 3],      # 4 rank 打包进 2 卡
    "quad_spread":    [0, 2, 4, 6],      # 4 rank 摊开 4 卡
    "octa_4cards":    [0, 1, 2, 3, 4, 5, 6, 7],   # 8 rank / 4 卡
    "all16":          list(range(16)),   # 整机
}

def run_prim(prim, x, g, n):
    if prim == "all_reduce":
        dist.all_reduce(x, group=g)
    elif prim == "all_gather":
        out = [torch.empty_like(x) for _ in range(n)]
        dist.all_gather(out, x, group=g)
    elif prim == "reduce_scatter":
        out = torch.empty(x.numel() // n, device=x.device, dtype=x.dtype)
        dist.reduce_scatter(out, list(x.chunk(n)), group=g)

def main():
    dist.init_process_group(backend="hccl")
    rank = dist.get_rank()
    torch.npu.set_device(rank)          # 关键修复：16 个逻辑设备一一对应
    dev = torch.device(f"npu:{rank}")

    # 建组是集合操作，全体 rank 必须全部调用
    handles = {tag: dist.new_group(ranks=m) for tag, m in GROUPS.items()}

    rows = []
    for tag, members in GROUPS.items():
        g, n = handles[tag], len(members)
        for mb in SIZES_MB:
            x = torch.randn(mb * 1024 * 1024 // 2, device=dev, dtype=torch.bfloat16)
            for prim in ("all_reduce", "all_gather", "reduce_scatter"):
                if rank in members:
                    try:
                        for _ in range(WARMUP):
                            run_prim(prim, x, g, n)
                        torch.npu.synchronize()
                        s, e = torch.npu.Event(True), torch.npu.Event(True)
                        s.record()
                        for _ in range(REPEAT):
                            run_prim(prim, x, g, n)
                        e.record(); torch.npu.synchronize()
                        ms = s.elapsed_time(e) / REPEAT
                        bw = mb * 1024 * 1024 / (ms / 1e3) / 1e9
                        if rank == members[0]:
                            rows.append([prim, tag, n, mb, round(ms, 4), round(bw, 2)])
                            print(rows[-1], flush=True)
                    except Exception as ex:
                        if rank == members[0]:
                            rows.append([prim, tag, n, mb, "ERR", str(ex)[:60]])
            dist.barrier()   # 组间隔离，避免互相干扰
            del x
            torch.npu.empty_cache()

    if rank == 0:
        os.makedirs("profiling_out", exist_ok=True)
        with open("profiling_out/hccl_bw.csv", "w", newline="") as f:
            w = csv.writer(f)
            w.writerow(["primitive", "group", "n_ranks", "msg_mb", "ms", "algbw_gbps"])
            w.writerows(rows)
        print("done -> profiling_out/hccl_bw.csv")
    dist.destroy_process_group()

if __name__ == "__main__":
    main()
