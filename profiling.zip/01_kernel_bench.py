# 01_kernel_bench.py — Llama2-13B 线性层 kernel 耗时采集（单 rank 可跑）
# 目的：为白盒模型的 T_F 项与 rho(b,s,h,t) 提供实测数据
# 用法：python 01_kernel_bench.py
import os
import csv
import torch
import torch_npu  # noqa: F401

H, FFN, V = 5120, 13824, 32000
S = 4096
WARMUP, REPEAT = 5, 20

def bench_linear(tokens, in_f, out_f, device="npu:0"):
    """返回 (fwd_ms, bwd_ms)。用 Linear 近似训练中的 matmul+反传。"""
    lin = torch.nn.Linear(in_f, out_f, bias=False).to(device).to(torch.bfloat16)
    x = torch.randn(tokens, in_f, device=device, dtype=torch.bfloat16,
                    requires_grad=True)
    # warmup
    for _ in range(WARMUP):
        y = lin(x)
        y.sum().backward()
        x.grad = None
    torch.npu.synchronize()
    # forward
    s_ev, e_ev = torch.npu.Event(True), torch.npu.Event(True)
    s_ev.record()
    for _ in range(REPEAT):
        y = lin(x)
    e_ev.record(); torch.npu.synchronize()
    fwd = s_ev.elapsed_time(e_ev) / REPEAT
    # forward + backward（训练更接近的组合）
    s_ev.record()
    for _ in range(REPEAT):
        y = lin(x)
        y.sum().backward()
        x.grad = None
    e_ev.record(); torch.npu.synchronize()
    fb = s_ev.elapsed_time(e_ev) / REPEAT
    return fwd, fb - fwd  # bwd ≈ fb - fwd

def flops(tokens, in_f, out_f, backward=False):
    base = 2 * tokens * in_f * out_f
    return base * (3 if backward else 1)  # bwd ≈ 2x fwd，合计 3x

rows = []
for t in (1, 2, 4, 8):
    shapes = {
        "qkv":    (H, 3 * H // t),
        "attn_o": (H, H // t),
        "ffn_up": (H, 2 * FFN // t),   # gate+up 合并
        "ffn_dn": (FFN // t, H),
        "vocab":  (H, V // t),         # vocab 输出层（华为论文强调不可忽略）
    }
    for b in (1, 2, 4, 8, 16):
        tokens = b * S
        for name, (fi, fo) in shapes.items():
            try:
                fwd, bwd = bench_linear(tokens, fi, fo)
                tf = flops(tokens, fi, fo, True) / ((fwd + bwd) / 1e3) / 1e12
                rows.append([name, t, b, fi, fo,
                             round(fwd, 4), round(bwd, 4), round(tf, 2)])
                print(rows[-1])
            except RuntimeError as e:
                rows.append([name, t, b, fi, fo, "OOM/ERR", str(e)[:60], ""])
                torch.npu.empty_cache()

os.makedirs("profiling_out", exist_ok=True)
with open("profiling_out/kernel_times.csv", "w", newline="") as f:
    w = csv.writer(f)
    w.writerow(["layer", "tp", "b", "in_f", "out_f",
                "fwd_ms", "bwd_ms", "tflops_total"])
    w.writerows(rows)
print("done -> profiling_out/kernel_times.csv")
