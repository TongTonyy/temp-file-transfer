# AscendTune 910C Profiling 脚本包

> 目标：采集 AscendTune 白盒模型与 trace 回放引擎所需的全部硬件系数。
> 环境：8×Ascend 910C（16 rank），CANN + torch_npu + hccl。
> 注意：本套脚本在**无 NPU 的环境编写，未经真机调试**，首次运行请逐项小步验证。

## 脚本清单

| 脚本 | 采集内容 | 服务的模型成分 | 预计耗时 |
|---|---|---|---|
| `00_env_probe.sh` | 环境指纹：npu-smi 设备数/显存、CANN/torch_npu 版本 | 环境确认（文档 v3.0 §1.2） | 1 分钟 |
| `01_kernel_bench.py` | Llama2-13B 全部线性层 shape 的前向+反向耗时（× t 切分 × b 档） | ρ(b,s,h,t)、T_F | 1–2 小时 |
| `02_hccl_bench.py` | HCCL all-reduce/all-gather/reduce-scatter 带宽-消息大小曲线，含**两级拓扑**（岛内 die 对 vs 跨卡组） | g、g₂、q、L5 剪枝依据 | 1–2 小时 |
| `03_overlap_bench.py` | 计算-通信并发时的互相拖慢系数 | overlap 系数（对标 Galvatron 的 1.3×） | 30 分钟 |
| `04_power_sampler.sh` | npu-smi 功耗连续采样 | 能耗目标（tokens/J） | 伴随训练运行 |

## 建议执行顺序

```bash
bash 00_env_probe.sh                 # 1. 先确认 16 rank × 64GB
python 01_kernel_bench.py            # 2. 单卡即可，先跑
torchrun --nproc_per_node=16 02_hccl_bench.py   # 3. 需要 16 rank
torchrun --nproc_per_node=2 03_overlap_bench.py # 4. 双 rank 即可
# 04 在后续真实训练时伴随运行
```

## 产出物（拷回本地）

```
profiling_out/
  env_probe.txt            # 环境指纹
  kernel_times.csv         # shape, fwd_ms, bwd_ms, tflops_achieved
  hccl_bw.csv              # primitive, group_spec, msg_bytes, ms, gbps
  overlap.csv              # serial_ms, overlapped_ms, slowdown
  power_*.log              # 功耗时间序列（后续训练时产生）
```
