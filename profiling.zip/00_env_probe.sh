#!/bin/bash
# 00_env_probe.sh — 环境指纹采集
# 目的：确认 910C 双 die 呈现方式（应见 16 个设备）、每 rank 显存、软件版本
# 用法：bash 00_env_probe.sh
set -x
mkdir -p profiling_out
OUT=profiling_out/env_probe.txt
{
  echo "===== date ====="; date
  echo "===== npu-smi info ====="; npu-smi info
  echo "===== npu-smi info -l (phy/logi id 映射) ====="; npu-smi info -l
  echo "===== HBM 明细（逐个 chip） ====="
  for i in $(seq 0 15); do npu-smi info -t memory -i $i 2>/dev/null; done
  echo "===== 版本 ====="
  python -c "import torch; print('torch', torch.__version__)"
  python -c "import torch_npu; print('torch_npu', torch_npu.__version__)"
  cat /usr/local/Ascend/ascend-toolkit/latest/version.cfg 2>/dev/null || \
    cat /usr/local/Ascend/*/latest/version.cfg 2>/dev/null
  echo "===== 拓扑（如工具存在） ====="
  npu-smi info -t topo 2>/dev/null || true
} > $OUT 2>&1
echo "written to $OUT"
