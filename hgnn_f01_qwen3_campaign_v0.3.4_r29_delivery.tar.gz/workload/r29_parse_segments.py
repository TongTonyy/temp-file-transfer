#!/usr/bin/env python3
"""CANN export for r29 sampled profiler segments."""

from __future__ import annotations

import argparse
import json
import time
from concurrent.futures import Future, ThreadPoolExecutor, as_completed
from pathlib import Path
from typing import Any, Mapping, Sequence

from r27_parse_sessions import csv_inventory, find_prof_dir, run_msprof_export
from torch_npu_offline_common import SESSION_RE, atomic_json, load_json

EXPECTED_RANKS = 16


def _summarize_outputs(outputs: Sequence[Mapping[str, Any]]) -> Mapping[str, Any]:
    return {
        "csv_count": len(outputs),
        "csv_bytes": sum(int(row.get("size_bytes", 0)) for row in outputs),
        "csv_sha256": [str(row.get("sha256", "")) for row in outputs],
    }


def discover_segment_sessions(
    profile_root: Path,
    metric: str,
    segment_id: str,
) -> dict[int, Path]:
    segment_root = profile_root.resolve(strict=True) / metric / segment_id
    if not segment_root.is_dir() or segment_root.is_symlink():
        raise SystemExit(f"missing segment profile root: {segment_root}")
    sessions: dict[int, Path] = {}
    for path in sorted(segment_root.iterdir()):
        match = SESSION_RE.fullmatch(path.name)
        if match is None or not path.is_dir() or path.is_symlink():
            continue
        rank = int(match.group(1))
        if rank in sessions:
            raise SystemExit(f"duplicate session for rank {rank} in {segment_id}")
        sessions[rank] = path.resolve(strict=True)
    if set(sessions) != set(range(EXPECTED_RANKS)):
        missing = sorted(set(range(EXPECTED_RANKS)) - set(sessions))
        raise SystemExit(f"{segment_id}: missing rank sessions: {missing}")
    return sessions


def parse_rank_segment(
    *,
    rank: int,
    session: Path,
    metric: str,
    segment_id: str,
    msprof_py: Path | None,
    cache_root: Path,
    mock: bool,
) -> Mapping[str, Any]:
    try:
        outputs = csv_inventory(session, metric)
        return {
            "rank": rank,
            "segment_id": segment_id,
            "status": "skipped_cached",
            "backend": "cached_validated_csv",
            "csv_summary": _summarize_outputs(outputs),
        }
    except SystemExit:
        pass
    prof_dir = find_prof_dir(session)
    log_path = cache_root / segment_id / f"rank_{rank}" / "msprof_export.log"
    outputs = run_msprof_export(
        msprof_py=msprof_py or Path("msprof.py"),
        prof_dir=prof_dir,
        log_path=log_path,
        mock=mock,
        session=session,
        metric=metric,
    )
    return {
        "rank": rank,
        "segment_id": segment_id,
        "status": "parsed",
        "backend": "mock_csv" if mock else "msprof_export_summary_csv",
        "csv_summary": _summarize_outputs(outputs),
    }


def parse_segments(
    *,
    profile_root: Path,
    metric: str,
    sample_plan: Path,
    cache_root: Path,
    output: Path,
    max_workers: int,
    msprof_py: Path | None = None,
    mock: bool = False,
) -> Mapping[str, Any]:
    started = time.monotonic()
    plan = load_json(sample_plan.resolve(strict=True))
    segments = plan.get("segments")
    if not isinstance(segments, list):
        raise SystemExit("sample plan segments missing")
    rows: list[Mapping[str, Any]] = []
    for segment in segments:
        if not isinstance(segment, Mapping):
            raise SystemExit("invalid segment in sample plan")
        segment_id = str(segment["segment_id"])
        sessions = discover_segment_sessions(profile_root, metric, segment_id)
        results: dict[int, Mapping[str, Any]] = {}
        futures: dict[Future[Mapping[str, Any]], int] = {}
        with ThreadPoolExecutor(max_workers=max_workers) as executor:
            for rank, session in sorted(sessions.items()):
                future = executor.submit(
                    parse_rank_segment,
                    rank=rank,
                    session=session,
                    metric=metric,
                    segment_id=segment_id,
                    msprof_py=msprof_py,
                    cache_root=cache_root,
                    mock=mock,
                )
                futures[future] = rank
            for future in as_completed(futures):
                rank = futures[future]
                results[rank] = future.result()
                print(
                    "R29_PARSE_PROGRESS="
                    f"{segment_id}:{len(results)}/16 rank={rank}",
                    flush=True,
                )
        rows.append(
            {
                "segment_id": segment_id,
                "phase": segment.get("phase"),
                "target_s": segment.get("target_s"),
                "active_steps": segment.get("active_steps"),
                "status": "complete",
                "rank_count": len(results),
                "ranks": [results[rank] for rank in range(EXPECTED_RANKS)],
            }
        )
    report = {
        "schema_version": "r29.segment_parse.v1",
        "status": "complete",
        "profile_root": str(profile_root.resolve(strict=True)),
        "metric": metric,
        "sample_plan": str(sample_plan.resolve(strict=True)),
        "segment_count": len(rows),
        "rank_count_per_segment": EXPECTED_RANKS,
        "elapsed_s": time.monotonic() - started,
        "segments": rows,
    }
    atomic_json(output, report)
    print(f"R29_PARSE_REPORT={output}")
    return report


def main(argv: Sequence[str] | None = None) -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--profile-root", type=Path, required=True)
    parser.add_argument("--metric", required=True)
    parser.add_argument("--sample-plan", type=Path, required=True)
    parser.add_argument("--cache-root", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--max-workers", type=int, default=4)
    parser.add_argument("--msprof-py", type=Path)
    parser.add_argument("--mock", action="store_true")
    args = parser.parse_args(argv)
    parse_segments(
        profile_root=args.profile_root,
        metric=args.metric,
        sample_plan=args.sample_plan,
        cache_root=args.cache_root,
        output=args.output,
        max_workers=args.max_workers,
        msprof_py=args.msprof_py,
        mock=args.mock,
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
