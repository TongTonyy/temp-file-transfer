#!/usr/bin/env bash
set -Eeuo pipefail
umask 077

ROOT="${HGNN_ROOT:-/root/hgnn_910c_readiness/hgnn_f01_qwen3_campaign_v0.3.4}"
DEPLOY_STAMP="$(date -u +%Y%m%dT%H%M%SZ)"
CAMPAIGN_ID="${HGNN_R29_CAMPAIGN_ID:-${DEPLOY_STAMP}-r29-sampled-300s}"
R29_MODE="${HGNN_R29_MODE:-pilot}"
WORKLOAD="$ROOT/workload"
PARSE_WORKERS="${HGNN_R29_PARSE_WORKERS:-4}"
EXTRACT_WORKERS="${HGNN_R29_EXTRACT_WORKERS:-8}"
MIN_FREE_GIB="${HGNN_R29_MIN_FREE_GIB:-120}"
DURATION_S="${HGNN_R29_DURATION_S:-600}"
BASELINE_S="${HGNN_R29_BASELINE_S:-120}"
RELEASE_AT_S="${HGNN_R29_RELEASE_AT_S:-420}"

[[ -d "$ROOT" ]] || { echo "campaign目录不存在: $ROOT" >&2; exit 2; }
cd "$ROOT"
mkdir -p runtime/logs runtime/gates runtime/manifests runtime/return_bundles
DEPLOY_LOG="$ROOT/runtime/logs/r29_sampled_${DEPLOY_STAMP}.log"
exec > >(tee -a "$DEPLOY_LOG") 2>&1

# shellcheck disable=SC1091
. "$ROOT/workload/common.sh"
resolve_llm_python

EXTRACTION_ROOT="$ROOT/runtime/extracted_targets_r29/$CAMPAIGN_ID"
MANIFEST_ROOT="$ROOT/runtime/manifests/$CAMPAIGN_ID"
PACKAGE_DIR="$ROOT/runtime/return_bundles"
mkdir -p "$EXTRACTION_ROOT/groups" "$MANIFEST_ROOT" "$PACKAGE_DIR"

r29_stage() {
  echo "============================================================"
  echo "R29_STAGE=$1/7"
  echo "R29_STAGE_NAME=$2"
  echo "R29_STAGE_UTC=$(date -u +%Y%m%dT%H%M%SZ)"
  echo "============================================================"
}

r29_now_ms() {
  "$HGNN_PYTHON" - <<'PY'
import time
print(int(time.monotonic() * 1000))
PY
}

r29_elapsed_s() {
  "$HGNN_PYTHON" - "$1" "$2" <<'PY'
import sys
print(f"{(int(sys.argv[2]) - int(sys.argv[1])) / 1000:.3f}")
PY
}

r29_check_profiles_empty() {
  "$HGNN_PYTHON" - "$ROOT/runtime/profiles" <<'PY'
import sys
from pathlib import Path
root = Path(sys.argv[1])
if root.exists():
    items = [p for p in root.iterdir() if p.name != ".keep"]
    if items:
        print("R29_STALE_PROFILE_ROOTS=" + ",".join(str(p) for p in sorted(items)))
        raise SystemExit(1)
PY
}

r29_mock_materialize() {
  local profile_root="$1" metric="$2" sample_plan="$3" run_id="$4" condition="$5"
  "$HGNN_PYTHON" - "$profile_root" "$metric" "$sample_plan" "$ROOT" "$run_id" \
    "$condition" "$DURATION_S" "$BASELINE_S" "$RELEASE_AT_S" <<'PY'
import json
import sys
from pathlib import Path
sys.path.insert(0, str(Path(sys.argv[4]) / "workload"))
from r27_state import materialize_mock_run_sidecars

profile_root = Path(sys.argv[1])
metric = sys.argv[2]
plan = json.loads(Path(sys.argv[3]).read_text(encoding="utf-8"))
root = Path(sys.argv[4])
run_id = sys.argv[5]
condition = sys.argv[6]
duration = float(sys.argv[7])
baseline = float(sys.argv[8])
release = float(sys.argv[9])

for rank in range(16):
    rank_dir = profile_root / f"rank_{rank}"
    rank_dir.mkdir(parents=True, exist_ok=True)
    events = []
    step = 100
    for index, segment in enumerate(plan["segments"], start=1):
        segment_id = segment["segment_id"]
        active_steps = int(segment["active_steps"])
        start_step = step
        stop_step = step + active_steps
        events.append({
            "event": "session_started",
            "command_id": index,
            "segment_id": segment_id,
            "phase": segment["phase"],
            "after_step": start_step,
            "start_step": start_step,
            "stop_step": None,
            "effective_profiler_steps": 0,
        })
        events.append({
            "event": "session_auto_stopped",
            "command_id": index,
            "segment_id": segment_id,
            "phase": segment["phase"],
            "after_step": stop_step,
            "start_step": start_step,
            "stop_step": stop_step,
            "effective_profiler_steps": active_steps,
        })
        session = profile_root / metric / segment_id / f"rank_{rank}_mock_{segment_id}_ascend_pt"
        prof = session / "PROF_mock"
        prof.mkdir(parents=True, exist_ok=True)
        step = stop_step + 10
    (rank_dir / "hgnn_profile_plan.json").write_text(
        json.dumps(
            {
                "schema_version": "1.2",
                "status": "complete",
                "run_id": run_id,
                "rank": rank,
                "aic_metric_name": metric,
                "last_command_id": len(plan["segments"]),
                "segments": [],
                "events": events,
            },
            indent=2,
            sort_keys=True,
        )
        + "\n",
        encoding="utf-8",
    )
materialize_mock_run_sidecars(
    root,
    run_id,
    condition=condition,
    duration_s=duration,
    baseline_s=baseline,
    release_at_s=release,
)
print(f"R29_MOCK_PROFILE={profile_root}")
PY
}

r29_run_group() {
  local key="$1" condition="$2" metric="$3" drawer="$4"
  local run_id profile_root gate_dir sample_plan parse_report started ended cleanup_report group_manifest
  run_id="${CAMPAIGN_ID}-${key}-a1"
  profile_root="$ROOT/runtime/profiles/$run_id"
  gate_dir="$ROOT/runtime/gates/r29_group_gate/$CAMPAIGN_ID/$run_id"
  sample_plan="$MANIFEST_ROOT/${run_id}_sample_plan.json"
  parse_report="$EXTRACTION_ROOT/provenance/r29/parse/$run_id/parse_report.json"
  cleanup_report="$EXTRACTION_ROOT/provenance/r29/cleanup/$run_id/cleanup_report.json"
  group_manifest="$EXTRACTION_ROOT/groups/$key.json"
  if [[ "${HGNN_R29_RESUME_COMPLETED_GROUPS:-1}" == "1" \
      && -f "$group_manifest" && -f "$cleanup_report" ]]; then
    if "$HGNN_PYTHON" - "$group_manifest" "$cleanup_report" "$run_id" <<'PY'
import json
import sys
from pathlib import Path

group = json.loads(Path(sys.argv[1]).read_text(encoding="utf-8"))
cleanup = json.loads(Path(sys.argv[2]).read_text(encoding="utf-8"))
run_id = sys.argv[3]
if group.get("status") != "complete" or group.get("run_id") != run_id:
    raise SystemExit(1)
if cleanup.get("status") != "complete" or cleanup.get("run_id") != run_id:
    raise SystemExit(1)
profile_root = Path(str(cleanup.get("profile_root", "")))
if profile_root.exists():
    raise SystemExit(1)
PY
    then
      echo "R29_GROUP_SKIP_COMPLETED=$key"
      echo "RUN_ID=$run_id"
      return 0
    fi
  fi
  mkdir -p "$gate_dir" "$(dirname "$parse_report")" "$(dirname "$cleanup_report")"
  echo "R29_GROUP_START=$key"
  echo "RUN_ID=$run_id"
  echo "AIC_METRIC=$metric"
  "$HGNN_PYTHON" "$WORKLOAD/r29_sample_plan.py" \
    --run-id "$run_id" \
    --metric "$metric" \
    --condition "$condition" \
    --duration-s "$DURATION_S" \
    --baseline-s "$BASELINE_S" \
    --release-at-s "$RELEASE_AT_S" \
    --output "$sample_plan"
  started="$(r29_now_ms)"
  export HGNN_FORMAL_DURATION="$DURATION_S"
  export HGNN_FORMAL_BASELINE="$BASELINE_S"
  export HGNN_FORMAL_RELEASE_AT="$RELEASE_AT_S"
  export HGNN_TORCH_NPU_AIC_METRIC="$metric"
  export HGNN_R29_SAMPLE_PLAN_PATH="$sample_plan"
  if [[ "${HGNN_R29_MOCK_RUN:-}" == "1" ]]; then
    r29_mock_materialize "$profile_root" "$metric" "$sample_plan" "$run_id" "$condition"
  else
    run_formal "$condition" "$drawer" "$run_id"
  fi
  local parse_argv=(
    "$HGNN_PYTHON" "$WORKLOAD/r29_parse_segments.py"
    --profile-root "$profile_root"
    --metric "$metric"
    --sample-plan "$sample_plan"
    --cache-root "$gate_dir/parse_cache"
    --output "$parse_report"
    --max-workers "$PARSE_WORKERS"
  )
  if [[ "${HGNN_R29_MOCK_RUN:-}" == "1" ]]; then
    parse_argv+=(--mock)
  elif [[ -n "${HGNN_MSPROF_PY:-}" ]]; then
    parse_argv+=(--msprof-py "$HGNN_MSPROF_PY")
  fi
  "${parse_argv[@]}"
  "$HGNN_PYTHON" "$WORKLOAD/r29_extract_segments.py" \
    --profile-root "$profile_root" \
    --output-root "$EXTRACTION_ROOT" \
    --run-id "$run_id" \
    --key "$key" \
    --condition "$condition" \
    --metric "$metric" \
    --sample-plan "$sample_plan" \
    --parse-report "$parse_report" \
    --max-workers "$EXTRACT_WORKERS" \
    --trust-complete-reports
  cp "$EXTRACTION_ROOT/$run_id/r29_group_extraction_manifest.json" \
    "$EXTRACTION_ROOT/groups/$key.json"
  "$HGNN_PYTHON" "$WORKLOAD/r29_cleanup_sampled_profile.py" \
    --root "$ROOT" \
    --profile-root "$profile_root" \
    --extraction-root "$EXTRACTION_ROOT" \
    --group-manifest "$EXTRACTION_ROOT/$run_id/r29_group_extraction_manifest.json" \
    --run-id "$run_id" \
    --profile-plans-output "$EXTRACTION_ROOT/provenance/r29/profile_plans/$run_id" \
    --cleanup-report "$cleanup_report"
  ended="$(r29_now_ms)"
  echo "R29_GROUP_TOTAL_S=$(r29_elapsed_s "$started" "$ended")"
  echo "R29_GROUP_COMPLETE=$key"
}

r29_stage 1 "启动与容量预检"
R29_RUN_START_MS="$(r29_now_ms)"
echo "R29_CAMPAIGN_ID=$CAMPAIGN_ID"
echo "R29_MODE=$R29_MODE"
echo "R29_LOG=$DEPLOY_LOG"
FREE_GIB="$("$HGNN_PYTHON" - "$ROOT" <<'PY'
import shutil
import sys
print(shutil.disk_usage(sys.argv[1]).free // (1024 ** 3))
PY
)"
echo "R29_FREE_GIB=$FREE_GIB"
if [[ "${HGNN_R29_MOCK_RUN:-}" != "1" ]] && ((FREE_GIB < MIN_FREE_GIB)); then
  echo "可用空间不足${MIN_FREE_GIB}GiB，拒绝启动" >&2
  exit 2
fi
if [[ "${HGNN_R29_ALLOW_STALE_PROFILES:-}" != "1" ]]; then
  r29_check_profiles_empty
fi

r29_stage 2 "初始化环境"
if [[ "${HGNN_R29_MOCK_RUN:-}" == "1" ]]; then
  workload_init
else
  campaign_init
  ASCEND_ENV=""
  for candidate in \
    /usr/local/Ascend/ascend-toolkit/set_env.sh \
    /usr/local/Ascend/ascend-toolkit/latest/set_env.sh
  do
    [[ -f "$candidate" ]] && { ASCEND_ENV="$candidate"; break; }
  done
  [[ -n "$ASCEND_ENV" ]] || { echo "未找到Ascend环境脚本" >&2; exit 2; }
  set +u
  # shellcheck disable=SC1090
  source "$ASCEND_ENV"
  set -u
  export HGNN_MSPROF_PY="${HGNN_MSPROF_PY:-/usr/local/Ascend/cann-8.5.2/tools/profiler/profiler_tool/analysis/msprof/msprof.py}"
fi

r29_stage 3 "采样式group运行"
if [[ "$R29_MODE" == "pilot" ]]; then
  r29_run_group "pilot_resource_conflict" "manual_baseline_sham" "ResourceConflictRatio" "drawer0"
  FINAL_MODE="pilot"
elif [[ "$R29_MODE" == "full" ]]; then
  [[ "${HGNN_R29_ENABLE_300S:-0}" == "1" ]] || {
    echo "300s采样式full需要显式设置 HGNN_R29_ENABLE_300S=1" >&2
    exit 2
  }
  require_smoke_gate "drawer0"
  r29_run_group "control_resource_conflict" "manual_baseline_sham" "ResourceConflictRatio" "drawer0"
  r29_run_group "fault_resource_conflict" "drawer0_s1" "ResourceConflictRatio" "drawer0"
  r29_run_group "control_memory_access" "manual_baseline_sham" "MemoryAccess" "drawer0"
  r29_run_group "fault_memory_access" "drawer0_s1" "MemoryAccess" "drawer0"
  FINAL_MODE="full"
else
  echo "HGNN_R29_MODE必须是pilot或full" >&2
  exit 2
fi

r29_stage 4 "最终manifest"
DATASET_MANIFEST="$MANIFEST_ROOT/r29_dataset_manifest.json"
"$HGNN_PYTHON" "$WORKLOAD/r29_finalize_sampled_dataset.py" \
  --root "$ROOT" \
  --extraction-root "$EXTRACTION_ROOT" \
  --campaign-id "$CAMPAIGN_ID" \
  --output "$DATASET_MANIFEST" \
  --mode "$FINAL_MODE"

r29_stage 5 "最终打包"
"$HGNN_PYTHON" "$WORKLOAD/r29_package_sampled_dataset.py" \
  --dataset-manifest "$DATASET_MANIFEST" \
  --extraction-root "$EXTRACTION_ROOT" \
  --output-dir "$PACKAGE_DIR" \
  --bundle-label "r29-sampled-dataset"

r29_stage 6 "完成"
R29_RUN_END_MS="$(r29_now_ms)"
echo "R29_RUN_TOTAL_S=$(r29_elapsed_s "$R29_RUN_START_MS" "$R29_RUN_END_MS")"
echo "R29_COMPLETE=1"
