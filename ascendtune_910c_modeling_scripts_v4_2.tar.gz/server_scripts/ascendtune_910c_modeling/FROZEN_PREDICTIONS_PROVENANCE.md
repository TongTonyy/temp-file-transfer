# Frozen Predictions Provenance

This package contains two different prediction files with different evidential status.

## `frozen_predictions.csv`

This is the V2 validation pre-run frozen prediction file. It must be used for blind/frozen prediction comparisons.

Important note: `V2F_BND_repeat` maps to the previously measured v1 anchor `BND-HGNN_tp2pp2`; therefore an `exact` support label for V2F means exact support from the prior BND-HGNN anchor, not from the later V2F repeat result.

Do not regenerate or edit this file after running V2 validation.

## `frozen_predictions_posthoc.csv`

This file is generated after incorporating V2 results into the model. It is post-hoc calibration output and must not be reported as blind/frozen prediction evidence.

Use it only to describe the updated calibrated model after V2 data were known.
