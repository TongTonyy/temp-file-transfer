#!/usr/bin/env python3
"""Measure Ascend 910C compute/collective overlap slowdown.

Run with torchrun, for example:
  torchrun --nproc_per_node 16 overlap_slowdown_910c.py --mode all_reduce --out overlap.csv

The output estimates separate slowdown terms:
  s_overlap_compute ~= concurrent_elapsed / gemm_alone_elapsed
  s_overlap_comm    ~= concurrent_elapsed / comm_alone_elapsed

These are conservative upper-bound estimates for T_O correction. They must be
measured on Ascend 910C and must not be copied from NVIDIA/GPU defaults.
"""
from __future__ import annotations

import argparse
import csv
import os
import time

import torch
import torch.distributed as dist
import torch_npu  # noqa: F401


def init_dist():
    local_rank = int(os.environ.get("LOCAL_RANK", "0"))
    torch.npu.set_device(local_rank)
    if not dist.is_initialized():
        dist.init_process_group(backend=os.environ.get("DIST_BACKEND", "hccl"))
    return local_rank


def sync():
    if dist.is_initialized():
        dist.barrier()
    torch.npu.synchronize()


def bench(fn, warmup, iters):
    for _ in range(warmup):
        fn()
    sync()
    start = time.time()
    for _ in range(iters):
        fn()
    sync()
    return (time.time() - start) / iters


def make_comm(mode, numel, group_size):
    rank = dist.get_rank()
    world = dist.get_world_size()
    x = torch.randn(numel, device="npu", dtype=torch.bfloat16)
    y = torch.empty_like(x)

    if mode == "all_reduce":
        def step():
            dist.all_reduce(x)
        return step
    if mode == "reduce_scatter":
        chunks = [torch.empty_like(x) for _ in range(world)]
        def step():
            dist.reduce_scatter(y, chunks)
        return step
    if mode == "all_gather":
        outs = [torch.empty_like(x) for _ in range(world)]
        def step():
            dist.all_gather(outs, x)
        return step
    if mode == "p2p_ring":
        dst = (rank + 1) % world
        src = (rank - 1 + world) % world
        def step():
            reqs = dist.batch_isend_irecv([
                dist.P2POp(dist.isend, x, dst),
                dist.P2POp(dist.irecv, y, src),
            ])
            for req in reqs:
                req.wait()
        return step
    if mode == "all_reduce_group":
        groups = []
        my_group = None
        for start in range(0, world, group_size):
            ranks = list(range(start, min(start + group_size, world)))
            group = dist.new_group(ranks=ranks)
            groups.append(group)
            if rank in ranks:
                my_group = group
        def step():
            dist.all_reduce(x, group=my_group)
        return step
    raise ValueError(mode)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--mode", default="all_reduce",
                        choices=["all_reduce", "all_gather", "reduce_scatter", "p2p_ring", "all_reduce_group"])
    parser.add_argument("--group-size", type=int, default=16)
    parser.add_argument("--numel", type=int, default=67108864)
    parser.add_argument("--m", type=int, default=4096)
    parser.add_argument("--n", type=int, default=4096)
    parser.add_argument("--k", type=int, default=4096)
    parser.add_argument("--iters", type=int, default=50)
    parser.add_argument("--warmup", type=int, default=10)
    parser.add_argument("--out", default="overlap_slowdown.csv")
    args = parser.parse_args()

    init_dist()
    a = torch.randn(args.m, args.k, device="npu", dtype=torch.bfloat16)
    b = torch.randn(args.k, args.n, device="npu", dtype=torch.bfloat16)
    comm_step = make_comm(args.mode, args.numel, args.group_size)

    def gemm_step():
        return torch.matmul(a, b)

    compute_stream = torch.npu.Stream()
    comm_stream = torch.npu.Stream()

    def concurrent_step():
        with torch.npu.stream(compute_stream):
            _ = torch.matmul(a, b)
        with torch.npu.stream(comm_stream):
            comm_step()
        torch.npu.synchronize()

    gemm_s = bench(gemm_step, args.warmup, args.iters)
    comm_s = bench(comm_step, args.warmup, args.iters)
    concurrent_s = bench(concurrent_step, args.warmup, args.iters)

    rank = dist.get_rank()
    if rank == 0:
        s_vs_max = concurrent_s / max(gemm_s, comm_s) if max(gemm_s, comm_s) else 0.0
        overlap_eff = (gemm_s + comm_s - concurrent_s) / (gemm_s + comm_s) if (gemm_s + comm_s) else 0.0
        row = {
            "mode": args.mode,
            "group_size": args.group_size,
            "numel": args.numel,
            "gemm_shape": f"{args.m}x{args.k}x{args.n}",
            "gemm_alone_s": gemm_s,
            "comm_alone_s": comm_s,
            "concurrent_s": concurrent_s,
            "s_vs_max": s_vs_max,
            "overlap_eff": overlap_eff,
            "s_overlap_compute": concurrent_s / gemm_s if gemm_s else 0.0,
            "s_overlap_comm": concurrent_s / comm_s if comm_s else 0.0,
            "metric_note": "s_vs_max>1 indicates true concurrent slowdown; s_overlap_compute/comm are upper-bound ratios for model diagnostics",
            "world_size": dist.get_world_size(),
            "timestamp": int(time.time()),
        }
        exists = os.path.exists(args.out)
        with open(args.out, "a", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=list(row))
            if not exists:
                writer.writeheader()
            writer.writerow(row)
        print(row, flush=True)


if __name__ == "__main__":
    main()
