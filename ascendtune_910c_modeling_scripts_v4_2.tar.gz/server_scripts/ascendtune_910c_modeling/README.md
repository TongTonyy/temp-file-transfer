# AscendTune 910C 建模与标定脚本包

本目录用于在 910C 服务器上执行第二轮建模标定。目标不是继续解释旧排序，而是获得可复验的吞吐/能耗结构化模型。

## v4.2 修复说明（相对 v4.1）

v4.1 中以下文件是旧版回退，已在本包内替换为**服务器上实测通过的版本**：

1. `posttrain_gpt_lab_v3.py` / `posttrain_gpt_lab_v2.py`：换回 2026-11-08 实测产出真实 token 数的 loss_func 类方法钩子版（v4.1 的模块级 forward/loss 钩子在这版 MindSpeed-LLM 上安装不上，会产出全 0 的 real_tokens.csv 且行数正常，造成"假 PASS"）。
2. `energy_microbench_910c.py`：换回 v2.1 修复版（GEMM 参数 `--gm/--gn/--gk`，v4.1 的 `--m/--n/--k` 会被 torchrun 当成自己的参数报 ambiguous option；新增 `--min_seconds` 持续负载模式）。
3. `run_energy_calibration.sh`：改为三阶段编排（时延测量 → sustained 持续负载功耗 → 有效性检查），v4.1 原版同时携带 GEMM 参数名 bug 和短迭代功耗稀释 bug。
4. `run_zero_stage_probe.sh`：删除失效的 `--help` flag 探测（系统 python 跑 `--help` 得到空文件，会让 z1/z2/z3 静默退化为无 flag = 和 z0 一样 OOM），改为显式已验证 flag 组合。
5. `run_anchor_validation_v2.sh`：换回带缺权重预检、`TP_SIZE_FALLBACK`、wrapper 自动部署的审查版。
6. zero probe / 锚点 / overlap 各组之间增加 60s/60s/20s 间隔（修复 HCCL `EJ0003: IP port already bound` 偶发失败）。

## 运行环境（必须先满足）

```bash
# 在 tmux 里运行（网页终端会断连）：
tmux new -s calib
# 用绝对路径钉住 conda 环境（conda activate 在 tmux 里可能不生效）：
export PATH=/root/miniconda3/envs/llm_env/bin:$PATH
which torchrun   # 必须是 /root/miniconda3/envs/llm_env/bin/torchrun
python3 --version  # 必须是 3.10.x（系统 3.9 会在 import 阶段 TypeError 崩溃）
```

## 推荐执行顺序

1. 将本目录提交到你的 GitHub 项目。
2. 在 910C 服务器上下载解压到 `/root/hgnn_910c_readiness/` 下。
3. 修改 `common_env.sh` 中的路径，确认 `MSLLM_DIR`、权重目录、数据目录正确。
4. 先跑优化器/分布式优化 flag 组合探测（**2026-11-07/08 已完成，可跳过**）：

```bash
bash run_zero_stage_probe.sh 2>&1 | tee zero_probe.log
```

`run_zero_stage_probe.sh` 中的 `z=2`、`z=3` 是候选 flag 组合标签，不等价于已经证明 MindSpeed-LLM 正在执行严格 ZeRO-2/ZeRO-3 语义。论文中应按实际命中的 flags 描述，例如 `--use-distributed-optimizer --overlap-grad-reduce`。

5. 再跑功耗状态机标定（**2026-11-10 已完成且 55/55 PASS，可跳过**）：

```bash
bash run_energy_calibration.sh 2>&1 | tee energy_calibration.log
```

6. 跑冻结模型验证批次（**2026-11-13 已完成，6/6 PASS，可跳过**）：

```bash
bash run_anchor_validation_v2.sh 2>&1 | tee anchor_validation_v2.log
```

`frozen_predictions.csv` 已随包提供，运行前不要再改候选或预测值。

7. 跑 overlap slowdown 标定（**本轮新增，必跑**）：

```bash
bash run_overlap_slowdown.sh 2>&1 | tee overlap_slowdown.log
```

该步骤用于拟合 Galvatron-style `s_overlap_compute` / `s_overlap_comm`，不要用 NVIDIA 经验值替代。

8. 打包结果并推送到 GitHub：

```bash
bash pack_and_push_results.sh
```

（服务器上 `git push` 一般没有凭据会失败，不影响打包；把生成的 `ascendtune_910c_modeling_results.tar.gz` 用 release asset 方式上传即可。）

## 产物

- `results_zero_probe/`：优化器/分布式优化 flag 组合的可执行性、显存、吞吐、错误日志。
- `results_energy_calibration/`：idle、16 卡 GEMM、vector、memory、SwiGLU、HCCL group/P2P 标定结果和功耗时间序列。
- `results_anchor_validation_v2/`：冻结预测候选的真实训练验证结果。
- `results_overlap_slowdown/`：GEMM 与 HCCL/P2P 并发运行的 slowdown 标定。
- `frozen_predictions.csv`：V2A-V2F 的运行前冻结预测，用于预测-实测对比。
- `frozen_predictions_posthoc.csv`：纳入 V2 后的事后校准输出，不得作为盲测冻结预测。
- `FROZEN_PREDICTIONS_PROVENANCE.md`：冻结预测与事后预测的证据链说明。
- `ascendtune_910c_modeling_results.tar.gz`：用于传回本地建模。

## 建模原则

参考 Galvatron 的结构化建模方式：先 profile 硬件和模型算子，再把策略预测拆成计算、通信、显存和调度项。能耗模型采用 Trace 状态机积分：

```text
Power_total(t) = P_idle + P_compute(t) + P_memory(t) + P_comm(t)
Energy = sum(Power_total(t) * dt)
tokens/J = effective_or_nominal_tokens / Energy
```

注意：`posttrain_gpt_lab_v3.py` 和 `posttrain_gpt_lab_v2.py` 都会通过 `TOK_OUT` 写入候选目录内的 `real_tokens.csv`，并只在 TP rank 0 计数 loss mask 以避免 TP 重复。如果 `real_tokens.csv` 行数不是 25 或 token 为 0，需要先修 token 计数入口，再谈 effective tokens/J。
