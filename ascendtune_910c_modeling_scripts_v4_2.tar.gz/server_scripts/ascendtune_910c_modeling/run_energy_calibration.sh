#!/bin/bash
# Orchestrated energy-state calibration (v4.2).
# Phase 1: latency/metrics pass (run_energy_calibration_v2.sh)
# Phase 2: sustained-load power pass (rerun_power_sustained.sh)
# Phase 3: validity check (check_calibration_validity.py)
#
# Both phases write into the SAME results directory so the validity check
# sees a complete picture. Skip phase 1 if bench_metrics.csv already exists:
#   SKIP_PHASE1=1 bash run_energy_calibration.sh

set -u
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
export OUT_ROOT=${OUT_ROOT:-$SCRIPT_DIR/results_energy_calibration}
mkdir -p "$OUT_ROOT"

if [ "${SKIP_PHASE1:-0}" != "1" ]; then
  echo "################## phase 1: latency metrics ##################"
  bash "$SCRIPT_DIR/run_energy_calibration_v2.sh"
fi

echo "################## phase 2: sustained power ##################"
bash "$SCRIPT_DIR/rerun_power_sustained.sh"

echo "################## phase 3: validity check ##################"
python3 "$SCRIPT_DIR/check_calibration_validity.py" "$OUT_ROOT"
