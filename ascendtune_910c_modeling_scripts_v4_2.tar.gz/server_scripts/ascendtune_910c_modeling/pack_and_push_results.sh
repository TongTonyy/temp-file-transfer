#!/bin/bash
# Pack calibration results and optionally push them through a GitHub repo.

set -u
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
ARCHIVE=${ARCHIVE:-ascendtune_910c_modeling_results.tar.gz}

cd "$SCRIPT_DIR" || exit 1
items=()
for path in results_zero_probe results_energy_calibration results_anchor_validation_v2 results_overlap_slowdown anchor_validation_v2.log ./*.csv ./*.log; do
  [ -e "$path" ] && items+=("$path")
done
if [ "${#items[@]}" -gt 0 ]; then
  tar czf "$ARCHIVE" "${items[@]}"
else
  tar czf "$ARCHIVE" --files-from /dev/null
fi
echo "[pack] wrote $SCRIPT_DIR/$ARCHIVE"

if git rev-parse --is-inside-work-tree >/dev/null 2>&1; then
  git add "$ARCHIVE" "${items[@]}" 2>/dev/null || true
  git commit -m "Add AscendTune 910C calibration results" || true
  git push || true
  echo "[git] attempted commit and push"
else
  echo "[git] not inside a git repo; move $ARCHIVE into your GitHub project and push manually"
fi
