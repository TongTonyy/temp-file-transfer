# Anchor Validation v2

本批次用于验证已经冻结的锚点校准吞吐-能效模型，不再用于修改候选列表。

## 运行命令

```bash
cd /root/hgnn_910c_readiness/ascendtune_910c_modeling
bash run_anchor_validation_v2.sh 2>&1 | tee anchor_validation_v2.log
```

默认入口为：

```text
posttrain_gpt_lab_v3.py
```

本包已包含 `posttrain_gpt_lab_v3.py`。`run_anchor_validation_v2.sh` 会在启动前复制到 `$MSLLM_DIR`，并为每个候选设置独立的 `TOK_OUT=$候选目录/real_tokens.csv`。

## 冻结预测

本包包含：

```text
frozen_predictions.csv
```

该文件是在运行 V2A-V2F 之前冻结的模型预测，包含 `pred_step_ms`、`pred_power_w`、effective/nominal tokens/s、effective/nominal tokens/J、0.5/0.5 加权分数、校准支撑锚点和不确定性说明。运行结束后请不要修改该文件，回传时一并打包，用于严格比较预测和实测。

## 候选列表

```text
name                       PP  TP  DP  micro_batch  SP   recompute  purpose
V2A_p1t4d4_sp1_b2          1   4   4   2            on   off        top unmeasured candidate
V2B_p2t2d4_sp1_b1          2   2   4   1            on   off        SP variant of BND-HGNN
V2C_p4t2d2_sp0_b1          4   2   2   1            off  off        PP4/TP2 high-rank candidate
V2D_p2t4d2_sp1_b2          2   4   2   2            on   off        PP2/TP4 high-rank candidate
V2E_p1t8d2_sp1_b4          1   8   2   4            on   off        TP8 b4 extrapolation check
V2F_BND_repeat             2   2   4   1            off  off        repeat current top point
```

所有 `DP > 1` 候选统一使用：

```bash
--use-distributed-optimizer --overlap-grad-reduce
```

## 需要的权重

```text
qwen3_mcore-4TP4DP
qwen3_mcore-2TP4DP
qwen3_mcore-2TP2DP
qwen3_mcore-4TP2DP
qwen3_mcore-8TP2DP
```

## 有效性判据

每个候选目录应包含：

```text
config_note.txt
launch.sh
train.log
exit_code.txt
step_times_raw.txt
real_tokens.csv
power_mem.csv
power_mem.csv.raw_snapshot.txt
run_status.txt
```

有效完成要求：

```text
exit_code = 0
step_times_raw.txt 有 25 行
real_tokens.csv 有 25 行且 tokens_nonpad_allranks > 0
power_mem.csv 覆盖完整训练窗口
MEMREPORT 可解析
```

## 回传

跑完后打包：

```bash
bash pack_and_push_results.sh
```
