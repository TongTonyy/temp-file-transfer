#!/bin/bash
# Probe optimizer/distributed-optimizer flag combinations on the current
# MindSpeed-LLM stack. z=2/z=3 are labels for candidate flag bundles, not
# strict proof of canonical ZeRO-2/ZeRO-3 semantics.

set -u
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
# shellcheck disable=SC1091
source "$SCRIPT_DIR/common_env.sh"

OUT_ROOT=${OUT_ROOT:-$SCRIPT_DIR/results_zero_probe}
ENTRY=${ENTRY:-posttrain_gpt_lab_v3.py}
PP=${PP:-1}
TP=${TP:-4}
MICRO_BATCH=${MICRO_BATCH:-1}
BASE_PORT=${BASE_PORT:-7800}
mkdir -p "$OUT_ROOT"

cp "$SCRIPT_DIR/$ENTRY" "$MSLLM_DIR/$ENTRY"

# Explicit flag bundles, verified on this MindSpeed-LLM stack (2026-11-07/08:
# z0 OOM FAIL; z1/z2/z3 PASS at 130.7/129.1/131.8 s/step, 41.77 GiB).
# The previous `--help` probe was unreliable: it ran under the system python
# (no torch), produced an empty help file, and silently degraded z1/z2/z3 to
# empty args (i.e. OOM like z0). Do not reintroduce flag probing.
zero_args() {
  local z=$1
  case "$z" in
    0)
      echo ""
      ;;
    1)
      echo "--use-distributed-optimizer"
      ;;
    2)
      echo "--use-distributed-optimizer --overlap-grad-reduce"
      ;;
    3)
      echo "--use-distributed-optimizer --overlap-grad-reduce --overlap-param-gather"
      ;;
  esac
}

run_one() {
  local z=$1
  local port=$2
  local dir="$OUT_ROOT/zero${z}"
  local dp=$(( NPUS_PER_NODE / (PP * TP) ))
  local ckpt="$CKPT_WEIGHTS_DIR/$(ckpt_name "$TP" "$PP" "$dp")"
  local args_file="$dir/zero_args.txt"
  local status_file="$dir/run_status.txt"
  local extra
  extra="$(zero_args "$z")"

  mkdir -p "$dir"
  echo "$extra" > "$args_file"
  echo "p=$PP t=$TP d=$dp z=$z b=$MICRO_BATCH entry=$ENTRY" > "$dir/config_note.txt"

  cat > "$dir/launch.sh" <<EOF
#!/bin/bash
source "$SCRIPT_DIR/common_env.sh"
cd "$MSLLM_DIR"
torchrun \\
  --nproc_per_node "$NPUS_PER_NODE" \\
  --nnodes 1 \\
  --node_rank 0 \\
  --master_addr "$MASTER_ADDR" \\
  --master_port "$port" \\
  "$ENTRY" \\
  \$(base_qwen_args "$PP" "$TP" "$MICRO_BATCH" "$ckpt") \\
  --sequence-parallel \\
  $extra
EOF
  chmod +x "$dir/launch.sh"

  echo "======================================================================"
  echo "[$(date '+%F %T')] probing zero=$z args: $extra"
  echo "======================================================================"
  SAMPLE_INTERVAL_SEC=${SAMPLE_INTERVAL_SEC:-1} bash "$SCRIPT_DIR/sampler_power_mem.sh" "$dir/power_mem.csv" &
  local sampler_pid=$!
  sleep 5
  export TOK_OUT="$dir/real_tokens.csv"
  (cd "$dir" && bash launch.sh > train.log 2>&1)
  local rc=$?
  sleep 3
  kill "$sampler_pid" 2>/dev/null || true
  wait "$sampler_pid" 2>/dev/null || true
  if grep -qi "out of memory\\|NPU out of memory\\|RuntimeError" "$dir/train.log"; then
    echo "FAIL rc=$rc" > "$status_file"
  elif [ "$rc" = "0" ]; then
    echo "PASS rc=0" > "$status_file"
  else
    echo "FAIL rc=$rc" > "$status_file"
  fi
}

for z in 0 1 2 3; do
  run_one "$z" $(( BASE_PORT + z ))
  # let HCCL ports/processes from the previous run fully release
  # (observed EJ0003 "IP port already bound" when runs start back-to-back)
  [ "$z" != "3" ] && sleep 60
done

python3 "$SCRIPT_DIR/summarize_zero_probe.py" "$OUT_ROOT" > "$OUT_ROOT/zero_probe_summary.csv"
echo "[done] summary: $OUT_ROOT/zero_probe_summary.csv"
