#!/bin/bash
# Measure compute/collective overlap slowdown for Galvatron-style T_O correction.

set -u
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
# shellcheck disable=SC1091
source "$SCRIPT_DIR/common_env.sh"

OUT_ROOT=${OUT_ROOT:-$SCRIPT_DIR/results_overlap_slowdown}
mkdir -p "$OUT_ROOT"
port=${MASTER_PORT:-8920}

run_one() {
  local name=$1
  shift
  local dir="$OUT_ROOT/$name"
  mkdir -p "$dir"
  echo "======================================================================"
  echo "[$(date '+%F %T')] overlap $name"
  echo "======================================================================"
  torchrun \
    --nproc_per_node "$NPUS_PER_NODE" \
    --nnodes 1 \
    --node_rank 0 \
    --master_addr "$MASTER_ADDR" \
    --master_port "$port" \
    "$SCRIPT_DIR/overlap_slowdown_910c.py" \
    --out "$OUT_ROOT/overlap_slowdown.csv" \
    "$@" > "$dir/run.log" 2>&1
  echo "$?" > "$dir/exit_code.txt"
  port=$((port + 1))
  # let HCCL ports/processes fully release before the next run
  sleep 20
}

for mode in all_reduce all_gather reduce_scatter p2p_ring; do
  for numel in 16777216 67108864 134217728; do
    run_one "${mode}_${numel}" --mode "$mode" --numel "$numel"
  done
done

for group_size in 2 4 8 16; do
  for numel in 16777216 67108864 134217728; do
    run_one "all_reduce_group_g${group_size}_${numel}" \
      --mode all_reduce_group --group-size "$group_size" --numel "$numel"
  done
done

echo "[done] results in $OUT_ROOT"
