# AscendTune 能耗标定完整需求

目标：为 Trace 状态机能耗模型提供可复验标定数据，使每个候选策略都能预测 `step time`、`avg power`、`energy per step` 和 `tokens/J`。

## 1. 总体模型需求

能耗模型采用：

```text
P_total(t) = P_idle + P_compute(t) + P_memory(t) + P_comm(t)
Energy_step = sum(P_total(t) * dt)
tokens/J = tokens_per_step / Energy_step
```

因此标定必须覆盖四类状态：

- `idle`：无训练任务时 16 卡整机静态功耗。
- `compute`：GEMM/Cube-heavy 算子功耗与时延。
- `memory`：RMSNorm、copy、带宽受限算子功耗与时延。
- `comm`：HCCL AllReduce、AllGather、ReduceScatter、P2P 的功耗与时延。

## 2. 必须采集的原始文件

每个实验目录必须包含：

- `run.log`：完整 stdout/stderr。
- `exit_code.txt`：退出码，必须为 `0` 才算有效完成。
- `power_mem.csv`：功耗/显存时间序列，采样间隔建议 1 秒。
- `power_mem.csv.raw_snapshot.txt`：npu-smi 原始快照，用于解析核查。
- `bench_metrics.csv` 或训练 summary：记录 benchmark 平均时延、工作量、world size。

完整训练锚点还必须包含：

- `train.log`
- `step_times_raw.txt` 或可从日志解析的每步 step time
- `real_tokens.csv`
- `config_note.txt`
- `launch.sh`

## 3. Idle 标定

目的：得到 `P_idle`。

要求：

- 机器无训练任务、无残留 Python/torchrun 进程。
- 采样时间不少于 180 秒，建议 300 秒。
- 输出 `idle/power_mem.csv`。
- 有效性判据：至少 120 个整机功耗采样点；功耗均值和标准差可计算。

本脚本默认采样 180 秒；如需要更稳的 idle 基线，可设置 `IDLE_SECONDS=300`。

## 4. Compute 标定

目的：得到 GEMM/Cube-heavy 状态的增量功耗和计算时延曲线。

必须 16 rank 同时压测，不能只跑单进程。否则整机功耗几乎等于 idle，无法拟合 `P_compute`。

建议矩阵：

- shape A：`4096 x 4096 x 4096`
- shape B：`8192 x 4096 x 4096`
- shape C：`4096 x 5120 x 17408` 或贴近 Qwen3 MLP 的矩阵形状
- 每个 shape 至少 80 次迭代，warmup 10 次。
- 每个实验用 `torchrun --nproc_per_node 16`。

输出要求：

- `compute_gemm_shape*/run.log`
- `compute_gemm_shape*/power_mem.csv`
- `bench_metrics.csv` 中记录 `avg_s`、`flop`、`world_size=16`。

有效性判据：

- `exit_code=0`
- `world_size=16`
- 整机平均功耗显著高于 idle，建议至少高出 5%-10%。

`run_energy_calibration.sh` 已按上述三种 shape 使用 `torchrun --nproc_per_node 16` 执行。

## 5. Memory / Vector 标定

目的：得到 memory-bound/vector 状态的功耗和时延。

必须改为 16 rank 同时压测。

建议矩阵：

- `memory_copy`：numel 覆盖 64M、128M、256M bf16 元素。
- `vector_norm`：覆盖 Qwen3 hidden size 5120，rows 覆盖 4096、8192、16384。
- 可补充 SwiGLU 或 elementwise multiply/add benchmark。

输出要求：

- 每个 size 独立目录。
- `bench_metrics.csv` 记录 `avg_s`、`byte` 或 `element`、`world_size=16`。
- 同步保存 `power_mem.csv`。

有效性判据：

- `exit_code=0`
- `world_size=16`
- 相对 idle 有可观功耗增量；否则不能单独拟合 `P_memory`。

`run_energy_calibration.sh` 已覆盖 64M/128M/256M bf16 copy、4096/8192/16384 x 5120 RMSNorm，以及 4096/8192 x 17408 SwiGLU elementwise。

## 6. HCCL 通信标定

目的：得到 `P_comm` 和通信时延曲线。

必须覆盖：

- AllReduce
- AllGather
- ReduceScatter
- P2P send/recv，如 pipeline parallel 需要

`run_energy_calibration.sh` 已覆盖：

- AllReduce：16M、64M、128M bf16 元素
- AllGather：16M、64M、128M bf16 元素
- ReduceScatter：16M、64M、128M bf16 元素
- group AllReduce：group size 2、4、8、16，每档覆盖 16M、64M、128M bf16 元素
- P2P ring：16M、64M、128M bf16 元素
- 均使用 `world_size=16`

有效性判据：

- `bench_metrics.csv` 每项都有 `avg_s`。
- `power_mem.csv` 非空。
- 时延随 message size 单调或近似单调增加。

## 7. 完整训练锚点

microbench 只能给状态机参数，必须用真实训练锚点校准最终模型。

至少需要以下完整训练锚点：

- 高吞吐候选：W1、W2、W6 或新模型排序 top 候选。
- 小 batch 问题区域：W7、W8 或同族修正配置。
- 人工基线：W0 或 cfg_09。
- 低功耗/高能效候选：由新版模型选出。
- 显存边界候选：至少 1 个保守可行边界点。

每个锚点要求：

- 25 steps，前 5 steps warmup，后 20 steps 计时。
- `power_mem.csv` 覆盖完整训练窗口。
- `real_tokens.csv` 必须有 25 行且 token 数大于 0。
- 建议关键锚点重复 2 次，用于估计 run-level 方差。

当前回传结果：缺少有效 real token。`real_tokens.csv` 有行但 token 全为 0，必须修复。

## 8. 真实 Token 计数要求

有效 `real_tokens.csv` 必须满足：

- 行数等于训练 step 数，例如 25。
- `tokens_numel_allranks > 0`
- `tokens_nonpad_allranks > 0`
- 第 6-25 步可计算均值。

如果继续使用 no-pad SFT，论文中必须同时输出：

- nominal tokens/s
- effective tokens/s
- nominal tokens/J
- effective tokens/J

`posttrain_gpt_lab_v3.py` 会尝试从 forward/loss/train_step 路径抓取 `loss_mask`，并使用 TP rank 0 去重后再 WORLD all-reduce。若服务器 MindSpeed-LLM 版本改变导致 token 仍为 0，需要优先根据 `train.log` 中的 `[TOKCOUNT]` hook 状态修复入口。

## 9. 最终建模输出

完成标定后，本地模型应生成：

- `energy_state_calibration.json`
- `operator_latency_curves.json`
- `comm_latency_curves.json`
- `power_state_coefficients.json`
- `candidate_metrics_energy_trace.json`
- `pareto_front_energy_trace.json`

每个候选至少输出：

- `pred_step_ms`
- `pred_avg_power_w`
- `pred_energy_j_per_step`
- `pred_tokens_per_j_nominal`
- `pred_tokens_per_j_effective`，如果 real token 可用
- `energy_model_region`
- `calibration_support_n`
- `uncertainty`

## 10. 完成判据

能耗标定可视为完成，必须同时满足：

- idle、compute、memory、comm 四类状态都有有效功耗增量数据。
- compute/memory/comm 均为多 NPU 标定，不是单卡数据混入整机功耗。
- 真实训练锚点能被模型预测，功耗 MAPE <= 5%-8%。
- 能效 MAPE <= 5%-8%。
- real token 计数有效，至少能报告 effective tokens/J。
- 所有数据和脚本可从 GitHub 回放。

本包的 v3 脚本按以上完成判据设计。实际是否完成以服务器回传的 `exit_code.txt`、`bench_metrics.csv`、`power_mem.csv` 和 anchor validation 结果为准。
