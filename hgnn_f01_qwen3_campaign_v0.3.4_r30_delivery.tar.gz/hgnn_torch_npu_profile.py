#!/usr/bin/env python3
"""Install event-driven, in-process torch_npu profiling for MindSpeed-LLM."""

from __future__ import annotations

import json
import os
import time
from pathlib import Path
from typing import Any, Mapping, Optional


ALLOWED_AIC_METRICS = ("ResourceConflictRatio", "MemoryAccess")
MANIFEST_SCHEMA_VERSION = "1.2"


class EventDrivenNpuProfiler:
    """Start and stop one full-window profile from orchestrator commands."""

    def __init__(self, torch_module: Any, torch_npu_module: Any) -> None:
        self._torch = torch_module
        self._torch_npu = torch_npu_module
        self._profile_root = Path(
            os.environ["HGNN_TORCH_NPU_PROFILE_DIR"]
        ).resolve()
        self._control_path = Path(
            os.environ["HGNN_PROFILE_CONTROL_PATH"]
        ).resolve()
        self._run_id = os.environ["HGNN_RUN_ID"]
        self._aic_metric_name = os.environ.get(
            "HGNN_TORCH_NPU_AIC_METRIC",
            "ResourceConflictRatio",
        )
        if self._aic_metric_name not in ALLOWED_AIC_METRICS:
            raise RuntimeError(
                "HGNN_TORCH_NPU_AIC_METRIC must be one of "
                + ", ".join(ALLOWED_AIC_METRICS)
            )
        self._rank = self._distributed_rank()
        self._step = 0
        self._last_command_id = 0
        self._active: Optional[Any] = None
        self._started = False
        self._events: list[dict[str, Any]] = []
        self._profiler_steps = 0
        self._start_step: Optional[int] = None
        self._stop_step: Optional[int] = None
        self._session_metric: Optional[str] = None
        self._session_root: Optional[str] = None
        self._forced_stop = False
        self._segment_id: Optional[str] = None
        self._segment_phase: Optional[str] = None
        self._active_steps_target: Optional[int] = None
        self._segments: list[dict[str, Any]] = []

    def _distributed_rank(self) -> int:
        distributed = self._torch.distributed
        if distributed.is_available() and distributed.is_initialized():
            return int(distributed.get_rank())
        return int(os.environ.get("RANK", "0"))

    def _session_payload(self) -> dict[str, Any]:
        return {
            "metric": self._session_metric or self._aic_metric_name,
            "root": self._session_root
            or str((self._profile_root / self._aic_metric_name).resolve()),
            "start_step": self._start_step,
            "stop_step": self._stop_step,
            "effective_profiler_steps": (
                self._profiler_steps
                if self._start_step is not None
                else None
            ),
            "forced_stop": self._forced_stop,
            "segment_id": self._segment_id,
            "phase": self._segment_phase,
            "active_steps_target": self._active_steps_target,
        }

    def _write_manifest(self, status: str) -> None:
        rank_dir = self._profile_root / f"rank_{self._rank}"
        rank_dir.mkdir(parents=True, exist_ok=True)
        target = rank_dir / "hgnn_profile_plan.json"
        temporary = target.with_suffix(".json.tmp")
        payload = {
            "schema_version": MANIFEST_SCHEMA_VERSION,
            "status": status,
            "run_id": self._run_id,
            "rank": self._rank,
            "control_path": str(self._control_path),
            "aic_metric_name": self._aic_metric_name,
            "trigger_policy": "orchestrator_intervention_events_v1",
            "data_simplification": True,
            "profiler_level": "Level1",
            "export_type": ["Text"],
            "activities": ["NPU"],
            "record_shapes": False,
            "profile_memory": False,
            "with_stack": False,
            "with_modules": False,
            "with_flops": False,
            "l2_cache": False,
            "op_attr": False,
            "record_op_args": False,
            "host_sys": [],
            "sys_io": False,
            "sys_interconnection": True,
            "online_analysis": False,
            "postprocess_policy": "deferred_offline_v1",
            "last_command_id": self._last_command_id,
            "session": self._session_payload(),
            "segments": self._segments,
            "events": self._events,
        }
        temporary.write_text(
            json.dumps(payload, indent=2, sort_keys=True) + "\n",
            encoding="utf-8",
        )
        os.replace(temporary, target)

    def _create_profiler(self) -> Any:
        profiler = self._torch_npu.profiler
        aic_metric = getattr(
            profiler.AiCMetrics,
            self._aic_metric_name,
        )
        experimental_config = profiler._ExperimentalConfig(
            export_type=[profiler.ExportType.Text],
            aic_metrics=aic_metric,
            profiler_level=profiler.ProfilerLevel.Level1,
            mstx=False,
            l2_cache=False,
            op_attr=False,
            data_simplification=True,
            record_op_args=False,
            gc_detect_threshold=None,
            host_sys=[],
            sys_io=False,
            sys_interconnection=True,
        )
        segment = self._segment_id or "full_window"
        session_root = self._profile_root / self._aic_metric_name / segment
        session_root.mkdir(parents=True, exist_ok=True)
        self._session_metric = self._aic_metric_name
        self._session_root = str(session_root.resolve())
        return profiler.profile(
            activities=[profiler.ProfilerActivity.NPU],
            on_trace_ready=profiler.tensorboard_trace_handler(
                str(session_root),
                worker_name=f"rank_{self._rank}",
                analyse_flag=False,
                async_mode=False,
            ),
            record_shapes=False,
            profile_memory=False,
            with_stack=False,
            with_modules=False,
            with_flops=False,
            experimental_config=experimental_config,
        )

    def _load_commands(self) -> tuple[Mapping[str, Any], ...]:
        try:
            payload = json.loads(self._control_path.read_text(encoding="utf-8"))
        except FileNotFoundError:
            return ()
        if not isinstance(payload, Mapping) or payload.get("run_id") != self._run_id:
            raise RuntimeError("invalid profiler control payload or run_id")
        commands = payload.get("commands")
        if not isinstance(commands, list):
            raise RuntimeError("profiler control commands must be a list")
        pending: list[Mapping[str, Any]] = []
        for command in commands:
            if not isinstance(command, Mapping):
                raise RuntimeError("invalid profiler control command")
            command_id = command.get("command_id")
            if not isinstance(command_id, int) or command_id < 1:
                raise RuntimeError("invalid profiler command_id")
            if command_id > self._last_command_id:
                pending.append(command)
        return tuple(sorted(pending, key=lambda item: int(item["command_id"])))

    def _segment_payload(self, event: str, command_id: int) -> dict[str, Any]:
        return {
            "event": event,
            "command_id": command_id,
            "segment_id": self._segment_id,
            "phase": self._segment_phase,
            "after_step": self._step,
            "start_step": self._start_step,
            "stop_step": self._stop_step,
            "effective_profiler_steps": self._profiler_steps,
            "active_steps_target": self._active_steps_target,
            "monotonic_ns": time.monotonic_ns(),
        }

    def _stop_active(self, *, event: str, status: str, command_id: int) -> None:
        if self._active is None:
            return
        self._active.stop()
        self._active = None
        self._stop_step = self._step
        payload = self._segment_payload(event, command_id)
        self._events.append(payload)
        self._segments.append(
            {
                "segment_id": self._segment_id,
                "phase": self._segment_phase,
                "start_step": self._start_step,
                "stop_step": self._stop_step,
                "effective_profiler_steps": self._profiler_steps,
                "active_steps_target": self._active_steps_target,
                "status": status,
                "session_root": self._session_root,
            }
        )
        self._write_manifest(status)

    def _apply_command(self, command: Mapping[str, Any]) -> None:
        command_id = int(command["command_id"])
        action = command.get("command")
        if action == "start":
            if self._active is not None:
                raise RuntimeError("duplicate profiler start command")
            self._forced_stop = False
            self._segment_id = str(command.get("segment_id") or f"segment_{command_id}")
            self._segment_phase = str(command.get("phase") or self._segment_id)
            active_steps = command.get("active_steps")
            self._active_steps_target = (
                int(active_steps) if active_steps is not None else None
            )
            if self._active_steps_target is not None and self._active_steps_target < 1:
                raise RuntimeError("active_steps must be positive")
            self._start_step = self._step
            self._stop_step = None
            self._profiler_steps = 0
            self._active = self._create_profiler()
            self._active.start()
            status = "recording"
        elif action == "stop":
            if self._active is None:
                raise RuntimeError("profiler stop command arrived before start")
            self._last_command_id = command_id
            self._stop_active(
                event="session_stopped",
                status="complete",
                command_id=command_id,
            )
            status = "complete"
        else:
            raise RuntimeError(f"unsupported profiler command: {action!r}")
        self._last_command_id = command_id
        if action == "start":
            event = self._segment_payload("session_started", command_id)
            event["orchestrator_monotonic_ns"] = command.get("monotonic_ns")
            event["orchestrator_utc_ns"] = command.get("utc_ns")
            self._events.append(event)
            self._write_manifest(status)

    def start(self) -> None:
        if self._started:
            return
        self._profile_root.mkdir(parents=True, exist_ok=True)
        self._started = True
        self._write_manifest("armed")

    def step(self) -> None:
        if not self._started:
            raise RuntimeError("event-driven NPU profiler was not armed")
        self._step += 1
        for command in self._load_commands():
            self._apply_command(command)
        if self._active is not None:
            self._active.step()
            self._profiler_steps += 1
            if (
                self._active_steps_target is not None
                and self._profiler_steps >= self._active_steps_target
            ):
                self._stop_active(
                    event="session_auto_stopped",
                    status="complete",
                    command_id=self._last_command_id,
                )

    def stop(self) -> None:
        if not self._started:
            return
        if self._active is not None:
            self._forced_stop = True
            self._stop_active(
                event="session_forced_stopped",
                status="forced_stop",
                command_id=self._last_command_id,
            )
        self._started = False


def install_event_driven_profiler() -> None:
    """Replace MindSpeed's profiler with an orchestrator-controlled instance."""

    import torch
    import torch_npu
    from mindspeed_llm.training import training as mindspeed_training

    missing = [
        name
        for name in ALLOWED_AIC_METRICS
        if not hasattr(torch_npu.profiler.AiCMetrics, name)
    ]
    if missing:
        raise RuntimeError(
            "torch_npu profiler is missing required AI Core metrics: "
            + ", ".join(missing)
        )
    required_environment = (
        "HGNN_RUN_ID",
        "HGNN_TORCH_NPU_PROFILE_DIR",
        "HGNN_PROFILE_CONTROL_PATH",
    )
    missing_environment = [
        name for name in required_environment if not os.environ.get(name)
    ]
    if missing_environment:
        raise RuntimeError(
            "missing profiler environment: " + ", ".join(missing_environment)
        )

    def get_hgnn_profiler() -> EventDrivenNpuProfiler:
        return EventDrivenNpuProfiler(torch, torch_npu)

    mindspeed_training.get_profiler = get_hgnn_profiler
