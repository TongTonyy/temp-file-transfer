#!/usr/bin/env python3
"""Delete one raw profiler run only after group extraction is complete."""

from __future__ import annotations

import argparse
import json
import shutil
import time
from pathlib import Path
from typing import Any, Mapping, Sequence

from torch_npu_offline_common import atomic_json, load_json, sha256


def _regular_file_size(root: Path) -> tuple[int, int]:
    files = 0
    bytes_total = 0
    for path in root.rglob("*"):
        if path.is_symlink():
            raise SystemExit(f"raw profile contains symlink: {path}")
        if path.is_file():
            files += 1
            bytes_total += path.stat().st_size
    return files, bytes_total


def _safe_profile_root(root: Path, profile_root: Path, run_id: str) -> Path:
    runtime_profiles = (root / "runtime/profiles").resolve(strict=True)
    resolved = profile_root.resolve(strict=True)
    if profile_root.is_symlink() or resolved.is_symlink():
        raise SystemExit(f"refusing to delete symlink profile root: {profile_root}")
    if resolved == runtime_profiles:
        raise SystemExit("refusing to delete runtime/profiles itself")
    if not resolved.is_relative_to(runtime_profiles):
        raise SystemExit(f"profile root escaped runtime/profiles: {resolved}")
    if resolved.name != run_id:
        raise SystemExit(
            f"profile root basename {resolved.name!r} does not match run_id {run_id!r}"
        )
    return resolved


def _verify_group_manifest(
    group_manifest: Path,
    extraction_root: Path,
    run_id: str,
) -> Mapping[str, Any]:
    manifest = load_json(group_manifest.resolve(strict=True))
    if manifest.get("status") != "complete":
        raise SystemExit("group manifest is not complete")
    if manifest.get("run_id") != run_id:
        raise SystemExit("group manifest run_id mismatch")
    for key, accepted in (
        ("inventory_report", {"collection_complete"}),
        ("parse_report", {"complete"}),
        ("schema_report", {"pass"}),
    ):
        report_text = str(manifest.get(key, "")).strip()
        if not report_text:
            raise SystemExit(f"group manifest missing {key}")
        report_path = Path(report_text).resolve(strict=True)
        report = load_json(report_path)
        if report.get("status") not in accepted:
            raise SystemExit(f"{key} did not pass: {report_path}")
    reports = manifest.get("rank_reports")
    if not isinstance(reports, list) or len(reports) != 16:
        raise SystemExit("group manifest must contain 16 rank reports")
    for rank, text in enumerate(reports):
        report_path = Path(str(text)).resolve(strict=True)
        if not report_path.is_relative_to(extraction_root.resolve(strict=False)):
            raise SystemExit(f"rank report escaped extraction root: {report_path}")
        report = load_json(report_path)
        if (
            report.get("status") != "complete"
            or report.get("run_id") != run_id
            or int(report.get("rank", -1)) != rank
        ):
            raise SystemExit(f"rank {rank} report is not complete")
        outputs = report.get("outputs")
        if not isinstance(outputs, list) or not outputs:
            raise SystemExit(f"rank {rank} report has no outputs")
        for item in outputs:
            output = Path(str(item.get("path", ""))).resolve(strict=True)
            if not output.is_relative_to(extraction_root.resolve(strict=False)):
                raise SystemExit(f"rank {rank} output escaped extraction root")
            if output.stat().st_size != item.get("size_bytes"):
                raise SystemExit(f"rank {rank} output size mismatch")
            if sha256(output) != item.get("sha256"):
                raise SystemExit(f"rank {rank} output sha256 mismatch")
    return manifest


def copy_profile_plans(
    profile_root: Path,
    output_root: Path,
    *,
    require_all: bool = True,
) -> list[Mapping[str, Any]]:
    copied: list[Mapping[str, Any]] = []
    for rank in range(16):
        source = profile_root / f"rank_{rank}/hgnn_profile_plan.json"
        if not source.is_file() or source.is_symlink():
            if not require_all:
                continue
            raise SystemExit(f"missing profile plan before cleanup: {source}")
        target = output_root / f"rank_{rank}/hgnn_profile_plan.json"
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(source, target)
        copied.append(
            {
                "rank": rank,
                "path": str(target),
                "size_bytes": target.stat().st_size,
                "sha256": sha256(target),
            }
        )
    return copied


def cleanup_raw_profile(
    *,
    root: Path,
    profile_root: Path,
    extraction_root: Path,
    group_manifest: Path,
    run_id: str,
    profile_plans_output: Path,
    cleanup_report: Path,
    dry_run: bool = False,
    failed_attempt: bool = False,
    failure_reason: str = "",
) -> Mapping[str, Any]:
    started = time.monotonic()
    root = root.resolve(strict=True)
    extraction_root = extraction_root.resolve(strict=False)
    safe_profile_root = _safe_profile_root(root, profile_root, run_id)
    if failed_attempt:
        group: Mapping[str, Any] = {
            "key": "",
            "run_id": run_id,
            "status": "excluded_failed_attempt",
        }
    else:
        group = _verify_group_manifest(group_manifest, extraction_root, run_id)
    file_count, bytes_total = _regular_file_size(safe_profile_root)
    plans = copy_profile_plans(
        safe_profile_root,
        profile_plans_output,
        require_all=not failed_attempt,
    )
    deleted = False
    if not dry_run:
        shutil.rmtree(safe_profile_root)
        deleted = not safe_profile_root.exists()
        if not deleted:
            raise SystemExit(f"raw profile still exists after cleanup: {safe_profile_root}")
    report = {
        "schema_version": "r28.raw_cleanup.v1",
        "status": "complete" if deleted or dry_run else "failed",
        "cleanup_kind": "failed_attempt" if failed_attempt else "complete_group",
        "dry_run": dry_run,
        "run_id": run_id,
        "key": group.get("key"),
        "failure_reason": failure_reason,
        "profile_root": str(safe_profile_root),
        "raw_file_count": file_count,
        "raw_bytes_deleted": 0 if dry_run else bytes_total,
        "raw_bytes_observed": bytes_total,
        "profile_plans_output": str(profile_plans_output),
        "profile_plans": plans,
        "group_manifest": (
            str(group_manifest.resolve(strict=True))
            if group_manifest.exists()
            else ""
        ),
        "elapsed_s": time.monotonic() - started,
    }
    atomic_json(cleanup_report, report)
    print(f"R28_RAW_CLEANUP_REPORT={cleanup_report}")
    print(f"RAW_PROFILE_DELETED={1 if deleted else 0}")
    print(f"R28_RAW_BYTES_DELETED={report['raw_bytes_deleted']}")
    return report


def main(argv: Sequence[str] | None = None) -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", type=Path, required=True)
    parser.add_argument("--profile-root", type=Path, required=True)
    parser.add_argument("--extraction-root", type=Path, required=True)
    parser.add_argument("--group-manifest", type=Path, required=True)
    parser.add_argument("--run-id", required=True)
    parser.add_argument("--profile-plans-output", type=Path, required=True)
    parser.add_argument("--cleanup-report", type=Path, required=True)
    parser.add_argument("--dry-run", action="store_true")
    parser.add_argument("--failed-attempt", action="store_true")
    parser.add_argument("--failure-reason", default="")
    args = parser.parse_args(argv)
    report = cleanup_raw_profile(
        root=args.root,
        profile_root=args.profile_root,
        extraction_root=args.extraction_root,
        group_manifest=args.group_manifest,
        run_id=args.run_id,
        profile_plans_output=args.profile_plans_output,
        cleanup_report=args.cleanup_report,
        dry_run=args.dry_run,
        failed_attempt=args.failed_attempt,
        failure_reason=args.failure_reason,
    )
    return 0 if report["status"] == "complete" else 2


if __name__ == "__main__":
    raise SystemExit(main())
