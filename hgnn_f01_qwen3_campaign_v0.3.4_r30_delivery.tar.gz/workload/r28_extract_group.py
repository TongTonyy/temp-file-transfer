#!/usr/bin/env python3
"""Extract one 16-rank profiler group immediately after CANN export."""

from __future__ import annotations

import argparse
import json
import os
import time
from concurrent.futures import Future, ThreadPoolExecutor, as_completed
from pathlib import Path
from typing import Any, Mapping, Sequence

from extract_r25_real_csv_metrics import (
    process_session,
    update_metric_coverage,
)
from torch_npu_offline_common import (
    atomic_json,
    load_json,
    load_profile_sessions,
)

EXPECTED_RANKS = 16


def _complete_report(path: Path) -> Mapping[str, Any] | None:
    if not path.is_file() or path.is_symlink():
        return None
    try:
        report = load_json(path)
    except (OSError, ValueError, json.JSONDecodeError):
        return None
    return report if report.get("status") == "complete" else None


def group_reports_complete(
    output_root: Path,
    run_id: str,
) -> list[Mapping[str, Any]] | None:
    reports: list[Mapping[str, Any]] = []
    for rank in range(EXPECTED_RANKS):
        report = _complete_report(
            output_root / run_id / f"rank_{rank}" / "r25_session_report.json"
        )
        if report is None:
            return None
        reports.append(report)
    return reports


def sanitize_session_report(report: Mapping[str, Any], report_path: Path) -> Mapping[str, Any]:
    """Keep extraction evidence while removing raw profiler paths from packaged JSON."""

    sanitized = dict(report)
    for key in (
        "session",
        "source_inventory",
        "summary_marker",
        "r23_session_report",
        "clock_anchors",
    ):
        sanitized.pop(key, None)
    schema = sanitized.get("schema")
    if isinstance(schema, Mapping):
        redacted_schema = dict(schema)
        files = redacted_schema.pop("files", None)
        if isinstance(files, list):
            redacted_schema["file_count"] = len(files)
        sanitized["schema"] = redacted_schema
    sanitized["raw_profiler_paths_redacted"] = True
    atomic_json(report_path, sanitized)
    return sanitized


def extract_group(
    *,
    profile_root: Path,
    output_root: Path,
    run_id: str,
    key: str,
    condition: str,
    metric: str,
    pair: str | None,
    attempt: int,
    max_workers: int,
    trust_complete_reports: bool,
    inventory_report: Path | None = None,
    parse_report: Path | None = None,
    schema_report: Path | None = None,
) -> Mapping[str, Any]:
    if not 1 <= max_workers <= 16:
        raise SystemExit("max-workers must be between 1 and 16")
    started = time.monotonic()
    profile_root = profile_root.resolve(strict=True)
    output_root = output_root.resolve(strict=False)
    sessions = load_profile_sessions(profile_root, metric)
    if set(sessions) != set(range(EXPECTED_RANKS)):
        raise SystemExit("profile sessions must cover ranks 0..15")

    reports = group_reports_complete(output_root, run_id)
    if reports is not None and trust_complete_reports:
        reports = [
            sanitize_session_report(
                report,
                output_root / run_id / f"rank_{int(report['rank'])}" / "r25_session_report.json",
            )
            for report in reports
        ]
        status = "complete"
    else:
        reports = []
        futures: dict[Future[Mapping[str, Any]], int] = {}
        with ThreadPoolExecutor(max_workers=max_workers) as executor:
            for rank, session in sorted(sessions.items()):
                future = executor.submit(
                    process_session,
                    output_root,
                    run_id,
                    metric,
                    rank,
                    session,
                    output_root,
                    trust_complete_reports,
                )
                futures[future] = rank
            for future in as_completed(futures):
                rank = futures[future]
                report = future.result()
                report = sanitize_session_report(
                    report,
                    output_root / run_id / f"rank_{int(report['rank'])}" / "r25_session_report.json",
                )
                reports.append(report)
                print(
                    "R28_GROUP_EXTRACT_PROGRESS="
                    f"{len(reports)}/16 run_id={run_id} rank={rank} "
                    f"status={report.get('status')} "
                    f"backend={report.get('backend', 'unknown')}",
                    flush=True,
                )
        reports = sorted(reports, key=lambda row: int(row["rank"]))
        status = (
            "complete"
            if [int(row["rank"]) for row in reports if row.get("status") == "complete"]
            == list(range(EXPECTED_RANKS))
            else "partial"
        )

    progress_path = output_root / "r25_extraction_progress.json"
    progress: dict[str, Any] = {
        "schema_version": "r28.group_extraction_progress.v1",
        "status": "running",
        "expected_session_count": 64,
        "sessions": {},
    }
    if progress_path.is_file():
        existing = load_json(progress_path)
        if isinstance(existing.get("sessions"), Mapping):
            progress.update(existing)
            progress["status"] = "running"
    for report in reports:
        progress.setdefault("sessions", {})[
            f"{run_id}/rank_{int(report['rank'])}"
        ] = report
    complete_count = sum(
        1
        for row in progress.get("sessions", {}).values()
        if isinstance(row, Mapping) and row.get("status") == "complete"
    )
    progress["complete_session_count"] = complete_count
    progress["status"] = "complete" if complete_count == 64 else "partial"
    atomic_json(progress_path, progress)

    group_manifest = {
        "schema_version": "r28.group_extraction.v1",
        "status": status,
        "run_id": run_id,
        "key": key,
        "condition": condition,
        "metric": metric,
        "pair": pair,
        "attempt": attempt,
        "profile_root": "",
        "profile_root_deleted_after_group_gate": True,
        "output_root": str(output_root / run_id),
        "expected_rank_count": EXPECTED_RANKS,
        "complete_rank_count": sum(row.get("status") == "complete" for row in reports),
        "rank_reports": [
            str(output_root / run_id / f"rank_{int(row['rank'])}" / "r25_session_report.json")
            for row in reports
        ],
        "rank_session_count": len(sessions),
        "inventory_report": str(inventory_report) if inventory_report else "",
        "parse_report": str(parse_report) if parse_report else "",
        "schema_report": str(schema_report) if schema_report else "",
        "elapsed_s": time.monotonic() - started,
    }
    groups_root = output_root / "groups"
    group_path = groups_root / f"{key}.json"
    atomic_json(group_path, group_manifest)
    dataset_manifest = {
        "schema_version": "r28.extraction_manifest.v1",
        "status": "complete" if complete_count == 64 else "partial",
        "expected_session_count": 64,
        "complete_session_count": complete_count,
        "groups": sorted(str(path) for path in groups_root.glob("*.json")),
    }
    atomic_json(output_root / "dataset_extraction_manifest.json", dataset_manifest)
    print(f"R28_GROUP_EXTRACTION_MANIFEST={group_path}")
    print(f"R28_GROUP_EXTRACT_STATUS={status}")
    return group_manifest


def main(argv: Sequence[str] | None = None) -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--profile-root", type=Path, required=True)
    parser.add_argument("--output-root", type=Path, required=True)
    parser.add_argument("--run-id", required=True)
    parser.add_argument("--key", required=True)
    parser.add_argument("--condition", required=True)
    parser.add_argument("--metric", required=True)
    parser.add_argument("--pair", default=None)
    parser.add_argument("--attempt", type=int, default=1)
    parser.add_argument("--max-workers", type=int, default=8)
    parser.add_argument("--metric-coverage", type=Path)
    parser.add_argument("--inventory-report", type=Path)
    parser.add_argument("--parse-report", type=Path)
    parser.add_argument("--schema-report", type=Path)
    parser.add_argument("--trust-complete-reports", action="store_true")
    args = parser.parse_args(argv)

    manifest = extract_group(
        profile_root=args.profile_root,
        output_root=args.output_root,
        run_id=args.run_id,
        key=args.key,
        condition=args.condition,
        metric=args.metric,
        pair=args.pair or None,
        attempt=args.attempt,
        max_workers=args.max_workers,
        trust_complete_reports=args.trust_complete_reports,
        inventory_report=args.inventory_report,
        parse_report=args.parse_report,
        schema_report=args.schema_report,
    )
    if args.metric_coverage is not None:
        reports = [
            load_json(Path(path))
            for path in manifest["rank_reports"]
            if Path(path).is_file()
        ]
        update_metric_coverage(args.metric_coverage.resolve(strict=True), reports)
    return 0 if manifest["status"] == "complete" else 2


if __name__ == "__main__":
    raise SystemExit(main())
