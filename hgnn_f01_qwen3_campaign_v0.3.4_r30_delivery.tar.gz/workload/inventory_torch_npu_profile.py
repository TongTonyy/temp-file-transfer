#!/usr/bin/env python3
"""Validate raw torch_npu profile sessions without parsing trace contents."""

from __future__ import annotations

import argparse
import json
import os
import re
import statistics
from pathlib import Path
from typing import Any, Mapping


GATE_MODES = {
    "formal": {
        "min_effective_steps": 100,
        "profile_window_min_s": 240.0,
        "profile_window_max_s": 360.0,
        "max_step_spread": 1,
        "min_raw_bytes": 128,
    },
    "canary": {
        "min_effective_steps": 3,
        "profile_window_min_s": 0.0,
        "profile_window_max_s": 720.0,
        "max_step_spread": 5,
        "min_raw_bytes": 64,
    },
}


def atomic_json(path: Path, value: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(
        json.dumps(value, ensure_ascii=False, indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )
    os.replace(temporary, path)


def raw_session_stats(root: Path) -> tuple[int, int]:
    file_count = 0
    total_bytes = 0
    for directory, dirnames, filenames in os.walk(root, followlinks=False):
        directory_path = Path(directory)
        for name in dirnames:
            if (directory_path / name).is_symlink():
                raise SystemExit(f"raw profile contains symlink directory: {name}")
        for name in filenames:
            path = directory_path / name
            try:
                if path.is_symlink():
                    raise SystemExit(f"raw profile contains symlink file: {path}")
                if path.is_file():
                    size = path.stat().st_size
                    if size > 0:
                        file_count += 1
                        total_bytes += size
            except FileNotFoundError:
                continue
    return file_count, total_bytes


def _event_by_name(events: list[Any], name: str) -> Mapping[str, Any] | None:
    for item in events:
        if isinstance(item, Mapping) and item.get("event") == name:
            return item
    return None


def session_timing(plan: Mapping[str, Any]) -> tuple[float, int, int, int]:
    """Return duration_s, start_step, stop_step, effective_profiler_steps."""

    session = plan.get("session")
    if isinstance(session, Mapping):
        start_step = session.get("start_step")
        stop_step = session.get("stop_step")
        effective = session.get("effective_profiler_steps")
        if (
            isinstance(start_step, int)
            and isinstance(stop_step, int)
            and isinstance(effective, int)
        ):
            events = plan.get("events")
            events_list = events if isinstance(events, list) else []
            started = _event_by_name(events_list, "session_started")
            stopped = _event_by_name(events_list, "session_stopped")
            if stopped is None:
                stopped = _event_by_name(events_list, "session_forced_stopped")
            if (
                started is not None
                and stopped is not None
                and isinstance(started.get("monotonic_ns"), int)
                and isinstance(stopped.get("monotonic_ns"), int)
            ):
                duration = (
                    stopped["monotonic_ns"] - started["monotonic_ns"]
                ) / 1e9
                return duration, start_step, stop_step, effective
            return 0.0, start_step, stop_step, effective

    events = plan.get("events")
    if not isinstance(events, list):
        raise SystemExit("profile plan missing session timing and events")
    started = _event_by_name(events, "session_started")
    stopped = _event_by_name(events, "session_stopped")
    if stopped is None:
        stopped = _event_by_name(events, "session_forced_stopped")
    if started is None or stopped is None:
        raise SystemExit("profile plan missing start/stop events")
    start_step = int(started.get("after_step", -1))
    stop_step = int(stopped.get("after_step", -1))
    effective = max(0, stop_step - start_step)
    duration = (
        int(stopped["monotonic_ns"]) - int(started["monotonic_ns"])
    ) / 1e9
    return duration, start_step, stop_step, effective


def apply_mode_defaults(args: argparse.Namespace) -> None:
    preset = GATE_MODES[args.mode]
    if args.min_effective_steps is None:
        args.min_effective_steps = preset["min_effective_steps"]
    if args.profile_window_min_s is None:
        args.profile_window_min_s = preset["profile_window_min_s"]
    if args.profile_window_max_s is None:
        args.profile_window_max_s = preset["profile_window_max_s"]
    if args.max_step_spread is None:
        args.max_step_spread = preset["max_step_spread"]
    if args.min_raw_bytes is None:
        args.min_raw_bytes = preset["min_raw_bytes"]


def main() -> int:
    parser = argparse.ArgumentParser(
        description=(
            "Collection-only torch_npu profile inventory gate. "
            "Does not validate PMU/CSV schema completeness."
        )
    )
    parser.add_argument("--input-root", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--metric", required=True)
    parser.add_argument("--expected-ranks", type=int, default=16)
    parser.add_argument(
        "--mode",
        choices=sorted(GATE_MODES),
        default="formal",
        help="formal uses production thresholds; canary allows lower step counts",
    )
    parser.add_argument("--min-effective-steps", type=int, default=None)
    parser.add_argument("--profile-window-min-s", type=float, default=None)
    parser.add_argument("--profile-window-max-s", type=float, default=None)
    parser.add_argument("--max-step-spread", type=int, default=None)
    parser.add_argument("--min-raw-bytes", type=int, default=None)
    args = parser.parse_args()
    apply_mode_defaults(args)

    source_root = args.input_root.resolve(strict=True)
    output = args.output.resolve(strict=False)
    if output.is_relative_to(source_root):
        raise SystemExit("inventory output must be outside the raw trace root")
    if args.expected_ranks < 1:
        raise SystemExit("expected-ranks must be positive")
    if args.metric not in {"ResourceConflictRatio", "MemoryAccess"}:
        raise SystemExit("unsupported profiler metric")
    if args.min_effective_steps < 0:
        raise SystemExit("min-effective-steps must be non-negative")
    if args.max_step_spread < 0:
        raise SystemExit("max-step-spread must be non-negative")
    if args.min_raw_bytes < 1:
        raise SystemExit("min-raw-bytes must be positive")
    if args.profile_window_min_s < 0 or args.profile_window_max_s < 0:
        raise SystemExit("profile window bounds must be non-negative")
    if args.profile_window_min_s > args.profile_window_max_s:
        raise SystemExit("profile-window-min-s must not exceed profile-window-max-s")

    metric_root = source_root / args.metric
    if not metric_root.is_dir() or metric_root.is_symlink():
        raise SystemExit(f"missing raw metric root: {metric_root}")
    session_pattern = re.compile(r"^rank_(\d+)_.*_ascend_pt$")
    sessions: dict[int, list[Path]] = {
        rank: [] for rank in range(args.expected_ranks)
    }
    for path in metric_root.iterdir():
        match = session_pattern.fullmatch(path.name)
        if match is None or not path.is_dir() or path.is_symlink():
            continue
        rank = int(match.group(1))
        if rank in sessions:
            sessions[rank].append(path)

    rank_rows: list[dict[str, Any]] = []
    start_steps: list[int] = []
    stop_steps: list[int] = []
    effective_steps: list[int] = []
    durations: list[float] = []

    for rank in range(args.expected_ranks):
        plan_path = source_root / f"rank_{rank}/hgnn_profile_plan.json"
        plan = json.loads(plan_path.read_text(encoding="utf-8"))
        plan_status = plan.get("status")
        allowed_status = {"complete", "forced_stop"}
        last_command_id = plan.get("last_command_id")
        command_ok = (
            last_command_id == 1
            if plan_status == "forced_stop"
            else last_command_id == 2
        )
        checks = {
            "rank": plan.get("rank") == rank,
            "status": plan_status in allowed_status,
            "last_command_id": command_ok,
            "metric": plan.get("aic_metric_name") == args.metric,
            "data_simplification": plan.get("data_simplification") is True,
            "online_analysis_disabled": plan.get("online_analysis") is False,
            "postprocess_deferred": (
                plan.get("postprocess_policy") == "deferred_offline_v1"
            ),
        }
        failed = sorted(name for name, passed in checks.items() if not passed)
        if failed:
            raise SystemExit(
                f"rank {rank} profile plan failed: {', '.join(failed)}"
            )
        if len(sessions[rank]) != 1:
            raise SystemExit(
                f"rank {rank} expected one raw session, observed "
                f"{len(sessions[rank])}"
            )
        session = sessions[rank][0]
        raw_file_count, raw_bytes_total = raw_session_stats(session)
        if raw_file_count == 0 or raw_bytes_total < args.min_raw_bytes:
            raise SystemExit(
                f"rank {rank} raw session insufficient: files={raw_file_count}, "
                f"bytes={raw_bytes_total}, min_bytes={args.min_raw_bytes}"
            )

        duration_s, start_step, stop_step, effective = session_timing(plan)
        if effective < args.min_effective_steps:
            raise SystemExit(
                f"rank {rank} effective_profiler_steps={effective} "
                f"< min={args.min_effective_steps}"
            )
        if not (
            args.profile_window_min_s
            <= duration_s
            <= args.profile_window_max_s
        ):
            raise SystemExit(
                f"rank {rank} profile duration {duration_s:.3f}s outside "
                f"[{args.profile_window_min_s}, {args.profile_window_max_s}]"
            )

        start_steps.append(start_step)
        stop_steps.append(stop_step)
        effective_steps.append(effective)
        durations.append(duration_s)
        rank_rows.append(
            {
                "rank": rank,
                "plan": str(plan_path),
                "raw_session_root": str(session),
                "raw_trace_present": True,
                "raw_file_count": raw_file_count,
                "raw_bytes_total": raw_bytes_total,
                "start_step": start_step,
                "stop_step": stop_step,
                "effective_profiler_steps": effective,
                "profile_duration_s": duration_s,
                "status": plan.get("status"),
            }
        )

    start_spread = max(start_steps) - min(start_steps)
    stop_spread = max(stop_steps) - min(stop_steps)
    if start_spread > args.max_step_spread:
        raise SystemExit(
            f"start_step spread {start_spread} exceeds max={args.max_step_spread}"
        )
    if stop_spread > args.max_step_spread:
        raise SystemExit(
            f"stop_step spread {stop_spread} exceeds max={args.max_step_spread}"
        )

    atomic_json(
        output,
        {
            "schema_version": "1.1",
            "report_type": "torch_npu_raw_collection_inventory",
            "gate_kind": "collection_only",
            "pmu_schema_complete": False,
            "status": "collection_complete",
            "analysis_status": "not_started",
            "mode": args.mode,
            "thresholds": {
                "min_effective_steps": args.min_effective_steps,
                "profile_window_min_s": args.profile_window_min_s,
                "profile_window_max_s": args.profile_window_max_s,
                "max_step_spread": args.max_step_spread,
                "min_raw_bytes": args.min_raw_bytes,
            },
            "input_root": str(source_root),
            "aic_metric_name": args.metric,
            "rank_count": len(rank_rows),
            "data_simplification": True,
            "online_analysis": False,
            "postprocess_policy": "separate_offline_stage",
            "cross_rank": {
                "start_step_min": min(start_steps),
                "start_step_max": max(start_steps),
                "start_step_spread": start_spread,
                "stop_step_min": min(stop_steps),
                "stop_step_max": max(stop_steps),
                "stop_step_spread": stop_spread,
                "effective_steps_min": min(effective_steps),
                "effective_steps_max": max(effective_steps),
                "effective_steps_mean": statistics.mean(effective_steps),
                "profile_duration_min_s": min(durations),
                "profile_duration_max_s": max(durations),
                "profile_duration_mean_s": statistics.mean(durations),
            },
            "ranks": rank_rows,
        },
    )
    print(f"PROFILE_INVENTORY={output}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
