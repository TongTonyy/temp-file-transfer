#!/usr/bin/env python3
"""R27 selective recapture progress and dataset manifest helper."""

from __future__ import annotations

import argparse
import json
import os
from pathlib import Path
from typing import Any, Mapping, Sequence

from audit_r25_extraction_contract import (
    AFFECTED_RECOLLECTION_KEYS,
    REUSABLE_IF_ALL_VERIFIED_KEY,
)
from prepare_r23_extraction_contract import (
    EXPECTED_CASE_SPECS,
    validate_manifest_entry,
)
from torch_npu_offline_common import atomic_json, load_json

SCHEMA_VERSION = "r27.progress.v1"
DATASET_SCHEMA_VERSION = "r27.dataset_manifest.v1"
MAX_ATTEMPTS = 2

CANARY_CASES = (
    {
        "key": "canary_resource_conflict",
        "condition": "manual_baseline_sham",
        "metric": "ResourceConflictRatio",
        "drawer": "drawer0",
        "phase": "canary",
    },
    {
        "key": "canary_memory_access",
        "condition": "manual_baseline_sham",
        "metric": "MemoryAccess",
        "drawer": "drawer0",
        "phase": "canary",
    },
)

FORMAL_SCRIPT_BY_CONDITION = {
    "manual_baseline_sham": "20_manual_sham_training.sh",
    "drawer0_s1": "30_drawer0_training.sh",
}

CANARY_TIMING = {
    "duration": 180,
    "baseline": 36,
    "release_at": 126,
    "inventory_mode": "canary",
}

FORMAL_TIMING = {
    "duration": 600,
    "baseline": 120,
    "release_at": 420,
    "inventory_mode": "formal",
}


MOCK_PROFILER_TIMESTAMP_US = 150_000_000


def mock_profiler_timestamp_us(
    *, baseline_s: float, release_at_s: float
) -> int:
    midpoint = baseline_s + (release_at_s - baseline_s) / 2.0
    return int(midpoint * 1_000_000)


def load_progress(path: Path) -> Mapping[str, Any]:
    return load_json(path.resolve(strict=True))


def resolve_campaign_id(progress_path: Path, default_campaign_id: str) -> str:
    if progress_path.is_file():
        existing = load_progress(progress_path)
        campaign_id = str(existing.get("campaign_id", "")).strip()
        if campaign_id:
            return campaign_id
    return default_campaign_id


def discover_telemetry_root(root: Path, run_id: str) -> str:
    direct = root / "runtime/data" / run_id
    if direct.is_dir():
        return str(direct.resolve(strict=True))
    data_root = root / "runtime/data"
    if data_root.is_dir():
        matches = sorted(
            candidate
            for candidate in data_root.rglob(run_id)
            if candidate.is_dir()
            and not candidate.is_symlink()
            and candidate.name == run_id
        )
        if len(matches) == 1:
            return str(matches[0].resolve(strict=True))
        if len(matches) > 1:
            raise ValueError(f"ambiguous telemetry roots for {run_id}: {matches}")
    raise ValueError(f"telemetry root not found for run_id={run_id}")


def save_progress(path: Path, payload: Mapping[str, Any]) -> None:
    atomic_json(path.resolve(strict=False), dict(payload))


def run_id_for(campaign_id: str, key: str, attempt: int) -> str:
    return f"{campaign_id}-{key}-a{attempt}"


def _empty_run_row() -> dict[str, Any]:
    return {
        "status": "pending",
        "attempt": 0,
        "run_id": "",
        "rank_progress": {},
        "detail": "",
    }


def _case_plan() -> list[dict[str, Any]]:
    plan: list[dict[str, Any]] = []
    for case in CANARY_CASES:
        plan.append({**case, "pair": None, "script": "20_manual_sham_training.sh"})
    for key in AFFECTED_RECOLLECTION_KEYS:
        spec = EXPECTED_CASE_SPECS[key]
        plan.append(
            {
                "key": key,
                "condition": spec["condition"],
                "metric": spec["metric"],
                "pair": spec["pair"],
                "drawer": "drawer0",
                "phase": "formal",
                "script": FORMAL_SCRIPT_BY_CONDITION[spec["condition"]],
            }
        )
    reusable = EXPECTED_CASE_SPECS[REUSABLE_IF_ALL_VERIFIED_KEY]
    plan.append(
        {
            "key": REUSABLE_IF_ALL_VERIFIED_KEY,
            "condition": reusable["condition"],
            "metric": reusable["metric"],
            "pair": reusable["pair"],
            "drawer": "drawer0",
            "phase": "formal_optional",
            "script": FORMAL_SCRIPT_BY_CONDITION[reusable["condition"]],
        }
    )
    return plan


def initialize_progress(
    *,
    campaign_id: str,
    source_campaign_id: str,
    source_dataset_manifest: Path,
    audit_report: Mapping[str, Any],
) -> dict[str, Any]:
    source_manifest = load_json(source_dataset_manifest)
    merge_plan = audit_report["merge_plan"]
    reuse_control_memory = bool(merge_plan["reused_16"]["verified"])
    source_entries = {
        str(entry["key"]): entry for entry in source_manifest.get("entries", [])
    }
    runs: dict[str, Any] = {case["key"]: _empty_run_row() for case in _case_plan()}
    if reuse_control_memory:
        reused = source_entries[REUSABLE_IF_ALL_VERIFIED_KEY]
        runs[REUSABLE_IF_ALL_VERIFIED_KEY] = {
            "status": "reused",
            "attempt": 0,
            "run_id": str(reused["run_id"]),
            "rank_progress": {str(rank): "reused" for rank in range(16)},
            "detail": "reused_from_source_manifest_16_of_16",
            "profile_root": str(reused.get("profile_root", "")),
            "telemetry_root": str(
                reused.get("telemetry_root")
                or (reused.get("validation") or {}).get("telemetry_root", "")
            ),
        }
    return {
        "schema_version": SCHEMA_VERSION,
        "status": "running",
        "campaign_id": campaign_id,
        "source_campaign_id": source_campaign_id,
        "source_dataset_manifest": str(source_dataset_manifest.resolve(strict=True)),
        "audit_report": str(audit_report.get("dataset_manifest", "")),
        "plan": _case_plan(),
        "reuse_control_memory": reuse_control_memory,
        "merge_mode": (
            "new48_reused16" if reuse_control_memory else "new64"
        ),
        "excluded_old_groups": audit_report.get("excluded_old_groups", []),
        "canary_gate_status": "pending",
        "canary_passed": False,
        "runs": runs,
    }


def merge_resume(existing: Mapping[str, Any], fresh: Mapping[str, Any]) -> dict[str, Any]:
    if existing.get("schema_version") != SCHEMA_VERSION:
        raise ValueError("incompatible r27 progress schema")
    if existing.get("campaign_id") != fresh.get("campaign_id"):
        # resume keeps the existing campaign id; fresh may carry a new stamp.
        pass
    if existing.get("plan") != fresh.get("plan"):
        raise ValueError("plan mismatch on resume")
    merged = dict(fresh)
    merged["campaign_id"] = existing.get("campaign_id", fresh.get("campaign_id"))
    merged["runs"] = dict(fresh.get("runs", {}))
    for key, row in existing.get("runs", {}).items():
        current = merged["runs"].get(key, _empty_run_row())
        if row.get("status") in {"complete", "reused", "failed", "running"}:
            merged["runs"][key] = dict(row)
        elif current.get("status") == "pending" and row.get("attempt", 0) > 0:
            merged["runs"][key] = dict(row)
    merged["canary_passed"] = bool(existing.get("canary_passed"))
    merged["canary_gate_status"] = existing.get(
        "canary_gate_status", merged.get("canary_gate_status")
    )
    merged["status"] = existing.get("status", "running")
    return merged


def plan_entry(state: Mapping[str, Any], key: str) -> Mapping[str, Any]:
    for item in state["plan"]:
        if item["key"] == key:
            return item
    raise KeyError(f"unknown r27 case key: {key}")


def begin_run(state: dict[str, Any], key: str) -> str:
    row = dict(state["runs"].get(key, _empty_run_row()))
    if row.get("status") == "reused":
        raise ValueError(f"{key} is reused and must not begin a new attempt")
    attempt = int(row.get("attempt", 0)) + 1
    if attempt > MAX_ATTEMPTS:
        raise ValueError(f"{key} exceeded max attempts ({MAX_ATTEMPTS})")
    run_id = run_id_for(str(state["campaign_id"]), key, attempt)
    state.setdefault("runs", {})[key] = {
        "status": "running",
        "attempt": attempt,
        "run_id": run_id,
        "rank_progress": {},
        "detail": "",
    }
    return run_id


def finish_run(
    state: dict[str, Any],
    key: str,
    *,
    status: str,
    detail: str = "",
    profile_root: str = "",
    telemetry_root: str = "",
    rank_progress: Mapping[str, str] | None = None,
    all_ranks_complete: bool = False,
) -> None:
    row = dict(state["runs"][key])
    row["status"] = status
    row["detail"] = detail
    if profile_root:
        row["profile_root"] = profile_root
    if telemetry_root:
        row["telemetry_root"] = telemetry_root
    if all_ranks_complete:
        rank_progress = {str(rank): "complete" for rank in range(16)}
    if rank_progress is not None:
        row["rank_progress"] = dict(rank_progress)
    state["runs"][key] = row
    if status == "failed":
        state["status"] = "failed"


def mark_canary_passed(state: dict[str, Any]) -> None:
    for case in CANARY_CASES:
        row = state["runs"][case["key"]]
        if row.get("status") != "complete":
            raise ValueError(f"canary incomplete: {case['key']}")
    state["canary_passed"] = True
    state["canary_gate_status"] = "pass"


def can_run_fault_groups(state: Mapping[str, Any]) -> bool:
    return bool(state.get("canary_passed"))


def should_skip_key(state: Mapping[str, Any], key: str) -> bool:
    row = state.get("runs", {}).get(key, {})
    return row.get("status") in {"complete", "reused"}


def formal_keys_to_run(state: Mapping[str, Any]) -> list[str]:
    keys = list(AFFECTED_RECOLLECTION_KEYS)
    if not state.get("reuse_control_memory"):
        keys.append(REUSABLE_IF_ALL_VERIFIED_KEY)
    return keys


def assert_full_rank_group(
    run_id: str,
    rank_progress: Mapping[str, str],
    *,
    required_status: str = "complete",
) -> None:
    if set(rank_progress) != {str(rank) for rank in range(16)}:
        raise ValueError(
            f"{run_id}: rank_progress must cover all 16 ranks, "
            f"observed {sorted(rank_progress)}"
        )
    mixed = sorted(
        {
            f"rank={rank}:{status}"
            for rank, status in rank_progress.items()
            if status != required_status
        }
    )
    if mixed:
        raise ValueError(
            f"{run_id}: incomplete rank group {mixed}; single-rank mixing forbidden"
        )


def record_rank_progress(
    state: dict[str, Any],
    key: str,
    rank_progress: Mapping[str, str],
) -> None:
    row = dict(state["runs"][key])
    existing = dict(row.get("rank_progress", {}))
    for rank, status in rank_progress.items():
        rank_key = str(rank)
        if rank_key in existing and existing[rank_key] != status:
            raise ValueError(
                f"{row.get('run_id')}: rank {rank_key} progress changed from "
                f"{existing[rank_key]!r} to {status!r}"
            )
        existing[rank_key] = status
    row["rank_progress"] = existing
    state["runs"][key] = row


def complete_formal_group(
    state: dict[str, Any],
    key: str,
    *,
    profile_root: Path,
    telemetry_root: str = "",
) -> None:
    row = state["runs"][key]
    rank_progress = {str(rank): "complete" for rank in range(16)}
    assert_full_rank_group(str(row["run_id"]), rank_progress)
    finish_run(
        state,
        key,
        status="complete",
        detail="formal_group_complete",
        profile_root=str(profile_root),
        telemetry_root=telemetry_root,
        rank_progress=rank_progress,
    )


def build_dataset_manifest(
    state: Mapping[str, Any],
    root: Path,
) -> dict[str, Any]:
    entries: list[dict[str, Any]] = []
    for key, spec in EXPECTED_CASE_SPECS.items():
        row = state["runs"][key]
        status = row.get("status")
        if status not in {"complete", "reused"}:
            raise ValueError(f"{key} is not complete for dataset manifest")
        run_id = str(row["run_id"])
        profile_root = Path(
            row.get("profile_root") or root / "runtime/profiles" / run_id
        ).resolve(strict=False)
        telemetry_text = str(row.get("telemetry_root", "")).strip()
        if telemetry_text:
            telemetry_root = Path(telemetry_text).resolve(strict=False)
        else:
            telemetry_root = Path(
                discover_telemetry_root(root, run_id)
            ).resolve(strict=False)
        if status == "complete":
            rank_progress = row.get("rank_progress", {})
            assert_full_rank_group(run_id, rank_progress)
        entry = {
            "key": key,
            "condition": spec["condition"],
            "metric": spec["metric"],
            "pair": spec["pair"],
            "run_id": run_id,
            "attempt": row.get("attempt", 0),
            "source": "reused" if status == "reused" else "recollected",
            "profile_root": str(profile_root),
            "telemetry_root": str(telemetry_root),
            "rank_count": 16,
        }
        validate_manifest_entry(entry, legacy_run_ids=False)
        entries.append(entry)

    pairs = {
        "resource_conflict": {
            "control": next(
                item["run_id"]
                for item in entries
                if item["key"] == "control_resource_conflict"
            ),
            "fault": next(
                item["run_id"]
                for item in entries
                if item["key"] == "fault_resource_conflict"
            ),
        },
        "memory_access": {
            "control": next(
                item["run_id"]
                for item in entries
                if item["key"] == "control_memory_access"
            ),
            "fault": next(
                item["run_id"]
                for item in entries
                if item["key"] == "fault_memory_access"
            ),
        },
    }
    merge_mode = str(state.get("merge_mode", "new64"))
    new_count = sum(1 for item in entries if item["source"] == "recollected") * 16
    reused_count = sum(1 for item in entries if item["source"] == "reused") * 16
    if merge_mode == "new48_reused16":
        if new_count != 48 or reused_count != 16:
            raise ValueError(
                f"new48_reused16 mismatch: new={new_count} reused={reused_count}"
            )
    elif merge_mode == "new64":
        if new_count != 64 or reused_count != 0:
            raise ValueError(
                f"new64 mismatch: new={new_count} reused={reused_count}"
            )
    else:
        raise ValueError(f"unknown merge_mode: {merge_mode}")

    return {
        "schema_version": DATASET_SCHEMA_VERSION,
        "status": "complete",
        "stage": "selective_recapture",
        "analysis_status": "not_started",
        "campaign_id": state["campaign_id"],
        "source_campaign_id": state["source_campaign_id"],
        "merge_mode": merge_mode,
        "session_semantics": {
            "new_sessions": new_count,
            "reused_sessions": reused_count,
            "total_sessions": new_count + reused_count,
        },
        "entries": entries,
        "pairs": pairs,
        "excluded_old_groups": state.get("excluded_old_groups", []),
    }


def finalize_progress(state: dict[str, Any]) -> None:
    for key in formal_keys_to_run(state):
        if state["runs"][key]["status"] != "complete":
            raise ValueError(f"formal key incomplete: {key}")
    if state.get("reuse_control_memory"):
        if state["runs"][REUSABLE_IF_ALL_VERIFIED_KEY]["status"] != "reused":
            raise ValueError("control_memory_access must remain reused")
    else:
        if state["runs"][REUSABLE_IF_ALL_VERIFIED_KEY]["status"] != "complete":
            raise ValueError("control_memory_access recollection incomplete")
    state["status"] = "complete"


def materialize_mock_profile_root(
    profile_root: Path,
    metric: str,
    *,
    effective_steps: int = 4,
) -> None:
    """Test helper: write minimal valid canary inventory fixtures (no training)."""

    profile_root.mkdir(parents=True, exist_ok=True)
    for rank in range(16):
        plan_path = profile_root / f"rank_{rank}/hgnn_profile_plan.json"
        plan_path.parent.mkdir(parents=True, exist_ok=True)
        start_step = 100
        stop_step = start_step + effective_steps
        plan_path.write_text(
            json.dumps(
                {
                    "schema_version": "1.0",
                    "status": "complete",
                    "run_id": "mock",
                    "rank": rank,
                    "aic_metric_name": metric,
                    "data_simplification": True,
                    "online_analysis": False,
                    "postprocess_policy": "deferred_offline_v1",
                    "last_command_id": 2,
                    "events": [
                        {
                            "event": "session_started",
                            "after_step": start_step,
                            "monotonic_ns": 0,
                        },
                        {
                            "event": "session_stopped",
                            "after_step": stop_step,
                            "monotonic_ns": int(300e9),
                        },
                    ],
                },
                indent=2,
                sort_keys=True,
            )
            + "\n",
            encoding="utf-8",
        )
        session = (
            profile_root
            / metric
            / f"rank_{rank}_mock_20260819_ascend_pt"
        )
        target = session / "PROF_mock/device_0/ts_track.data"
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(b"x" * 128)


def materialize_mock_run_sidecars(
    root: Path,
    run_id: str,
    *,
    condition: str,
    duration_s: float,
    baseline_s: float,
    release_at_s: float,
) -> Path:
    """Test helper: protocol, telemetry, and training-sidecar fixtures."""

    formal = root / "runtime/outputs/formal" / run_id
    formal.mkdir(parents=True, exist_ok=True)
    protocol = {
        "status": "complete",
        "passed": True,
        "condition": condition,
        "duration_s": duration_s,
        "baseline_s": baseline_s,
        "release_at_s": release_at_s,
    }
    (formal / "protocol_report.json").write_text(
        json.dumps(protocol, indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )
    (formal / "intervention_events.jsonl").write_text(
        "\n".join(
            json.dumps(
                {
                    "record_type": "profile_control_command",
                    "run_id": run_id,
                    "command": command,
                    "utc_ns": int(timestamp_s * 1_000_000_000),
                },
                sort_keys=True,
            )
            for command, timestamp_s in (
                ("start", baseline_s),
                ("stop", release_at_s),
            )
        )
        + "\n",
        encoding="utf-8",
    )
    manifest_root = root / "runtime/manifests" / run_id
    manifest_root.mkdir(parents=True, exist_ok=True)
    (manifest_root / "profile_control.json").write_text(
        json.dumps(
            {
                "run_id": run_id,
                "commands": [
                    {
                        "command_id": 1,
                        "command": "start",
                        "utc_ns": int(baseline_s * 1_000_000_000),
                    },
                    {
                        "command_id": 2,
                        "command": "stop",
                        "utc_ns": int(release_at_s * 1_000_000_000),
                    },
                ],
            },
            indent=2,
            sort_keys=True,
        )
        + "\n",
        encoding="utf-8",
    )
    telemetry = root / "runtime/data" / run_id
    (telemetry / "raw").mkdir(parents=True, exist_ok=True)
    (telemetry / "normalized/nodes").mkdir(parents=True, exist_ok=True)
    ts = mock_profiler_timestamp_us(
        baseline_s=baseline_s, release_at_s=release_at_s
    )
    (telemetry / "raw/npu.csv").write_text(
        f"timestamp_us,value\n{ts},1\n",
        encoding="utf-8",
    )
    (telemetry / "normalized/nodes/npu.csv").write_text(
        f"timestamp_us,value\n{ts},1\n",
        encoding="utf-8",
    )
    (telemetry / "normalized/nodes/hbm.csv").write_text(
        f"timestamp_us,value\n{ts},1\n",
        encoding="utf-8",
    )
    (telemetry / "normalized/nodes/global_task.csv").write_text(
        f"timestamp_us,Step,Step Time(us)\n{ts},1,100000\n",
        encoding="utf-8",
    )
    (telemetry / "manifest.json").write_text("{}\n", encoding="utf-8")
    logs = root / "runtime/logs"
    logs.mkdir(parents=True, exist_ok=True)
    (logs / f"{run_id}.log").write_text(
        "iteration 1 Step Time(us)=100000\n",
        encoding="utf-8",
    )
    return telemetry


def _cmd_init(args: argparse.Namespace) -> int:
    audit = load_json(args.audit_report)
    campaign_id = resolve_campaign_id(args.progress_path, args.campaign_id)
    payload = initialize_progress(
        campaign_id=campaign_id,
        source_campaign_id=args.source_campaign_id,
        source_dataset_manifest=args.source_dataset_manifest,
        audit_report=audit,
    )
    path = args.progress_path
    if path.is_file():
        payload = merge_resume(load_progress(path), payload)
        payload["campaign_id"] = campaign_id
    save_progress(path, payload)
    print(f"R27_PROGRESS={path}")
    print(f"R27_CAMPAIGN_ID={payload['campaign_id']}")
    print(f"R27_MERGE_MODE={payload['merge_mode']}")
    return 0


def _cmd_begin(args: argparse.Namespace) -> int:
    state = dict(load_progress(args.progress_path))
    key = args.key
    entry = plan_entry(state, key)
    if entry.get("phase") in {"formal", "formal_optional"} and not can_run_fault_groups(state):
        raise SystemExit("fault/formal groups blocked until canary passes")
    if should_skip_key(state, key):
        row = state["runs"][key]
        print(f"R27_SKIP={key} run_id={row.get('run_id')}")
        save_progress(args.progress_path, state)
        return 0
    run_id = begin_run(state, key)
    save_progress(args.progress_path, state)
    print(f"R27_RUN_ID={run_id}")
    return 0


def _cmd_finish(args: argparse.Namespace) -> int:
    state = dict(load_progress(args.progress_path))
    finish_run(
        state,
        args.key,
        status=args.status,
        detail=args.detail,
        profile_root=args.profile_root or "",
        telemetry_root=args.telemetry_root or "",
        all_ranks_complete=args.all_ranks_complete,
    )
    save_progress(args.progress_path, state)
    print(f"R27_FINISH={args.key} status={args.status}")
    return 0


def _cmd_complete_group(args: argparse.Namespace) -> int:
    state = dict(load_progress(args.progress_path))
    complete_formal_group(
        state,
        args.key,
        profile_root=args.profile_root,
        telemetry_root=args.telemetry_root or "",
    )
    save_progress(args.progress_path, state)
    print(f"R27_GROUP_COMPLETE={args.key}")
    return 0


def _cmd_mark_canary(args: argparse.Namespace) -> int:
    state = dict(load_progress(args.progress_path))
    mark_canary_passed(state)
    save_progress(args.progress_path, state)
    print("R27_CANARY_PASS=1")
    return 0


def _cmd_build_manifest(args: argparse.Namespace) -> int:
    state = dict(load_progress(args.progress_path))
    finalize_progress(state)
    manifest = build_dataset_manifest(state, args.root)
    atomic_json(args.output, manifest)
    save_progress(args.progress_path, state)
    print(f"R27_DATASET_MANIFEST={args.output}")
    print(f"R27_MERGE_MODE={manifest['merge_mode']}")
    return 0


def _cmd_should_skip(args: argparse.Namespace) -> int:
    state = load_progress(args.progress_path)
    print("yes" if should_skip_key(state, args.key) else "no")
    return 0


def _cmd_can_run_fault(args: argparse.Namespace) -> int:
    state = load_progress(args.progress_path)
    print("yes" if can_run_fault_groups(state) else "no")
    return 0


def _cmd_resolve_campaign(args: argparse.Namespace) -> int:
    print(resolve_campaign_id(args.progress_path, args.default_campaign_id))
    return 0


def _cmd_discover_telemetry(args: argparse.Namespace) -> int:
    telemetry = discover_telemetry_root(args.root, args.run_id)
    print(f"R27_TELEMETRY_ROOT={telemetry}")
    return 0


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="R27 selective recapture state")
    sub = parser.add_subparsers(dest="command", required=True)

    init = sub.add_parser("init")
    init.add_argument("--progress-path", type=Path, required=True)
    init.add_argument("--campaign-id", required=True)
    init.add_argument("--source-campaign-id", required=True)
    init.add_argument("--source-dataset-manifest", type=Path, required=True)
    init.add_argument("--audit-report", type=Path, required=True)
    init.set_defaults(func=_cmd_init)

    begin = sub.add_parser("begin")
    begin.add_argument("--progress-path", type=Path, required=True)
    begin.add_argument("--key", required=True)
    begin.set_defaults(func=_cmd_begin)

    finish = sub.add_parser("finish")
    finish.add_argument("--progress-path", type=Path, required=True)
    finish.add_argument("--key", required=True)
    finish.add_argument("--status", choices=("complete", "failed"), required=True)
    finish.add_argument("--detail", default="")
    finish.add_argument("--profile-root", default="")
    finish.add_argument("--telemetry-root", default="")
    finish.add_argument(
        "--all-ranks-complete",
        action="store_true",
        help="Mark all 16 ranks complete after CANN parse + schema pass",
    )
    finish.set_defaults(func=_cmd_finish)

    complete = sub.add_parser("complete-group")
    complete.add_argument("--progress-path", type=Path, required=True)
    complete.add_argument("--key", required=True)
    complete.add_argument("--profile-root", type=Path, required=True)
    complete.add_argument("--telemetry-root", default="")
    complete.set_defaults(func=_cmd_complete_group)

    mark = sub.add_parser("mark-canary-passed")
    mark.add_argument("--progress-path", type=Path, required=True)
    mark.set_defaults(func=_cmd_mark_canary)

    manifest = sub.add_parser("build-manifest")
    manifest.add_argument("--progress-path", type=Path, required=True)
    manifest.add_argument("--root", type=Path, required=True)
    manifest.add_argument("--output", type=Path, required=True)
    manifest.set_defaults(func=_cmd_build_manifest)

    skip = sub.add_parser("should-skip")
    skip.add_argument("--progress-path", type=Path, required=True)
    skip.add_argument("--key", required=True)
    skip.set_defaults(func=_cmd_should_skip)

    fault = sub.add_parser("can-run-fault")
    fault.add_argument("--progress-path", type=Path, required=True)
    fault.set_defaults(func=_cmd_can_run_fault)

    resolve = sub.add_parser("resolve-campaign-id")
    resolve.add_argument("--progress-path", type=Path, required=True)
    resolve.add_argument("--default-campaign-id", required=True)
    resolve.set_defaults(func=_cmd_resolve_campaign)

    telemetry = sub.add_parser("discover-telemetry")
    telemetry.add_argument("--root", type=Path, required=True)
    telemetry.add_argument("--run-id", required=True)
    telemetry.set_defaults(func=_cmd_discover_telemetry)

    return parser


def main(argv: Sequence[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    return int(args.func(args))


if __name__ == "__main__":
    raise SystemExit(main())
