#!/usr/bin/env python3
"""Finalize r30 expanded sampled dataset manifests."""

from __future__ import annotations

import argparse
from pathlib import Path
from typing import Any, Mapping, Sequence

from r27_state import discover_telemetry_root
from torch_npu_offline_common import atomic_json, load_json


def finalize_expanded_dataset(
    *,
    root: Path,
    extraction_root: Path,
    campaign_id: str,
    output: Path,
    expected_groups: int | None,
) -> Mapping[str, Any]:
    groups_root = extraction_root / "groups"
    group_paths = sorted(groups_root.glob("*.json"))
    if not group_paths:
        raise SystemExit("no r30 groups found")
    if expected_groups is not None and len(group_paths) != expected_groups:
        raise SystemExit(
            f"expected {expected_groups} r30 groups, observed {len(group_paths)}"
        )

    entries: list[Mapping[str, Any]] = []
    for group_path in group_paths:
        group = load_json(group_path)
        if group.get("status") != "complete":
            raise SystemExit(f"group incomplete: {group_path}")
        run_id = str(group["run_id"])
        cleanup = extraction_root / "provenance/r30/cleanup" / run_id / "cleanup_report.json"
        if not cleanup.exists():
            cleanup = extraction_root / "provenance/r29/cleanup" / run_id / "cleanup_report.json"
        cleanup_report = load_json(cleanup.resolve(strict=True))
        if cleanup_report.get("status") != "complete":
            raise SystemExit(f"cleanup incomplete: {cleanup}")
        entries.append(
            {
                "key": group["key"],
                "run_id": run_id,
                "condition": group["condition"],
                "metric": group["metric"],
                "segment_count": group["segment_count"],
                "complete_segment_count": group["complete_segment_count"],
                "telemetry_root": discover_telemetry_root(root, run_id),
                "profile_root": "",
                "profile_root_deleted": True,
                "profile_plans_root": cleanup_report["profile_plans_output"],
                "raw_cleanup_report": str(cleanup),
                "group_extraction_manifest": str(group_path),
                "sample_plan": group["sample_plan"],
            }
        )

    manifest = {
        "schema_version": "r30.dataset_manifest.v1",
        "status": "complete",
        "mode": "expanded",
        "campaign_id": campaign_id,
        "group_count": len(entries),
        "entries": entries,
        "raw_profiler_trace_required": False,
        "aggregation_policy": "none_on_910c_raw_segments_only",
    }
    atomic_json(output, manifest)
    atomic_json(
        extraction_root / "dataset_extraction_manifest.json",
        {
            "schema_version": "r30.extraction_manifest.v1",
            "status": "complete",
            "campaign_id": campaign_id,
            "group_count": len(entries),
            "groups": [str(path) for path in group_paths],
        },
    )
    print(f"R30_DATASET_MANIFEST={output}")
    print(f"R30_DATASET_GROUPS={len(entries)}")
    return manifest


def main(argv: Sequence[str] | None = None) -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", type=Path, required=True)
    parser.add_argument("--extraction-root", type=Path, required=True)
    parser.add_argument("--campaign-id", required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--expected-groups", type=int)
    args = parser.parse_args(argv)
    finalize_expanded_dataset(
        root=args.root,
        extraction_root=args.extraction_root,
        campaign_id=args.campaign_id,
        output=args.output,
        expected_groups=args.expected_groups,
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
