#!/usr/bin/env python3
"""Extract r25 metrics from existing real CANN CSV or SQLite output."""

from __future__ import annotations

import argparse
import bisect
import csv
import hashlib
import json
import math
import os
import shutil
import sqlite3
import time
from collections import defaultdict
from concurrent.futures import Future, ThreadPoolExecutor, as_completed
from pathlib import Path
from typing import Any, Iterable, Mapping, Sequence

from torch_npu_offline_common import atomic_json, load_json, numeric, sha256


BIN_US = 1_000_000
MARKER_NAME = ".hgnn_r25_real_csv_complete.json"
REPORT_NAME = "r25_session_report.json"
COMMON_COLUMNS = ("Task Start Time(us)", "Task Duration(us)")
RESOURCE_COLUMNS = (
    "aiv_total_cycles",
    "aiv_vec_bankgroup_cflt_ratio",
    "aiv_vec_bank_cflt_ratio",
    "aiv_vec_resc_cflt_ratio",
)
MEMORY_COLUMNS = (
    "aic_read_main_memory_datas(KB)",
    "aiv_read_main_memory_datas(KB)",
    "aic_write_main_memory_datas(KB)",
    "aiv_write_main_memory_datas(KB)",
)
IDENTITY_COLUMNS = ("Op Name", "Op Type", "Task Type")
RESOURCE_COMPONENTS = RESOURCE_COLUMNS[1:]
SPLIT_JOIN_KEYS = ("task_id", "stream_id", "subtask_id", "batch_id")
SPLIT_MEMORY_ALIASES = {
    column: (column, column.removesuffix("(KB)"))
    for column in MEMORY_COLUMNS
}
SPLIT_METRIC_TABLE = "ai_core_metrics"
SPLIT_TIME_TABLE = "task_time"
SPLIT_DATABASE_NAME = "ai_core_op_summary.db"
SPLIT_TIMESTAMP_DERIVATION = (
    "utc_us=(collectionTimeEnd+(start_time-MonotonicTimeEnd))/1000"
)
HCCL_TOKENS = (
    "hccl",
    "communication",
    "allreduce",
    "all_reduce",
    "allgather",
    "all_gather",
    "reducescatter",
    "reduce_scatter",
    "broadcast",
    "alltoall",
    "all_to_all",
)


def marker_path(session: Path) -> Path:
    return session / MARKER_NAME


def _normalized_header(header: Iterable[Any]) -> tuple[str, ...]:
    return tuple(str(value).strip() for value in header)


def required_columns(metric_family: str) -> tuple[str, ...]:
    if metric_family == "ResourceConflictRatio":
        return COMMON_COLUMNS + RESOURCE_COLUMNS
    if metric_family == "MemoryAccess":
        return COMMON_COLUMNS + MEMORY_COLUMNS
    raise ValueError(f"unsupported metric family: {metric_family}")


def _natural_path_key(path: Path) -> tuple[Any, ...]:
    pieces: list[Any] = []
    text = path.as_posix()
    current = ""
    digit = False
    for character in text:
        if character.isdigit() == digit:
            current += character
            continue
        if current:
            pieces.append(int(current) if digit else current)
        current = character
        digit = character.isdigit()
    if current:
        pieces.append(int(current) if digit else current)
    return tuple(pieces)


def discover_csv_slices(session: Path) -> tuple[Path, ...]:
    """Return only safe, existing op-summary CSV slices under a session."""
    resolved_session = session.resolve(strict=True)
    def collect(patterns: Sequence[str]) -> set[Path]:
        matches: set[Path] = set()
        for pattern in patterns:
            for candidate in session.rglob(pattern):
                if not candidate.is_file() or candidate.is_symlink():
                    continue
                try:
                    resolved = candidate.resolve(strict=True)
                except OSError:
                    continue
                if (
                    resolved.is_relative_to(resolved_session)
                    and "mindstudio_profiler_output" in resolved.parts
                    and resolved.stat().st_size > 0
                ):
                    matches.add(resolved)
        return matches

    candidates = collect(("op_summary_slice_*.csv", "op_summary_slice*.csv"))
    if candidates:
        return tuple(sorted(candidates, key=_natural_path_key))

    fallback = sorted(collect(("op_summary_*.csv",)), key=_natural_path_key)
    if fallback:
        # Re-running msprof export can create duplicate timestamped summaries
        # for the same raw trace. Keep only the latest batch in this format.
        return (fallback[-1],)
    return ()


def inspect_csv_schema(
    files: Sequence[Path], metric_family: str
) -> Mapping[str, Any]:
    required = set(required_columns(metric_family))
    schemas: list[Mapping[str, Any]] = []
    all_valid = bool(files)
    for path in files:
        try:
            with path.open(encoding="utf-8-sig", newline="") as stream:
                header = _normalized_header(next(csv.reader(stream), ()))
        except (OSError, UnicodeDecodeError, csv.Error):
            header = ()
        missing = sorted(required - set(header))
        has_identity = any(column in header for column in IDENTITY_COLUMNS)
        valid = bool(header) and not missing and has_identity
        all_valid = all_valid and valid
        schemas.append(
            {
                "path": str(path),
                "columns": list(header),
                "missing_columns": missing,
                "has_task_identity": has_identity,
                "status": "valid" if valid else "invalid",
            }
        )
    fingerprint_payload = json.dumps(
        [schema["columns"] for schema in schemas],
        ensure_ascii=False,
        separators=(",", ":"),
    ).encode()
    return {
        "status": "valid" if all_valid else "invalid",
        "metric_family": metric_family,
        "required_columns": list(required_columns(metric_family)),
        "identity_columns": list(IDENTITY_COLUMNS),
        "files": schemas,
        "schema_sha256": hashlib.sha256(fingerprint_payload).hexdigest(),
    }


def _source_records(session: Path, files: Sequence[Path]) -> list[Mapping[str, Any]]:
    resolved_session = session.resolve(strict=True)
    records: list[Mapping[str, Any]] = []
    for path in files:
        resolved = path.resolve(strict=True)
        if not resolved.is_relative_to(resolved_session) or resolved.is_symlink():
            raise RuntimeError(f"CSV slice escaped session root: {path}")
        records.append(
            {
                "path": str(resolved),
                "relative_path": str(resolved.relative_to(resolved_session)),
                "size_bytes": resolved.stat().st_size,
                "sha256": sha256(resolved),
            }
        )
    return records


def write_adoption_marker(
    session: Path,
    metric_family: str,
    files: Sequence[Path],
    schema: Mapping[str, Any],
) -> Mapping[str, Any]:
    if schema.get("status") != "valid":
        raise ValueError("cannot adopt CSV slices with an invalid real-field schema")
    marker = {
        "schema_version": "r25.real_csv.v1",
        "status": "complete",
        "session": str(session.resolve(strict=True)),
        "metric_family": metric_family,
        "provenance": "existing_csv_only_no_cann",
        "schema": schema,
        "outputs": _source_records(session, files),
    }
    atomic_json(marker_path(session), marker)
    return marker


def cached_csv_slices(
    session: Path, metric_family: str
) -> tuple[Path, ...] | None:
    path = marker_path(session)
    if not path.is_file() or path.is_symlink():
        return None
    try:
        marker = load_json(path)
    except (OSError, ValueError, json.JSONDecodeError):
        return None
    if (
        marker.get("status") != "complete"
        or marker.get("metric_family") != metric_family
        or marker.get("session") != str(session.resolve(strict=True))
    ):
        return None
    outputs = marker.get("outputs")
    if not isinstance(outputs, list) or not outputs:
        return None
    resolved_session = session.resolve(strict=True)
    files: list[Path] = []
    for item in outputs:
        if not isinstance(item, Mapping):
            return None
        candidate = Path(str(item.get("path", "")))
        try:
            resolved = candidate.resolve(strict=True)
        except OSError:
            return None
        if (
            not resolved.is_relative_to(resolved_session)
            or resolved.is_symlink()
            or resolved.stat().st_size != item.get("size_bytes")
            or sha256(resolved) != item.get("sha256")
        ):
            return None
        files.append(resolved)
    schema = inspect_csv_schema(files, metric_family)
    marker_schema = marker.get("schema")
    if (
        schema.get("status") != "valid"
        or not isinstance(marker_schema, Mapping)
        or schema.get("schema_sha256") != marker_schema.get("schema_sha256")
    ):
        return None
    return tuple(sorted(files, key=_natural_path_key))


def iter_csv_rows(paths: Sequence[Path]) -> Iterable[Mapping[str, str]]:
    """Stream slices one row at a time; no slice is materialized in memory."""
    for path in paths:
        with path.open(encoding="utf-8-sig", newline="") as stream:
            reader = csv.DictReader(stream)
            for row in reader:
                yield row


def quote_identifier(value: str) -> str:
    return '"' + value.replace('"', '""') + '"'


def discover_sqlite_files(session: Path) -> tuple[Path, ...]:
    """Recursively identify safe SQLite databases by their file magic."""
    resolved_session = session.resolve(strict=True)
    databases: list[Path] = []
    for candidate in session.rglob("*"):
        if (
            not candidate.is_file()
            or candidate.is_symlink()
            or candidate.stat().st_size < 16
        ):
            continue
        try:
            resolved = candidate.resolve(strict=True)
            with resolved.open("rb") as stream:
                magic = stream.read(16)
        except OSError:
            continue
        if (
            resolved.is_relative_to(resolved_session)
            and magic == b"SQLite format 3\x00"
        ):
            databases.append(resolved)
    return tuple(sorted(set(databases), key=_natural_path_key))


def _sqlite_uri(path: Path) -> str:
    return path.resolve(strict=True).as_uri() + "?mode=ro"


def discover_sqlite_sources(
    session: Path, metric_family: str
) -> tuple[Mapping[str, Any], ...]:
    """Find tables whose exact real schema can feed the shared aggregator."""
    required = set(required_columns(metric_family))
    sources: list[Mapping[str, Any]] = []
    for database in discover_sqlite_files(session):
        connection: sqlite3.Connection | None = None
        try:
            connection = sqlite3.connect(
                _sqlite_uri(database), uri=True, timeout=5.0
            )
            connection.execute("PRAGMA query_only=ON")
            tables = connection.execute(
                "SELECT name FROM sqlite_master "
                "WHERE type='table' AND name NOT LIKE 'sqlite_%' "
                "ORDER BY name"
            ).fetchall()
            for (raw_table,) in tables:
                table = str(raw_table)
                columns = tuple(
                    str(row[1])
                    for row in connection.execute(
                        f"PRAGMA table_info({quote_identifier(table)})"
                    )
                )
                identities = tuple(
                    column for column in IDENTITY_COLUMNS if column in columns
                )
                if not required.issubset(columns) or not identities:
                    continue
                selected = tuple(
                    column
                    for column in required_columns(metric_family) + IDENTITY_COLUMNS
                    if column in columns
                )
                sources.append(
                    {
                        "database": str(database),
                        "table": table,
                        "columns": list(selected),
                        "database_size_bytes": database.stat().st_size,
                    }
                )
        except sqlite3.Error:
            continue
        finally:
            if connection is not None:
                connection.close()
    return tuple(sources)


def _integer_ns(value: Any) -> int | None:
    if isinstance(value, bool):
        return None
    try:
        number = int(value)
    except (TypeError, ValueError, OverflowError):
        return None
    return number if number >= 0 else None


def clock_anchors_for_session(session: Path) -> Mapping[str, Any] | None:
    """Load a same-object UTC/monotonic end anchor pair without float loss."""
    for path in sorted(session.rglob("profiler_info*.json"), key=_natural_path_key):
        if (
            not path.is_file()
            or path.is_symlink()
            or path.stat().st_size > 16 * 1024 * 1024
        ):
            continue
        try:
            payload = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, UnicodeDecodeError, json.JSONDecodeError):
            continue

        def visit(value: Any) -> Mapping[str, Any] | None:
            if isinstance(value, Mapping):
                collection = _integer_ns(value.get("collectionTimeEnd"))
                monotonic = _integer_ns(value.get("MonotonicTimeEnd"))
                if collection is not None and monotonic is not None:
                    return {
                        "profiler_info_path": str(path.resolve(strict=True)),
                        "collection_time_end_utc_ns": collection,
                        "monotonic_time_end_ns": monotonic,
                        "timestamp_derivation": SPLIT_TIMESTAMP_DERIVATION,
                    }
                for child in value.values():
                    found = visit(child)
                    if found is not None:
                        return found
            elif isinstance(value, list):
                for child in value:
                    found = visit(child)
                    if found is not None:
                        return found
            return None

        anchors = visit(payload)
        if anchors is not None:
            return anchors
    return None


def discover_split_memory_sqlite_sources(
    session: Path,
) -> tuple[Mapping[str, Any], ...]:
    """Discover the real ai_core_metrics/task_time four-key split schema."""
    anchors = clock_anchors_for_session(session)
    if anchors is None:
        return ()
    sources: list[Mapping[str, Any]] = []
    for database in discover_sqlite_files(session):
        if database.name != SPLIT_DATABASE_NAME:
            continue
        connection: sqlite3.Connection | None = None
        try:
            connection = sqlite3.connect(
                _sqlite_uri(database), uri=True, timeout=5.0
            )
            connection.execute("PRAGMA query_only=ON")
            table_rows = connection.execute(
                "SELECT name FROM sqlite_master "
                "WHERE type='table' AND name IN (?, ?)",
                (SPLIT_METRIC_TABLE, SPLIT_TIME_TABLE),
            ).fetchall()
            table_names = {str(row[0]) for row in table_rows}
            if table_names != {SPLIT_METRIC_TABLE, SPLIT_TIME_TABLE}:
                continue
            metric_columns = tuple(
                str(row[1])
                for row in connection.execute(
                    f"PRAGMA table_info({quote_identifier(SPLIT_METRIC_TABLE)})"
                )
            )
            time_columns = tuple(
                str(row[1])
                for row in connection.execute(
                    f"PRAGMA table_info({quote_identifier(SPLIT_TIME_TABLE)})"
                )
            )
            if not set(SPLIT_JOIN_KEYS).issubset(metric_columns):
                continue
            if not (
                set(SPLIT_JOIN_KEYS)
                | {"start_time", "duration_time", "task_type"}
            ).issubset(time_columns):
                continue
            aliases: dict[str, str] = {}
            for target, candidates in SPLIT_MEMORY_ALIASES.items():
                source = next(
                    (candidate for candidate in candidates if candidate in metric_columns),
                    None,
                )
                if source is None:
                    aliases = {}
                    break
                aliases[target] = source
            if len(aliases) != len(MEMORY_COLUMNS):
                continue
            sources.append(
                {
                    "kind": "split_memory_four_key_join",
                    "database": str(database),
                    "database_size_bytes": database.stat().st_size,
                    "metric_table": SPLIT_METRIC_TABLE,
                    "time_table": SPLIT_TIME_TABLE,
                    "join_keys": list(SPLIT_JOIN_KEYS),
                    "column_aliases": aliases,
                    "columns": {
                        SPLIT_METRIC_TABLE: list(metric_columns),
                        SPLIT_TIME_TABLE: list(time_columns),
                    },
                    "clock_anchors": dict(anchors),
                    "timestamp_derivation": SPLIT_TIMESTAMP_DERIVATION,
                    "duration_derivation": "Task Duration(us)=duration_time/1000",
                }
            )
        except sqlite3.Error:
            continue
        finally:
            if connection is not None:
                connection.close()
    return tuple(sources)


def iter_sqlite_rows(
    sources: Sequence[Mapping[str, Any]], batch_size: int = 4096
) -> Iterable[Mapping[str, Any]]:
    """Read selected SQLite tables through read-only URIs in bounded batches."""
    if batch_size <= 0:
        raise ValueError("batch_size must be positive")
    for source in sources:
        database = Path(str(source["database"]))
        table = str(source["table"])
        columns = tuple(str(column) for column in source["columns"])
        selection = ", ".join(quote_identifier(column) for column in columns)
        connection: sqlite3.Connection | None = None
        try:
            connection = sqlite3.connect(
                _sqlite_uri(database), uri=True, timeout=5.0
            )
            connection.execute("PRAGMA query_only=ON")
            cursor = connection.execute(
                f"SELECT {selection} FROM {quote_identifier(table)}"
            )
            while True:
                batch = cursor.fetchmany(batch_size)
                if not batch:
                    break
                for values in batch:
                    yield dict(zip(columns, values))
        finally:
            if connection is not None:
                connection.close()


def iter_split_memory_sqlite_rows(
    sources: Sequence[Mapping[str, Any]], batch_size: int = 4096
) -> Iterable[Mapping[str, Any]]:
    """Stream four-key joined rows and translate monotonic ns to UTC us."""
    if batch_size <= 0:
        raise ValueError("batch_size must be positive")
    for source in sources:
        database = Path(str(source["database"]))
        metric_table = str(source["metric_table"])
        time_table = str(source["time_table"])
        join_keys = tuple(str(key) for key in source["join_keys"])
        aliases = {
            str(target): str(column)
            for target, column in source["column_aliases"].items()
        }
        anchors = source["clock_anchors"]
        collection_end = int(anchors["collection_time_end_utc_ns"])
        monotonic_end = int(anchors["monotonic_time_end_ns"])
        metric_selection = ", ".join(
            f"m.{quote_identifier(column)}"
            for column in aliases.values()
        )
        predicates = " AND ".join(
            f"m.{quote_identifier(key)} = t.{quote_identifier(key)}"
            for key in join_keys
        )
        query = (
            f"SELECT t.{quote_identifier('start_time')}, "
            f"t.{quote_identifier('duration_time')}, "
            f"t.{quote_identifier('task_type')}, {metric_selection} "
            f"FROM {quote_identifier(metric_table)} AS m "
            f"JOIN {quote_identifier(time_table)} AS t ON {predicates}"
        )
        connection: sqlite3.Connection | None = None
        try:
            connection = sqlite3.connect(
                _sqlite_uri(database), uri=True, timeout=5.0
            )
            connection.execute("PRAGMA query_only=ON")
            cursor = connection.execute(query)
            targets = tuple(aliases)
            while True:
                batch = cursor.fetchmany(batch_size)
                if not batch:
                    break
                for values in batch:
                    start_ns = _integer_ns(values[0])
                    duration_ns = _finite_number(values[1])
                    if start_ns is None or duration_ns is None:
                        start_us: float | None = None
                        duration_us: float | None = None
                    else:
                        start_us = (
                            collection_end + (start_ns - monotonic_end)
                        ) / 1000.0
                        duration_us = duration_ns / 1000.0
                    row: dict[str, Any] = {
                        "Task Start Time(us)": start_us,
                        "Task Duration(us)": duration_us,
                        "Task Type": values[2],
                    }
                    row.update(zip(targets, values[3:]))
                    yield row
        finally:
            if connection is not None:
                connection.close()


def inspect_sqlite_schema(
    sources: Sequence[Mapping[str, Any]], metric_family: str
) -> Mapping[str, Any]:
    return {
        "status": "valid" if sources else "missing",
        "metric_family": metric_family,
        "required_columns": list(required_columns(metric_family)),
        "identity_columns": list(IDENTITY_COLUMNS),
        "tables": [dict(source) for source in sources],
    }


def inspect_split_sqlite_schema(
    sources: Sequence[Mapping[str, Any]],
) -> Mapping[str, Any]:
    return {
        "status": "valid" if sources else "missing",
        "metric_family": "MemoryAccess",
        "schema_kind": "split_memory_four_key_join",
        "required_output_columns": list(required_columns("MemoryAccess")),
        "tables": [dict(source) for source in sources],
        "timestamp_derivation": SPLIT_TIMESTAMP_DERIVATION,
    }


def _sqlite_inventory_matches(
    session: Path,
    metric_family: str,
    inventory: Any,
) -> bool:
    if not isinstance(inventory, list) or not inventory:
        return False
    if any(
        isinstance(item, Mapping)
        and item.get("kind") == "split_memory_four_key_join"
        for item in inventory
    ):
        if metric_family != "MemoryAccess":
            return False
        current_split = discover_split_memory_sqlite_sources(session)
        return json.dumps(
            [dict(source) for source in current_split],
            sort_keys=True,
            separators=(",", ":"),
        ) == json.dumps(inventory, sort_keys=True, separators=(",", ":"))
    current = discover_sqlite_sources(session, metric_family)

    def identity(source: Mapping[str, Any]) -> tuple[Any, ...]:
        return (
            str(source.get("database", "")),
            str(source.get("table", "")),
            tuple(str(column) for column in source.get("columns", [])),
            source.get("database_size_bytes"),
        )

    expected_sources = [
        item for item in inventory if isinstance(item, Mapping)
    ]
    return (
        len(expected_sources) == len(inventory)
        and sorted(identity(source) for source in current)
        == sorted(identity(source) for source in expected_sources)
    )


def _finite_number(value: Any) -> float | None:
    number = numeric(value)
    if number is None or not math.isfinite(number):
        return None
    return number


def _bin_overlaps(start_us: float, duration_us: float) -> Iterable[tuple[int, float]]:
    if duration_us <= 0:
        return
    end_us = start_us + duration_us
    bin_us = math.floor(start_us / BIN_US) * BIN_US
    while bin_us < end_us:
        overlap = min(end_us, bin_us + BIN_US) - max(start_us, bin_us)
        if overlap > 0:
            yield int(bin_us), overlap
        bin_us += BIN_US


class CompactIntervalUnion:
    """A sorted, merged interval union with compact storage."""

    def __init__(self) -> None:
        self.intervals: list[tuple[float, float]] = []

    def add(self, start: float, end: float) -> None:
        if end <= start:
            return
        index = bisect.bisect_left(self.intervals, (start, float("-inf")))
        if index and self.intervals[index - 1][1] >= start:
            index -= 1
        merged_start, merged_end = start, end
        stop = index
        while stop < len(self.intervals) and self.intervals[stop][0] <= merged_end:
            merged_start = min(merged_start, self.intervals[stop][0])
            merged_end = max(merged_end, self.intervals[stop][1])
            stop += 1
        self.intervals[index:stop] = [(merged_start, merged_end)]

    def duration(self) -> float:
        return sum(end - start for start, end in self.intervals)


def _intersection_duration(
    left: CompactIntervalUnion, right: CompactIntervalUnion
) -> float:
    total = 0.0
    left_index = right_index = 0
    while (
        left_index < len(left.intervals)
        and right_index < len(right.intervals)
    ):
        left_start, left_end = left.intervals[left_index]
        right_start, right_end = right.intervals[right_index]
        total += max(0.0, min(left_end, right_end) - max(left_start, right_start))
        if left_end <= right_end:
            left_index += 1
        else:
            right_index += 1
    return total


def _task_kind(row: Mapping[str, Any]) -> str:
    identity = " ".join(str(row.get(column, "")) for column in IDENTITY_COLUMNS)
    lowered = identity.casefold()
    if any(token in lowered for token in HCCL_TOKENS):
        return "communication"
    return "compute"


def _add_task_intervals(
    destination: dict[int, CompactIntervalUnion],
    start_us: float,
    duration_us: float,
) -> None:
    for bin_us, _ in _bin_overlaps(start_us, duration_us):
        clipped_start = max(start_us, bin_us)
        clipped_end = min(start_us + duration_us, bin_us + BIN_US)
        destination[bin_us].add(clipped_start, clipped_end)


def aggregate_real_csv(
    rows: Iterable[Mapping[str, Any]],
    run_id: str,
    metric_family: str,
    rank: int,
) -> tuple[Mapping[str, list[Mapping[str, Any]]], Mapping[str, Any]]:
    memory_kb: dict[tuple[int, str], float] = defaultdict(float)
    resource_weighted: dict[tuple[int, str], list[float]] = defaultdict(
        lambda: [0.0, 0.0]
    )
    communication: dict[int, CompactIntervalUnion] = defaultdict(CompactIntervalUnion)
    compute: dict[int, CompactIntervalUnion] = defaultdict(CompactIntervalUnion)
    source_rows = valid_timeline_rows = 0
    missing_numeric_rows = 0
    timestamp_min: float | None = None
    timestamp_max: float | None = None

    for row in rows:
        source_rows += 1
        start = _finite_number(row.get("Task Start Time(us)"))
        duration = _finite_number(row.get("Task Duration(us)"))
        if start is None or duration is None or duration < 0:
            missing_numeric_rows += 1
            continue
        timestamp_min = start if timestamp_min is None else min(timestamp_min, start)
        timestamp_max = (
            start + duration
            if timestamp_max is None
            else max(timestamp_max, start + duration)
        )
        if duration > 0:
            valid_timeline_rows += 1
            intervals = communication if _task_kind(row) == "communication" else compute
            _add_task_intervals(intervals, start, duration)

        if metric_family == "MemoryAccess" and duration > 0:
            for direction, columns in (
                ("read", MEMORY_COLUMNS[:2]),
                ("write", MEMORY_COLUMNS[2:]),
            ):
                values = [
                    value
                    for value in (_finite_number(row.get(column)) for column in columns)
                    if value is not None
                ]
                if not values:
                    continue
                total_kb = sum(values)
                for bin_us, overlap_us in _bin_overlaps(start, duration):
                    memory_kb[(bin_us, direction)] += (
                        total_kb * overlap_us / duration
                    )
        elif metric_family == "ResourceConflictRatio" and duration > 0:
            cycles = _finite_number(row.get("aiv_total_cycles"))
            if cycles is None or cycles < 0:
                continue
            for component in RESOURCE_COMPONENTS:
                ratio = _finite_number(row.get(component))
                if ratio is None:
                    continue
                for bin_us, overlap_us in _bin_overlaps(start, duration):
                    allocated_cycles = cycles * overlap_us / duration
                    totals = resource_weighted[(bin_us, component)]
                    totals[0] += ratio * allocated_cycles
                    totals[1] += allocated_cycles

    raw_rows: list[Mapping[str, Any]] = []
    canonical_rows: list[Mapping[str, Any]] = []
    if metric_family == "MemoryAccess":
        for (bin_us, direction), allocated_kb in sorted(memory_kb.items()):
            value = allocated_kb * 1024.0 / 1_000_000_000.0
            canonical_rows.append(
                {
                    "run_id": run_id,
                    "metric_family": metric_family,
                    "rank": rank,
                    "profiler_time_bin_us": bin_us,
                    "metric_id": f"hbm.{direction}_gbps",
                    "value": value,
                    "unit": "GB/s",
                    "source_field": "+".join(
                        MEMORY_COLUMNS[:2] if direction == "read" else MEMORY_COLUMNS[2:]
                    ),
                    "derivation": (
                        "task_KB_time_prorated_to_absolute_1s_bin"
                        "*1024_bytes_per_KB/1e9_bytes_per_GB"
                    ),
                    "quality_flags": ["absolute_1s_task_proration"],
                }
            )
    else:
        weighted_values: dict[int, dict[str, float]] = defaultdict(dict)
        for (bin_us, component), (weighted_sum, cycle_sum) in sorted(
            resource_weighted.items()
        ):
            if cycle_sum <= 0:
                continue
            value = weighted_sum / cycle_sum
            weighted_values[bin_us][component] = value
            raw_rows.append(
                {
                    "run_id": run_id,
                    "metric_family": metric_family,
                    "rank": rank,
                    "profiler_time_bin_us": bin_us,
                    "field": component,
                    "value": value,
                    "unit": "ratio",
                    "weight_field": "aiv_total_cycles",
                    "weight_sum": cycle_sum,
                    "derivation": "aiv_total_cycles_weighted_mean",
                }
            )
        for bin_us, components in sorted(weighted_values.items()):
            if set(components) != set(RESOURCE_COMPONENTS):
                continue
            canonical_rows.append(
                {
                    "run_id": run_id,
                    "metric_family": metric_family,
                    "rank": rank,
                    "profiler_time_bin_us": bin_us,
                    "metric_id": "npu.aicore_stall_ratio",
                    "value": max(components.values()),
                    "unit": "ratio",
                    "source_field": ",".join(sorted(components)),
                    "derivation": (
                        "max_of_three_aiv_total_cycles_weighted_conflict_ratios"
                    ),
                    "quality_flags": ["conflict_proxy_not_true_stall"],
                }
            )

    for bin_us in sorted(communication):
        comm = communication[bin_us]
        comp = compute.get(bin_us)
        communication_us = comm.duration()
        if communication_us <= 0:
            continue
        overlap_us = (
            _intersection_duration(comm, comp) if comp is not None else 0.0
        )
        canonical_rows.append(
            {
                "run_id": run_id,
                "metric_family": metric_family,
                "rank": rank,
                "profiler_time_bin_us": bin_us,
                "metric_id": "global_task.comm_compute_overlap_pct",
                "value": overlap_us / communication_us * 100.0,
                "unit": "percent",
                "source_field": "Op Name/Op Type/Task Type task intervals",
                "derivation": (
                    "union(HCCL)_intersection_union(compute)"
                    "/union(HCCL)*100_within_absolute_1s_bin"
                ),
                "quality_flags": ["one_second_interval_proxy"],
            }
        )

    metric_ids = sorted(
        {str(row["metric_id"]) for row in canonical_rows}
    )
    datasets = {
        "raw_pmu_timeseries": raw_rows,
        "canonical_profiler_metrics": sorted(
            canonical_rows,
            key=lambda row: (
                int(row["profiler_time_bin_us"]),
                str(row["metric_id"]),
            ),
        ),
    }
    quality = {
        "source_rows": source_rows,
        "valid_timeline_rows": valid_timeline_rows,
        "missing_numeric_rows": missing_numeric_rows,
        "profiler_timestamp_min_us": timestamp_min,
        "profiler_timestamp_max_us": timestamp_max,
        "canonical_metric_ids": metric_ids,
        "dataset_rows": {name: len(value) for name, value in datasets.items()},
        "memory_mode": "streaming_rows_bounded_by_time_bins_and_interval_unions",
    }
    return datasets, quality


def write_parquet(path: Path, rows: Sequence[Mapping[str, Any]]) -> None:
    try:
        import pyarrow as pa
        import pyarrow.parquet as pq
    except ImportError as error:
        raise SystemExit("pyarrow is required for Zstd Parquet extraction") from error
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    table = pa.Table.from_pylist(list(rows))
    pq.write_table(table, temporary, compression="zstd", compression_level=9)
    os.replace(temporary, path)


def _write_outputs(
    rank_output: Path,
    datasets: Mapping[str, Sequence[Mapping[str, Any]]],
) -> list[Mapping[str, Any]]:
    outputs: list[Mapping[str, Any]] = []
    for kind, rows in datasets.items():
        if not rows:
            continue
        path = rank_output / f"{kind}.parquet"
        write_parquet(path, rows)
        outputs.append(
            {
                "kind": kind,
                "path": str(path),
                "rows": len(rows),
                "size_bytes": path.stat().st_size,
                "sha256": sha256(path),
            }
        )
    return outputs


def _complete_report(path: Path) -> Mapping[str, Any] | None:
    if not path.is_file() or path.is_symlink():
        return None
    try:
        report = load_json(path)
    except (OSError, ValueError, json.JSONDecodeError):
        return None
    if report.get("status") != "complete":
        return None
    outputs = report.get("outputs")
    if not isinstance(outputs, list) or not outputs:
        return None
    for item in outputs:
        if not isinstance(item, Mapping):
            return None
        output = Path(str(item.get("path", "")))
        if (
            not output.is_file()
            or output.is_symlink()
            or output.stat().st_size != item.get("size_bytes")
            or sha256(output) != item.get("sha256")
        ):
            return None
    return report


def copy_completed_outputs(
    report: Mapping[str, Any], rank_output: Path
) -> list[Mapping[str, Any]]:
    copied: list[Mapping[str, Any]] = []
    rank_output.mkdir(parents=True, exist_ok=True)
    for item in report.get("outputs", []):
        source = Path(str(item["path"])).resolve(strict=True)
        destination = rank_output / source.name
        temporary = destination.with_suffix(destination.suffix + ".tmp")
        shutil.copy2(source, temporary)
        os.replace(temporary, destination)
        copied.append(
            {
                "kind": item.get("kind", source.stem),
                "path": str(destination),
                "rows": item.get("rows"),
                "size_bytes": destination.stat().st_size,
                "sha256": sha256(destination),
                "copied_from": str(source),
            }
        )
    return copied


def _required_metric_ids(metric_family: str) -> set[str]:
    if metric_family == "ResourceConflictRatio":
        return {"npu.aicore_stall_ratio"}
    if metric_family == "MemoryAccess":
        return {"hbm.read_gbps", "hbm.write_gbps"}
    raise ValueError(f"unsupported metric family: {metric_family}")


def process_session(
    output_root: Path,
    run_id: str,
    metric_family: str,
    rank: int,
    session: Path,
    r23_output_root: Path | None = None,
    trust_complete_report: bool = False,
) -> Mapping[str, Any]:
    """Extract one session without invoking or importing any CANN API."""
    rank_output = output_root / run_id / f"rank_{rank}"
    report_path = rank_output / REPORT_NAME
    resumed = _complete_report(report_path)
    if resumed is not None:
        if trust_complete_report:
            return resumed
        backend = resumed.get("backend")
        if backend == "reused_completed_r23_session_report":
            return resumed
        if (
            backend == "existing_real_op_summary_csv"
            and cached_csv_slices(session, metric_family) is not None
        ):
            return resumed
        if (
            backend
            in {"existing_real_sqlite", "existing_real_sqlite_split_join"}
            and _sqlite_inventory_matches(
                session, metric_family, resumed.get("source_inventory")
            )
        ):
            return resumed

    started = time.monotonic()
    files = cached_csv_slices(session, metric_family)
    if files is None:
        files = discover_csv_slices(session)
    if not files:
        r23_root = r23_output_root if r23_output_root is not None else output_root
        r23_report_path = r23_root / run_id / f"rank_{rank}" / "r23_session_report.json"
        r23_report = _complete_report(r23_report_path)
        if r23_report is not None:
            copied_outputs = copy_completed_outputs(r23_report, rank_output)
            report = {
                "schema_version": "r25.real_csv.v1",
                "status": "complete",
                "run_id": run_id,
                "metric": metric_family,
                "rank": rank,
                "session": str(session),
                "backend": "reused_completed_r23_session_report",
                "r23_session_report": str(r23_report_path),
                "quality_flags": ["no_csv_reused_completed_r23"],
                "quality": r23_report.get("quality", {}),
                "outputs": copied_outputs,
                "elapsed_s": time.monotonic() - started,
            }
            atomic_json(report_path, report)
            return report
        sqlite_sources = discover_sqlite_sources(session, metric_family)
        split_sources: tuple[Mapping[str, Any], ...] = ()
        if not sqlite_sources and metric_family == "MemoryAccess":
            split_sources = discover_split_memory_sqlite_sources(session)
        if sqlite_sources or split_sources:
            selected_sources = sqlite_sources or split_sources
            if sqlite_sources:
                source_rows = iter_sqlite_rows(sqlite_sources)
                backend = "existing_real_sqlite"
                sqlite_schema = inspect_sqlite_schema(
                    sqlite_sources, metric_family
                )
                clock_anchors = None
                source_derivation = "same_table_exact_real_schema"
            else:
                source_rows = iter_split_memory_sqlite_rows(split_sources)
                backend = "existing_real_sqlite_split_join"
                sqlite_schema = inspect_split_sqlite_schema(split_sources)
                clock_anchors = split_sources[0]["clock_anchors"]
                source_derivation = SPLIT_TIMESTAMP_DERIVATION
            datasets, quality = aggregate_real_csv(
                source_rows, run_id, metric_family, rank
            )
            outputs = _write_outputs(rank_output, datasets)
            missing_metric_ids = sorted(
                _required_metric_ids(metric_family)
                - set(quality["canonical_metric_ids"])
            )
            status = (
                "complete"
                if quality["source_rows"] > 0
                and not missing_metric_ids
                and outputs
                else "partial"
            )
            report = {
                "schema_version": "r25.real_csv.v1",
                "status": status,
                "run_id": run_id,
                "metric": metric_family,
                "rank": rank,
                "session": str(session),
                "backend": backend,
                "cann_invoked": False,
                "source_inventory": [
                    dict(source) for source in selected_sources
                ],
                "schema": sqlite_schema,
                "clock_anchors": clock_anchors,
                "source_derivation": source_derivation,
                "quality": quality,
                "quality_flags": (
                    ["conflict_proxy_not_true_stall"]
                    if metric_family == "ResourceConflictRatio"
                    else []
                )
                + (
                    ["one_second_interval_proxy"]
                    if "global_task.comm_compute_overlap_pct"
                    in quality["canonical_metric_ids"]
                    else ["comm_overlap_missing_session_optional"]
                ),
                "missing_metric_ids": missing_metric_ids,
                "outputs": outputs,
                "elapsed_s": time.monotonic() - started,
            }
            atomic_json(report_path, report)
            return report
        report = {
            "schema_version": "r25.real_csv.v1",
            "status": "missing",
            "run_id": run_id,
            "metric": metric_family,
            "rank": rank,
            "session": str(session),
            "backend": "none",
            "reason": (
                "no_existing_op_summary_slice_csv_completed_r23_report"
                "_or_real_schema_sqlite"
            ),
            "cann_invoked": False,
            "outputs": [],
            "elapsed_s": time.monotonic() - started,
        }
        atomic_json(report_path, report)
        return report

    schema = inspect_csv_schema(files, metric_family)
    if schema["status"] != "valid":
        report = {
            "schema_version": "r25.real_csv.v1",
            "status": "partial",
            "run_id": run_id,
            "metric": metric_family,
            "rank": rank,
            "session": str(session),
            "backend": "existing_csv_invalid_schema",
            "schema": schema,
            "cann_invoked": False,
            "outputs": [],
            "elapsed_s": time.monotonic() - started,
        }
        atomic_json(report_path, report)
        return report

    datasets, quality = aggregate_real_csv(
        iter_csv_rows(files), run_id, metric_family, rank
    )
    outputs = _write_outputs(rank_output, datasets)
    missing_metric_ids = sorted(
        _required_metric_ids(metric_family)
        - set(quality["canonical_metric_ids"])
    )
    status = (
        "complete"
        if quality["source_rows"] > 0 and not missing_metric_ids and outputs
        else "partial"
    )
    marker = write_adoption_marker(session, metric_family, files, schema)
    report = {
        "schema_version": "r25.real_csv.v1",
        "status": status,
        "run_id": run_id,
        "metric": metric_family,
        "rank": rank,
        "session": str(session),
        "backend": "existing_real_op_summary_csv",
        "cann_invoked": False,
        "source_inventory": marker["outputs"],
        "summary_marker": str(marker_path(session)),
        "schema": schema,
        "quality": quality,
        "quality_flags": (
            ["conflict_proxy_not_true_stall"]
            if metric_family == "ResourceConflictRatio"
            else []
        )
        + (
            ["one_second_interval_proxy"]
            if "global_task.comm_compute_overlap_pct"
            in quality["canonical_metric_ids"]
            else ["comm_overlap_missing_session_optional"]
        ),
        "missing_metric_ids": missing_metric_ids,
        "outputs": outputs,
        "elapsed_s": time.monotonic() - started,
    }
    atomic_json(report_path, report)
    return report


def _selection_tasks(
    selection: Mapping[str, Any],
) -> list[tuple[str, str, int, Path, Mapping[str, Any]]]:
    tasks: list[tuple[str, str, int, Path, Mapping[str, Any]]] = []
    entries = selection.get("entries")
    if not isinstance(entries, list):
        raise ValueError("selection manifest entries must be a list")
    for entry in entries:
        if not isinstance(entry, Mapping):
            raise ValueError("selection entry must be an object")
        run_id = str(entry["run_id"])
        metric = str(entry["metric"])
        sessions = entry.get("rank_sessions")
        if not isinstance(sessions, Mapping):
            raise ValueError(f"selection entry missing rank_sessions: {run_id}")
        for rank_text, session_text in sessions.items():
            tasks.append(
                (run_id, metric, int(rank_text), Path(str(session_text)), entry)
            )
    return sorted(tasks, key=lambda item: (item[0], item[2]))


def update_metric_coverage(
    path: Path, reports: Sequence[Mapping[str, Any]]
) -> None:
    coverage = dict(load_json(path))
    observed: set[str] = set()
    for report in reports:
        quality = report.get("quality")
        if isinstance(quality, Mapping):
            observed.update(
                str(metric_id)
                for metric_id in quality.get("canonical_metric_ids", [])
            )
    metrics: list[Mapping[str, Any]] = []
    for item in coverage.get("metrics", []):
        row = dict(item)
        metric_id = str(row.get("metric_id"))
        if metric_id in observed:
            row["present"] = True
            row["status"] = "extracted"
            row["output_fields"] = ["canonical_profiler_metrics.parquet"]
        elif metric_id == "global_task.step_time_ms":
            row["present"] = None
            row["status"] = "training_log_packaged_for_local_extraction"
            row["quality_flags"] = ["profiler_step_trace_not_exported"]
        elif row.get("profiler_contract") is not None:
            row["present"] = False
            row["status"] = "not_extracted"
            row["quality_flags"] = ["real_csv_or_sqlite_field_unavailable"]
        else:
            row["present"] = None
            row["status"] = "source_packaged_for_local_validation"
        metrics.append(row)
    coverage["metrics"] = metrics
    coverage["status"] = "complete_with_declared_proxies"
    coverage["profiler_metrics_present"] = sorted(observed)
    coverage["profiler_proxy_metrics"] = [
        "global_task.comm_compute_overlap_pct",
        "npu.aicore_stall_ratio",
    ]
    atomic_json(path, coverage)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--selection-manifest", type=Path, required=True)
    parser.add_argument("--output-root", type=Path, required=True)
    parser.add_argument("--r23-output-root", type=Path)
    parser.add_argument("--metric-coverage", type=Path)
    parser.add_argument("--max-workers", type=int, default=8)
    parser.add_argument("--trust-complete-reports", action="store_true")
    args = parser.parse_args()
    if not 8 <= args.max_workers <= 16:
        raise SystemExit("max-workers must be between 8 and 16")

    selection_path = args.selection_manifest.resolve(strict=True)
    selection = load_json(selection_path)
    tasks = _selection_tasks(selection)
    expected = int(selection.get("expected_session_count", 64))
    if expected != 64 or len(tasks) != 64:
        raise SystemExit(
            f"r25 extraction requires 64 selected sessions; observed {len(tasks)}"
        )

    output_root = args.output_root.resolve(strict=False)
    r23_output_root = (
        args.r23_output_root.resolve(strict=False)
        if args.r23_output_root is not None
        else output_root
    )
    progress_path = output_root / "r25_extraction_progress.json"
    progress: dict[str, Any] = {
        "schema_version": "r25.real_csv.v1",
        "status": "running",
        "selection_manifest": str(selection_path),
        "expected_session_count": 64,
        "max_workers": args.max_workers,
        "sessions": {},
    }
    if progress_path.is_file():
        previous = load_json(progress_path)
        if previous.get("selection_manifest") == str(selection_path):
            progress.update(previous)
            progress["status"] = "running"
            progress["max_workers"] = args.max_workers
    atomic_json(progress_path, progress)

    reports: list[Mapping[str, Any]] = []
    futures: dict[Future[Mapping[str, Any]], tuple[str, int]] = {}
    with ThreadPoolExecutor(max_workers=args.max_workers) as executor:
        for run_id, metric, rank, session, _ in tasks:
            future = executor.submit(
                process_session,
                output_root,
                run_id,
                metric,
                rank,
                session,
                r23_output_root,
                args.trust_complete_reports,
            )
            futures[future] = (run_id, rank)
        for future in as_completed(futures):
            run_id, rank = futures[future]
            try:
                report = future.result()
            except Exception as error:
                report = {
                    "schema_version": "r25.real_csv.v1",
                    "status": "partial",
                    "run_id": run_id,
                    "rank": rank,
                    "backend": "error",
                    "error": f"{type(error).__name__}: {error}",
                    "outputs": [],
                }
            reports.append(report)
            progress["sessions"][f"{run_id}/rank_{rank}"] = report
            atomic_json(progress_path, progress)
            print(
                "R25_SESSION_PROGRESS="
                f"{len(reports)}/64 run_id={run_id} rank={rank} "
                f"status={report.get('status')} "
                f"backend={report.get('backend', 'error')} "
                f"elapsed_s={float(report.get('elapsed_s', 0.0)):.2f}",
                flush=True,
            )

    run_reports: list[Mapping[str, Any]] = []
    for entry in selection["entries"]:
        run_id = str(entry["run_id"])
        selected = [report for report in reports if report.get("run_id") == run_id]
        complete_ranks = sorted(
            int(report["rank"])
            for report in selected
            if report.get("status") == "complete"
        )
        run_reports.append(
            {
                "run_id": run_id,
                "condition": entry.get("condition"),
                "metric": entry["metric"],
                "status": (
                    "complete" if complete_ranks == list(range(16)) else "partial"
                ),
                "rank_coverage": complete_ranks,
                "sessions": sorted(
                    selected, key=lambda report: int(report["rank"])
                ),
            }
        )

    complete_count = sum(report.get("status") == "complete" for report in reports)
    partial_count = sum(report.get("status") == "partial" for report in reports)
    missing_count = sum(report.get("status") == "missing" for report in reports)
    globally_observed_metric_ids = {
        str(metric_id)
        for report in reports
        if isinstance(report.get("quality"), Mapping)
        for metric_id in report["quality"].get("canonical_metric_ids", [])
    }
    overlap_globally_available = (
        "global_task.comm_compute_overlap_pct" in globally_observed_metric_ids
    )
    status = (
        "complete"
        if complete_count == 64 and overlap_globally_available
        else "partial"
    )
    manifest_path = output_root / "dataset_extraction_manifest.json"
    manifest = {
        "schema_version": "r25.real_csv.v1",
        "status": status,
        "selection_manifest": str(selection_path),
        "extraction_mode": "existing_real_csv_or_sqlite_only_no_cann",
        "expected_session_count": 64,
        "observed_session_count": len(reports),
        "complete_session_count": complete_count,
        "partial_session_count": partial_count,
        "missing_session_count": missing_count,
        "coverage": {
            "complete": complete_count,
            "expected": 64,
            "fraction": complete_count / 64,
            "all_64_sessions": complete_count == 64,
        },
        "global_metric_acceptance": {
            "global_task.comm_compute_overlap_pct": {
                "status": (
                    "complete" if overlap_globally_available else "missing"
                ),
                "required_scope": "dataset",
                "not_required_per_session": True,
            }
        },
        "max_workers": args.max_workers,
        "runs": run_reports,
    }
    atomic_json(manifest_path, manifest)
    progress["status"] = status
    progress["complete_session_count"] = complete_count
    atomic_json(progress_path, progress)
    if args.metric_coverage is not None:
        update_metric_coverage(args.metric_coverage.resolve(strict=True), reports)
    print(f"DATASET_EXTRACTION_MANIFEST={manifest_path}")
    return 0 if status == "complete" else 2


if __name__ == "__main__":
    raise SystemExit(main())
