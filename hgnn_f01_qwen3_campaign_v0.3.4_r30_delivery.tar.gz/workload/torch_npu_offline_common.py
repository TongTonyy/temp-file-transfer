#!/usr/bin/env python3
"""Shared helpers for deferred torch_npu profile extraction."""

from __future__ import annotations

import csv
import hashlib
import importlib
import json
import math
import os
import re
from pathlib import Path
from typing import Any, Iterable, Mapping, Sequence


SUPPORTED_METRICS = {"ResourceConflictRatio", "MemoryAccess"}
SESSION_RE = re.compile(r"^rank_(\d+)_.*_ascend_pt$")
TEXT_SUFFIXES = {".csv", ".json", ".txt"}


def resolve_torch_npu_analyse() -> Any:
    """Resolve the canonical CANN API while tolerating older re-exports."""
    errors: list[str] = []
    for module_name in (
        "torch_npu.profiler.profiler",
        "torch_npu.profiler",
    ):
        try:
            module = importlib.import_module(module_name)
        except ImportError as error:
            errors.append(f"{module_name}: {error}")
            continue
        analyse = getattr(module, "analyse", None)
        if callable(analyse):
            return analyse
        errors.append(f"{module_name}: analyse is not exported")
    raise ImportError(
        "torch_npu profiler offline analyse API is unavailable; "
        + "; ".join(errors)
    )


def atomic_json(path: Path, value: Mapping[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(
        json.dumps(value, ensure_ascii=False, indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )
    os.replace(temporary, path)


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def load_json(path: Path) -> Mapping[str, Any]:
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, Mapping):
        raise ValueError(f"JSON root must be an object: {path}")
    return value


def load_dataset_entries(path: Path) -> tuple[Mapping[str, Any], ...]:
    manifest = load_json(path.resolve(strict=True))
    if manifest.get("status") != "complete":
        raise ValueError("dataset collection manifest is not complete")
    entries = manifest.get("entries")
    if not isinstance(entries, list) or len(entries) != 4:
        raise ValueError("dataset collection manifest must contain four entries")
    result: list[Mapping[str, Any]] = []
    seen: set[str] = set()
    for entry in entries:
        if not isinstance(entry, Mapping):
            raise ValueError("dataset entry must be an object")
        run_id = entry.get("run_id")
        metric = entry.get("metric")
        if not isinstance(run_id, str) or not run_id or run_id in seen:
            raise ValueError("dataset run_id is missing or duplicated")
        if metric not in SUPPORTED_METRICS:
            raise ValueError(f"unsupported dataset profiler metric: {metric}")
        profile_root = Path(str(entry.get("profile_root", "")))
        telemetry_root = Path(str(entry.get("telemetry_root", "")))
        if not profile_root.is_absolute() or not telemetry_root.is_absolute():
            raise ValueError("dataset roots must be absolute")
        seen.add(run_id)
        result.append(entry)
    return tuple(result)


def load_profile_sessions(
    profile_root: Path, metric: str
) -> dict[int, Path]:
    metric_root = profile_root.resolve(strict=True) / metric
    if not metric_root.is_dir() or metric_root.is_symlink():
        raise ValueError(f"missing metric profile root: {metric_root}")
    sessions: dict[int, Path] = {}
    for path in metric_root.iterdir():
        match = SESSION_RE.fullmatch(path.name)
        if match is None or not path.is_dir() or path.is_symlink():
            continue
        rank = int(match.group(1))
        if rank in sessions:
            raise ValueError(f"duplicate profile session for rank {rank}")
        sessions[rank] = path.resolve(strict=True)
    if set(sessions) != set(range(16)):
        raise ValueError(
            "profile sessions do not cover ranks 0..15: "
            + ",".join(str(rank) for rank in sorted(sessions))
        )
    return sessions


def analysed_text_files(session: Path) -> tuple[Path, ...]:
    result: list[Path] = []
    for path in session.rglob("*"):
        if path.is_symlink() or not path.is_file():
            continue
        if path.suffix.lower() not in TEXT_SUFFIXES:
            continue
        lowered = path.as_posix().lower()
        if "ascend_profiler_output" not in lowered:
            continue
        result.append(path)
    return tuple(sorted(result))


def csv_columns(path: Path) -> tuple[str, ...]:
    try:
        with path.open(encoding="utf-8-sig", newline="") as stream:
            row = next(csv.reader(stream), ())
    except (OSError, UnicodeDecodeError, csv.Error):
        return ()
    return tuple(str(item).strip() for item in row if str(item).strip())


def json_keys(path: Path) -> tuple[str, ...]:
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, UnicodeDecodeError, json.JSONDecodeError):
        return ()
    keys: set[str] = set()

    def visit(item: Any, depth: int = 0) -> None:
        if depth > 4:
            return
        if isinstance(item, Mapping):
            keys.update(str(key) for key in item)
            for child in item.values():
                visit(child, depth + 1)
        elif isinstance(item, list):
            for child in item[:20]:
                visit(child, depth + 1)

    visit(value)
    return tuple(sorted(keys))


def classify_analysed_file(
    metric: str, path: Path, columns: Sequence[str]
) -> tuple[str, ...]:
    # Do not inspect parent names: the collection directory itself contains the
    # configured metric name and would otherwise classify every output as PMU.
    path_text = path.name.lower()
    column_text = " ".join(str(column) for column in columns).lower()
    text = f"{path_text} {column_text}"
    roles: list[str] = []
    metric_tokens = (
        ("resource", "conflict")
        if metric == "ResourceConflictRatio"
        else ("memory", "access")
    )
    if all(token in text for token in metric_tokens) or any(
        token in text
        for token in (
            "aic_metrics",
            "pmu",
            "op_summary",
            "kernel_details",
            "cube_wait",
            "vec_wait",
            "memory_bound",
            "memory bound",
        )
    ):
        roles.append("pmu")
    if any(
        token in text
        for token in (
            "step_trace",
            "step time",
            "steptime",
            "iteration",
            "overlapped",
        )
    ):
        roles.append("step")
    if (
        "communication" in path_text
        or any(
            token in text
            for token in (
                "hccl",
                "allreduce",
                "all_reduce",
                "allgather",
                "reduce_scatter",
            )
        )
    ):
        roles.append("hccl")
    if any(
        token in text
        for token in ("op_summary", "operator", "kernel_details", "kernel name")
    ):
        roles.append("operator")
    return tuple(dict.fromkeys(roles))


def schema_for_session(metric: str, session: Path) -> Mapping[str, Any]:
    files: list[Mapping[str, Any]] = []
    role_counts = {"pmu": 0, "step": 0, "hccl": 0, "operator": 0}
    for path in analysed_text_files(session):
        columns = (
            csv_columns(path)
            if path.suffix.lower() == ".csv"
            else json_keys(path)
            if path.suffix.lower() == ".json"
            else ()
        )
        roles = classify_analysed_file(metric, path, columns)
        for role in roles:
            role_counts[role] += 1
        files.append(
            {
                "relative_path": path.relative_to(session).as_posix(),
                "suffix": path.suffix.lower(),
                "size_bytes": path.stat().st_size,
                "columns_or_keys": list(columns),
                "roles": list(roles),
            }
        )
    required_roles = ("pmu", "step", "hccl")
    missing = [role for role in required_roles if role_counts[role] == 0]
    return {
        "metric": metric,
        "probe_session": str(session),
        "files": files,
        "role_counts": role_counts,
        "required_roles": list(required_roles),
        "missing_required_roles": missing,
        "status": "ready" if not missing else "incomplete",
    }


def iter_records(path: Path) -> Iterable[Mapping[str, Any]]:
    suffix = path.suffix.lower()
    if suffix == ".csv":
        try:
            with path.open(encoding="utf-8-sig", newline="") as stream:
                yield from csv.DictReader(stream)
        except (OSError, UnicodeDecodeError, csv.Error):
            return
    elif suffix == ".json":
        try:
            value = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, UnicodeDecodeError, json.JSONDecodeError):
            return

        def walk(item: Any) -> Iterable[Mapping[str, Any]]:
            if isinstance(item, Mapping):
                scalar = {
                    str(key): child
                    for key, child in item.items()
                    if not isinstance(child, (Mapping, list))
                }
                if scalar:
                    yield scalar
                for child in item.values():
                    yield from walk(child)
            elif isinstance(item, list):
                for child in item:
                    yield from walk(child)

        yield from walk(value)


def numeric(value: Any) -> float | None:
    if isinstance(value, bool) or value is None:
        return None
    try:
        result = float(str(value).strip().rstrip("%"))
    except (TypeError, ValueError):
        return None
    return result if math.isfinite(result) else None


def percentile(values: Sequence[float], quantile: float) -> float:
    if not values:
        raise ValueError("percentile requires values")
    ordered = sorted(values)
    if len(ordered) == 1:
        return ordered[0]
    position = (len(ordered) - 1) * quantile
    lower = math.floor(position)
    upper = math.ceil(position)
    if lower == upper:
        return ordered[lower]
    weight = position - lower
    return ordered[lower] * (1.0 - weight) + ordered[upper] * weight


def aggregate(values: Sequence[float]) -> Mapping[str, float | int]:
    return {
        "count": len(values),
        "mean": sum(values) / len(values),
        "min": min(values),
        "max": max(values),
        "p50": percentile(values, 0.50),
        "p95": percentile(values, 0.95),
    }


def first_value(
    row: Mapping[str, Any], tokens: Sequence[str]
) -> tuple[str | None, Any]:
    for key, value in row.items():
        lowered = str(key).lower().replace("_", " ")
        if all(token in lowered for token in tokens):
            return str(key), value
    return None, None
