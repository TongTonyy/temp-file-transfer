#!/usr/bin/env python3
"""Extract r29 sampled profiler segments into raw canonical artifacts."""

from __future__ import annotations

import argparse
import json
import time
from concurrent.futures import Future, ThreadPoolExecutor, as_completed
from pathlib import Path
from typing import Any, Mapping, Sequence

from extract_r25_real_csv_metrics import process_session
from r29_parse_segments import EXPECTED_RANKS, discover_segment_sessions
from r28_extract_group import sanitize_session_report
from torch_npu_offline_common import atomic_json, load_json


def extract_segments(
    *,
    profile_root: Path,
    output_root: Path,
    run_id: str,
    key: str,
    condition: str,
    metric: str,
    sample_plan: Path,
    parse_report: Path,
    max_workers: int,
    trust_complete_reports: bool,
) -> Mapping[str, Any]:
    started = time.monotonic()
    plan = load_json(sample_plan.resolve(strict=True))
    parse = load_json(parse_report.resolve(strict=True))
    if parse.get("status") != "complete":
        raise SystemExit("parse report is not complete")
    segments = plan.get("segments")
    if not isinstance(segments, list):
        raise SystemExit("sample plan segments missing")
    run_root = output_root.resolve(strict=False) / run_id
    segment_reports: list[Mapping[str, Any]] = []
    for segment in segments:
        if not isinstance(segment, Mapping):
            raise SystemExit("invalid segment in sample plan")
        segment_id = str(segment["segment_id"])
        sessions = discover_segment_sessions(profile_root, metric, segment_id)
        reports: list[Mapping[str, Any]] = []
        futures: dict[Future[Mapping[str, Any]], int] = {}
        with ThreadPoolExecutor(max_workers=max_workers) as executor:
            for rank, session in sorted(sessions.items()):
                future = executor.submit(
                    process_session,
                    run_root,
                    segment_id,
                    metric,
                    rank,
                    session,
                    run_root,
                    trust_complete_reports,
                )
                futures[future] = rank
            for future in as_completed(futures):
                rank = futures[future]
                report = dict(future.result())
                report["parent_run_id"] = run_id
                report["segment_id"] = segment_id
                report = dict(
                    sanitize_session_report(
                        report,
                        run_root
                        / segment_id
                        / f"rank_{int(report['rank'])}"
                        / "r25_session_report.json",
                    )
                )
                reports.append(report)
                print(
                    "R29_EXTRACT_PROGRESS="
                    f"{segment_id}:{len(reports)}/16 rank={rank} "
                    f"status={report.get('status')}",
                    flush=True,
                )
        reports = sorted(reports, key=lambda item: int(item["rank"]))
        complete = [
            int(report["rank"]) for report in reports if report.get("status") == "complete"
        ]
        status = "complete" if complete == list(range(EXPECTED_RANKS)) else "partial"
        manifest = {
            "schema_version": "r29.segment_extraction.v1",
            "status": status,
            "run_id": run_id,
            "segment_id": segment_id,
            "key": key,
            "condition": condition,
            "metric": metric,
            "phase": segment.get("phase"),
            "target_s": segment.get("target_s"),
            "active_steps": segment.get("active_steps"),
            "rank_count": len(reports),
            "rank_reports": [
                str(run_root / segment_id / f"rank_{int(row['rank'])}" / "r25_session_report.json")
                for row in reports
            ],
        }
        atomic_json(run_root / "segments" / f"{segment_id}.json", manifest)
        segment_reports.append(manifest)
    complete_segments = [
        report for report in segment_reports if report.get("status") == "complete"
    ]
    group_manifest = {
        "schema_version": "r29.group_extraction.v1",
        "status": (
            "complete"
            if len(complete_segments) == len(segment_reports)
            else "partial"
        ),
        "run_id": run_id,
        "key": key,
        "condition": condition,
        "metric": metric,
        "sample_plan": str(sample_plan.resolve(strict=True)),
        "parse_report": str(parse_report.resolve(strict=True)),
        "segment_count": len(segment_reports),
        "complete_segment_count": len(complete_segments),
        "segments": [
            str(run_root / "segments" / f"{report['segment_id']}.json")
            for report in segment_reports
        ],
        "elapsed_s": time.monotonic() - started,
    }
    atomic_json(run_root / "r29_group_extraction_manifest.json", group_manifest)
    print(f"R29_GROUP_EXTRACTION_MANIFEST={run_root / 'r29_group_extraction_manifest.json'}")
    print(f"R29_GROUP_EXTRACT_STATUS={group_manifest['status']}")
    return group_manifest


def main(argv: Sequence[str] | None = None) -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--profile-root", type=Path, required=True)
    parser.add_argument("--output-root", type=Path, required=True)
    parser.add_argument("--run-id", required=True)
    parser.add_argument("--key", required=True)
    parser.add_argument("--condition", required=True)
    parser.add_argument("--metric", required=True)
    parser.add_argument("--sample-plan", type=Path, required=True)
    parser.add_argument("--parse-report", type=Path, required=True)
    parser.add_argument("--max-workers", type=int, default=8)
    parser.add_argument("--trust-complete-reports", action="store_true")
    args = parser.parse_args(argv)
    manifest = extract_segments(
        profile_root=args.profile_root,
        output_root=args.output_root,
        run_id=args.run_id,
        key=args.key,
        condition=args.condition,
        metric=args.metric,
        sample_plan=args.sample_plan,
        parse_report=args.parse_report,
        max_workers=args.max_workers,
        trust_complete_reports=args.trust_complete_reports,
    )
    return 0 if manifest["status"] == "complete" else 2


if __name__ == "__main__":
    raise SystemExit(main())
