#!/usr/bin/env python3
"""Deep audit of r25 extraction outputs against the dataset manifest contract."""

from __future__ import annotations

import argparse
import json
import math
from pathlib import Path
from typing import Any, Mapping, Sequence

from prepare_r23_extraction_contract import (
    EXPECTED_CASE_SPECS,
    required_metric_ids_for_family,
)
from torch_npu_offline_common import (
    atomic_json,
    load_dataset_entries,
    load_json,
    load_profile_sessions,
    sha256,
)

REPORT_NAME = "r25_session_report.json"
CANONICAL_PARQUET = "canonical_profiler_metrics.parquet"
AFFECTED_RECOLLECTION_KEYS = (
    "control_resource_conflict",
    "fault_resource_conflict",
    "fault_memory_access",
)
REUSABLE_IF_ALL_VERIFIED_KEY = "control_memory_access"
TRUSTED_BACKENDS = frozenset(
    {
        "existing_real_op_summary_csv",
        "existing_real_sqlite",
        "existing_real_sqlite_split_join",
        "reused_completed_r23_session_report",
    }
)


def read_parquet_rows(path: Path) -> list[Mapping[str, Any]]:
    """Read real Zstd Parquet or JSON-encoded test fixtures."""
    data = path.read_bytes()
    if len(data) >= 4 and (data[:4] == b"PAR1" or data[-4:] == b"PAR1"):
        import pyarrow.parquet as pq

        return pq.read_table(path).to_pylist()
    try:
        parsed = json.loads(data.decode("utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError) as error:
        raise ValueError(f"unreadable parquet payload: {path}") from error
    if not isinstance(parsed, list):
        raise ValueError(f"parquet fixture must be a JSON list: {path}")
    return [row for row in parsed if isinstance(row, Mapping)]


def _finite_number(value: Any) -> float | None:
    if isinstance(value, bool):
        return None
    if isinstance(value, (int, float)):
        number = float(value)
        return number if math.isfinite(number) else None
    return None


def _verify_report_outputs(report: Mapping[str, Any]) -> tuple[bool, list[str], list[Path]]:
    reasons: list[str] = []
    paths: list[Path] = []
    outputs = report.get("outputs")
    if not isinstance(outputs, list) or not outputs:
        return False, ["report_missing_outputs"], paths
    for item in outputs:
        if not isinstance(item, Mapping):
            reasons.append("report_output_not_object")
            continue
        output = Path(str(item.get("path", "")))
        if not output.is_file() or output.is_symlink():
            reasons.append(f"missing_output:{output.name}")
            continue
        size_bytes = item.get("size_bytes")
        digest = item.get("sha256")
        if not isinstance(size_bytes, int) or output.stat().st_size != size_bytes:
            reasons.append(f"size_mismatch:{output.name}")
            continue
        if not isinstance(digest, str) or sha256(output) != digest:
            reasons.append(f"sha256_mismatch:{output.name}")
            continue
        paths.append(output.resolve(strict=True))
    return not reasons, reasons, paths


def _canonical_path(rank_output: Path) -> Path:
    return rank_output / CANONICAL_PARQUET


def _audit_canonical_parquet(
    path: Path,
    metric_family: str,
    report: Mapping[str, Any],
) -> tuple[bool, list[str], Mapping[str, Any]]:
    reasons: list[str] = []
    details: dict[str, Any] = {
        "path": str(path),
        "row_count": 0,
        "metric_ids": [],
        "timestamp_min_us": None,
        "timestamp_max_us": None,
        "finite_values_ok": False,
    }
    if not path.is_file() or path.is_symlink():
        return False, ["canonical_parquet_missing"], details
    try:
        rows = read_parquet_rows(path)
    except ValueError as error:
        return False, [f"canonical_parquet_unreadable:{error}"], details
    details["row_count"] = len(rows)
    if not rows:
        return False, ["canonical_parquet_empty"], details

    required = required_metric_ids_for_family(metric_family)
    observed_ids: set[str] = set()
    timestamp_min: float | None = None
    timestamp_max: float | None = None
    finite_ok = True
    for row in rows:
        metric_id = str(row.get("metric_id", ""))
        if metric_id:
            observed_ids.add(metric_id)
        value = _finite_number(row.get("value"))
        if value is None:
            finite_ok = False
            reasons.append(f"non_finite_value:{metric_id or 'unknown'}")
        bin_us = _finite_number(row.get("profiler_time_bin_us"))
        if bin_us is None:
            finite_ok = False
            reasons.append(f"non_finite_time_bin:{metric_id or 'unknown'}")
        else:
            timestamp_min = bin_us if timestamp_min is None else min(timestamp_min, bin_us)
            timestamp_max = bin_us if timestamp_max is None else max(timestamp_max, bin_us)

    missing = sorted(required - observed_ids)
    if missing:
        reasons.append(f"missing_primary_metrics:{','.join(missing)}")
    details["metric_ids"] = sorted(observed_ids)
    details["timestamp_min_us"] = timestamp_min
    details["timestamp_max_us"] = timestamp_max
    details["finite_values_ok"] = finite_ok and not missing

    quality = report.get("quality")
    if isinstance(quality, Mapping):
        reported_min = _finite_number(quality.get("profiler_timestamp_min_us"))
        reported_max = _finite_number(quality.get("profiler_timestamp_max_us"))
        if (
            reported_min is not None
            and timestamp_min is not None
            and reported_min > timestamp_min + 1.0
        ):
            reasons.append("quality_min_after_parquet_bins")
        if (
            reported_max is not None
            and timestamp_max is not None
            and reported_max + 1.0 < timestamp_max
        ):
            reasons.append("quality_max_before_parquet_bins")

    return not reasons, reasons, details


def _source_lineage(report: Mapping[str, Any]) -> Mapping[str, Any]:
    backend = str(report.get("backend", ""))
    lineage: dict[str, Any] = {"backend": backend}
    if backend == "existing_real_op_summary_csv":
        marker = report.get("summary_marker")
        inventory = report.get("source_inventory")
        lineage["summary_marker"] = marker
        lineage["source_inventory_count"] = (
            len(inventory) if isinstance(inventory, list) else 0
        )
    elif backend in {"existing_real_sqlite", "existing_real_sqlite_split_join"}:
        inventory = report.get("source_inventory")
        lineage["source_inventory"] = (
            list(inventory) if isinstance(inventory, list) else []
        )
        if report.get("clock_anchors") is not None:
            lineage["clock_anchors"] = report.get("clock_anchors")
        if report.get("source_derivation") is not None:
            lineage["source_derivation"] = report.get("source_derivation")
    elif backend == "reused_completed_r23_session_report":
        lineage["r23_session_report"] = report.get("r23_session_report")
    return lineage


def audit_rank_session(
    extraction_root: Path,
    run_id: str,
    metric_family: str,
    rank: int,
    session: Path,
) -> Mapping[str, Any]:
    rank_output = extraction_root / run_id / f"rank_{rank}"
    report_path = rank_output / REPORT_NAME
    result: dict[str, Any] = {
        "run_id": run_id,
        "rank": rank,
        "session": str(session),
        "report_path": str(report_path),
        "verified": False,
        "rejection_reasons": [],
    }
    if not report_path.is_file() or report_path.is_symlink():
        result["rejection_reasons"] = ["missing_report"]
        result["status"] = "missing"
        return result

    try:
        report = load_json(report_path)
    except (OSError, ValueError, json.JSONDecodeError):
        result["rejection_reasons"] = ["invalid_report_json"]
        result["status"] = "rejected"
        return result

    backend = str(report.get("backend", ""))
    result["backend"] = backend
    result["report_status"] = report.get("status")
    result["source_lineage"] = _source_lineage(report)

    reasons: list[str] = []
    if backend not in TRUSTED_BACKENDS:
        reasons.append(f"untrusted_backend:{backend or 'missing'}")
    if report.get("metric") != metric_family:
        reasons.append("metric_family_mismatch")
    if report.get("run_id") != run_id:
        reasons.append("run_id_mismatch")
    if int(report.get("rank", -1)) != rank:
        reasons.append("rank_mismatch")

    outputs_ok, output_reasons, output_paths = _verify_report_outputs(report)
    reasons.extend(output_reasons)

    canonical = _canonical_path(rank_output)
    if canonical not in output_paths and not canonical.is_file():
        reasons.append("canonical_not_in_verified_outputs")

    parquet_ok, parquet_reasons, parquet_details = _audit_canonical_parquet(
        canonical, metric_family, report
    )
    reasons.extend(parquet_reasons)
    result["primary_metric_ids"] = sorted(
        required_metric_ids_for_family(metric_family)
    )
    result["parquet"] = parquet_details
    result["time_window_us"] = {
        "min": parquet_details.get("timestamp_min_us"),
        "max": parquet_details.get("timestamp_max_us"),
    }

    if report.get("status") == "complete" and reasons:
        reasons.append("pseudo_complete_report")

    verified = outputs_ok and parquet_ok and not reasons
    result["verified"] = verified
    result["rejection_reasons"] = sorted(set(reasons))
    result["status"] = "verified" if verified else "rejected"
    return result


def audit_group(
    entry: Mapping[str, Any],
    extraction_root: Path,
) -> Mapping[str, Any]:
    key = str(entry["key"])
    run_id = str(entry["run_id"])
    metric_family = str(entry["metric"])
    spec = EXPECTED_CASE_SPECS[key]
    sessions = load_profile_sessions(Path(str(entry["profile_root"])), metric_family)
    rank_audits = [
        audit_rank_session(
            extraction_root,
            run_id,
            metric_family,
            rank,
            sessions[rank],
        )
        for rank in range(16)
    ]
    verified_ranks = sorted(
        int(row["rank"]) for row in rank_audits if row.get("verified") is True
    )
    failed_ranks = sorted(
        int(row["rank"])
        for row in rank_audits
        if row.get("status") in {"rejected", "missing"}
    )
    strict_complete = verified_ranks == list(range(16))
    recollection_required = key in AFFECTED_RECOLLECTION_KEYS
    if key == REUSABLE_IF_ALL_VERIFIED_KEY:
        strict_synchronized_reusable = strict_complete
        reuse_reason = (
            "all_sixteen_ranks_deep_verified"
            if strict_complete
            else "control_memory_requires_16_of_16"
        )
    else:
        strict_synchronized_reusable = False
        reuse_reason = "affected_group_fixed_recollect"

    return {
        "key": key,
        "run_id": run_id,
        "condition": entry.get("condition"),
        "metric": metric_family,
        "pair": entry.get("pair", spec.get("pair")),
        "expected_rank_count": 16,
        "verified_complete_ranks": verified_ranks,
        "failed_ranks": failed_ranks,
        "verified_session_count": len(verified_ranks),
        "strict_synchronized_reusable": strict_synchronized_reusable,
        "recollection_required": recollection_required,
        "reuse_decision_reason": reuse_reason,
        "rank_audits": rank_audits,
    }


def build_merge_plan(groups: Sequence[Mapping[str, Any]]) -> Mapping[str, Any]:
    by_key = {str(group["key"]): group for group in groups}
    control = by_key[REUSABLE_IF_ALL_VERIFIED_KEY]
    affected = [by_key[key] for key in AFFECTED_RECOLLECTION_KEYS]
    reused_verified = control["verified_session_count"] == 16
    reused_sessions = [
        {
            "run_id": control["run_id"],
            "rank": int(row["rank"]),
            "session": row["session"],
        }
        for row in control["rank_audits"]
        if row.get("verified") is True
    ]
    new_sessions: list[Mapping[str, Any]] = []
    for group in affected:
        for rank in range(16):
            row = group["rank_audits"][rank]
            new_sessions.append(
                {
                    "key": group["key"],
                    "run_id": group["run_id"],
                    "rank": rank,
                    "session": row["session"],
                    "current_status": row.get("status"),
                }
            )
    return {
        "semantics": (
            "reused_16 verified sessions from control_memory_access when all "
            "16 ranks pass deep audit; new_48 sessions from the three fixed "
            "affected groups requiring strict synchronized re-collection; "
            "merged_session_count=reused_16+new_48"
        ),
        "reused_16": {
            "key": REUSABLE_IF_ALL_VERIFIED_KEY,
            "run_id": control["run_id"],
            "verified": reused_verified,
            "session_count": len(reused_sessions) if reused_verified else 0,
            "sessions": reused_sessions if reused_verified else [],
        },
        "new_48": {
            "keys": list(AFFECTED_RECOLLECTION_KEYS),
            "session_count": 48,
            "groups": [
                {
                    "key": group["key"],
                    "run_id": group["run_id"],
                    "verified_complete_ranks": group["verified_complete_ranks"],
                }
                for group in affected
            ],
            "sessions": new_sessions,
        },
        "merged_session_count": (
            (16 if reused_verified else 0) + len(new_sessions)
        ),
    }


def build_excluded_old_groups(
    manifest_path: Path,
    groups: Sequence[Mapping[str, Any]],
) -> list[Mapping[str, Any]]:
    manifest = load_json(manifest_path)
    campaign_id = str(manifest.get("campaign_id", manifest_path.parent.name))
    active_run_ids = {str(group["run_id"]) for group in groups}
    excluded: list[Mapping[str, Any]] = []
    for group in groups:
        key = str(group["key"])
        prefix = f"{campaign_id}-{key}-a"
        excluded.append(
            {
                "key": key,
                "pattern": f"{prefix}<attempt>",
                "active_run_id": group["run_id"],
                "reason": "superseded_by_manifest_active_run",
            }
        )
        for attempt in range(1, 20):
            candidate = f"{prefix}{attempt}"
            if candidate not in active_run_ids:
                excluded.append(
                    {
                        "run_id": candidate,
                        "key": key,
                        "reason": "legacy_attempt_excluded",
                    }
                )
    return excluded


def audit_contract(
    dataset_manifest: Path,
    extraction_root: Path,
) -> Mapping[str, Any]:
    entries = load_dataset_entries(dataset_manifest)
    by_key = {str(entry.get("key")): entry for entry in entries}
    if set(by_key) != set(EXPECTED_CASE_SPECS):
        raise ValueError("dataset manifest keys do not match expected four cases")
    for key, spec in EXPECTED_CASE_SPECS.items():
        entry = by_key[key]
        for field in ("condition", "metric", "pair"):
            expected = spec.get(field)
            if expected is not None and entry.get(field) != expected:
                raise ValueError(
                    f"{key} {field} mismatch: expected {expected!r}, "
                    f"observed {entry.get(field)!r}"
                )

    groups = [audit_group(entry, extraction_root.resolve(strict=False)) for entry in entries]
    merge_plan = build_merge_plan(groups)
    excluded = build_excluded_old_groups(dataset_manifest, groups)
    all_verified = sum(group["verified_session_count"] for group in groups)
    return {
        "schema_version": "r27.audit_contract.v1",
        "status": "complete",
        "strict_synchronized": True,
        "dataset_manifest": str(dataset_manifest.resolve(strict=True)),
        "extraction_root": str(extraction_root.resolve(strict=False)),
        "group_count": 4,
        "expected_session_count": 64,
        "deep_verified_session_count": all_verified,
        "groups": groups,
        "merge_plan": merge_plan,
        "excluded_old_groups": excluded,
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--dataset-manifest", type=Path, required=True)
    parser.add_argument("--extraction-root", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    report = audit_contract(args.dataset_manifest, args.extraction_root)
    output = args.output.resolve(strict=False)
    atomic_json(output, report)
    print(f"R27_AUDIT_CONTRACT={output}")
    print(
        "R27_MERGE_PLAN="
        f"reused_16={report['merge_plan']['reused_16']['session_count']} "
        f"new_48={report['merge_plan']['new_48']['session_count']} "
        f"merged={report['merge_plan']['merged_session_count']}"
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
