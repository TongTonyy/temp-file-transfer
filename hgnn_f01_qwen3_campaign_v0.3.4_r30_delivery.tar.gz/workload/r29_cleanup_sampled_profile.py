#!/usr/bin/env python3
"""Clean r29 sampled raw profiler roots after segment extraction."""

from __future__ import annotations

import argparse
import shutil
import time
from pathlib import Path
from typing import Any, Mapping, Sequence

from r28_cleanup_raw_profile import _regular_file_size, _safe_profile_root
from torch_npu_offline_common import atomic_json, load_json, sha256


def _verify_group_extraction(
    group_manifest: Path,
    extraction_root: Path,
    run_id: str,
) -> Mapping[str, Any]:
    group = load_json(group_manifest.resolve(strict=True))
    if group.get("status") != "complete" or group.get("run_id") != run_id:
        raise SystemExit("r29 group extraction is not complete")
    segments = group.get("segments")
    if not isinstance(segments, list) or not segments:
        raise SystemExit("r29 group extraction has no segment manifests")
    for segment_text in segments:
        segment_path = Path(str(segment_text)).resolve(strict=True)
        if not segment_path.is_relative_to(extraction_root.resolve(strict=False)):
            raise SystemExit(f"segment manifest escaped extraction root: {segment_path}")
        segment = load_json(segment_path)
        if segment.get("status") != "complete" or segment.get("run_id") != run_id:
            raise SystemExit(f"segment extraction incomplete: {segment_path}")
        reports = segment.get("rank_reports")
        if not isinstance(reports, list) or len(reports) != 16:
            raise SystemExit(f"segment rank reports invalid: {segment_path}")
        for rank, report_text in enumerate(reports):
            report_path = Path(str(report_text)).resolve(strict=True)
            report = load_json(report_path)
            if report.get("status") != "complete" or int(report.get("rank", -1)) != rank:
                raise SystemExit(f"rank report incomplete: {report_path}")
            for output_row in report.get("outputs", []):
                output = Path(str(output_row.get("path", ""))).resolve(strict=True)
                if output.stat().st_size != output_row.get("size_bytes"):
                    raise SystemExit(f"output size mismatch: {output}")
                if sha256(output) != output_row.get("sha256"):
                    raise SystemExit(f"output sha256 mismatch: {output}")
    return group


def copy_profile_plans(profile_root: Path, output_root: Path) -> list[Mapping[str, Any]]:
    copied: list[Mapping[str, Any]] = []
    for rank in range(16):
        source = profile_root / f"rank_{rank}/hgnn_profile_plan.json"
        if not source.is_file() or source.is_symlink():
            raise SystemExit(f"missing profile plan: {source}")
        target = output_root / f"rank_{rank}/hgnn_profile_plan.json"
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(source, target)
        copied.append(
            {
                "rank": rank,
                "path": str(target),
                "size_bytes": target.stat().st_size,
                "sha256": sha256(target),
            }
        )
    return copied


def cleanup_sampled_profile(
    *,
    root: Path,
    profile_root: Path,
    extraction_root: Path,
    group_manifest: Path,
    run_id: str,
    profile_plans_output: Path,
    cleanup_report: Path,
) -> Mapping[str, Any]:
    started = time.monotonic()
    safe_profile_root = _safe_profile_root(root.resolve(strict=True), profile_root, run_id)
    group = _verify_group_extraction(group_manifest, extraction_root, run_id)
    file_count, bytes_total = _regular_file_size(safe_profile_root)
    plans = copy_profile_plans(safe_profile_root, profile_plans_output)
    shutil.rmtree(safe_profile_root)
    deleted = not safe_profile_root.exists()
    if not deleted:
        raise SystemExit("sampled raw profile still exists after cleanup")
    report = {
        "schema_version": "r29.raw_cleanup.v1",
        "status": "complete",
        "run_id": run_id,
        "key": group.get("key"),
        "segment_count": group.get("segment_count"),
        "profile_root": str(safe_profile_root),
        "raw_file_count": file_count,
        "raw_bytes_deleted": bytes_total,
        "profile_plans_output": str(profile_plans_output),
        "profile_plans": plans,
        "group_manifest": str(group_manifest.resolve(strict=True)),
        "elapsed_s": time.monotonic() - started,
    }
    atomic_json(cleanup_report, report)
    print(f"R29_RAW_CLEANUP_REPORT={cleanup_report}")
    print("RAW_PROFILE_DELETED=1")
    print(f"R29_RAW_BYTES_DELETED={bytes_total}")
    return report


def main(argv: Sequence[str] | None = None) -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", type=Path, required=True)
    parser.add_argument("--profile-root", type=Path, required=True)
    parser.add_argument("--extraction-root", type=Path, required=True)
    parser.add_argument("--group-manifest", type=Path, required=True)
    parser.add_argument("--run-id", required=True)
    parser.add_argument("--profile-plans-output", type=Path, required=True)
    parser.add_argument("--cleanup-report", type=Path, required=True)
    args = parser.parse_args(argv)
    cleanup_sampled_profile(
        root=args.root,
        profile_root=args.profile_root,
        extraction_root=args.extraction_root,
        group_manifest=args.group_manifest,
        run_id=args.run_id,
        profile_plans_output=args.profile_plans_output,
        cleanup_report=args.cleanup_report,
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
