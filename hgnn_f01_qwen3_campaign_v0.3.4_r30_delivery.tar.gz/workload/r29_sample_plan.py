#!/usr/bin/env python3
"""Build and validate r29 sampled profiler plans."""

from __future__ import annotations

import argparse
import json
import re
from pathlib import Path
from typing import Any, Mapping, Sequence

from torch_npu_offline_common import atomic_json, load_json

SCHEMA_VERSION = "r29.sample_plan.v1"
SEGMENT_RE = re.compile(r"^[a-z][a-z0-9_]*$")

DEFAULT_SEGMENTS: tuple[tuple[str, str, float, int], ...] = (
    ("pre_fault_stable", "fault_pre_stable", -30.0, 3),
    ("pre_fault_edge", "fault_pre_edge", -5.0, 5),
    ("post_fault_edge", "fault_post_edge", 5.0, 5),
    ("fault_early", "fault_early", 30.0, 3),
    ("fault_mid", "fault_mid", 150.0, 3),
    ("pre_release_edge", "release_pre_edge", 295.0, 5),
    ("post_release_edge", "release_post_edge", 305.0, 5),
    ("recovery_stable", "recovery_stable", 360.0, 3),
)


def default_sample_plan(
    *,
    run_id: str,
    metric: str,
    condition: str,
    duration_s: float,
    baseline_s: float,
    release_at_s: float,
) -> Mapping[str, Any]:
    fault_window_s = release_at_s - baseline_s
    if fault_window_s <= 0:
        raise ValueError("release_at_s must be greater than baseline_s")
    segments: list[Mapping[str, Any]] = []
    for segment_id, phase, offset_s, active_steps in DEFAULT_SEGMENTS:
        target_s = baseline_s + offset_s
        if target_s < 0 or target_s > duration_s:
            raise ValueError(f"sample target out of campaign bounds: {segment_id}")
        boundary = (
            "fault_apply"
            if "fault" in phase and "release" not in phase
            else "fault_release"
            if "release" in phase
            else "recovery"
        )
        segments.append(
            {
                "segment_id": segment_id,
                "phase": phase,
                "boundary": boundary,
                "target_s": target_s,
                "offset_from_fault_apply_s": target_s - baseline_s,
                "offset_from_fault_release_s": target_s - release_at_s,
                "active_steps": active_steps,
            }
        )
    return {
        "schema_version": SCHEMA_VERSION,
        "run_id": run_id,
        "condition": condition,
        "metric": metric,
        "duration_s": duration_s,
        "baseline_s": baseline_s,
        "release_at_s": release_at_s,
        "fault_window_s": fault_window_s,
        "segment_count": len(segments),
        "total_active_steps": sum(int(row["active_steps"]) for row in segments),
        "segments": segments,
        "aggregation_policy": "none_on_910c_raw_segments_only",
    }


def validate_sample_plan(plan: Mapping[str, Any]) -> None:
    if plan.get("schema_version") != SCHEMA_VERSION:
        raise ValueError("invalid r29 sample plan schema")
    duration_s = float(plan["duration_s"])
    segments = plan.get("segments")
    if not isinstance(segments, list) or not segments:
        raise ValueError("sample plan requires segments")
    seen: set[str] = set()
    previous = -1.0
    for item in segments:
        if not isinstance(item, Mapping):
            raise ValueError("segment must be an object")
        segment_id = str(item.get("segment_id", ""))
        if not SEGMENT_RE.fullmatch(segment_id):
            raise ValueError(f"invalid segment_id: {segment_id}")
        if segment_id in seen:
            raise ValueError(f"duplicate segment_id: {segment_id}")
        seen.add(segment_id)
        target_s = float(item["target_s"])
        if target_s < 0 or target_s > duration_s:
            raise ValueError(f"segment target out of bounds: {segment_id}")
        if target_s <= previous:
            raise ValueError("sample segments must be strictly increasing")
        previous = target_s
        active_steps = int(item["active_steps"])
        if active_steps < 1 or active_steps > 20:
            raise ValueError(f"invalid active_steps for {segment_id}: {active_steps}")


def main(argv: Sequence[str] | None = None) -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--run-id", required=True)
    parser.add_argument("--metric", required=True)
    parser.add_argument("--condition", required=True)
    parser.add_argument("--duration-s", type=float, default=600.0)
    parser.add_argument("--baseline-s", type=float, default=120.0)
    parser.add_argument("--release-at-s", type=float, default=420.0)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--validate-only", type=Path)
    args = parser.parse_args(argv)
    if args.validate_only is not None:
        validate_sample_plan(load_json(args.validate_only))
        print(f"R29_SAMPLE_PLAN_VALID={args.validate_only}")
        return 0
    plan = default_sample_plan(
        run_id=args.run_id,
        metric=args.metric,
        condition=args.condition,
        duration_s=args.duration_s,
        baseline_s=args.baseline_s,
        release_at_s=args.release_at_s,
    )
    validate_sample_plan(plan)
    atomic_json(args.output, plan)
    print(f"R29_SAMPLE_PLAN={args.output}")
    print(f"R29_SAMPLE_SEGMENTS={plan['segment_count']}")
    print(f"R29_SAMPLE_ACTIVE_STEPS={plan['total_active_steps']}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
