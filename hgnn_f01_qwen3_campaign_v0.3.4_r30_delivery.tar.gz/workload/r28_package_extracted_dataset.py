#!/usr/bin/env python3
"""Package r28 extracted artifacts without raw profiler traces."""

from __future__ import annotations

import argparse
import os
import re
import tarfile
import tempfile
from pathlib import Path
from typing import Any, Iterable, Mapping

from package_extracted_dataset import forbidden
from torch_npu_offline_common import atomic_json, load_json, sha256

TELEMETRY_DIRS = ("raw", "normalized", "aligned")


def regular_files(root: Path) -> Iterable[Path]:
    if not root.exists() or root.is_symlink():
        return
    if root.is_file():
        yield root
        return
    for path in sorted(root.rglob("*")):
        if path.is_file() and not path.is_symlink():
            yield path


def add_tree(
    selected: dict[str, Path],
    excluded: list[Mapping[str, str]],
    root: Path,
    arc_root: str,
) -> None:
    for path in regular_files(root):
        reason = forbidden(path)
        if reason:
            excluded.append({"path": str(path), "reason": reason})
            continue
        relative = path.relative_to(root) if root.is_dir() else Path(path.name)
        arcname = (Path(arc_root) / relative).as_posix()
        previous = selected.get(arcname)
        if previous is not None and previous != path:
            raise ValueError(f"archive path collision: {arcname}")
        selected[arcname] = path.resolve(strict=True)


def campaign_root_from_manifest(manifest: Path) -> Path:
    resolved = manifest.resolve(strict=True)
    try:
        root = resolved.parents[3]
    except IndexError as error:
        raise ValueError("dataset manifest path is too shallow") from error
    if root.joinpath("runtime").resolve(strict=True) != resolved.parents[2]:
        raise ValueError("dataset manifest is not below runtime/manifests/<campaign>")
    return root


def select_payload(
    dataset_manifest: Path,
    extraction_root: Path,
) -> tuple[dict[str, Path], list[Mapping[str, str]], Mapping[str, Any], Path]:
    dataset = load_json(dataset_manifest.resolve(strict=True))
    entries = dataset.get("entries")
    if not isinstance(entries, list):
        raise SystemExit("dataset manifest entries missing")
    campaign_id = str(dataset.get("campaign_id") or dataset_manifest.parent.name)
    campaign_root = campaign_root_from_manifest(dataset_manifest)
    runtime = campaign_root / "runtime"
    selected: dict[str, Path] = {}
    excluded: list[Mapping[str, str]] = []
    add_tree(
        selected,
        excluded,
        extraction_root.resolve(strict=True),
        f"dataset/{campaign_id}/extracted",
    )
    add_tree(
        selected,
        excluded,
        dataset_manifest.parent,
        f"dataset/{campaign_id}/campaign_manifests",
    )
    for entry in entries:
        run_id = str(entry["run_id"])
        telemetry = Path(str(entry["telemetry_root"])).resolve(strict=True)
        for directory in TELEMETRY_DIRS:
            add_tree(
                selected,
                excluded,
                telemetry / directory,
                f"dataset/{campaign_id}/runs/{run_id}/telemetry/{directory}",
            )
        for candidate in sorted(telemetry.iterdir()):
            if candidate.is_file() and not candidate.is_symlink():
                add_tree(
                    selected,
                    excluded,
                    candidate,
                    f"dataset/{campaign_id}/runs/{run_id}/telemetry",
                )
        add_tree(
            selected,
            excluded,
            runtime / "outputs/formal" / run_id,
            f"dataset/{campaign_id}/runs/{run_id}/formal",
        )
        add_tree(
            selected,
            excluded,
            runtime / "manifests" / run_id,
            f"dataset/{campaign_id}/runs/{run_id}/manifests",
        )
        add_tree(
            selected,
            excluded,
            Path(str(entry["profile_plans_root"])).resolve(strict=True),
            f"dataset/{campaign_id}/runs/{run_id}/profile_plans",
        )
    return selected, excluded, dataset, campaign_root


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--dataset-manifest", type=Path, required=True)
    parser.add_argument("--extraction-root", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path)
    parser.add_argument("--bundle-label", default="r28-extracted-dataset")
    args = parser.parse_args()
    extraction_manifest = load_json(
        args.extraction_root.resolve(strict=True) / "dataset_extraction_manifest.json"
    )
    if extraction_manifest.get("status") not in {"pilot_complete", "complete"}:
        raise SystemExit("dataset extraction is not complete")
    selected, excluded, dataset, campaign_root = select_payload(
        args.dataset_manifest, args.extraction_root
    )
    campaign_id = str(dataset.get("campaign_id") or args.dataset_manifest.parent.name)
    output_dir = (
        args.output_dir.resolve(strict=False)
        if args.output_dir
        else campaign_root / "runtime/packages"
    )
    output_dir.mkdir(parents=True, exist_ok=True)
    if not re.fullmatch(r"[A-Za-z0-9_.-]+", args.bundle_label):
        raise SystemExit("bundle-label contains unsafe characters")
    bundle = output_dir / f"{campaign_id}-{args.bundle_label}.tar.gz"
    temporary_bundle = bundle.with_suffix(bundle.suffix + ".tmp")
    if temporary_bundle.exists():
        temporary_bundle.unlink()

    inventory: list[Mapping[str, Any]] = []
    checksum_lines: list[str] = []
    for arcname, path in sorted(selected.items()):
        reason = forbidden(Path(arcname))
        if reason:
            raise SystemExit(f"forbidden archive member selected: {arcname}: {reason}")
        digest = sha256(path)
        size = path.stat().st_size
        inventory.append(
            {
                "archive_path": arcname,
                "source_path": str(path),
                "size_bytes": size,
                "sha256": digest,
            }
        )
        checksum_lines.append(f"{digest}  {arcname}")

    with tempfile.TemporaryDirectory(prefix=".r28-package-", dir=output_dir) as temporary:
        metadata_root = Path(temporary)
        internal_root = Path(f"dataset/{campaign_id}/package")
        package_manifest = metadata_root / "package_manifest.json"
        manifest_value = {
            "schema_version": "r28.package.v1",
            "status": "complete",
            "campaign_id": campaign_id,
            "source_dataset_manifest": str(args.dataset_manifest.resolve(strict=True)),
            "payload_file_count": len(inventory),
            "payload_size_bytes": sum(item["size_bytes"] for item in inventory),
            "raw_profiler_trace_included": False,
            "files": inventory,
        }
        atomic_json(package_manifest, manifest_value)
        package_manifest_arc = (internal_root / "package_manifest.json").as_posix()
        checksum_lines.append(f"{sha256(package_manifest)}  {package_manifest_arc}")
        sums = metadata_root / "SHA256SUMS"
        sums.write_text("\n".join(checksum_lines) + "\n", encoding="utf-8")
        exclusion_audit = metadata_root / "exclusion_audit.json"
        atomic_json(
            exclusion_audit,
            {
                "schema_version": "r28.exclusion_audit.v1",
                "raw_profiler_trace_included": False,
                "excluded_files": excluded,
            },
        )
        with tarfile.open(str(temporary_bundle), mode="w|gz") as archive:
            for arcname, path in sorted(selected.items()):
                archive.add(path, arcname=arcname, recursive=False)
            archive.add(package_manifest, arcname=package_manifest_arc, recursive=False)
            archive.add(sums, arcname=(internal_root / "SHA256SUMS").as_posix())
            archive.add(
                exclusion_audit,
                arcname=(internal_root / "exclusion_audit.json").as_posix(),
            )
    os.replace(temporary_bundle, bundle)
    bundle_digest = sha256(bundle)
    external_checksum = Path(str(bundle) + ".sha256")
    external_checksum.write_text(f"{bundle_digest}  {bundle.name}\n", encoding="utf-8")
    print(f"R28_DATASET_BUNDLE={bundle}")
    print(f"R28_DATASET_BUNDLE_SHA256={external_checksum}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
