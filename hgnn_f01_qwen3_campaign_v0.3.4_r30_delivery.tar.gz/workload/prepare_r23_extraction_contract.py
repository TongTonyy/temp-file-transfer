#!/usr/bin/env python3
"""Validate the four successful runs and materialize the 83-metric contract."""

from __future__ import annotations

import argparse
from pathlib import Path
from typing import Any, Mapping

import yaml

from torch_npu_offline_common import (
    atomic_json,
    load_dataset_entries,
    load_json,
    load_profile_sessions,
)


EXPECTED_CASE_SPECS = {
    "control_resource_conflict": {
        "condition": "manual_baseline_sham",
        "metric": "ResourceConflictRatio",
        "pair": "resource_conflict",
    },
    "fault_resource_conflict": {
        "condition": "drawer0_s1",
        "metric": "ResourceConflictRatio",
        "pair": "resource_conflict",
    },
    "control_memory_access": {
        "condition": "manual_baseline_sham",
        "metric": "MemoryAccess",
        "pair": "memory_access",
    },
    "fault_memory_access": {
        "condition": "drawer0_s1",
        "metric": "MemoryAccess",
        "pair": "memory_access",
    },
}
LEGACY_RUN_IDS = {
    "control_resource_conflict": (
        "20260814T041544Z-r13-full-dataset-"
        "control_resource_conflict-a5"
    ),
    "fault_resource_conflict": (
        "20260814T041544Z-r13-full-dataset-"
        "fault_resource_conflict-a1"
    ),
    "control_memory_access": (
        "20260814T041544Z-r13-full-dataset-"
        "control_memory_access-a1"
    ),
    "fault_memory_access": (
        "20260814T041544Z-r13-full-dataset-"
        "fault_memory_access-a1"
    ),
}
# Backward-compatible alias used by older tests and tooling.
EXPECTED_CASES = {
    key: {**spec, "run_id": LEGACY_RUN_IDS[key]}
    for key, spec in EXPECTED_CASE_SPECS.items()
}


def required_metric_ids_for_family(metric_family: str) -> set[str]:
    if metric_family == "ResourceConflictRatio":
        return {"npu.aicore_stall_ratio"}
    if metric_family == "MemoryAccess":
        return {"hbm.read_gbps", "hbm.write_gbps"}
    raise ValueError(f"unsupported metric family: {metric_family}")


def validate_manifest_entry(
    entry: Mapping[str, Any], *, legacy_run_ids: bool = False
) -> None:
    key = str(entry.get("key"))
    if key not in EXPECTED_CASE_SPECS:
        raise ValueError(f"unexpected dataset manifest key: {key}")
    spec = EXPECTED_CASE_SPECS[key]
    for field in ("condition", "metric", "pair"):
        expected = spec[field]
        observed = entry.get(field)
        if observed != expected:
            raise ValueError(
                f"{key} {field} mismatch: expected {expected!r}, "
                f"observed {observed!r}"
            )
    run_id = entry.get("run_id")
    if not isinstance(run_id, str) or not run_id:
        raise SystemExit(f"{key} run_id is missing")
    if legacy_run_ids and run_id != LEGACY_RUN_IDS[key]:
        raise SystemExit(
            f"{key} run_id mismatch: expected {LEGACY_RUN_IDS[key]!r}, "
            f"observed {run_id!r}"
        )
PROFILER_TARGETS = {
    "npu.aicore_stall_ratio": {
        "metric_family": "ResourceConflictRatio",
        "required_fields": [
            "aic_cube_wait_ratio",
            "aiv_vec_wait_ratio",
            "aic_total_cycles",
            "aiv_total_cycles",
        ],
        "derivation": "resource_conflict_wait_v1",
    },
    "hbm.read_gbps": {
        "metric_family": "MemoryAccess",
        "required_fields": ["HBMbwData.read"],
        "derivation": "strict_unit_conversion_only",
    },
    "hbm.write_gbps": {
        "metric_family": "MemoryAccess",
        "required_fields": ["HBMbwData.write"],
        "derivation": "strict_unit_conversion_only",
    },
    "global_task.comm_compute_overlap_pct": {
        "metric_family": "both",
        "required_fields": ["Communication", "Overlapped"],
        "derivation": "Overlapped/Communication*100",
    },
    "global_task.step_time_ms": {
        "metric_family": "both",
        "required_fields": ["Step", "Stage|Step Time(us)"],
        "derivation": "microseconds_to_milliseconds",
    },
}
TRAINING_CAPABILITIES = {
    "npu_runtime_log",
    "training_instrumentation",
    "workload",
}
PROTOCOL_CAPABILITIES = {"bmc"}


def source_for(metric_id: str, capability: str) -> str:
    if metric_id in PROFILER_TARGETS:
        return "profiler" if capability != "workload" else "profiler+training"
    if capability in TRAINING_CAPABILITIES:
        return "training"
    if capability in PROTOCOL_CAPABILITIES:
        return "protocol"
    return "collector"


def load_metric_contract(path: Path) -> tuple[str, list[Mapping[str, Any]]]:
    value = yaml.safe_load(path.resolve(strict=True).read_text(encoding="utf-8"))
    if not isinstance(value, Mapping):
        raise ValueError("node metric schema root must be an object")
    metrics: list[Mapping[str, Any]] = []
    for node_type, payload in value.get("node_types", {}).items():
        if not isinstance(payload, Mapping):
            continue
        for item in payload.get("features", []):
            if not isinstance(item, Mapping):
                continue
            row = dict(item)
            row["node_type"] = str(node_type)
            metrics.append(row)
    ids = [str(item.get("id")) for item in metrics]
    if len(ids) != 83 or len(set(ids)) != 83:
        raise ValueError(
            f"node metric contract must contain 83 unique metrics, got {len(ids)}"
        )
    return str(value.get("schema_version")), metrics


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--dataset-manifest", type=Path, required=True)
    parser.add_argument("--node-schema", type=Path, required=True)
    parser.add_argument("--output-root", type=Path, required=True)
    parser.add_argument(
        "--legacy-run-ids",
        action="store_true",
        help="Reject manifests whose run_id values differ from historical r13 ids",
    )
    args = parser.parse_args()
    source_manifest = load_json(args.dataset_manifest.resolve(strict=True))
    entries = load_dataset_entries(args.dataset_manifest)
    by_key = {str(entry.get("key")): entry for entry in entries}
    if set(by_key) != set(EXPECTED_CASE_SPECS):
        raise SystemExit(
            "dataset manifest cases do not match the four successful r13 cases"
        )

    selected: list[Mapping[str, Any]] = []
    for key in EXPECTED_CASE_SPECS:
        entry = by_key[key]
        try:
            validate_manifest_entry(entry, legacy_run_ids=args.legacy_run_ids)
        except ValueError as error:
            raise SystemExit(str(error)) from error
        sessions = load_profile_sessions(
            Path(str(entry["profile_root"])), str(entry["metric"])
        )
        validation = entry.get("validation")
        if isinstance(validation, Mapping):
            if validation.get("collection_status") != "complete":
                raise SystemExit(f"{key} collection validation is incomplete")
            if validation.get("rank_count") != 16:
                raise SystemExit(f"{key} validation does not cover 16 ranks")
        selected.append(
            {
                **entry,
                "expected_rank_count": 16,
                "rank_sessions": {
                    str(rank): str(session)
                    for rank, session in sorted(sessions.items())
                },
            }
        )

    schema_version, metrics = load_metric_contract(args.node_schema)
    coverage: list[Mapping[str, Any]] = []
    for metric in metrics:
        metric_id = str(metric["id"])
        capability = str(metric.get("required_capability", ""))
        profiler = PROFILER_TARGETS.get(metric_id)
        coverage.append(
            {
                "metric_id": metric_id,
                "node_type": metric["node_type"],
                "kind": metric.get("kind"),
                "unit": str(metric.get("unit", "")),
                "required_capability": capability,
                "expected_source": source_for(metric_id, capability),
                "present": None,
                "status": "pending_extraction",
                "output_fields": [],
                "quality_flags": [],
                "profiler_contract": profiler,
            }
        )

    output_root = args.output_root.resolve(strict=False)
    selection_path = output_root / "r23_selection_manifest.json"
    coverage_path = output_root / "metric_coverage_83.json"
    atomic_json(
        selection_path,
        {
            "schema_version": "1.0",
            "status": "ready",
            "campaign_id": source_manifest.get("campaign_id"),
            "source_dataset_manifest": str(
                args.dataset_manifest.resolve(strict=True)
            ),
            "run_count": 4,
            "expected_session_count": 64,
            "pairs": source_manifest.get("pairs"),
            "entries": selected,
        },
    )
    atomic_json(
        coverage_path,
        {
            "schema_version": "1.0",
            "status": "pending_extraction",
            "node_schema_version": schema_version,
            "metric_count": 83,
            "profiler_target_count": len(PROFILER_TARGETS),
            "metrics": sorted(coverage, key=lambda row: row["metric_id"]),
        },
    )
    print(f"R23_SELECTION_MANIFEST={selection_path}")
    print(f"R23_METRIC_COVERAGE={coverage_path}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
