#!/usr/bin/env python3
"""Controlled parallel CANN msprof export for one run profile root (16 ranks)."""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import subprocess
import sys
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
from typing import Any, Mapping, Sequence

from extract_r25_real_csv_metrics import discover_csv_slices, required_columns
from torch_npu_offline_common import atomic_json, load_json, sha256

MARKER_NAME = ".hgnn_r27_cann_parse_complete.json"
SESSION_RE = __import__(
    "torch_npu_offline_common", fromlist=["SESSION_RE"]
).SESSION_RE


def _metric_header(metric: str) -> str:
    common = "Task Start Time(us),Op Name,Op Type,Task Duration(us)"
    if metric == "ResourceConflictRatio":
        return (
            f"{common},aiv_total_cycles,aiv_vec_bankgroup_cflt_ratio,"
            "aiv_vec_bank_cflt_ratio,aiv_vec_resc_cflt_ratio"
        )
    return (
        f"{common},aic_read_main_memory_datas(KB),aiv_read_main_memory_datas(KB),"
        "aic_write_main_memory_datas(KB),aiv_write_main_memory_datas(KB)"
    )


def discover_sessions(profile_root: Path, metric: str) -> dict[int, Path]:
    metric_root = profile_root / metric
    if not metric_root.is_dir():
        raise SystemExit(f"missing metric root: {metric_root}")
    sessions: dict[int, Path] = {}
    for path in sorted(metric_root.iterdir()):
        if not path.is_dir() or path.is_symlink():
            continue
        match = SESSION_RE.fullmatch(path.name)
        if match is None:
            continue
        rank = int(match.group(1))
        if rank in sessions:
            raise SystemExit(f"duplicate session for rank {rank}: {path}")
        sessions[rank] = path
    if set(sessions) != set(range(16)):
        missing = sorted(set(range(16)) - set(sessions))
        raise SystemExit(f"missing rank sessions: {missing}")
    return sessions


def find_prof_dir(session: Path) -> Path:
    matches = sorted(
        candidate
        for candidate in session.iterdir()
        if candidate.is_dir()
        and not candidate.is_symlink()
        and candidate.name.startswith("PROF")
    )
    if len(matches) != 1:
        raise SystemExit(
            f"expected one PROF directory under {session}, observed {len(matches)}"
        )
    return matches[0]


def csv_inventory(session: Path, metric: str) -> list[Mapping[str, Any]]:
    files = discover_csv_slices(session)
    required = set(required_columns(metric))
    rows: list[Mapping[str, Any]] = []
    for path in files:
        with path.open(encoding="utf-8-sig", newline="") as stream:
            reader = __import__("csv").DictReader(stream)
            header = set(reader.fieldnames or [])
            if not required.issubset(header):
                raise SystemExit(
                    f"csv schema incomplete for {path}: missing "
                    f"{sorted(required - header)}"
                )
        rows.append(
            {
                "path": str(path),
                "size_bytes": path.stat().st_size,
                "sha256": sha256(path),
            }
        )
    if not rows:
        raise SystemExit(f"no validated csv slices under {session}")
    return rows


def marker_path(session: Path) -> Path:
    return session / MARKER_NAME


def load_marker(session: Path) -> Mapping[str, Any] | None:
    path = marker_path(session)
    if not path.is_file() or path.is_symlink():
        return None
    try:
        return load_json(path)
    except (OSError, ValueError, json.JSONDecodeError):
        return None


def marker_matches(session: Path, metric: str, marker: Mapping[str, Any]) -> bool:
    if marker.get("metric") != metric:
        return False
    outputs = marker.get("csv_outputs")
    if not isinstance(outputs, list) or not outputs:
        return False
    try:
        current = csv_inventory(session, metric)
    except SystemExit:
        return False
    if len(current) != len(outputs):
        return False
    for left, right in zip(current, outputs):
        if not isinstance(right, Mapping):
            return False
        if left.get("sha256") != right.get("sha256"):
            return False
        if left.get("size_bytes") != right.get("size_bytes"):
            return False
    return True


def mock_export_csv(session: Path, metric: str) -> list[Mapping[str, Any]]:
    output = session / "PROF_fixture/mindstudio_profiler_output"
    output.mkdir(parents=True, exist_ok=True)
    values = (
        "100,0.2,0.4,0.1"
        if metric == "ResourceConflictRatio"
        else "120,80,60,40"
    )
    ts = os.environ.get("HGNN_R27_MOCK_TIMESTAMP_US", "150000000")
    target = output / "op_summary_slice_1.csv"
    target.write_text(
        f"{_metric_header(metric)}\n{ts},HcclAllReduce,Communication,10,{values}\n",
        encoding="utf-8",
    )
    return csv_inventory(session, metric)


def run_msprof_export(
    *,
    msprof_py: Path,
    prof_dir: Path,
    log_path: Path,
    mock: bool,
    session: Path,
    metric: str,
) -> list[Mapping[str, Any]]:
    if mock:
        return mock_export_csv(session, metric)
    log_path.parent.mkdir(parents=True, exist_ok=True)
    command = [
        sys.executable,
        str(msprof_py),
        "export",
        "summary",
        "-dir",
        str(prof_dir),
        "--format",
        "csv",
    ]
    if any(part == "--clear" for part in command):
        raise SystemExit("msprof export must never use --clear")
    started = time.monotonic()
    with log_path.open("w", encoding="utf-8") as stream:
        completed = subprocess.run(
            command,
            stdout=stream,
            stderr=subprocess.STDOUT,
            text=True,
            check=False,
        )
    if completed.returncode != 0:
        raise SystemExit(
            f"msprof export failed rc={completed.returncode} log={log_path}"
        )
    outputs = csv_inventory(session, metric)
    elapsed = time.monotonic() - started
    log_path.with_suffix(log_path.suffix + ".elapsed").write_text(
        f"{elapsed:.3f}\n", encoding="utf-8"
    )
    return outputs


def parse_rank(
    *,
    rank: int,
    session: Path,
    metric: str,
    msprof_py: Path,
    cache_root: Path,
    mock: bool,
) -> Mapping[str, Any]:
    rank_cache = cache_root / f"rank_{rank}"
    rank_cache.mkdir(parents=True, exist_ok=True)
    log_path = rank_cache / "msprof_export.log"
    marker = load_marker(session)
    if marker is not None and marker_matches(session, metric, marker):
        return {
            "rank": rank,
            "session": str(session),
            "status": "skipped_cached",
            "backend": "cached_validated_csv",
            "marker": str(marker_path(session)),
            "csv_outputs": marker.get("csv_outputs", []),
        }
    prof_dir = find_prof_dir(session)
    outputs = run_msprof_export(
        msprof_py=msprof_py,
        prof_dir=prof_dir,
        log_path=log_path,
        mock=mock,
        session=session,
        metric=metric,
    )
    payload = {
        "schema_version": "r27.parse_session.v1",
        "status": "complete",
        "rank": rank,
        "session": str(session),
        "metric": metric,
        "prof_dir": str(prof_dir),
        "backend": "mock_csv" if mock else "msprof_export_summary_csv",
        "log_path": str(log_path),
        "csv_outputs": outputs,
        "parsed_at_utc": time.strftime("%Y%m%dT%H%M%SZ", time.gmtime()),
    }
    atomic_json(marker_path(session), payload)
    digest = hashlib.sha256(
        json.dumps(outputs, sort_keys=True).encode("utf-8")
    ).hexdigest()
    (rank_cache / "csv_sha256.txt").write_text(f"{digest}\n", encoding="utf-8")
    return {
        "rank": rank,
        "session": str(session),
        "status": "parsed",
        "backend": payload["backend"],
        "marker": str(marker_path(session)),
        "csv_outputs": outputs,
    }


def parse_run(
    *,
    profile_root: Path,
    metric: str,
    max_workers: int,
    msprof_py: Path | None,
    cache_root: Path,
    mock: bool,
) -> Mapping[str, Any]:
    if not 1 <= max_workers <= 8:
        raise SystemExit("max-workers must be between 1 and 8")
    sessions = discover_sessions(profile_root.resolve(strict=True), metric)
    started = time.monotonic()
    results: dict[int, Mapping[str, Any]] = {}
    completed = 0
    if msprof_py is None and not mock:
        raise SystemExit("MSPROF_PY is required unless mock mode is enabled")
    resolved_msprof = msprof_py or Path("/dev/null")
    with ThreadPoolExecutor(max_workers=max_workers) as pool:
        futures = {
            pool.submit(
                parse_rank,
                rank=rank,
                session=session,
                metric=metric,
                msprof_py=resolved_msprof,
                cache_root=cache_root,
                mock=mock,
            ): rank
            for rank, session in sessions.items()
        }
        for future in as_completed(futures):
            rank = futures[future]
            row = future.result()
            results[rank] = row
            completed += 1
            print(f"R27_PARSE_PROGRESS={completed}/16", flush=True)
    elapsed = time.monotonic() - started
    backends = sorted({str(row.get("backend", "")) for row in results.values()})
    return {
        "schema_version": "r27.parse_run.v1",
        "status": "complete",
        "profile_root": str(profile_root),
        "metric": metric,
        "rank_count": 16,
        "max_workers": max_workers,
        "mock": mock,
        "backends": backends,
        "elapsed_s": elapsed,
        "ranks": [results[rank] for rank in range(16)],
    }


def main(argv: Sequence[str] | None = None) -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--profile-root", type=Path, required=True)
    parser.add_argument("--metric", required=True)
    parser.add_argument("--cache-root", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--max-workers", type=int, default=4)
    parser.add_argument("--msprof-py", type=Path, default=None)
    parser.add_argument("--mock", action="store_true")
    args = parser.parse_args(argv)
    mock = args.mock or os.environ.get("HGNN_R27_MOCK_CANN", "") == "1"
    msprof = args.msprof_py
    if msprof is None and not mock:
        env_msprof = os.environ.get("HGNN_MSPROF_PY", "")
        if env_msprof:
            msprof = Path(env_msprof)
    report = parse_run(
        profile_root=args.profile_root,
        metric=args.metric,
        max_workers=args.max_workers,
        msprof_py=msprof,
        cache_root=args.cache_root,
        mock=mock,
    )
    atomic_json(args.output, report)
    print(f"R27_PARSE_RUN={args.output}")
    print(f"R27_PARSE_PROGRESS=16/16")
    print(f"R27_ELAPSED_S={report['elapsed_s']:.3f}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
