#!/bin/bash
# Rerun all non-idle workloads in SUSTAINED mode (>= MIN_SECONDS of continuous
# load) to capture clean power plateaus. Latency data from the first run
# (bench_metrics.csv) stays untouched; this pass writes:
#   <exp>/power_mem_sustained.csv      power during sustained load
#   <exp>/run_sustained.log
#   <exp>/exit_code_sustained.txt
#   bench_metrics_sustained.csv        avg_s under sustained conditions
#
# Usage (point OUT_ROOT at the existing results dir):
#   OUT_ROOT=/path/to/results_energy_calibration_v2 bash rerun_power_sustained.sh

set -u
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
# shellcheck disable=SC1091
source "$SCRIPT_DIR/common_env.sh"

OUT_ROOT=${OUT_ROOT:-$SCRIPT_DIR/results_energy_calibration_v2}
BENCH=$SCRIPT_DIR/energy_microbench_910c.py
METRICS="$OUT_ROOT/bench_metrics_sustained.csv"
MIN_SEC=${MIN_SECONDS:-40}
CAP=${ITERS_CAP:-2000000}
PORT=${BASE_PORT:-8700}
mkdir -p "$OUT_ROOT"

run_dist() {
  local name=$1
  shift
  local dir="$OUT_ROOT/$name"
  PORT=$((PORT + 1))
  mkdir -p "$dir"
  echo "======================================================================"
  echo "[$(date '+%F %T')] sustained: $name  (port $PORT, >=${MIN_SEC}s load)"
  echo "======================================================================"
  SAMPLE_INTERVAL_SEC=${SAMPLE_INTERVAL_SEC:-1} bash "$SCRIPT_DIR/sampler_power_mem.sh" "$dir/power_mem_sustained.csv" &
  local sampler_pid=$!
  sleep 5
  torchrun \
    --nproc_per_node "$NPUS_PER_NODE" \
    --nnodes 1 \
    --node_rank 0 \
    --master_addr "$MASTER_ADDR" \
    --master_port "$PORT" \
    "$@" --min_seconds "$MIN_SEC" --iters "$CAP" --out "$METRICS" \
    > "$dir/run_sustained.log" 2>&1
  local rc=$?
  sleep 3
  kill "$sampler_pid" 2>/dev/null || true
  wait "$sampler_pid" 2>/dev/null || true
  echo "$rc" > "$dir/exit_code_sustained.txt"
  if [ "$rc" != "0" ]; then
    echo "[warn] $name rc=$rc; see $dir/run_sustained.log"
  fi
}

cd "$SCRIPT_DIR" || exit 1

# compute (GEMM) - with fixed --gm/--gn/--gk args
for shape in "4096 4096 4096" "8192 4096 4096" "4096 5120 17408"; do
  set -- $shape
  run_dist "compute_gemm_$1x$2x$3" "$BENCH" \
    --mode compute_gemm --warmup 10 --gm "$1" --gn "$2" --gk "$3"
done

# memory copy
for numel in 67108864 134217728 268435456; do
  run_dist "memory_copy_$numel" "$BENCH" \
    --mode memory_copy --warmup 10 --numel "$numel"
done

# vector norm
for rows in 4096 8192 16384; do
  run_dist "vector_norm_r${rows}_c5120" "$BENCH" \
    --mode vector_norm --warmup 10 --rows "$rows" --cols 5120
done

# swiglu elementwise
run_dist "swiglu_elementwise_r65536_c5120" "$BENCH" \
  --mode swiglu_elementwise --warmup 10 --rows 65536 --cols 5120

# HCCL collectives
for mode in all_reduce all_gather reduce_scatter; do
  for numel in 16777216 67108864 134217728; do
    run_dist "${mode}_${numel}" "$BENCH" \
      --mode "$mode" --warmup 10 --numel "$numel"
  done
done

# group-size scaling
for gs in 2 4 8 16; do
  run_dist "all_reduce_group${gs}_67108864" "$BENCH" \
    --mode all_reduce_group --warmup 10 --group_size "$gs" --numel 67108864
done

# P2P ring
for numel in 20971520 41943040; do
  run_dist "p2p_ring_${numel}" "$BENCH" \
    --mode p2p_ring --warmup 10 --numel "$numel"
done

echo "[done] sustained rerun finished; results in $OUT_ROOT"
echo "[next] python3 $SCRIPT_DIR/check_calibration_validity.py $OUT_ROOT"
