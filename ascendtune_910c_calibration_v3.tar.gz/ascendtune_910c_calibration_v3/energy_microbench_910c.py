#!/usr/bin/env python3
"""Microbenchmarks for 910C energy-state calibration (v2.1).

Changes vs v2:
  - GEMM args renamed --m/--n/--k -> --gm/--gn/--gk (torchrun treated
    "--m" as an ambiguous abbreviation of its own options).
  - New --min_seconds: run in sustained mode until the load has lasted at
    least this many seconds (for clean power plateaus; --iters acts as cap).
"""
import argparse
import csv
import os
import time

import torch
import torch.distributed as dist
import torch_npu  # noqa: F401


def set_device():
    local_rank = int(os.environ.get("LOCAL_RANK", "0"))
    torch.npu.set_device(local_rank)
    return local_rank


def maybe_init_dist():
    if int(os.environ.get("WORLD_SIZE", "1")) > 1 and not dist.is_initialized():
        dist.init_process_group(backend=os.environ.get("DIST_BACKEND", "hccl"))


def sync():
    if dist.is_initialized():
        dist.barrier()
    torch.npu.synchronize()


def bench_loop(fn, warmup, iters, min_seconds=0.0):
    for _ in range(warmup):
        fn()
    sync()
    start = time.time()
    if min_seconds and min_seconds > 0:
        n = 0
        while time.time() - start < min_seconds and n < iters:
            fn()
            n += 1
    else:
        n = iters
        for _ in range(iters):
            fn()
    sync()
    return (time.time() - start) / max(n, 1)


def make_tensor(numel, dtype=torch.bfloat16):
    return torch.randn(numel, device="npu", dtype=dtype)


def run_compute_gemm(args):
    a = torch.randn(args.gm, args.gk, device="npu", dtype=torch.bfloat16)
    b = torch.randn(args.gk, args.gn, device="npu", dtype=torch.bfloat16)
    c = None

    def step():
        nonlocal c
        c = torch.matmul(a, b)
        return c

    avg = bench_loop(step, args.warmup, args.iters, args.min_seconds)
    flops = 2 * args.gm * args.gn * args.gk
    return {"metric": f"gemm_{args.gm}x{args.gn}x{args.gk}", "avg_s": avg, "work": flops, "unit": "flop"}


def run_memory_copy(args):
    x = make_tensor(args.numel)
    y = torch.empty_like(x)

    def step():
        y.copy_(x)

    avg = bench_loop(step, args.warmup, args.iters, args.min_seconds)
    bytes_moved = x.numel() * x.element_size()
    return {"metric": f"memory_copy_{args.numel}", "avg_s": avg, "work": bytes_moved, "unit": "byte"}


def run_vector_norm(args):
    x = torch.randn(args.rows, args.cols, device="npu", dtype=torch.bfloat16)
    y = None

    def step():
        nonlocal y
        y = torch.nn.functional.rms_norm(x, (args.cols,))
        return y

    avg = bench_loop(step, args.warmup, args.iters, args.min_seconds)
    return {"metric": f"vector_rms_norm_r{args.rows}_c{args.cols}", "avg_s": avg,
            "work": x.numel(), "unit": "element"}


def run_swiglu_elementwise(args):
    """Memory-bound SwiGLU-style elementwise op: y = silu(a) * b."""
    a = torch.randn(args.rows, args.cols, device="npu", dtype=torch.bfloat16)
    b = torch.randn(args.rows, args.cols, device="npu", dtype=torch.bfloat16)
    y = None

    def step():
        nonlocal y
        y = torch.nn.functional.silu(a) * b
        return y

    avg = bench_loop(step, args.warmup, args.iters, args.min_seconds)
    return {"metric": f"swiglu_elementwise_r{args.rows}_c{args.cols}", "avg_s": avg,
            "work": a.numel(), "unit": "element"}


def run_collective(args):
    maybe_init_dist()
    x = make_tensor(args.numel)
    world = dist.get_world_size()
    op = args.mode

    if op == "all_gather":
        out = [torch.empty_like(x) for _ in range(world)]

        def step():
            dist.all_gather(out, x)
    elif op == "reduce_scatter":
        chunks = [torch.empty_like(x) for _ in range(world)]
        out = torch.empty_like(x)

        def step():
            dist.reduce_scatter(out, chunks)
    elif op == "all_reduce":
        def step():
            dist.all_reduce(x)
    else:
        raise ValueError(op)

    avg = bench_loop(step, args.warmup, args.iters, args.min_seconds)
    bytes_moved = args.numel * x.element_size()
    return {"metric": f"{op}_{args.numel}", "avg_s": avg, "work": bytes_moved,
            "unit": "byte_per_rank"}


def run_group_all_reduce(args):
    """AllReduce inside subgroups of size group_size (groups tile the 16 ranks)."""
    maybe_init_dist()
    world = dist.get_world_size()
    rank = dist.get_rank()
    gs = args.group_size
    if world % gs != 0:
        raise ValueError(f"world_size {world} not divisible by group_size {gs}")
    my_group = None
    for start in range(0, world, gs):
        ranks = list(range(start, start + gs))
        g = dist.new_group(ranks)
        if rank in ranks:
            my_group = g

    x = make_tensor(args.numel)

    def step():
        dist.all_reduce(x, group=my_group)

    avg = bench_loop(step, args.warmup, args.iters, args.min_seconds)
    bytes_moved = args.numel * x.element_size()
    return {"metric": f"all_reduce_group{gs}_{args.numel}", "avg_s": avg, "work": bytes_moved,
            "unit": "byte_per_rank"}


def run_p2p_ring(args):
    """Ring P2P send/recv: each rank sends to rank+1 and receives from rank-1."""
    maybe_init_dist()
    world = dist.get_world_size()
    rank = dist.get_rank()
    if world % 2 != 0:
        raise ValueError("p2p_ring requires an even world_size")
    x = make_tensor(args.numel)
    y = torch.empty_like(x)
    peer_next = (rank + 1) % world
    peer_prev = (rank - 1) % world

    def step():
        if rank % 2 == 0:
            dist.send(x, peer_next)
            dist.recv(y, peer_prev)
        else:
            dist.recv(y, peer_prev)
            dist.send(x, peer_next)

    avg = bench_loop(step, args.warmup, args.iters, args.min_seconds)
    bytes_moved = args.numel * x.element_size()
    return {"metric": f"p2p_ring_{args.numel}", "avg_s": avg, "work": bytes_moved,
            "unit": "byte_per_rank"}


def write_row(args, row):
    rank = int(os.environ.get("RANK", "0"))
    if rank != 0:
        return
    path = args.out
    exists = os.path.exists(path)
    fields = ["mode", "metric", "avg_s", "work", "unit", "world_size", "local_rank", "timestamp"]
    with open(path, "a", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fields)
        if not exists:
            writer.writeheader()
        row = dict(row)
        row.update({
            "mode": args.mode,
            "world_size": int(os.environ.get("WORLD_SIZE", "1")),
            "local_rank": int(os.environ.get("LOCAL_RANK", "0")),
            "timestamp": int(time.time()),
        })
        writer.writerow(row)
    print(row, flush=True)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--mode", required=True,
                        choices=["compute_gemm", "memory_copy", "vector_norm",
                                 "swiglu_elementwise",
                                 "all_reduce", "all_gather", "reduce_scatter",
                                 "all_reduce_group", "p2p_ring"])
    parser.add_argument("--out", default="bench_metrics.csv")
    parser.add_argument("--warmup", type=int, default=10)
    parser.add_argument("--iters", type=int, default=80)
    parser.add_argument("--min_seconds", type=float, default=0.0)
    parser.add_argument("--gm", type=int, default=4096)
    parser.add_argument("--gn", type=int, default=4096)
    parser.add_argument("--gk", type=int, default=4096)
    parser.add_argument("--numel", type=int, default=134217728)
    parser.add_argument("--rows", type=int, default=8192)
    parser.add_argument("--cols", type=int, default=5120)
    parser.add_argument("--group_size", type=int, default=16)
    args = parser.parse_args()

    set_device()
    if args.mode in ("all_reduce", "all_gather", "reduce_scatter"):
        row = run_collective(args)
    elif args.mode == "all_reduce_group":
        row = run_group_all_reduce(args)
    elif args.mode == "p2p_ring":
        row = run_p2p_ring(args)
    elif args.mode == "compute_gemm":
        row = run_compute_gemm(args)
    elif args.mode == "memory_copy":
        row = run_memory_copy(args)
    elif args.mode == "vector_norm":
        row = run_vector_norm(args)
    elif args.mode == "swiglu_elementwise":
        row = run_swiglu_elementwise(args)
    else:
        raise ValueError(args.mode)
    write_row(args, row)


if __name__ == "__main__":
    main()
