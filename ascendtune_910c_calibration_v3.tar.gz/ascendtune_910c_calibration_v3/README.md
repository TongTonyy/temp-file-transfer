# AscendTune 910C 能耗标定脚本包 v3

针对 ENERGY_CALIBRATION_REQUIREMENTS + TRAINING_ANCHOR_REQUIREMENTS_FULL 的完整标定包。

v3 相对 v2 的变化：anchors.conf 预填完整 W 系列候选表（含各候选 SP/recompute/优化器设置），
run_training_anchor.sh 支持 SP 开关、full recompute、无优化器（DP=1 边界）和 OOM 产物保留。
注意：微基准脚本与 v2 完全一致，结果目录仍为 `results_energy_calibration_v2/`，
v2 正在跑或已跑完的微基准数据在 v3 下直接可用。

相比 v1 修复的四个缺口：

1. compute/memory/vector 全部改为 **torchrun 16 rank 压测**（v1 是单进程，功耗≈idle 无效）；
2. 新增 **P2P ring send/recv** 标定（模拟流水线并行相邻 stage 的激活传输）；
3. 新增 **group size 2/4/8/16** 的 AllReduce 分组通信标定；
4. 训练锚点使用**修好的 token 计数脚本**（`posttrain_gpt_lab_v3.py`，钩 `loss_func` 类方法，已实测有效）。

## 部署

```bash
cd /root/hgnn_910c_readiness
wget "https://ghfast.top/https://raw.githubusercontent.com/TongTonyy/temp-file-transfer/main/ascendtune_910c_calibration_v3.tar.gz" -O ascendtune_910c_calibration_v3.tar.gz
tar -xzf ascendtune_910c_calibration_v3.tar.gz
cd ascendtune_910c_calibration_v3
```

## 执行步骤

### 1. 环境

```bash
conda activate llm_env        # 或 source /root/miniconda3/bin/activate llm_env
source common_env.sh          # 确认 MSLLM_DIR=/root/MindSpeed-LLM 等路径正确
```

### 2. 微基准标定（约 40–50 分钟）

```bash
bash run_energy_calibration_v2.sh 2>&1 | tee energy_calibration_v2.log
```

覆盖矩阵：

| 类别 | 内容 |
|---|---|
| idle | 300 秒静态功耗（确保无残留任务） |
| compute | GEMM 4096³、8192×4096×4096、4096×5120×17408（Qwen3 MLP 形状），各 80 iters |
| memory | copy 64M/128M/256M bf16，各 120 iters |
| vector | RMSNorm rows 4096/8192/16384 × cols 5120，各 120 iters |
| swiglu | elementwise silu(a)*b，65536×5120，120 iters |
| comm | all_reduce/all_gather/reduce_scatter × 16M/64M/128M |
| group | all_reduce 64M @ group size 2/4/8/16 |
| p2p | ring send/recv @ 40MiB / 80MiB（micro_batch 1/2 激活大小） |

可用 `SKIP_IDLE=1`、`SKIP_COMM=1` 等跳过已有数据的段落（见脚本头部注释）。

跑完做有效性自检（对照需求文档判据：exit code、world_size=16、idle ≥120 样本、功耗增量 ≥5%、通信时延单调性）：

```bash
python3 check_calibration_validity.py results_energy_calibration_v2
```

### 3. 训练锚点（每个约 55 分钟，25 steps）

`anchors.conf` 已按 TRAINING_ANCHOR_REQUIREMENTS_FULL 预填完整候选表（W0/W1/W2/W6/W7/W8/W5/W3a/BND-HGNN，含各候选的 SP、recompute、优化器设置），执行顺序按需求 §9：W1 先行验证脚本，TP8 族连续执行，W3a（DP=1 高显存边界）最后。

**执行前必须先转换缺失的权重**（脚本会自动跳过缺权重的候选并标 `FAIL missing_ckpt`）：

```bash
ls /root/MindSpeed-LLM/model_weights/
# 需要: qwen3_mcore-4TP4DP(已有) 8TP2DP 4TP2DP 2TP4DP 4TP1DP
```

然后批量执行：

```bash
bash run_all_anchors.sh 2>&1 | tee anchors.log
```

单个锚点手动跑（示例为 W5，注意其 SP=off、recompute=full）：

```bash
ANCHOR_NAME=W5_pp2_lowpower TP=4 PP=2 MICRO_BATCH=1 GLOBAL_BATCH=1024 \
  SP=off RECOMPUTE=full \
  ZERO_ARGS="--use-distributed-optimizer --overlap-grad-reduce" \
  bash run_training_anchor.sh
```

每个锚点产出需求 §2 要求的全部文件：`launch.sh`、`config_note.txt`、`train.log`、`power_mem.csv`、`real_tokens.csv`（25 行且非 0，否则 run_status 标 `TOKENS_MISSING`）、`step_times_raw.txt`、`exit_code.txt`、`run_status.txt`。

### 4. 打包上传

```bash
bash pack_and_push_results.sh
```

或用 GitHub release + curl 流程上传 `ascendtune_910c_calibration_v2_results.tar.gz`。

## 产物目录

- `results_energy_calibration_v2/`：全部微基准 + `bench_metrics.csv` + `validity_report.txt`
- `results_anchors/`：训练锚点
- `ascendtune_910c_calibration_v2_results.tar.gz`：回传包

## 完成判据对应

- idle/compute/memory/comm 四类有效功耗增量 → `check_calibration_validity.py` 自动核查
- real token 有效 → 锚点 `run_status.txt` 含 `tok_rows_ok`
- 功耗/能效 MAPE ≤ 5–8% → 回传后本地建模验证
