#!/bin/bash
# Run ONE full training anchor with complete artifact collection.
#
# Required env:
#   ANCHOR_NAME   unique name, e.g. W1_tp4dp4
# Optional env (defaults in parentheses):
#   TP (4) PP (1) MICRO_BATCH (1) GLOBAL_BATCH (1024) TRAIN_ITERS (25)
#   SP (on|off)            --sequence-parallel toggle
#   RECOMPUTE (off|full)   full = --recompute-granularity full --recompute-method uniform --recompute-num-layers 1
#   ZERO_ARGS ("--use-distributed-optimizer --overlap-grad-reduce"; empty = none, e.g. DP=1 boundary)
#   BASE_PORT (auto)
#
# Artifacts in results_anchors/$ANCHOR_NAME/:
#   launch.sh config_note.txt train.log power_mem.csv (+raw snapshot)
#   real_tokens.csv step_times_raw.txt run_status.txt exit_code.txt

set -u
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
# shellcheck disable=SC1091
source "$SCRIPT_DIR/common_env.sh"

ANCHOR_NAME=${ANCHOR_NAME:?usage: ANCHOR_NAME=name TP=.. PP=.. MICRO_BATCH=.. GLOBAL_BATCH=.. SP=.. RECOMPUTE=.. ZERO_ARGS=.. bash run_training_anchor.sh}
TP=${TP:-4}
PP=${PP:-1}
MICRO_BATCH=${MICRO_BATCH:-1}
GLOBAL_BATCH=${GLOBAL_BATCH:-1024}
TRAIN_ITERS=${TRAIN_ITERS:-25}
SP=${SP:-on}
RECOMPUTE=${RECOMPUTE:-off}
ZERO_ARGS=${ZERO_ARGS:---use-distributed-optimizer --overlap-grad-reduce}
if [ "$ZERO_ARGS" = "none" ]; then
  ZERO_ARGS=""
fi
PORT=${BASE_PORT:-$((8800 + RANDOM % 200))}
ENTRY=posttrain_gpt_lab_v3.py

SP_FLAG=""
if [ "$SP" = "on" ]; then
  SP_FLAG="--sequence-parallel"
fi
RECOMPUTE_FLAGS=""
if [ "$RECOMPUTE" = "full" ]; then
  RECOMPUTE_FLAGS="--recompute-granularity full --recompute-method uniform --recompute-num-layers 1"
fi

OUT_ROOT=${OUT_ROOT:-$SCRIPT_DIR/results_anchors}
dir="$OUT_ROOT/$ANCHOR_NAME"
dp=$(( NPUS_PER_NODE / (PP * TP) ))
ckpt="$CKPT_WEIGHTS_DIR/$(ckpt_name "$TP" "$PP" "$dp")"

rm -rf "$dir"
mkdir -p "$dir"

boundary_note=""
if [ "$dp" = "1" ] && [ -z "$ZERO_ARGS" ]; then
  boundary_note=" DP=1_boundary(no distributed optimizer)"
fi
echo "name=$ANCHOR_NAME tp=$TP pp=$PP dp=$dp micro_batch=$MICRO_BATCH global_batch=$GLOBAL_BATCH seq=$SEQ_LEN iters=$TRAIN_ITERS sp=$SP recompute=$RECOMPUTE zero_args=[$ZERO_ARGS] ckpt=$ckpt$boundary_note" > "$dir/config_note.txt"

if [ ! -d "$ckpt" ]; then
  echo "[error] checkpoint dir missing: $ckpt"
  echo "[hint] convert weights first, e.g. via MindSpeed-LLM convert_ckpt tooling"
  echo "FAIL missing_ckpt" > "$dir/run_status.txt"
  echo "1" > "$dir/exit_code.txt"
  exit 1
fi

cp "$SCRIPT_DIR/posttrain_gpt_lab_v3.py" "$MSLLM_DIR/$ENTRY"

cat > "$dir/launch.sh" <<LAUNCH
#!/bin/bash
source "$SCRIPT_DIR/common_env.sh"
export TRAIN_ITERS=$TRAIN_ITERS
export GLOBAL_BATCH=$GLOBAL_BATCH
cd "$MSLLM_DIR"
torchrun \\
  --nproc_per_node "$NPUS_PER_NODE" \\
  --nnodes 1 \\
  --node_rank 0 \\
  --master_addr "$MASTER_ADDR" \\
  --master_port "$PORT" \\
  "$ENTRY" \\
  \$(base_qwen_args "$PP" "$TP" "$MICRO_BATCH" "$ckpt") \\
  $SP_FLAG \\
  $RECOMPUTE_FLAGS \\
  $ZERO_ARGS
LAUNCH
chmod +x "$dir/launch.sh"

echo "======================================================================"
echo "[$(date '+%F %T')] anchor=$ANCHOR_NAME tp=$TP pp=$PP dp=$dp mb=$MICRO_BATCH gb=$GLOBAL_BATCH iters=$TRAIN_ITERS sp=$SP recompute=$RECOMPUTE"
echo "zero_args: [$ZERO_ARGS]$boundary_note"
echo "======================================================================"
SAMPLE_INTERVAL_SEC=${SAMPLE_INTERVAL_SEC:-1} bash "$SCRIPT_DIR/sampler_power_mem.sh" "$dir/power_mem.csv" &
sampler_pid=$!
sleep 5
(cd "$dir" && bash launch.sh > train.log 2>&1)
rc=$?
sleep 3
kill "$sampler_pid" 2>/dev/null || true
wait "$sampler_pid" 2>/dev/null || true
echo "$rc" > "$dir/exit_code.txt"

# collect per-step times and real token counts
grep -o "elapsed time per iteration (ms): [0-9.]*" "$dir/train.log" \
  | awk '{print $NF}' > "$dir/step_times_raw.txt" || true
if [ -f "$MSLLM_DIR/real_tokens.csv" ]; then
  cp "$MSLLM_DIR/real_tokens.csv" "$dir/real_tokens.csv"
fi

# verdict per requirements: 25 steps, exit 0, real tokens > 0
tok_ok=0
if [ -f "$dir/real_tokens.csv" ]; then
  rows=$(($(wc -l < "$dir/real_tokens.csv") - 1))
  nonzero=$(awk -F, 'NR>1 && $3>0 {c++} END {print c+0}' "$dir/real_tokens.csv")
  if [ "$rows" -ge "$TRAIN_ITERS" ] && [ "$nonzero" -ge "$TRAIN_ITERS" ]; then
    tok_ok=1
  fi
fi
if grep -qi "out of memory\|NPU out of memory" "$dir/train.log"; then
  echo "FAIL OOM rc=$rc" > "$dir/run_status.txt"
  echo "[warn] $ANCHOR_NAME OOM; artifacts kept for memory-boundary model (do NOT overwrite)"
elif [ "$rc" = "0" ] && [ "$tok_ok" = "1" ]; then
  echo "PASS rc=0 tok_rows_ok" > "$dir/run_status.txt"
  echo "[done] $ANCHOR_NAME PASS (tokens OK)"
elif [ "$rc" = "0" ]; then
  echo "PASS rc=0 TOKENS_MISSING" > "$dir/run_status.txt"
  echo "[warn] $ANCHOR_NAME ran but real_tokens.csv incomplete; usable for nominal metrics only"
else
  echo "FAIL rc=$rc" > "$dir/run_status.txt"
  echo "[warn] $ANCHOR_NAME FAILED rc=$rc; see $dir/train.log"
fi
