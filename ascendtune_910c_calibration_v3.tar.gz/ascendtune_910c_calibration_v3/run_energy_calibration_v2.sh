#!/bin/bash
# Run full energy-state calibration on a 910C server (v2).
# Covers: idle, compute (GEMM x3 shapes), memory (copy x3 sizes),
# vector (RMSNorm x3 sizes), swiglu elementwise, HCCL collectives (3 ops x 3 sizes),
# group-size scaling (all_reduce @ group 2/4/8/16), and P2P ring send/recv.
# Every workload runs under torchrun with 16 ranks (except idle).
#
# Skip individual sections with: SKIP_IDLE=1 SKIP_COMPUTE=1 SKIP_MEMORY=1
#   SKIP_VECTOR=1 SKIP_SWIGLU=1 SKIP_COMM=1 SKIP_GROUPS=1 SKIP_P2P=1

set -u
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
# shellcheck disable=SC1091
source "$SCRIPT_DIR/common_env.sh"

OUT_ROOT=${OUT_ROOT:-$SCRIPT_DIR/results_energy_calibration_v2}
BENCH=${BENCH:-$SCRIPT_DIR/energy_microbench_910c.py}
METRICS="$OUT_ROOT/bench_metrics.csv"
PORT=${BASE_PORT:-8600}
mkdir -p "$OUT_ROOT"

run_dist() {
  local name=$1
  shift
  local dir="$OUT_ROOT/$name"
  PORT=$((PORT + 1))
  mkdir -p "$dir"
  echo "======================================================================"
  echo "[$(date '+%F %T')] $name  (port $PORT)"
  echo "command: torchrun x$NPUS_PER_NODE $*"
  echo "======================================================================"
  SAMPLE_INTERVAL_SEC=${SAMPLE_INTERVAL_SEC:-1} bash "$SCRIPT_DIR/sampler_power_mem.sh" "$dir/power_mem.csv" &
  local sampler_pid=$!
  sleep 5
  torchrun \
    --nproc_per_node "$NPUS_PER_NODE" \
    --nnodes 1 \
    --node_rank 0 \
    --master_addr "$MASTER_ADDR" \
    --master_port "$PORT" \
    "$@" > "$dir/run.log" 2>&1
  local rc=$?
  sleep 3
  kill "$sampler_pid" 2>/dev/null || true
  wait "$sampler_pid" 2>/dev/null || true
  echo "$rc" > "$dir/exit_code.txt"
  if [ "$rc" != "0" ]; then
    echo "[warn] $name exited with rc=$rc; see $dir/run.log"
  fi
}

cd "$SCRIPT_DIR" || exit 1

# ---------------------------------------------------------------- idle
if [ "${SKIP_IDLE:-0}" != "1" ]; then
  echo "[idle] sampling idle power for ${IDLE_SECONDS:-300} seconds"
  echo "       (make sure no training/python jobs are running!)"
  mkdir -p "$OUT_ROOT/idle"
  SAMPLE_INTERVAL_SEC=${SAMPLE_INTERVAL_SEC:-1} bash "$SCRIPT_DIR/sampler_power_mem.sh" "$OUT_ROOT/idle/power_mem.csv" &
  idle_pid=$!
  sleep "${IDLE_SECONDS:-300}"
  kill "$idle_pid" 2>/dev/null || true
  wait "$idle_pid" 2>/dev/null || true
  echo "0" > "$OUT_ROOT/idle/exit_code.txt"
fi

# ---------------------------------------------------------------- compute (GEMM)
if [ "${SKIP_COMPUTE:-0}" != "1" ]; then
  for shape in "4096 4096 4096" "8192 4096 4096" "4096 5120 17408"; do
    set -- $shape
    run_dist "compute_gemm_$1x$2x$3" "$BENCH" \
      --mode compute_gemm --out "$METRICS" --iters 80 --warmup 10 \
      --gm "$1" --gn "$2" --gk "$3"
  done
fi

# ---------------------------------------------------------------- memory copy
if [ "${SKIP_MEMORY:-0}" != "1" ]; then
  for numel in 67108864 134217728 268435456; do
    run_dist "memory_copy_$numel" "$BENCH" \
      --mode memory_copy --out "$METRICS" --iters 120 --warmup 10 --numel "$numel"
  done
fi

# ---------------------------------------------------------------- vector norm
if [ "${SKIP_VECTOR:-0}" != "1" ]; then
  for rows in 4096 8192 16384; do
    run_dist "vector_norm_r${rows}_c5120" "$BENCH" \
      --mode vector_norm --out "$METRICS" --iters 120 --warmup 10 \
      --rows "$rows" --cols 5120
  done
fi

# ---------------------------------------------------------------- swiglu elementwise
if [ "${SKIP_SWIGLU:-0}" != "1" ]; then
  run_dist "swiglu_elementwise_r65536_c5120" "$BENCH" \
    --mode swiglu_elementwise --out "$METRICS" --iters 120 --warmup 10 \
    --rows 65536 --cols 5120
fi

# ---------------------------------------------------------------- HCCL collectives
if [ "${SKIP_COMM:-0}" != "1" ]; then
  for mode in all_reduce all_gather reduce_scatter; do
    for numel in 16777216 67108864 134217728; do
      run_dist "${mode}_${numel}" "$BENCH" \
        --mode "$mode" --out "$METRICS" --iters 80 --warmup 10 --numel "$numel"
    done
  done
fi

# ---------------------------------------------------------------- group-size scaling
if [ "${SKIP_GROUPS:-0}" != "1" ]; then
  for gs in 2 4 8 16; do
    run_dist "all_reduce_group${gs}_67108864" "$BENCH" \
      --mode all_reduce_group --out "$METRICS" --iters 80 --warmup 10 \
      --group_size "$gs" --numel 67108864
  done
fi

# ---------------------------------------------------------------- P2P ring (pipeline activation sizes)
# 20971520 elems = 1 x 4096 x 5120 bf16 = 40 MiB (micro_batch=1 activation)
# 41943040 elems = 2 x 4096 x 5120 bf16 = 80 MiB (micro_batch=2 activation)
if [ "${SKIP_P2P:-0}" != "1" ]; then
  for numel in 20971520 41943040; do
    run_dist "p2p_ring_${numel}" "$BENCH" \
      --mode p2p_ring --out "$METRICS" --iters 80 --warmup 10 --numel "$numel"
  done
fi

echo "[done] results in $OUT_ROOT"
echo "[next] run: python3 $SCRIPT_DIR/check_calibration_validity.py $OUT_ROOT"
