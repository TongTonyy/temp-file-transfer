#!/usr/bin/env python3
"""Check energy-calibration results against the validity criteria. (v2)

Usage: python3 check_calibration_validity.py [results_dir]

Sustained-aware: when <exp>/power_mem_sustained.csv exists (from
rerun_power_sustained.sh), the power delta is computed over the middle 60%
of that sustained window; otherwise the original power_mem.csv is used.

Checks:
  - every experiment dir has exit_code.txt == 0 (and exit_code_sustained.txt == 0 when present)
  - idle has >= 120 whole-machine power samples
  - bench_metrics rows have world_size == 16
  - mean load power >= idle mean * 1.05
  - collective latency is (near-)monotonic in message size
Writes validity_report.txt into the results dir and prints a summary.
"""
import csv
import os
import re
import sys

ROOT = sys.argv[1] if len(sys.argv) > 1 else "results_energy_calibration_v2"

POWER_DELTA_MIN = 1.05
MONO_TOL = 0.9


def per_ts_totals(csv_path):
    per_ts = {}
    with open(csv_path, newline="", encoding="utf-8") as f:
        for row in csv.DictReader(f):
            try:
                p = float(row["power_w"])
            except (KeyError, TypeError, ValueError):
                continue
            ts = row.get("ts_unix", "")
            per_ts[ts] = per_ts.get(ts, 0.0) + p
    return per_ts


def mean_total_power(csv_path):
    vals = list(per_ts_totals(csv_path).values())
    if not vals:
        return 0, 0.0
    return len(vals), sum(vals) / len(vals)


def sustained_window_power(csv_path):
    """Mean of the middle 60% of per-timestamp totals (trims ramp/drain)."""
    totals = per_ts_totals(csv_path)
    vals = [totals[k] for k in sorted(totals)]
    if not vals:
        return 0, 0.0
    lo = int(len(vals) * 0.2)
    hi = int(len(vals) * 0.8)
    mid = vals[lo:hi] or vals
    return len(mid), sum(mid) / len(mid)


def experiment_power(exp_dir):
    """Prefer sustained window power; fall back to the original series."""
    sus = os.path.join(exp_dir, "power_mem_sustained.csv")
    if os.path.exists(sus):
        n, p = sustained_window_power(sus)
        return n, p, "sustained"
    orig = os.path.join(exp_dir, "power_mem.csv")
    if os.path.exists(orig):
        n, p = mean_total_power(orig)
        return n, p, "original"
    return 0, 0.0, "missing"


def main():
    problems = []
    oks = []

    # ---- exit codes -------------------------------------------------------
    exp_dirs = sorted(
        d for d in os.listdir(ROOT)
        if os.path.isdir(os.path.join(ROOT, d))
    )
    for d in exp_dirs:
        ec_file = os.path.join(ROOT, d, "exit_code.txt")
        sus_file = os.path.join(ROOT, d, "exit_code_sustained.txt")
        if os.path.exists(sus_file):
            rc = open(sus_file, encoding="utf-8").read().strip()
            if rc != "0":
                problems.append(f"[exit] {d}: sustained exit_code={rc}")
                continue
            oks.append(f"[exit] {d}: sustained rc=0")
            continue
        if not os.path.exists(ec_file):
            problems.append(f"[exit] {d}: exit_code.txt missing")
            continue
        rc = open(ec_file, encoding="utf-8").read().strip()
        if rc != "0":
            problems.append(f"[exit] {d}: exit_code={rc}")
        else:
            oks.append(f"[exit] {d}: rc=0 (no sustained rerun yet)")

    # ---- idle -------------------------------------------------------------
    idle_csv = os.path.join(ROOT, "idle", "power_mem.csv")
    idle_mean = 0.0
    if os.path.exists(idle_csv):
        n_idle, idle_mean = mean_total_power(idle_csv)
        if n_idle < 120:
            problems.append(f"[idle] only {n_idle} samples (<120)")
        else:
            oks.append(f"[idle] {n_idle} samples, mean total power {idle_mean:.1f} W")
    else:
        problems.append("[idle] idle/power_mem.csv missing")

    # ---- bench metrics: world_size ---------------------------------------
    for mname in ("bench_metrics.csv", "bench_metrics_sustained.csv"):
        metrics_path = os.path.join(ROOT, mname)
        if not os.path.exists(metrics_path):
            continue
        with open(metrics_path, newline="", encoding="utf-8") as f:
            for row in csv.DictReader(f):
                if row.get("world_size") and row["world_size"] != "16":
                    problems.append(
                        f"[world] {mname}:{row['metric']}: world_size={row['world_size']} (must be 16)")

    metrics_path = os.path.join(ROOT, "bench_metrics.csv")
    bench_rows = []
    if os.path.exists(metrics_path):
        with open(metrics_path, newline="", encoding="utf-8") as f:
            bench_rows = list(csv.DictReader(f))
    else:
        problems.append("[bench] bench_metrics.csv missing")

    # ---- power deltas vs idle --------------------------------------------
    if idle_mean > 0:
        for d in exp_dirs:
            if d == "idle":
                continue
            n, mean_p, src = experiment_power(os.path.join(ROOT, d))
            if n == 0:
                problems.append(f"[power] {d}: no parseable power samples")
                continue
            ratio = mean_p / idle_mean
            tag = "OK " if ratio >= POWER_DELTA_MIN else "LOW"
            line = (f"[power] {d}: {mean_p:.1f} W vs idle {idle_mean:.1f} W "
                    f"(x{ratio:.3f}, {src}) {tag}")
            (oks if ratio >= POWER_DELTA_MIN else problems).append(line)

    # ---- collective latency monotonicity ----------------------------------
    coll = {}
    for row in bench_rows:
        if row["mode"] in ("all_reduce", "all_gather", "reduce_scatter"):
            m = re.search(r"_(\d+)$", row["metric"])
            if m:
                coll.setdefault(row["mode"], []).append((int(m.group(1)), float(row["avg_s"])))
    for mode, pts in coll.items():
        pts.sort()
        mono = all(b >= a * MONO_TOL for (_, a), (_, b) in zip(pts, pts[1:]))
        line = (f"[mono] {mode}: " +
                " -> ".join(f"{n / 1e6:.0f}M:{t * 1e3:.2f}ms" for n, t in pts) +
                (" OK" if mono else " NON-MONOTONIC"))
        (oks if mono else problems).append(line)

    # ---- report ------------------------------------------------------------
    lines = ["=== AscendTune 910C energy calibration validity report (v2) ===", ""]
    lines.append(f"--- PASS ({len(oks)}) ---")
    lines += oks
    lines.append("")
    lines.append(f"--- PROBLEMS ({len(problems)}) ---")
    lines += problems if problems else ["(none)"]
    lines.append("")
    lines.append("OVERALL: " + ("PASS" if not problems else "INCOMPLETE - fix the items above"))
    report = "\n".join(lines)
    print(report)
    with open(os.path.join(ROOT, "validity_report.txt"), "w", encoding="utf-8") as f:
        f.write(report + "\n")


if __name__ == "__main__":
    main()
