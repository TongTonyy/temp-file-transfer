# PWM20 padded 7-mode formal 采集命令

## 采集设计

- 训练负载: V2 第五组 `mbs2_seq2048_gbs32_padded`
- `micro_batch_size=2`
- `global_batch_size=32`
- `seq_length=2048`
- `HGNN_NO_PAD_TO_SEQ_LENGTHS=0`
- 故障 PWM: `20`
- 默认时序: `baseline=180s`, `fault_active=900s`, `release_at=1080s`, `recovery=180s`, `duration=1260s`
- manual fan mode timeout: `1560s`
- profiling: extended thermal 计划，10 个 segment，已适配 900s fault window

7 种模式：

```text
1. pwm20_padded_control              manual_baseline_sham
2. pwm20_padded_drawer0              drawer0_pwm20
3. pwm20_padded_drawer1_cpu          drawer1_pwm20
4. pwm20_padded_drawer2              drawer2_pwm20
5. pwm20_padded_drawer0_drawer1      drawer0_drawer1_pwm20
6. pwm20_padded_drawer1_drawer2      drawer1_drawer2_pwm20
7. pwm20_padded_all_drawers          all_drawers_pwm20
```

## 1. 在 910C 拉取并覆盖脚本

前提：你已经把 `full83_pwm20_padded_7mode_formal_20260907.tar.gz` 和 `.sha256` 上传到 `TongTonyy/temp-file-transfer` 仓库根目录。

```bash
cd /root/hgnn_910c_readiness

rm -rf /root/hgnn_910c_readiness/temp-file-transfer

GIT_TERMINAL_PROMPT=0 timeout 900 git -c http.version=HTTP/1.1 \
  clone --progress --depth 1 --single-branch --no-tags --filter=blob:none --sparse \
  -b main https://github.com/TongTonyy/temp-file-transfer.git \
  /root/hgnn_910c_readiness/temp-file-transfer

cd /root/hgnn_910c_readiness/temp-file-transfer
git sparse-checkout init --no-cone
git sparse-checkout set \
  full83_pwm20_padded_7mode_formal_20260907.tar.gz \
  full83_pwm20_padded_7mode_formal_20260907.tar.gz.sha256

command cp -f \
  full83_pwm20_padded_7mode_formal_20260907.tar.gz \
  full83_pwm20_padded_7mode_formal_20260907.tar.gz.sha256 \
  /root/hgnn_910c_readiness/hgnn_f01_qwen3_campaign_v0.3.4/

cd /root/hgnn_910c_readiness/hgnn_f01_qwen3_campaign_v0.3.4
sha256sum -c full83_pwm20_padded_7mode_formal_20260907.tar.gz.sha256
tar -xzf full83_pwm20_padded_7mode_formal_20260907.tar.gz

chmod +x \
  tools/offline/full83_910c/run_full83_910c_collection.sh \
  tools/offline/full83_910c/run_full83_pwm20_padded_7mode_910c_collection.sh \
  workload/full83_fan_detail_sidecar.py \
  workload/full83_extract_step_time_by_segment.py \
  workload/reference/tune_qwen3_14b_4K_full_ptd.sh \
  app/bin/run_hsh_f01_active.py
```

## 2. 后台启动正式采集

默认 `start` 会使用 `setsid + nohup`，堡垒机网页终端断开后后端仍继续执行。

```bash
cd /root/hgnn_910c_readiness/hgnn_f01_qwen3_campaign_v0.3.4

export HGNN_CAMPAIGN_ROOT_APPROVAL=I_ACKNOWLEDGE_HARDENED_ROOT_EXECUTION

bash tools/offline/full83_910c/run_full83_pwm20_padded_7mode_910c_collection.sh start
```

启动后会打印：

```text
FULL83_CAMPAIGN_ID=...
FULL83_RUN_LOG=...
FULL83_BACKGROUND_PID=...
```

请保存 `FULL83_CAMPAIGN_ID`。

## 3. 查看关键进度

```bash
cd /root/hgnn_910c_readiness/hgnn_f01_qwen3_campaign_v0.3.4

bash tools/offline/full83_910c/run_full83_pwm20_padded_7mode_910c_collection.sh tail
```

另开一个终端查看进程：

```bash
ps -eo pid,ppid,user,etime,stat,cmd | \
  egrep 'run_full83_pwm20_padded_7mode|run_full83_910c_collection|run_hsh_f01_active|full83_monitor|full83_fan_detail|torchrun|posttrain_gpt' | \
  grep -v grep
```

查看各 group 完成情况：

```bash
cd /root/hgnn_910c_readiness/hgnn_f01_qwen3_campaign_v0.3.4

export FULL83_CAMPAIGN_ID="<启动时打印的FULL83_CAMPAIGN_ID>"

bash tools/offline/full83_910c/run_full83_pwm20_padded_7mode_910c_collection.sh status
```

## 4. 中断后续跑

```bash
cd /root/hgnn_910c_readiness/hgnn_f01_qwen3_campaign_v0.3.4

export HGNN_CAMPAIGN_ROOT_APPROVAL=I_ACKNOWLEDGE_HARDENED_ROOT_EXECUTION
export FULL83_CAMPAIGN_ID="<上一次启动时打印的FULL83_CAMPAIGN_ID>"

nohup setsid bash tools/offline/full83_910c/run_full83_pwm20_padded_7mode_910c_collection.sh resume \
  > runtime/logs/full83_pwm20_padded_7mode_resume_${FULL83_CAMPAIGN_ID}.log 2>&1 < /dev/null &

echo "PID=$!"
```

## 5. 新增输出

逐风扇 RPM / Manual Level / Actual Level：

```text
runtime/extracted_targets_full83/${FULL83_CAMPAIGN_ID}/provenance/full83/fan_detail/<run_id>/fan_detail_timeseries.csv
runtime/extracted_targets_full83/${FULL83_CAMPAIGN_ID}/provenance/full83/fan_detail/<run_id>/drawer_fan_timeseries.csv
```

分阶段 step time：

```text
runtime/extracted_targets_full83/${FULL83_CAMPAIGN_ID}/provenance/full83/step_time/<run_id>/step_time_by_segment.csv
runtime/extracted_targets_full83/${FULL83_CAMPAIGN_ID}/provenance/full83/step_time/<run_id>/step_time_by_rank_segment.csv
```
