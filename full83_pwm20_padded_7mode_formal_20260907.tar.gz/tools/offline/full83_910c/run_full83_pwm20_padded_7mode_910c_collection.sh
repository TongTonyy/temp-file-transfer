#!/usr/bin/env bash
set -Eeuo pipefail
umask 077

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd -P)"
ACTION="${1:-start}"
PACKAGE_NAME="hgnn_f01_qwen3_campaign_v0.3.4"
REPO_ROOT="$(cd "$SCRIPT_DIR/../../.." && pwd -P)"
if [[ -n "${HGNN_ROOT:-}" ]]; then
  ROOT="$HGNN_ROOT"
elif [[ -d "$REPO_ROOT/campaigns/$PACKAGE_NAME/workload" ]]; then
  ROOT="$REPO_ROOT/campaigns/$PACKAGE_NAME"
elif [[ -d "$PWD/workload" && -d "$PWD/app" ]]; then
  ROOT="$(pwd -P)"
else
  ROOT="/root/hgnn_910c_readiness/$PACKAGE_NAME"
fi
ROOT="$(cd "$ROOT" && pwd -P)"
cd "$ROOT"

configure_pwm20_padded_7mode() {
  export FULL83_MODE="full"
  export FULL83_GROUP_PLAN="pwm20_padded_7mode"
  export FULL83_TARGET_PWM="20"
  export FULL83_BASELINE_S="${FULL83_BASELINE_S:-180}"
  export FULL83_RELEASE_AT_S="${FULL83_RELEASE_AT_S:-1080}"
  export FULL83_DURATION_S="${FULL83_DURATION_S:-1260}"
  export FULL83_MANUAL_TIMEOUT_S="${FULL83_MANUAL_TIMEOUT_S:-1560}"
  export FULL83_REQUIRE_SMOKE_GATES="${FULL83_REQUIRE_SMOKE_GATES:-0}"
  export FULL83_ENABLE_BMC="${FULL83_ENABLE_BMC:-auto}"
  export FULL83_MAX_GROUPS="${FULL83_MAX_GROUPS:-7}"
  export FULL83_EXTENDED_THERMAL_PROFILE_PLAN="${FULL83_EXTENDED_THERMAL_PROFILE_PLAN:-1}"
  export FULL83_FAN_DETAIL_SIDECAR="${FULL83_FAN_DETAIL_SIDECAR:-1}"
  export FULL83_FAN_DETAIL_INTERVAL_S="${FULL83_FAN_DETAIL_INTERVAL_S:-2}"
  export FULL83_EXTRACT_STEP_TIME="${FULL83_EXTRACT_STEP_TIME:-1}"
  export FULL83_MONITOR_LOG_ONLY="${FULL83_MONITOR_LOG_ONLY:-1}"
  export FULL83_MONITOR_INTERVAL_S="${FULL83_MONITOR_INTERVAL_S:-120}"

  # V2 fifth workload: mbs2_seq2048_gbs32_padded.
  export HGNN_MBS="${HGNN_MBS:-2}"
  export HGNN_GBS="${HGNN_GBS:-32}"
  export HGNN_SEQ_LENGTH="${HGNN_SEQ_LENGTH:-2048}"
  export HGNN_NO_PAD_TO_SEQ_LENGTHS="${HGNN_NO_PAD_TO_SEQ_LENGTHS:-0}"

  # Four physical training cards / eight ranks.
  export HGNN_EXPECTED_NPU_IDS="${HGNN_EXPECTED_NPU_IDS:-0,1,2,3,4,5,6,7}"
  export HGNN_EXPECTED_PROFILE_RANKS="${HGNN_EXPECTED_PROFILE_RANKS:-8}"
  export HGNN_NPUS_PER_NODE="${HGNN_NPUS_PER_NODE:-8}"
  export HGNN_TP="${HGNN_TP:-4}"
  export HGNN_PP="${HGNN_PP:-2}"
  export HGNN_ASCEND_RT_VISIBLE_DEVICES="${HGNN_ASCEND_RT_VISIBLE_DEVICES:-0,1,2,3,4,5,6,7}"
  export HGNN_TORCH_NPU_AIC_METRIC="${HGNN_TORCH_NPU_AIC_METRIC:-ResourceConflictRatio}"
}

latest_log() {
  ls -t "$ROOT"/runtime/logs/full83_pwm20_padded_7mode_*.log 2>/dev/null | head -n 1
}

case "$ACTION" in
  start)
    configure_pwm20_padded_7mode
    export FULL83_CAMPAIGN_ID="${FULL83_CAMPAIGN_ID:-$(date -u +%Y%m%dT%H%M%SZ)-full83-pwm20-padded-7mode-r35}"
    mkdir -p "$ROOT/runtime/logs"
    RUN_LOG="$ROOT/runtime/logs/full83_pwm20_padded_7mode_${FULL83_CAMPAIGN_ID}.log"
    echo "FULL83_CAMPAIGN_ID=$FULL83_CAMPAIGN_ID"
    echo "FULL83_RUN_LOG=$RUN_LOG"
    echo "FULL83_TIMING baseline=${FULL83_BASELINE_S}s fault_active=$((FULL83_RELEASE_AT_S - FULL83_BASELINE_S))s release_at=${FULL83_RELEASE_AT_S}s duration=${FULL83_DURATION_S}s"
    echo "FULL83_MANUAL_TIMEOUT_S=$FULL83_MANUAL_TIMEOUT_S"
    echo "FULL83_WORKLOAD mbs=$HGNN_MBS gbs=$HGNN_GBS seq=$HGNN_SEQ_LENGTH no_pad=$HGNN_NO_PAD_TO_SEQ_LENGTHS"
    nohup setsid bash "$0" foreground >"$RUN_LOG" 2>&1 < /dev/null &
    echo "FULL83_BACKGROUND_PID=$!"
    ;;
  foreground|full|resume|package|preflight)
    configure_pwm20_padded_7mode
    exec "$SCRIPT_DIR/run_full83_910c_collection.sh" "$([[ "$ACTION" == "foreground" ]] && echo full || echo "$ACTION")"
    ;;
  status)
    configure_pwm20_padded_7mode
    echo "FULL83_CAMPAIGN_ID=${FULL83_CAMPAIGN_ID:-}"
    ps -eo pid,ppid,user,etime,stat,cmd | \
      egrep 'run_full83_pwm20_padded_7mode|run_full83_910c_collection|run_hsh_f01_active|full83_monitor|full83_fan_detail|torchrun|posttrain_gpt' | \
      grep -v grep || true
    if [[ -n "${FULL83_CAMPAIGN_ID:-}" ]]; then
      "$SCRIPT_DIR/run_full83_910c_collection.sh" status || true
    fi
    ;;
  tail)
    log="$(latest_log)"
    [[ -n "$log" ]] || { echo "未找到 full83_pwm20_padded_7mode 日志" >&2; exit 1; }
    echo "FULL83_TAIL_LOG=$log"
    tail -f "$log"
    ;;
  *)
    echo "用法: $0 {start|foreground|full|resume|status|tail|package|preflight}" >&2
    exit 2
    ;;
esac
