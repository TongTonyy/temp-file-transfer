#!/usr/bin/env bash
set -Eeuo pipefail
umask 077

ROOT="${HGNN_ROOT:-/root/hgnn_910c_readiness/hgnn_f01_qwen3_campaign_v0.3.4}"
SOURCE_CAMPAIGN_ID="${HGNN_R28_SOURCE_CAMPAIGN_ID:-r28-new-collection}"
DEPLOY_STAMP="$(date -u +%Y%m%dT%H%M%SZ)"
CAMPAIGN_ID="${HGNN_R28_CAMPAIGN_ID:-${DEPLOY_STAMP}-r28-realtime-cleanup}"
R28_MODE="${HGNN_R28_MODE:-pilot-30s}"
WORKLOAD="$ROOT/workload"
NODE_SCHEMA="$ROOT/app/schemas/node_features.yaml"
PARSE_WORKERS="${HGNN_R28_PARSE_WORKERS:-4}"
EXTRACT_WORKERS="${HGNN_R28_EXTRACT_WORKERS:-8}"
MIN_FREE_GIB="${HGNN_R28_MIN_FREE_GIB:-120}"
MAX_RAW_GROUP_GIB="${HGNN_R28_MAX_RAW_GROUP_GIB:-700}"
PILOT_WINDOW_S="${HGNN_R28_PILOT_WINDOW_S:-30}"
CANARY_WINDOW_S="${HGNN_R28_CANARY_WINDOW_S:-30}"
FULL_WINDOW_S="${HGNN_R28_FULL_WINDOW_S:-300}"

[[ -d "$ROOT" ]] || {
  echo "campaign目录不存在: $ROOT" >&2
  exit 2
}
cd "$ROOT"
mkdir -p runtime/logs runtime/gates runtime/manifests runtime/return_bundles
DEPLOY_LOG="$ROOT/runtime/logs/r28_realtime_cleanup_${DEPLOY_STAMP}.log"
exec > >(tee -a "$DEPLOY_LOG") 2>&1

# shellcheck disable=SC1091
. "$ROOT/workload/common.sh"
resolve_llm_python

PILOT_EXTRACTION_ROOT="$ROOT/runtime/extracted_targets_r28/$CAMPAIGN_ID/pilot"
CANARY_EXTRACTION_ROOT="$ROOT/runtime/extracted_targets_r28/$CAMPAIGN_ID/canary"
FULL_EXTRACTION_ROOT="$ROOT/runtime/extracted_targets_r28/$CAMPAIGN_ID/full"
MANIFEST_ROOT="$ROOT/runtime/manifests/$CAMPAIGN_ID"
PACKAGE_DIR="$ROOT/runtime/return_bundles"
TIMING_ROOT="$ROOT/runtime/gates/r28_timing/$CAMPAIGN_ID"
mkdir -p "$PILOT_EXTRACTION_ROOT" "$CANARY_EXTRACTION_ROOT" \
  "$FULL_EXTRACTION_ROOT" "$MANIFEST_ROOT" "$PACKAGE_DIR" "$TIMING_ROOT"

r28_stage() {
  echo "============================================================"
  echo "R28_STAGE=$1/9"
  echo "R28_STAGE_NAME=$2"
  echo "R28_STAGE_UTC=$(date -u +%Y%m%dT%H%M%SZ)"
  echo "============================================================"
}

r28_now_ms() {
  "$HGNN_PYTHON" - <<'PY'
import time
print(int(time.monotonic() * 1000))
PY
}

r28_elapsed_s() {
  "$HGNN_PYTHON" - "$1" "$2" <<'PY'
import sys
print(f"{(int(sys.argv[2]) - int(sys.argv[1])) / 1000:.3f}")
PY
}

r28_dir_bytes() {
  "$HGNN_PYTHON" - "$1" <<'PY'
import os
import sys
from pathlib import Path
root = Path(sys.argv[1])
total = 0
if root.is_file():
    total = root.stat().st_size
elif root.exists():
    for current, dirs, files in os.walk(root):
        dirs[:] = [name for name in dirs if not Path(current, name).is_symlink()]
        for name in files:
            path = Path(current, name)
            if not path.is_symlink():
                total += path.stat().st_size
print(total)
PY
}

r28_json_timing() {
  "$HGNN_PYTHON" - "$@" <<'PY'
import json
import sys
from pathlib import Path
out = Path(sys.argv[1])
keys = sys.argv[2::2]
values = sys.argv[3::2]
payload = {"schema_version": "r28.timing.v1"}
for key, value in zip(keys, values):
    try:
        if value.isdigit():
            payload[key] = int(value)
        else:
            payload[key] = float(value)
    except ValueError:
        payload[key] = value
out.parent.mkdir(parents=True, exist_ok=True)
out.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")
PY
}

r28_window_timing() {
  local window_s="$1"
  "$HGNN_PYTHON" - "$window_s" <<'PY'
import sys
window = int(float(sys.argv[1]))
baseline = 30
release = baseline + window
duration = release + 30
print(f"{duration} {baseline} {release}")
PY
}

r28_sanitize_report() {
  "$HGNN_PYTHON" - "$1" "$2" <<'PY'
import json
import sys
from pathlib import Path

DROP_KEYS = {
    "path",
    "paths",
    "session",
    "sessions",
    "prof_dir",
    "profile_root",
    "source_path",
    "csv_outputs",
    "ranks",
    "files",
    "source_inventory",
    "summary_marker",
}

def scrub(value):
    if isinstance(value, dict):
        return {
            key: scrub(item)
            for key, item in value.items()
            if key not in DROP_KEYS
        }
    if isinstance(value, list):
        return [scrub(item) for item in value]
    if isinstance(value, str) and (
        "_ascend_pt" in value
        or "PROF_" in value
        or "PROF" in value
        or "op_summary_slice" in value
    ):
        return "<raw_profiler_path_redacted>"
    return value

source = Path(sys.argv[1])
target = Path(sys.argv[2])
payload = scrub(json.loads(source.read_text(encoding="utf-8")))
if isinstance(payload, dict):
    payload["raw_profiler_paths_redacted"] = True
target.parent.mkdir(parents=True, exist_ok=True)
target.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")
PY
}

r28_check_profiles_empty() {
  "$HGNN_PYTHON" - "$ROOT/runtime/profiles" <<'PY'
import sys
from pathlib import Path
root = Path(sys.argv[1])
if not root.exists():
    raise SystemExit(0)
items = [p for p in root.iterdir() if p.name not in {".keep"}]
if items:
    print("R28_STALE_PROFILE_ROOTS=" + ",".join(str(p) for p in sorted(items)))
    raise SystemExit(1)
PY
}

r28_mock_materialize() {
  local profile_root="$1" metric="$2" run_id="$3" condition="$4"
  local duration="$5" baseline="$6" release="$7" mode="$8"
  local steps="4"
  [[ "$mode" == "formal" ]] && steps="120"
  export HGNN_R27_MOCK_TIMESTAMP_US="$("$HGNN_PYTHON" - "$WORKLOAD" "$baseline" "$release" <<'PY'
import sys
sys.path.insert(0, sys.argv[1])
from r27_state import mock_profiler_timestamp_us
print(mock_profiler_timestamp_us(baseline_s=float(sys.argv[2]), release_at_s=float(sys.argv[3])))
PY
)"
  "$HGNN_PYTHON" - "$WORKLOAD" "$profile_root" "$metric" "$ROOT" "$run_id" \
    "$condition" "$duration" "$baseline" "$release" "$steps" <<'PY'
import sys
from pathlib import Path
sys.path.insert(0, sys.argv[1])
from r27_state import materialize_mock_profile_root, materialize_mock_run_sidecars
materialize_mock_profile_root(Path(sys.argv[2]), sys.argv[3], effective_steps=int(sys.argv[10]))
materialize_mock_run_sidecars(
    Path(sys.argv[4]),
    sys.argv[5],
    condition=sys.argv[6],
    duration_s=float(sys.argv[7]),
    baseline_s=float(sys.argv[8]),
    release_at_s=float(sys.argv[9]),
)
print(f"R28_MOCK_PROFILE={sys.argv[2]}")
PY
}

r28_cleanup_failed_attempt() {
  local run_id="$1" profile_root="$2" extraction_root="$3" reason="$4"
  if [[ -d "$profile_root" ]]; then
    "$HGNN_PYTHON" "$WORKLOAD/r28_cleanup_raw_profile.py" \
      --root "$ROOT" \
      --profile-root "$profile_root" \
      --extraction-root "$extraction_root" \
      --group-manifest "$extraction_root/excluded/$run_id.json" \
      --run-id "$run_id" \
      --profile-plans-output "$extraction_root/provenance/r28/excluded/$run_id/profile_plans" \
      --cleanup-report "$extraction_root/provenance/r28/excluded/$run_id/cleanup_report.json" \
      --failed-attempt \
      --failure-reason "$reason" || true
  fi
}

r28_run_group() {
  local key="$1" condition="$2" metric="$3" drawer="$4" mode="$5" extraction_root="$6" window_s="$7" pair="${8:-}"
  local run_id profile_root gate_dir provenance_gate timing_json duration baseline release collect_start collect_end
  local parse_start parse_end schema_start schema_end extract_start extract_end cleanup_start cleanup_end
  local package_start package_end raw_peak_bytes cann_csv_bytes canonical_bytes bundle_bytes
  read -r duration baseline release < <(r28_window_timing "$window_s")
  run_id="${CAMPAIGN_ID}-${key}-a1"
  profile_root="$ROOT/runtime/profiles/$run_id"
  gate_dir="$ROOT/runtime/gates/r28_group_gate/$CAMPAIGN_ID/$run_id"
  provenance_gate="$extraction_root/provenance/r28/gates/$run_id"
  timing_json="$extraction_root/provenance/r28/timing/${run_id}.json"
  mkdir -p "$gate_dir" "$provenance_gate" "$(dirname "$timing_json")" "$extraction_root"
  echo "R28_GROUP_START=$key"
  echo "RUN_ID=$run_id"
  echo "R28_PROFILE_WINDOW_S=$window_s"
  echo "AIC_METRIC=$metric"

  collect_start="$(r28_now_ms)"
  export HGNN_FORMAL_DURATION="$duration"
  export HGNN_FORMAL_BASELINE="$baseline"
  export HGNN_FORMAL_RELEASE_AT="$release"
  export HGNN_PROFILE_INVENTORY_MODE="$mode"
  export HGNN_TORCH_NPU_AIC_METRIC="$metric"
  if [[ "${HGNN_R28_MOCK_RUN:-}" == "1" ]]; then
    r28_mock_materialize "$profile_root" "$metric" "$run_id" "$condition" \
      "$duration" "$baseline" "$release" "$mode"
  else
    if ! run_formal "$condition" "$drawer" "$run_id"; then
      r28_cleanup_failed_attempt "$run_id" "$profile_root" "$extraction_root" "collect_failed"
      return 1
    fi
  fi
  collect_end="$(r28_now_ms)"
  raw_peak_bytes="$(r28_dir_bytes "$profile_root")"
  echo "R28_RAW_PROFILE_BYTES=$raw_peak_bytes"
  "$HGNN_PYTHON" - "$raw_peak_bytes" "$MAX_RAW_GROUP_GIB" <<'PY'
import sys
raw = int(sys.argv[1])
limit = int(sys.argv[2]) * 1024**3
if raw > limit:
    raise SystemExit(f"raw profile exceeds budget: {raw} > {limit}")
PY

  local inventory_raw="$gate_dir/${metric}_collection_inventory.json"
  local parse_report_raw="$gate_dir/${metric}_cann_parse_report.json"
  local schema_report_raw="$gate_dir/${metric}_schema_audit.json"
  local inventory="$provenance_gate/${metric}_collection_inventory.json"
  local parse_report="$provenance_gate/${metric}_cann_parse_report.json"
  local schema_report="$provenance_gate/${metric}_schema_audit.json"
  local parse_cache="$gate_dir/parse_cache"

  if ! "$HGNN_PYTHON" "$WORKLOAD/inventory_torch_npu_profile.py" \
    --input-root "$profile_root" \
    --output "$inventory_raw" \
    --metric "$metric" \
    --expected-ranks 16 \
    --mode "$mode"; then
    r28_cleanup_failed_attempt "$run_id" "$profile_root" "$extraction_root" "inventory_failed"
    return 1
  fi
  r28_sanitize_report "$inventory_raw" "$inventory"

  parse_start="$(r28_now_ms)"
  local parse_argv=(
    "$HGNN_PYTHON" "$WORKLOAD/r27_parse_sessions.py"
    --profile-root "$profile_root"
    --metric "$metric"
    --cache-root "$parse_cache"
    --output "$parse_report_raw"
    --max-workers "$PARSE_WORKERS"
  )
  if [[ "${HGNN_R28_MOCK_RUN:-}" == "1" || "${HGNN_R28_MOCK_CANN:-}" == "1" ]]; then
    parse_argv+=(--mock)
  elif [[ -n "${HGNN_MSPROF_PY:-}" ]]; then
    parse_argv+=(--msprof-py "$HGNN_MSPROF_PY")
  fi
  if ! "${parse_argv[@]}"; then
    r28_cleanup_failed_attempt "$run_id" "$profile_root" "$extraction_root" "cann_parse_failed"
    return 1
  fi
  r28_sanitize_report "$parse_report_raw" "$parse_report"
  parse_end="$(r28_now_ms)"

  schema_start="$(r28_now_ms)"
  if ! "$HGNN_PYTHON" "$WORKLOAD/validate_r27_profiler_schema.py" \
    --metric-root "$profile_root/$metric" \
    --metric "$metric" \
    --output "$schema_report_raw" \
    --expected-ranks 16 \
    --mode "$mode"; then
    r28_cleanup_failed_attempt "$run_id" "$profile_root" "$extraction_root" "schema_failed"
    return 1
  fi
  r28_sanitize_report "$schema_report_raw" "$schema_report"
  schema_end="$(r28_now_ms)"

  extract_start="$(r28_now_ms)"
  if ! "$HGNN_PYTHON" "$WORKLOAD/r28_extract_group.py" \
    --profile-root "$profile_root" \
    --output-root "$extraction_root" \
    --run-id "$run_id" \
    --key "$key" \
    --condition "$condition" \
    --metric "$metric" \
    --pair "$pair" \
    --attempt 1 \
    --max-workers "$EXTRACT_WORKERS" \
    --inventory-report "$inventory" \
    --parse-report "$parse_report" \
    --schema-report "$schema_report" \
    --trust-complete-reports; then
    r28_cleanup_failed_attempt "$run_id" "$profile_root" "$extraction_root" "r25_extract_failed"
    return 1
  fi
  extract_end="$(r28_now_ms)"
  canonical_bytes="$(r28_dir_bytes "$extraction_root/$run_id")"
  cann_csv_bytes="$(r28_dir_bytes "$profile_root/$metric")"

  cleanup_start="$(r28_now_ms)"
  if ! "$HGNN_PYTHON" "$WORKLOAD/r28_cleanup_raw_profile.py" \
    --root "$ROOT" \
    --profile-root "$profile_root" \
    --extraction-root "$extraction_root" \
    --group-manifest "$extraction_root/groups/$key.json" \
    --run-id "$run_id" \
    --profile-plans-output "$extraction_root/provenance/r28/profile_plans/$run_id" \
    --cleanup-report "$extraction_root/provenance/r28/cleanup/$run_id/cleanup_report.json"; then
    return 1
  fi
  cleanup_end="$(r28_now_ms)"
  bundle_bytes=0
  package_start="$cleanup_end"
  package_end="$cleanup_end"
  r28_json_timing "$timing_json" \
    run_id "$run_id" key "$key" metric "$metric" mode "$mode" \
    profile_window_s "$window_s" collect_s "$(r28_elapsed_s "$collect_start" "$collect_end")" \
    cann_export_s "$(r28_elapsed_s "$parse_start" "$parse_end")" \
    schema_gate_s "$(r28_elapsed_s "$schema_start" "$schema_end")" \
    r25_extract_s "$(r28_elapsed_s "$extract_start" "$extract_end")" \
    raw_cleanup_s "$(r28_elapsed_s "$cleanup_start" "$cleanup_end")" \
    package_s "$(r28_elapsed_s "$package_start" "$package_end")" \
    total_s "$(r28_elapsed_s "$collect_start" "$cleanup_end")" \
    raw_profile_bytes_peak "$raw_peak_bytes" cann_csv_bytes "$cann_csv_bytes" \
    canonical_bytes "$canonical_bytes" bundle_bytes "$bundle_bytes"
  cp "$timing_json" "$TIMING_ROOT/${run_id}.json"
  echo "R28_GROUP_TIMING=$timing_json"
  echo "R28_GROUP_COMPLETE=$key"
}

r28_finalize_and_package() {
  local mode="$1" extraction_root="$2" manifest_name="$3" bundle_label="$4"
  local dataset_manifest validation_report package_start package_end bundle_path timing_report
  dataset_manifest="$MANIFEST_ROOT/$manifest_name"
  validation_report="$ROOT/runtime/gates/r28_dataset_validation_${CAMPAIGN_ID}_${mode}.json"
  "$HGNN_PYTHON" "$WORKLOAD/r28_finalize_dataset.py" \
    --root "$ROOT" \
    --extraction-root "$extraction_root" \
    --campaign-id "$CAMPAIGN_ID" \
    --source-campaign-id "$SOURCE_CAMPAIGN_ID" \
    --node-schema "$NODE_SCHEMA" \
    --output "$dataset_manifest" \
    --mode "$mode"
  "$HGNN_PYTHON" "$WORKLOAD/r28_validate_dataset_83.py" \
    --dataset-manifest "$dataset_manifest" \
    --extraction-root "$extraction_root" \
    --mode "$mode" \
    --output "$validation_report"
  mkdir -p "$extraction_root/provenance/r28/validation"
  cp "$validation_report" "$extraction_root/provenance/r28/validation/$(basename "$validation_report")"
  package_start="$(r28_now_ms)"
  "$HGNN_PYTHON" "$WORKLOAD/r28_package_extracted_dataset.py" \
    --dataset-manifest "$dataset_manifest" \
    --extraction-root "$extraction_root" \
    --output-dir "$PACKAGE_DIR" \
    --bundle-label "$bundle_label"
  package_end="$(r28_now_ms)"
  bundle_path="$(ls -t "$PACKAGE_DIR"/"$CAMPAIGN_ID"-"$bundle_label".tar.gz)"
  timing_report="$TIMING_ROOT/${mode}_package.json"
  r28_json_timing "$timing_report" \
    mode "$mode" package_s "$(r28_elapsed_s "$package_start" "$package_end")" \
    bundle_bytes "$(r28_dir_bytes "$bundle_path")"
  echo "R28_PACKAGE_TIMING=$timing_report"
}

r28_stage 1 "启动与容量预检"
R28_RUN_START_MS="$(r28_now_ms)"
echo "R28_STARTED=$DEPLOY_STAMP"
echo "R28_CAMPAIGN_ID=$CAMPAIGN_ID"
echo "R28_MODE=$R28_MODE"
echo "R28_LOG=$DEPLOY_LOG"
[[ "$MIN_FREE_GIB" =~ ^[0-9]+$ && "$MAX_RAW_GROUP_GIB" =~ ^[0-9]+$ ]] || {
  echo "HGNN_R28_MIN_FREE_GIB/HGNN_R28_MAX_RAW_GROUP_GIB必须是整数" >&2
  exit 2
}
FREE_GIB="$("$HGNN_PYTHON" - "$ROOT" <<'PY'
import shutil
import sys
print(shutil.disk_usage(sys.argv[1]).free // (1024 ** 3))
PY
)"
echo "R28_FREE_GIB=$FREE_GIB"
if [[ "${HGNN_R28_MOCK_RUN:-}" != "1" ]] && ((FREE_GIB < MIN_FREE_GIB)); then
  echo "可用空间不足${MIN_FREE_GIB}GiB，拒绝启动" >&2
  exit 2
fi
if [[ "${HGNN_R28_ALLOW_STALE_PROFILES:-}" != "1" ]]; then
  r28_check_profiles_empty
fi
if [[ "${HGNN_R28_SKIP_PROCESS_CHECK:-}" != "1" ]] && \
  pgrep -af 'torchrun|posttrain_gpt|msprof' >runtime/logs/r28_process_check.txt; then
  echo "检测到遗留训练或Profiler进程，拒绝启动" >&2
  exit 2
fi

r28_stage 2 "初始化运行环境"
if [[ "${HGNN_R28_MOCK_RUN:-}" == "1" ]]; then
  workload_init
else
  campaign_init
  ASCEND_ENV=""
  for candidate in \
    /usr/local/Ascend/ascend-toolkit/set_env.sh \
    /usr/local/Ascend/ascend-toolkit/latest/set_env.sh
  do
    [[ -f "$candidate" ]] && { ASCEND_ENV="$candidate"; break; }
  done
  [[ -n "$ASCEND_ENV" ]] || {
    echo "未找到Ascend环境脚本" >&2
    exit 2
  }
  set +u
  # shellcheck disable=SC1090
  source "$ASCEND_ENV"
  set -u
  export HGNN_MSPROF_PY="${HGNN_MSPROF_PY:-/usr/local/Ascend/cann-8.5.2/tools/profiler/profiler_tool/analysis/msprof/msprof.py}"
  [[ -f "$HGNN_MSPROF_PY" ]] || {
    echo "msprof.py不存在: $HGNN_MSPROF_PY" >&2
    exit 2
  }
fi

r28_stage 3 "30秒pilot采集解析提取清理"
PILOT_E2E_START_MS="$(r28_now_ms)"
r28_run_group "pilot_resource_conflict" "manual_baseline_sham" \
  "ResourceConflictRatio" "drawer0" "canary" "$PILOT_EXTRACTION_ROOT" "$PILOT_WINDOW_S" "pilot"

r28_stage 4 "pilot最小数据包与估算"
r28_finalize_and_package "pilot" "$PILOT_EXTRACTION_ROOT" \
  "r28_pilot_dataset_manifest.json" "r28-pilot-30s"
PILOT_E2E_END_MS="$(r28_now_ms)"
PILOT_E2E_TOTAL_S="$(r28_elapsed_s "$PILOT_E2E_START_MS" "$PILOT_E2E_END_MS")"
echo "R28_PILOT_E2E_TOTAL_S=$PILOT_E2E_TOTAL_S"
"$HGNN_PYTHON" - "$TIMING_ROOT" "$PILOT_WINDOW_S" "$FULL_WINDOW_S" <<'PY'
import json
import sys
from pathlib import Path
root = Path(sys.argv[1])
pilot_window = float(sys.argv[2])
full_window = float(sys.argv[3])
rows = [json.loads(path.read_text(encoding="utf-8")) for path in root.glob("*pilot_resource_conflict*.json")]
if not rows:
    raise SystemExit("missing pilot timing")
row = rows[-1]
ratio = full_window / pilot_window
estimate_total = float(row["total_s"]) * ratio
estimate_raw = int(row["raw_profile_bytes_peak"]) * ratio
print(f"R28_PILOT_TOTAL_S={row['total_s']}")
print(f"R28_PILOT_RAW_PEAK_BYTES={row['raw_profile_bytes_peak']}")
print(f"R28_ESTIMATE_300S_TOTAL_S={estimate_total:.3f}")
print(f"R28_ESTIMATE_300S_RAW_BYTES={int(estimate_raw)}")
if int(row["raw_profile_bytes_peak"]) > int(120 * 1024**3):
    raise SystemExit("pilot raw exceeds 120GiB; stop before full collection")
PY

if [[ "$R28_MODE" == "pilot-30s" ]]; then
  R28_RUN_END_MS="$(r28_now_ms)"
  echo "R28_RUN_TOTAL_S=$(r28_elapsed_s "$R28_RUN_START_MS" "$R28_RUN_END_MS")"
  echo "R28_COMPLETE=pilot-30s"
  exit 0
fi
if [[ "$R28_MODE" != "full" ]]; then
  echo "HGNN_R28_MODE必须是pilot-30s或full" >&2
  exit 2
fi
if [[ "$FULL_WINDOW_S" == "300" && "${HGNN_R28_ENABLE_300S:-0}" != "1" ]]; then
  echo "300秒正式采集需要显式设置 HGNN_R28_ENABLE_300S=1" >&2
  exit 2
fi

r28_stage 5 "完整模式前置smoke gate"
FULL_E2E_START_MS="$(r28_now_ms)"
SMOKE_GATE_CHECK_START_MS="$(r28_now_ms)"
require_smoke_gate "drawer0"
SMOKE_GATE_CHECK_END_MS="$(r28_now_ms)"
echo "R28_SMOKE_GATE_CHECK_S=$(r28_elapsed_s "$SMOKE_GATE_CHECK_START_MS" "$SMOKE_GATE_CHECK_END_MS")"

r28_stage 6 "canary实时闭环并清理raw"
r28_run_group "canary_resource_conflict" "manual_baseline_sham" \
  "ResourceConflictRatio" "drawer0" "canary" "$CANARY_EXTRACTION_ROOT" "$CANARY_WINDOW_S" "canary"
r28_run_group "canary_memory_access" "manual_baseline_sham" \
  "MemoryAccess" "drawer0" "canary" "$CANARY_EXTRACTION_ROOT" "$CANARY_WINDOW_S" "canary"

r28_stage 7 "四个formal组逐组闭环"
r28_run_group "control_resource_conflict" "manual_baseline_sham" \
  "ResourceConflictRatio" "drawer0" "formal" "$FULL_EXTRACTION_ROOT" "$FULL_WINDOW_S" "resource_conflict"
r28_run_group "fault_resource_conflict" "drawer0_s1" \
  "ResourceConflictRatio" "drawer0" "formal" "$FULL_EXTRACTION_ROOT" "$FULL_WINDOW_S" "resource_conflict"
r28_run_group "fault_memory_access" "drawer0_s1" \
  "MemoryAccess" "drawer0" "formal" "$FULL_EXTRACTION_ROOT" "$FULL_WINDOW_S" "memory_access"
r28_run_group "control_memory_access" "manual_baseline_sham" \
  "MemoryAccess" "drawer0" "formal" "$FULL_EXTRACTION_ROOT" "$FULL_WINDOW_S" "memory_access"

r28_stage 8 "最终manifest验证与打包"
r28_finalize_and_package "full" "$FULL_EXTRACTION_ROOT" \
  "r28_dataset_manifest.json" "r28-extracted-dataset"
FULL_E2E_END_MS="$(r28_now_ms)"
echo "R28_FULL_TOTAL_S=$(r28_elapsed_s "$FULL_E2E_START_MS" "$FULL_E2E_END_MS")"

r28_stage 9 "完成"
R28_RUN_END_MS="$(r28_now_ms)"
echo "R28_RUN_TOTAL_S=$(r28_elapsed_s "$R28_RUN_START_MS" "$R28_RUN_END_MS")"
echo "R28_COMPLETE=1"
