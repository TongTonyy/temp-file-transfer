#!/usr/bin/env python3
"""Validate r28 extracted groups without requiring raw profiler roots."""

from __future__ import annotations

import argparse
from pathlib import Path
from typing import Any, Mapping, Sequence

from prepare_r23_extraction_contract import EXPECTED_CASE_SPECS
from torch_npu_offline_common import atomic_json, load_json


def _require_file(path: Path, label: str) -> None:
    if not path.is_file() or path.is_symlink():
        raise SystemExit(f"missing {label}: {path}")


def _validate_entry(entry: Mapping[str, Any], extraction_root: Path) -> Mapping[str, Any]:
    run_id = str(entry["run_id"])
    if not bool(entry.get("profile_root_deleted")):
        raise SystemExit(f"{run_id} does not declare profile_root_deleted")
    profile_root = str(entry.get("profile_root", "")).strip()
    if profile_root and Path(profile_root).exists():
        raise SystemExit(f"{run_id} raw profile root still exists: {profile_root}")
    cleanup_report = Path(str(entry["raw_cleanup_report"]))
    group_manifest = Path(str(entry["group_extraction_manifest"]))
    _require_file(cleanup_report, "cleanup report")
    _require_file(group_manifest, "group manifest")
    cleanup = load_json(cleanup_report)
    group = load_json(group_manifest)
    if cleanup.get("status") != "complete":
        raise SystemExit(f"{run_id} cleanup report is not complete")
    if group.get("status") != "complete":
        raise SystemExit(f"{run_id} group extraction is not complete")
    reports = group.get("rank_reports")
    if not isinstance(reports, list) or len(reports) != 16:
        raise SystemExit(f"{run_id} must have 16 rank reports")
    for rank, text in enumerate(reports):
        report_path = Path(str(text))
        _require_file(report_path, f"rank {rank} report")
        report = load_json(report_path)
        if report.get("status") != "complete" or int(report.get("rank", -1)) != rank:
            raise SystemExit(f"{run_id} rank {rank} extraction incomplete")
        if not report_path.resolve(strict=True).is_relative_to(
            extraction_root.resolve(strict=True)
        ):
            raise SystemExit(f"{run_id} rank {rank} report escaped extraction root")
    telemetry = Path(str(entry["telemetry_root"]))
    for relative in (
        "manifest.json",
        "normalized/nodes/npu.csv",
        "normalized/nodes/hbm.csv",
        "normalized/nodes/global_task.csv",
    ):
        _require_file(telemetry / relative, f"telemetry {relative}")
    plans_root = Path(str(entry["profile_plans_root"]))
    plan_count = sum(
        (plans_root / f"rank_{rank}/hgnn_profile_plan.json").is_file()
        for rank in range(16)
    )
    if plan_count != 16:
        raise SystemExit(f"{run_id} profile plan count is {plan_count}, expected 16")
    return {
        "run_id": run_id,
        "key": entry["key"],
        "rank_reports": 16,
        "raw_deleted": True,
        "profile_plans": plan_count,
    }


def validate_dataset(
    *,
    dataset_manifest: Path,
    extraction_root: Path,
    mode: str,
) -> Mapping[str, Any]:
    manifest = load_json(dataset_manifest.resolve(strict=True))
    entries = manifest.get("entries")
    if not isinstance(entries, list):
        raise SystemExit("dataset manifest entries missing")
    if mode == "full":
        keys = {str(entry["key"]) for entry in entries}
        if keys != set(EXPECTED_CASE_SPECS):
            raise SystemExit(f"full mode requires four expected keys, observed {sorted(keys)}")
    elif mode == "pilot":
        if len(entries) != 1:
            raise SystemExit("pilot mode requires exactly one entry")
    else:
        raise SystemExit("mode must be pilot or full")
    progress = load_json(extraction_root / "r25_extraction_progress.json")
    sessions = progress.get("sessions")
    if not isinstance(sessions, Mapping):
        raise SystemExit("missing extraction progress sessions")
    required_sessions = len(entries) * 16
    complete_sessions = sum(
        1
        for row in sessions.values()
        if isinstance(row, Mapping) and row.get("status") == "complete"
    )
    if complete_sessions < required_sessions:
        raise SystemExit(
            f"expected at least {required_sessions} complete sessions, "
            f"observed {complete_sessions}"
        )
    coverage = load_json(Path(str(manifest["metric_coverage"])))
    metrics = coverage.get("metrics")
    if not isinstance(metrics, list) or len(metrics) != 83:
        raise SystemExit("metric coverage must contain 83 metrics")
    rows = [
        _validate_entry(entry, extraction_root)
        for entry in sorted(entries, key=lambda item: str(item["key"]))
    ]
    return {
        "schema_version": "r28.dataset_validation.v1",
        "status": "pilot_complete" if mode == "pilot" else "complete",
        "mode": mode,
        "entry_count": len(entries),
        "complete_session_count": complete_sessions,
        "metric_count": 83,
        "raw_profiler_trace_required": False,
        "groups_verified_16_of_16": [row["key"] for row in rows],
        "runs": rows,
    }


def main(argv: Sequence[str] | None = None) -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--dataset-manifest", type=Path, required=True)
    parser.add_argument("--extraction-root", type=Path, required=True)
    parser.add_argument("--mode", choices=("pilot", "full"), default="pilot")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    report = validate_dataset(
        dataset_manifest=args.dataset_manifest,
        extraction_root=args.extraction_root,
        mode=args.mode,
    )
    atomic_json(args.output, report)
    print(f"R28_DATASET_VALIDATION={args.output}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
