#!/usr/bin/env python3
"""Finalize r28 dataset manifests from per-group extracted artifacts."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any, Mapping, Sequence

from prepare_r23_extraction_contract import EXPECTED_CASE_SPECS, load_metric_contract
from r27_state import discover_telemetry_root
from torch_npu_offline_common import atomic_json, load_json


def _load_groups(extraction_root: Path) -> list[Mapping[str, Any]]:
    groups_root = extraction_root / "groups"
    if not groups_root.is_dir():
        raise SystemExit(f"missing groups directory: {groups_root}")
    groups = [load_json(path) for path in sorted(groups_root.glob("*.json"))]
    if not groups:
        raise SystemExit("no group extraction manifests found")
    return groups


def _load_cleanup(extraction_root: Path, run_id: str) -> Mapping[str, Any]:
    cleanup = extraction_root / "provenance/r28/cleanup" / run_id / "cleanup_report.json"
    if not cleanup.is_file():
        raise SystemExit(f"missing cleanup report: {cleanup}")
    report = load_json(cleanup)
    if report.get("status") != "complete" or report.get("run_id") != run_id:
        raise SystemExit(f"cleanup report is not complete: {cleanup}")
    return report


def _entry_for_group(
    *,
    root: Path,
    extraction_root: Path,
    group: Mapping[str, Any],
) -> Mapping[str, Any]:
    run_id = str(group["run_id"])
    cleanup = _load_cleanup(extraction_root, run_id)
    return {
        "key": group["key"],
        "condition": group["condition"],
        "metric": group["metric"],
        "pair": group.get("pair"),
        "run_id": run_id,
        "attempt": group.get("attempt", 1),
        "source": "recollected",
        "rank_count": 16,
        "telemetry_root": discover_telemetry_root(root, run_id),
        "profile_root": "",
        "profile_root_deleted": True,
        "profile_plans_root": cleanup["profile_plans_output"],
        "raw_cleanup_report": str(
            extraction_root / "provenance/r28/cleanup" / run_id / "cleanup_report.json"
        ),
        "group_extraction_manifest": str(
            extraction_root / "groups" / f"{group['key']}.json"
        ),
    }


def _pairs(entries: Sequence[Mapping[str, Any]]) -> Mapping[str, Mapping[str, str]]:
    by_key = {str(entry["key"]): entry for entry in entries}
    if set(by_key) != set(EXPECTED_CASE_SPECS):
        return {}
    return {
        "resource_conflict": {
            "control": str(by_key["control_resource_conflict"]["run_id"]),
            "fault": str(by_key["fault_resource_conflict"]["run_id"]),
        },
        "memory_access": {
            "control": str(by_key["control_memory_access"]["run_id"]),
            "fault": str(by_key["fault_memory_access"]["run_id"]),
        },
    }


def _coverage_manifest(node_schema: Path, output: Path) -> Mapping[str, Any]:
    schema_version, metrics = load_metric_contract(node_schema)
    rows = []
    for metric in metrics:
        rows.append(
            {
                "metric_id": metric["id"],
                "node_type": metric["node_type"],
                "kind": metric.get("kind"),
                "unit": str(metric.get("unit", "")),
                "status": "pending_dataset_validation",
                "present": None,
            }
        )
    payload = {
        "schema_version": "r28.metric_coverage.v1",
        "status": "pending_dataset_validation",
        "node_schema_version": schema_version,
        "metric_count": len(rows),
        "metrics": sorted(rows, key=lambda row: str(row["metric_id"])),
    }
    atomic_json(output, payload)
    return payload


def finalize_dataset(
    *,
    root: Path,
    extraction_root: Path,
    campaign_id: str,
    source_campaign_id: str,
    node_schema: Path,
    output: Path,
    mode: str,
) -> Mapping[str, Any]:
    root = root.resolve(strict=True)
    extraction_root = extraction_root.resolve(strict=True)
    groups = _load_groups(extraction_root)
    if mode == "full":
        keys = {str(group["key"]) for group in groups}
        if keys != set(EXPECTED_CASE_SPECS):
            raise SystemExit(f"full dataset requires four groups, observed {sorted(keys)}")
    elif mode == "pilot":
        if len(groups) != 1:
            raise SystemExit("pilot dataset must contain exactly one group")
    else:
        raise SystemExit("mode must be pilot or full")
    entries = [
        _entry_for_group(root=root, extraction_root=extraction_root, group=group)
        for group in groups
    ]
    complete_sessions = len(entries) * 16
    coverage_path = extraction_root / "contract/metric_coverage_83.json"
    coverage_path.parent.mkdir(parents=True, exist_ok=True)
    _coverage_manifest(node_schema, coverage_path)
    manifest = {
        "schema_version": "r28.dataset_manifest.v1",
        "status": "pilot_complete" if mode == "pilot" else "complete",
        "mode": mode,
        "stage": "realtime_extract_cleanup",
        "analysis_status": "complete",
        "campaign_id": campaign_id,
        "source_campaign_id": source_campaign_id,
        "merge_mode": "pilot_16" if mode == "pilot" else "new64",
        "session_semantics": {
            "new_sessions": complete_sessions,
            "reused_sessions": 0,
            "total_sessions": complete_sessions,
            "raw_profiler_deleted": True,
        },
        "entries": entries,
        "pairs": _pairs(entries),
        "metric_coverage": str(coverage_path),
    }
    atomic_json(output, manifest)
    extraction_manifest = {
        "schema_version": "r28.extraction_manifest.v1",
        "status": "pilot_complete" if mode == "pilot" else "complete",
        "expected_session_count": complete_sessions,
        "complete_session_count": complete_sessions,
        "groups": [str(extraction_root / "groups" / f"{group['key']}.json") for group in groups],
    }
    atomic_json(extraction_root / "dataset_extraction_manifest.json", extraction_manifest)
    print(f"R28_DATASET_MANIFEST={output}")
    print(f"R28_DATASET_MODE={mode}")
    return manifest


def main(argv: Sequence[str] | None = None) -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", type=Path, required=True)
    parser.add_argument("--extraction-root", type=Path, required=True)
    parser.add_argument("--campaign-id", required=True)
    parser.add_argument("--source-campaign-id", required=True)
    parser.add_argument("--node-schema", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--mode", choices=("pilot", "full"), default="pilot")
    args = parser.parse_args(argv)
    finalize_dataset(
        root=args.root,
        extraction_root=args.extraction_root,
        campaign_id=args.campaign_id,
        source_campaign_id=args.source_campaign_id,
        node_schema=args.node_schema,
        output=args.output,
        mode=args.mode,
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
