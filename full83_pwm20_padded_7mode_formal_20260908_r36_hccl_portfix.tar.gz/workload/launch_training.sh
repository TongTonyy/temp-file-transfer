#!/usr/bin/env bash
set -Eeuo pipefail
umask 077
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd -P)"
cd "$ROOT"
# shellcheck disable=SC1091
. "$ROOT/workload/common.sh"
workload_init
: "${HGNN_RUN_ID:?HGNN_RUN_ID is required}"
MINDSPEED_ROOT="/root/MindSpeed-LLM"
[[ -d "$MINDSPEED_ROOT/mindspeed_llm" ]] || {
  echo "缺少MindSpeed-LLM源码目录: $MINDSPEED_ROOT/mindspeed_llm" >&2
  exit 2
}
export PYTHONPATH="$MINDSPEED_ROOT${PYTHONPATH:+:$PYTHONPATH}"
HCCL_IF_BASE_PORT="${HCCL_IF_BASE_PORT:-61000}"
[[ "$HCCL_IF_BASE_PORT" =~ ^[0-9]+$ ]] &&
  (( HCCL_IF_BASE_PORT >= 1024 && HCCL_IF_BASE_PORT <= 65504 )) || {
    echo "HCCL_IF_BASE_PORT必须是1024到65504之间的整数" >&2
    exit 2
  }
export HCCL_IF_BASE_PORT
HCCL_NPU_SOCKET_PORT_RANGE="$HCCL_IF_BASE_PORT-$((HCCL_IF_BASE_PORT + 31))"
export HCCL_NPU_SOCKET_PORT_RANGE
echo "HCCL_NPU_SOCKET_PORT_RANGE=$HCCL_NPU_SOCKET_PORT_RANGE"
mkdir -p "$RUNTIME/logs" "$RUNTIME/ckpt"
exec "$HGNN_CONDA_EXE" run --no-capture-output -n llm_env \
  bash "$ROOT/workload/reference/tune_qwen3_14b_4K_full_ptd.sh"
