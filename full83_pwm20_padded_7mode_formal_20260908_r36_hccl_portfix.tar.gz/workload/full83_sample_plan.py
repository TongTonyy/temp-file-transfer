#!/usr/bin/env python3
"""Build r29-compatible sample plans for full83 test and formal runs."""

from __future__ import annotations

import argparse
import os
from pathlib import Path
from typing import Any, Mapping, Sequence

from r29_sample_plan import DEFAULT_SEGMENTS, SCHEMA_VERSION, validate_sample_plan
from torch_npu_offline_common import atomic_json


def _extended_thermal_segments(fault_window_s: float, recovery_window_s: float) -> list[tuple[str, str, float, int]]:
    recovery_sample_s = fault_window_s + min(120.0, max(30.0, recovery_window_s * 0.67))
    fault_late_s = max(180.0, fault_window_s - 120.0)
    segments = [
        ("pre_fault_stable", "fault_pre_stable", -30.0, 3),
        ("pre_fault_edge", "fault_pre_edge", -5.0, 5),
        ("post_fault_edge", "fault_post_edge", 5.0, 5),
        ("fault_early", "fault_early", 30.0, 3),
        ("fault_mid", "fault_mid", min(300.0, max(150.0, fault_window_s * 0.50)), 3),
    ]
    if fault_window_s >= 720.0:
        segments.append(
            (
                "fault_mid_late",
                "fault_mid_late",
                min(600.0, max(360.0, fault_window_s - 300.0)),
                3,
            )
        )
    segments.extend(
        [
            ("fault_late", "fault_late", min(fault_late_s, fault_window_s - 30.0), 3),
            ("pre_release_edge", "release_pre_edge", fault_window_s - 5.0, 5),
            ("post_release_edge", "release_post_edge", fault_window_s + 5.0, 5),
            ("recovery_stable", "recovery_stable", recovery_sample_s, 3),
        ]
    )
    return segments


def _segment_template(fault_window_s: float, recovery_window_s: float) -> list[tuple[str, str, float, int]]:
    if os.environ.get("FULL83_EXTENDED_THERMAL_PROFILE_PLAN", "0") == "1":
        return _extended_thermal_segments(fault_window_s, recovery_window_s)
    return list(DEFAULT_SEGMENTS)


def build_sample_plan(
    *,
    run_id: str,
    metric: str,
    condition: str,
    duration_s: float,
    baseline_s: float,
    release_at_s: float,
    time_scale: float,
) -> Mapping[str, Any]:
    fault_window_s = release_at_s - baseline_s
    if fault_window_s <= 0:
        raise ValueError("release_at_s must be greater than baseline_s")
    recovery_window_s = duration_s - release_at_s
    if recovery_window_s <= 0:
        raise ValueError("duration_s must be greater than release_at_s")
    segments: list[Mapping[str, Any]] = []
    for segment_id, phase, offset_s, active_steps in _segment_template(
        fault_window_s,
        recovery_window_s,
    ):
        target_s = baseline_s + offset_s * time_scale
        if target_s < 0 or target_s > duration_s:
            raise ValueError(f"sample target out of campaign bounds: {segment_id}")
        boundary = (
            "fault_apply"
            if "fault" in phase and "release" not in phase
            else "fault_release"
            if "release" in phase
            else "recovery"
        )
        segments.append(
            {
                "segment_id": segment_id,
                "phase": phase,
                "boundary": boundary,
                "target_s": target_s,
                "offset_from_fault_apply_s": target_s - baseline_s,
                "offset_from_fault_release_s": target_s - release_at_s,
                "active_steps": active_steps,
                "full83_time_scale": time_scale,
            }
        )
    plan = {
        "schema_version": SCHEMA_VERSION,
        "run_id": run_id,
        "condition": condition,
        "metric": metric,
        "duration_s": duration_s,
        "baseline_s": baseline_s,
        "release_at_s": release_at_s,
        "fault_window_s": fault_window_s,
        "segment_count": len(segments),
        "total_active_steps": sum(int(row["active_steps"]) for row in segments),
        "segments": segments,
        "aggregation_policy": "full83_timeseries_with_sampled_profiler_segments",
        "full83_time_scale": time_scale,
    }
    validate_sample_plan(plan)
    return plan


def main(argv: Sequence[str] | None = None) -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--run-id", required=True)
    parser.add_argument("--metric", required=True)
    parser.add_argument("--condition", required=True)
    parser.add_argument("--duration-s", type=float, required=True)
    parser.add_argument("--baseline-s", type=float, required=True)
    parser.add_argument("--release-at-s", type=float, required=True)
    parser.add_argument("--time-scale", type=float, default=1.0)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    plan = build_sample_plan(
        run_id=args.run_id,
        metric=args.metric,
        condition=args.condition,
        duration_s=args.duration_s,
        baseline_s=args.baseline_s,
        release_at_s=args.release_at_s,
        time_scale=args.time_scale,
    )
    atomic_json(args.output, plan)
    print(f"FULL83_SAMPLE_PLAN={args.output}")
    print(f"FULL83_SAMPLE_SEGMENTS={plan['segment_count']}")
    print(f"FULL83_SAMPLE_ACTIVE_STEPS={plan['total_active_steps']}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
