#!/bin/bash
# V2 global-optimality follow-up anchors G1-G10.
# Config source of truth: configs/v2_global_anchors.json (parsed at runtime).
#
# These are CLEAN timing runs: plog is OFF by default because plog inflates
# step time ~5x (measured in P1 step0: 610s vs 130s). Enable only for
# debugging via ENABLE_PLOG=1.
#
# Usage:
#   bash run_v2_global.sh                 # G1-G7 only (P0 set)
#   RUN_OPTIONAL=1 bash run_v2_global.sh  # all 10 (G1-G10)
#   ONLY=G3,G4 bash run_v2_global.sh      # named subset
set -u
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
# shellcheck disable=SC1091
source "$SCRIPT_DIR/common_env.sh"

CFG="$SCRIPT_DIR/configs/v2_global_anchors.json"
OUT_ROOT=${OUT_ROOT:-$SCRIPT_DIR/results_v2_global}
ENTRY=${ENTRY:-posttrain_gpt_lab_v3.py}
BASE_PORT=${BASE_PORT:-12000}
ENABLE_PLOG=${ENABLE_PLOG:-0}
mkdir -p "$OUT_ROOT"

# deploy the PROVEN token-counting wrapper (loss_func class-hook version,
# validated 2026-11-08 on this MindSpeed-LLM install)
cat "$SCRIPT_DIR/$ENTRY" > "$MSLLM_DIR/$ENTRY" || { echo "[error] deploy wrapper failed"; exit 2; }

zero_args() {
  python3 - "$CFG" "$1" <<'PY'
import json, sys
cfg = json.load(open(sys.argv[1]))
print(cfg["zero_flag_bundles"][sys.argv[2]])
PY
}

extract_step_times() {
  python3 - "$1/train.log" "$1/step_time.csv" <<'PY'
import re, sys
log, out = sys.argv[1], sys.argv[2]
pat = re.compile(r"\[(\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2})\]\s*iteration\s+(\d+)/.*?elapsed time per iteration \(ms\):\s*([0-9.]+)")
rows = []
for line in open(log, errors="ignore"):
    m = pat.search(line)
    if m:
        rows.append((int(m.group(2)), float(m.group(3)), m.group(1)))
with open(out, "w") as f:
    f.write("step,step_time_ms,timestamp\n")
    for step, ms, ts in rows:
        if 6 <= step <= 25:   # statistical window: warmup steps 1-5 excluded
            f.write(f"{step},{ms},{ts}\n")
PY
}

run_attempt() {
  # args: name pp tp dp mb sp recompute zero_args port attempt
  local name=$1 pp=$2 tp=$3 dp=$4 mb=$5 sp=$6 recompute=$7 zargs=$8 port=$9 attempt=${10}
  local dir="$OUT_ROOT/$name"
  local ckpt="$CKPT_WEIGHTS_DIR/$(ckpt_name "$tp" "$pp" "$dp")"
  mkdir -p "$dir"
  local extra="$zargs"
  [ "$sp" = "1" ] && extra="$extra --sequence-parallel"
  case "$recompute" in
    full) extra="$extra --recompute-granularity full --recompute-method uniform --recompute-num-layers 1" ;;
    off) : ;;
    *) echo "[error] unknown recompute=$recompute"; return 3 ;;
  esac

  # plog env lines only when explicitly enabled (default: clean timing run)
  local plog_env="# plog disabled (clean timing run)"
  if [ "$ENABLE_PLOG" = "1" ]; then
    plog_env="export HCCL_ENTRY_LOG_ENABLE=1
export HCCL_DEBUG_CONFIG=\"ALG,TASK,RESOURCE,AIV_OPS_EXC\"
export ASCEND_GLOBAL_LOG_LEVEL=1
export ASCEND_SLOG_PRINT_TO_STDOUT=0"
  fi

  cat > "$dir/launch.sh" <<EOF
#!/bin/bash
source "$SCRIPT_DIR/common_env.sh"
cd "$MSLLM_DIR"
export TOK_OUT="$dir/real_tokens.csv"
export TP_SIZE_FALLBACK=$tp
$plog_env
torchrun \\
  --nproc_per_node "$NPUS_PER_NODE" \\
  --nnodes 1 \\
  --node_rank 0 \\
  --master_addr "$MASTER_ADDR" \\
  --master_port "$port" \\
  "$ENTRY" \\
  \$(base_qwen_args "$pp" "$tp" "$mb" "$ckpt") \\
  $extra
EOF
  chmod +x "$dir/launch.sh"

  echo "======================================================================"
  echo "[$(date '+%F %T')] anchor=$name attempt=$attempt pp=$pp tp=$tp dp=$dp mb=$mb sp=$sp recompute=$recompute zargs=[$zargs] port=$port plog=$ENABLE_PLOG"
  echo "======================================================================"
  SAMPLE_INTERVAL_SEC=${SAMPLE_INTERVAL_SEC:-1} bash "$SCRIPT_DIR/sampler_power_mem.sh" "$dir/power_mem.csv" &
  local sampler_pid=$!
  local trace_start; trace_start=$(date '+%Y-%m-%d %H:%M:%S')
  sleep 5
  (cd "$dir" && bash launch.sh > "train_attempt${attempt}.log" 2>&1)
  local rc=$?
  cp "$dir/train_attempt${attempt}.log" "$dir/train.log"
  sleep 3
  kill "$sampler_pid" 2>/dev/null || true
  wait "$sampler_pid" 2>/dev/null || true
  echo "$rc" > "$dir/exit_code.txt"
  if [ "$ENABLE_PLOG" = "1" ]; then
    mkdir -p "$dir/plog"
    local log_src="$HOME/ascend/log/run"
    if [ -d "$log_src" ]; then
      (cd "$log_src" && find . -type f \( -name "*.log" -o -name "*.log.*" \) -newermt "$trace_start" \
        -exec cp --parents {} "$dir/plog/" \; 2>/dev/null) || true
    fi
  fi
  return "$rc"
}

token_rows() {
  local f="$1/real_tokens.csv"
  [ -f "$f" ] && echo $(( $(wc -l < "$f") - 1 )) || echo 0
}

run_anchor() {
  local name=$1 pp=$2 tp=$3 dp=$4 mb=$5 sp=$6 z=$7 recompute=$8
  local dir="$OUT_ROOT/$name"
  local ckpt="$CKPT_WEIGHTS_DIR/$(ckpt_name "$tp" "$pp" "$dp")"
  local iters=${TRAIN_ITERS:-25}
  mkdir -p "$dir"

  if [ ! -d "$ckpt" ]; then
    echo "[warn] $name SKIPPED: checkpoint dir missing: $ckpt"
    echo "FAIL missing_ckpt" > "$dir/run_status.txt"
    return 0
  fi

  local zargs; zargs="$(zero_args "$z")"
  local port=$(( BASE_PORT + RANDOM % 500 ))
  local attempt rc
  for attempt in 1 2; do
    run_attempt "$name" "$pp" "$tp" "$dp" "$mb" "$sp" "$recompute" "$zargs" "$port" "$attempt"
    rc=$?
    if [ "$rc" = "0" ] && [ "$(token_rows "$dir")" = "$iters" ]; then
      break
    fi
    echo "[warn] $name attempt $attempt failed (rc=$rc token_rows=$(token_rows "$dir")); waiting 90s for HCCL release"
    pkill -f torchrun 2>/dev/null; sleep 90
    port=$((port + 100))
  done

  extract_step_times "$dir"
  python3 "$SCRIPT_DIR/validate_anchor.py" "$dir" "$CFG" "$name" > "$dir/validate_stdout.txt" 2>&1 || true

  if [ "$rc" = "0" ] && [ "$(token_rows "$dir")" = "$iters" ]; then
    echo "PASS rc=0 tok_rows_ok" > "$dir/run_status.txt"
  else
    echo "FAIL rc=$rc token_rows=$(token_rows "$dir")" > "$dir/run_status.txt"
  fi
  cat "$dir/run_status.txt"
}

# ---- preflight: report checkpoint availability for ALL anchors up front
echo "===== preflight: checkpoint availability ====="
python3 - "$CFG" <<'PY' > "$OUT_ROOT/anchors_to_run.tsv"
import json, sys
cfg = json.load(open(sys.argv[1]))
for a in cfg["anchors"]:
    print("\t".join([a["name"], str(a["pp"]), str(a["tp"]), str(a["dp"]),
                     str(a["micro_batch"]), str(a["sp"]), str(a["z"]),
                     a["recompute"], "1" if a["required"] else "0"]))
PY
while IFS=$'\t' read -r name pp tp dp mb sp z recompute required; do
  ckpt="$CKPT_WEIGHTS_DIR/$(ckpt_name "$tp" "$pp" "$dp")"
  if [ -d "$ckpt" ]; then echo "  [OK]      $name -> $(basename "$ckpt")"; else echo "  [MISSING] $name -> $(basename "$ckpt")"; fi
done < "$OUT_ROOT/anchors_to_run.tsv"
echo "=============================================="

first=1
while IFS=$'\t' read -r name pp tp dp mb sp z recompute required; do
  if [ -n "${ONLY:-}" ] && ! echo ",$ONLY," | grep -q ",$name,"; then
    echo "[skip] $name (ONLY=$ONLY)"
    continue
  fi
  if [ -z "${ONLY:-}" ] && [ "$required" != "1" ] && [ "${RUN_OPTIONAL:-0}" != "1" ]; then
    echo "[skip] $name (optional; set RUN_OPTIONAL=1 to include)"
    continue
  fi
  if [ "$first" = "0" ]; then
    # HCCL port residue caused V2B/V2C failures before: clean between configs
    pkill -f torchrun 2>/dev/null; sleep 90
  fi
  first=0
  run_anchor "$name" "$pp" "$tp" "$dp" "$mb" "$sp" "$z" "$recompute"
done < "$OUT_ROOT/anchors_to_run.tsv"

echo "[done] results in $OUT_ROOT"

# ---- pack everything for upload
PKG_OUT="$SCRIPT_DIR/v2_global_results.tar.gz"
rm -f "$PKG_OUT"
tar czf "$PKG_OUT" -C "$SCRIPT_DIR" results_v2_global 2>/dev/null || true
echo "[packed] $PKG_OUT ($(du -h "$PKG_OUT" 2>/dev/null | cut -f1))"
