# AscendTune 910C — V2 Global-Optimality Follow-up Package (G1–G10)

对应需求文档：`V2_GLOBAL_OPTIMALITY_MINIMAL_COLLECTION_LIST.md`。
目的：测量 V2/V3 同族 ZeRO 变体、PP=4 边界、高 TP b=2 代表点，用于支撑
"V2 是已测顶层候选区域中最优策略"的结论。

## 与之前包的关键差异

1. **plog 默认关闭** —— G 系列是干净计时实验，plog 会把步长膨胀约 5 倍
   （P1 step0 实测 610s vs 130s）。只有调试时才用 `ENABLE_PLOG=1` 打开。
2. **配置间强制清理** —— 每个配置结束后 `pkill torchrun + sleep 90`，
   避免 V2B/V2C 当时的 HCCL 端口残留失败。
3. **独立端口段** —— BASE_PORT=12000，与 lineA 的 9600 段错开。
4. **预检** —— 启动时先打印全部 10 个配置的权重可用性，缺权重的配置
   会被跳过（不中断整批）。

## 配置清单

| ID | PP | TP | DP | ZeRO | mb | required | 所需权重 |
|----|----|----|----|------|----|----------|----------|
| G1 | 1 | 4 | 4 | 2 | 2 | 是 | qwen3_mcore-4TP4DP |
| G2 | 1 | 4 | 4 | 3 | 2 | 是 | qwen3_mcore-4TP4DP |
| G3 | 2 | 4 | 2 | 1 | 2 | 是 | qwen3_mcore-4TP2DP |
| G4 | 2 | 4 | 2 | 2 | 2 | 是 | qwen3_mcore-4TP2DP |
| G5 | 2 | 4 | 2 | 3 | 2 | 是 | qwen3_mcore-4TP2DP |
| G6 | 4 | 4 | 1 | 0 | 2 | 是 | qwen3_mcore-4TP1DP |
| G7 | 1 | 8 | 2 | 0 | 2 | 是 | qwen3_mcore-8TP2DP |
| G8 | 1 | 8 | 2 | 2 | 2 | 否 | qwen3_mcore-8TP2DP |
| G9 | 2 | 8 | 1 | 0 | 2 | 否 | qwen3_mcore-8TP1DP ⚠️ |
| G10 | 1 | 4 | 4 | 2 | 1 | 否 | qwen3_mcore-4TP4DP |

⚠️ G9 需要 `qwen3_mcore-8TP1DP`，该权重在 2026-11-10 的检查中**不存在**，
需要先转换；未转换时 G9 会被自动跳过，其余 9 个不受影响。

## 用法

```bash
bash self_check.sh                       # 跑前必做（需先激活 llm_env）
bash run_v2_global.sh                    # 只跑 G1-G7
RUN_OPTIONAL=1 bash run_v2_global.sh     # 跑全部 G1-G10
ONLY=G3,G4 bash run_v2_global.sh         # 只跑点名配置
```

产物：`results_v2_global/<G*>/{step_time.csv, real_tokens.csv, power_mem.csv,
validate_report.json, token_scope_check.json, run_status.txt, train.log}`
+ 自动打包 `v2_global_results.tar.gz`。

约定与之前一致：TRAIN_ITERS=25，统计窗口 step 6–25，global_batch=1024，
seq_len=4096，OOM/失败即数据点（不救）。
