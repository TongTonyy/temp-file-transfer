#!/usr/bin/env bash
set -Eeuo pipefail
umask 077

ROOT="${HGNN_ROOT:-/root/hgnn_910c_readiness/hgnn_f01_qwen3_campaign_v0.3.4}"
PACKAGE="hgnn_f01_qwen3_campaign_v0.3.4_offline_r26.tar.gz"
CAMPAIGN_ID="${HGNN_R26_CAMPAIGN_ID:-20260814T041544Z-r13-full-dataset}"
DATASET_MANIFEST="$ROOT/runtime/manifests/$CAMPAIGN_ID/r13_dataset_manifest.json"
R23_ROOT="$ROOT/runtime/extracted_targets_r23/$CAMPAIGN_ID"
EXTRACT_ROOT="$ROOT/runtime/extracted_targets_r25/$CAMPAIGN_ID"
OUTPUT_DIR="$ROOT/runtime/return_bundles"

[[ -d "$ROOT" ]] || { echo "campaign目录不存在: $ROOT" >&2; exit 2; }
cd "$ROOT"
mkdir -p runtime/logs "$OUTPUT_DIR"
STAMP="$(date -u +%Y%m%dT%H%M%SZ)"
LOG="$ROOT/runtime/logs/r26_recover_${STAMP}.log"
exec > >(tee -a "$LOG") 2>&1

r26_stage() {
  echo "============================================================"
  echo "R26_STAGE=$1/10"
  echo "R26_STAGE_NAME=$2"
  echo "R26_STAGE_UTC=$(date -u +%Y%m%dT%H%M%SZ)"
  echo "============================================================"
}

r26_stage 1 "启动与遗留解析进程检查"
echo "R26_STARTED=$STAMP"
echo "R26_LOG=$LOG"
if pgrep -af \
  'extract_r25_real_csv_metrics|msprof.py.*export|analyse_torch_npu_profiles' \
  >runtime/logs/r26_process_check.txt; then
  echo "检测到解析进程，拒绝叠加启动：" >&2
  while IFS= read -r process; do echo "$process" >&2; done \
    <runtime/logs/r26_process_check.txt
  exit 2
fi

r26_stage 2 "r26工具包完整性校验与部署"
[[ -f "$PACKAGE" && -f "$PACKAGE.sha256" ]] || {
  echo "缺少r26工具包或SHA256" >&2
  exit 2
}
sha256sum -c "$PACKAGE.sha256"
tar -xzf "$PACKAGE"
sha256sum -c r26_SHA256SUMS

r26_stage 3 "Python、Ascend与msprof环境初始化"
if [[ -f /root/miniconda3/etc/profile.d/conda.sh ]]; then
  # shellcheck disable=SC1091
  source /root/miniconda3/etc/profile.d/conda.sh
else
  eval "$(conda shell.bash hook)"
fi
conda activate llm_env
ASCEND_ENV=""
for candidate in \
  /usr/local/Ascend/ascend-toolkit/set_env.sh \
  /usr/local/Ascend/ascend-toolkit/latest/set_env.sh
do
  [[ -f "$candidate" ]] && { ASCEND_ENV="$candidate"; break; }
done
[[ -n "$ASCEND_ENV" ]] || { echo "未找到Ascend环境" >&2; exit 2; }
set +u
# shellcheck disable=SC1090
source "$ASCEND_ENV"
set -u
MSPROF_PY="${HGNN_MSPROF_PY:-/usr/local/Ascend/cann-8.5.2/tools/profiler/profiler_tool/analysis/msprof/msprof.py}"
[[ -f "$MSPROF_PY" ]] || { echo "msprof.py不存在" >&2; exit 2; }
python - <<'PY'
import pyarrow
print(f"R26_DEPENDENCY_PREFLIGHT=PASS pyarrow={pyarrow.__version__}")
PY

r26_stage 4 "确认当前恰为60完成与4缺失"
python - "$EXTRACT_ROOT/r25_extraction_progress.json" <<'PY'
import json
import sys
from pathlib import Path
data = json.loads(Path(sys.argv[1]).read_text())
missing = {
    key for key, row in data["sessions"].items()
    if row.get("status") == "missing"
}
expected = {
    "20260814T041544Z-r13-full-dataset-control_resource_conflict-a5/rank_0",
    "20260814T041544Z-r13-full-dataset-fault_resource_conflict-a1/rank_0",
    "20260814T041544Z-r13-full-dataset-fault_memory_access-a1/rank_0",
    "20260814T041544Z-r13-full-dataset-fault_memory_access-a1/rank_10",
}
complete = sum(
    row.get("status") == "complete" for row in data["sessions"].values()
)
if complete != 60 or missing != expected:
    raise SystemExit(
        f"unexpected r25 state: complete={complete} missing={sorted(missing)}"
    )
print("R26_INPUT_STATE=PASS complete=60 missing=4")
PY

r26_stage 5 "三个rank0解析副产物dry-run审计"
AUDIT_DIR="$ROOT/runtime/logs/r26_reparse_${STAMP}"
mkdir -p "$AUDIT_DIR"
python workload/r26_reparse_three_rank0.py \
  --selection-manifest "$EXTRACT_ROOT/r23_selection_manifest.json" \
  --report "$AUDIT_DIR/dry_run.json"

r26_stage 6 "原子备份三个rank0不完整SQLite与summary"
python workload/r26_reparse_three_rank0.py \
  --selection-manifest "$EXTRACT_ROOT/r23_selection_manifest.json" \
  --report "$AUDIT_DIR/applied.json" \
  --apply \
  --confirm "$CAMPAIGN_ID"

r26_stage 7 "三个rank0顺序重新解析并保留SQLite与CSV"
python - "$AUDIT_DIR/applied.json" <<'PY' >"$AUDIT_DIR/prof_paths.txt"
import json
import sys
from pathlib import Path
data = json.loads(Path(sys.argv[1]).read_text())
for path in data["msprof_prof_paths"]:
    print(path)
PY
INDEX=0
while IFS= read -r PROF_PATH; do
  INDEX=$((INDEX + 1))
  echo "R26_CANN_PROGRESS=$INDEX/3 PROF_PATH=$PROF_PATH"
  python "$MSPROF_PY" export summary \
    -dir "$PROF_PATH" \
    --format csv \
    >"$AUDIT_DIR/cann_${INDEX}.log" 2>&1
  python - "$PROF_PATH" <<'PY'
import sys
from pathlib import Path
prof = Path(sys.argv[1])
files = list(prof.rglob("op_summary_slice_*.csv"))
if not files:
    raise SystemExit(f"CANN produced no op_summary slice: {prof}")
print(f"R26_CANN_CSV_VALIDATED={prof} files={len(files)}")
PY
done <"$AUDIT_DIR/prof_paths.txt"

r26_stage 8 "仅恢复4个缺失session并复用60个完成报告"
python workload/extract_r25_real_csv_metrics.py \
  --selection-manifest "$EXTRACT_ROOT/r23_selection_manifest.json" \
  --metric-coverage "$EXTRACT_ROOT/metric_coverage_83.json" \
  --output-root "$EXTRACT_ROOT" \
  --r23-output-root "$R23_ROOT" \
  --max-workers 8 \
  --trust-complete-reports

r26_stage 9 "64 Session验收与最终单包打包"
python - "$EXTRACT_ROOT/dataset_extraction_manifest.json" <<'PY'
import json
import sys
from pathlib import Path
data = json.loads(Path(sys.argv[1]).read_text())
if data.get("status") != "complete" or data.get("complete_session_count") != 64:
    raise SystemExit(
        f"r26 recovery incomplete: {data.get('complete_session_count')}/64"
    )
print("R26_SESSION_VALIDATED=PASS complete=64")
PY
PACKAGE_OUTPUT="$(
  python workload/package_extracted_dataset.py \
    --dataset-manifest "$DATASET_MANIFEST" \
    --extraction-root "$EXTRACT_ROOT" \
    --output-dir "$OUTPUT_DIR" \
    --bundle-label r26-recovered-real-metrics-dataset
)"
echo "$PACKAGE_OUTPUT"
BUNDLE="$(printf '%s\n' "$PACKAGE_OUTPUT" | awk -F= '$1=="DATASET_BUNDLE"{print substr($0,index($0,"=")+1)}')"
BUNDLE_SUM="$(printf '%s\n' "$PACKAGE_OUTPUT" | awk -F= '$1=="DATASET_BUNDLE_SHA256"{print substr($0,index($0,"=")+1)}')"
[[ -f "$BUNDLE" && -f "$BUNDLE_SUM" ]] || { echo "最终数据包缺失" >&2; exit 2; }
(cd "$(dirname "$BUNDLE")" && sha256sum -c "$(basename "$BUNDLE_SUM")")

r26_stage 10 "安全边界与最终完成"
python - "$BUNDLE" <<'PY'
import sys
import tarfile
with tarfile.open(sys.argv[1], "r:gz") as archive:
    names = archive.getnames()
if any("_ascend_pt/" in name.lower() or "/prof_" in name.lower() for name in names):
    raise SystemExit("raw profiler trace leaked into bundle")
print(f"R26_BUNDLE_VALIDATED=PASS members={len(names)}")
PY
echo "R26_COMPLETE=$STAMP"
echo "R26_DATASET_BUNDLE=$BUNDLE"
echo "R26_DATASET_BUNDLE_SHA256=$BUNDLE_SUM"
