# drawer0 PWM20 临时风扇/温度 probe

## 实验目标

这个临时实验只验证三件事：

- 只对第一个 NPU 抽屉 `drawer0` 的风扇 `Fan1/Fan2/Fan3/Fan4/Fan13` 设置 `PWM=20`。
- 保持原 4 卡 8 die 训练负载，活跃 NPU 为 `0..7`，其中 `drawer2` 为 `0..3`，`drawer0` 为 `4..7`。
- 连续记录逐风扇 `Manual fan level`、`Actual fan level`、Redfish RPM，以及逐 NPU 温度曲线。

该脚本不执行 full83 解析、不生成 canonical profiler 明细、不做正式数据集打包。训练脚本本身仍会创建 profile 目录，这是现有训练入口的依赖，但本 probe 不解析、不回传这些 profiler 数据。

## 默认阶段

- `0-120s`: `baseline_auto_pwm80`，训练已进入 iteration 后，在 auto 模式下采样。
- `120-420s`: `drawer0_target_pwm_manual_hold`，进入 manual，先全风扇短暂设置 `95`，再全风扇设置 `80`，最后仅 `drawer0` 风扇设置 `20`。
- `420-600s`: `recovery_auto`，显式恢复 auto 并继续采样。

默认采样间隔为 `2s`。如需更密集可设置 `HGNN_TEMP_PROBE_SAMPLE_INTERVAL_S=1`，但 iBMC SSH 与 Redfish 请求压力也会增加。

## 910C 安装和执行

假设你已经把 `drawer0_pwm20_fan_temp_probe_20260903.tar.gz` 和 `.sha256` 上传到 `TongTonyy/temp-file-transfer` 仓库根目录：

```bash
cd /root/hgnn_910c_readiness
rm -rf /root/hgnn_910c_readiness/temp-file-transfer
GIT_TERMINAL_PROMPT=0 timeout 900 git -c http.version=HTTP/1.1 clone --progress --depth 1 --single-branch --no-tags --filter=blob:none --sparse -b main https://github.com/TongTonyy/temp-file-transfer.git /root/hgnn_910c_readiness/temp-file-transfer
cd /root/hgnn_910c_readiness/temp-file-transfer
git sparse-checkout init --no-cone
git sparse-checkout set drawer0_pwm20_fan_temp_probe_20260903.tar.gz drawer0_pwm20_fan_temp_probe_20260903.tar.gz.sha256
command cp -f drawer0_pwm20_fan_temp_probe_20260903.tar.gz drawer0_pwm20_fan_temp_probe_20260903.tar.gz.sha256 /root/hgnn_910c_readiness/hgnn_f01_qwen3_campaign_v0.3.4/
cd /root/hgnn_910c_readiness/hgnn_f01_qwen3_campaign_v0.3.4
sha256sum -c drawer0_pwm20_fan_temp_probe_20260903.tar.gz.sha256
tar -xzf drawer0_pwm20_fan_temp_probe_20260903.tar.gz
chmod +x tools/offline/full83_910c/run_drawer0_pwm20_fan_temp_probe_910c.sh tools/offline/full83_910c/run_drawer0_pwm30_fan_temp_probe_910c.sh tools/offline/full83_910c/drawer0_pwm30_fan_temp_probe.py
HGNN_TEMP_PROBE_SAMPLE_INTERVAL_S=2 bash tools/offline/full83_910c/run_drawer0_pwm20_fan_temp_probe_910c.sh
```

## 可调参数

```bash
export HGNN_TEMP_PROBE_BASELINE_S=120
export HGNN_TEMP_PROBE_RELEASE_AT_S=420
export HGNN_TEMP_PROBE_DURATION_S=600
export HGNN_TEMP_PROBE_SAMPLE_INTERVAL_S=2
export HGNN_TEMP_PROBE_MANUAL_TIMEOUT_S=700
export HGNN_TEMP_PROBE_BASELINE_PWM=80
export HGNN_TEMP_PROBE_TARGET_PWM=20
export HGNN_TEMP_PROBE_NPU_HARD_STOP_C=75
```

一般不需要修改这些默认值。

## 输出目录

执行开始时会打印：

```text
TEMP_PROBE_RUN_ID=...
TEMP_PROBE_OUTPUT_DIR=/root/hgnn_910c_readiness/hgnn_f01_qwen3_campaign_v0.3.4/runtime/outputs/temp_probe/...
```

主要文件：

- `fan_timeseries.csv`: 逐风扇曲线，包含 `fan_id`、`drawer`、`manual_level_pct`、`actual_level_pct`、`redfish_rpm`。
- `npu_temperature_timeseries.csv`: 逐 NPU 温度曲线，包含 `logical_npu_id`、`drawer`、`active_training`、`temperature_c`、`utilization_pct`。
- `events.jsonl`: 阶段切换、控扇动作、异常和最终 auto 回滚记录。
- `summary.json`: 简短统计摘要。

## 回传结果

只需要回传临时 probe 结果目录，不需要回传 profiler 目录：

```bash
cd /root/hgnn_910c_readiness/hgnn_f01_qwen3_campaign_v0.3.4
RUN_ID="<替换为 TEMP_PROBE_RUN_ID 的值>"
mkdir -p runtime/return_bundles
tar -czf "runtime/return_bundles/${RUN_ID}-temp-probe-results.tar.gz" -C runtime/outputs/temp_probe "$RUN_ID"
cd runtime/return_bundles
sha256sum "${RUN_ID}-temp-probe-results.tar.gz" > "${RUN_ID}-temp-probe-results.tar.gz.sha256"
ls -lh "${RUN_ID}-temp-probe-results.tar.gz" "${RUN_ID}-temp-probe-results.tar.gz.sha256"
```
