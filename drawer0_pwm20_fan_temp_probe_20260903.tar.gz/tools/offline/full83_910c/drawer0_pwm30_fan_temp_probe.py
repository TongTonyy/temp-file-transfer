#!/usr/bin/env python3
"""Temporary drawer0 PWM30 fan/RPM/NPU-temperature probe for 910C.

This script intentionally avoids the full83 collector/profiler pipeline.  It
keeps the formal timing shape, launches the existing 4-card training workload,
and records only the signals needed to understand fan level/RPM and NPU
temperature curves.
"""

from __future__ import annotations

import argparse
import base64
import csv
import json
import os
import re
import signal
import ssl
import subprocess
import sys
import time
import urllib.error
import urllib.request
from collections.abc import Mapping, Sequence
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import yaml

from hgnn_collect.collectors.npu_smi import parse_npu_summary
from hgnn_collect.daemon.ipmc_fan_backend import (
    ALL_FAN_IDS,
    DRAWER_TOPOLOGY,
    FanMode,
    SshIpmcConfig,
    SshIpmcTransport,
)


DRAWER_BY_FAN_ID = {
    fan_id: drawer
    for drawer, topology in DRAWER_TOPOLOGY.items()
    for fan_id in topology.fan_ids
}
DRAWER0_FAN_IDS = tuple(DRAWER_TOPOLOGY["drawer0"].fan_ids)
ACTIVE_TRAINING_NPU_IDS = set(range(8))
DRAWER0_ACTIVE_NPU_IDS = {4, 5, 6, 7}
DRAWER2_ACTIVE_NPU_IDS = {0, 1, 2, 3}
DRAWER_BY_NPU_ID = {
    **{npu_id: "drawer2" for npu_id in (0, 1, 2, 3, 8, 9, 10, 11)},
    **{npu_id: "drawer0" for npu_id in (4, 5, 6, 7, 12, 13, 14, 15)},
}

FAN_FIELDS = (
    "ts_utc",
    "elapsed_s",
    "phase",
    "fan_id",
    "drawer",
    "manual_level_pct",
    "actual_level_pct",
    "redfish_rpm",
    "redfish_pwm_pct",
    "redfish_name",
    "status",
)
NPU_FIELDS = (
    "ts_utc",
    "elapsed_s",
    "phase",
    "logical_npu_id",
    "card_id",
    "chip_id",
    "drawer",
    "active_training",
    "temperature_c",
    "power_w",
    "utilization_pct",
    "health",
    "status",
)


@dataclass
class FanReading:
    fan_id: int
    name: str | None = None
    rpm: float | None = None
    pwm_pct: float | None = None


def utc_now() -> str:
    return time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())


def write_json(path: Path, payload: Mapping[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(
        json.dumps(payload, ensure_ascii=False, sort_keys=True, indent=2) + "\n",
        encoding="utf-8",
    )
    temporary.replace(path)
    os.chmod(path, 0o600)


def append_event(path: Path, event: str, **payload: Any) -> None:
    row = {
        "ts_utc": utc_now(),
        "event": event,
        **payload,
    }
    with path.open("a", encoding="utf-8") as stream:
        stream.write(json.dumps(row, ensure_ascii=False, sort_keys=True) + "\n")


def load_credentials(path: Path) -> dict[str, str]:
    env: dict[str, str] = {}
    if not path.is_file():
        raise FileNotFoundError(f"credentials env file is missing: {path}")
    for raw in path.read_text(encoding="utf-8").splitlines():
        line = raw.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        if line.startswith("export "):
            line = line[len("export ") :].strip()
        key, value = line.split("=", 1)
        key = key.strip()
        value = value.strip().strip("'\"")
        if key:
            env[key] = value
    os.environ.update(env)
    if not os.environ.get("HGNN_IPMC_PASSWORD") and os.environ.get("HGNN_BMC_PASSWORD"):
        os.environ["HGNN_IPMC_PASSWORD"] = os.environ["HGNN_BMC_PASSWORD"]
    return env


def build_ipmc_transport(site_config: Path) -> SshIpmcTransport:
    payload = yaml.safe_load(site_config.read_text(encoding="utf-8"))
    ssh = payload["ipmc_ssh"]
    identity_file = ssh.get("identity_file")
    config = SshIpmcConfig(
        host=str(ssh["host"]),
        port=int(ssh.get("port", 22)),
        username=str(ssh["username"]),
        known_hosts_path=Path(str(ssh["known_hosts_path"])),
        expected_host_key_sha256=str(ssh["expected_host_key_sha256"]),
        identity_file=Path(str(identity_file)) if identity_file else None,
        password_env=str(ssh.get("password_env") or "HGNN_IPMC_PASSWORD"),
        connect_timeout_s=int(ssh.get("connect_timeout_s", 5)),
        command_timeout_s=int(ssh.get("command_timeout_s", 10)),
    )
    return SshIpmcTransport(config)


def number(value: Any) -> float | None:
    if isinstance(value, bool) or value is None:
        return None
    if isinstance(value, (int, float)):
        return float(value)
    match = re.search(r"-?\d+(?:\.\d+)?", str(value))
    return float(match.group(0)) if match else None


def fan_id_from_payload(item: Mapping[str, Any], fallback_id: int) -> int:
    candidates = [
        item.get("Name"),
        item.get("FanName"),
        item.get("MemberId"),
        item.get("@odata.id"),
        item.get("PhysicalContext"),
    ]
    for candidate in candidates:
        if candidate is None:
            continue
        match = re.search(r"\bfan\D*([0-9]{1,2})\b", str(candidate), re.IGNORECASE)
        if match:
            fan_id = int(match.group(1))
            if fan_id in ALL_FAN_IDS:
                return fan_id
    return fallback_id


def fan_rpm(item: Mapping[str, Any]) -> float | None:
    value = number(item.get("ReadingRPM"))
    if value is not None:
        return value
    units = str(item.get("ReadingUnits") or "").casefold()
    if "rpm" in units:
        return number(item.get("Reading"))
    return None


def fan_pwm(item: Mapping[str, Any]) -> float | None:
    for key in ("SpeedPercent", "PwmPercent", "PWM", "SpeedRatio"):
        value = number(item.get(key))
        if value is not None:
            return value
    oem = item.get("Oem")
    if isinstance(oem, Mapping):
        for vendor_payload in oem.values():
            if not isinstance(vendor_payload, Mapping):
                continue
            for key in ("SpeedPercent", "PwmPercent", "PWM", "SpeedRatio"):
                value = number(vendor_payload.get(key))
                if value is not None:
                    return value
    return None


def fetch_redfish_fans(endpoint: str, username: str, password: str, path: str) -> dict[int, FanReading]:
    url = endpoint.rstrip("/") + path
    token = base64.b64encode(f"{username}:{password}".encode("utf-8")).decode("ascii")
    request = urllib.request.Request(
        url,
        headers={
            "Accept": "application/json",
            "Authorization": f"Basic {token}",
            "User-Agent": "hgnn-temp-fan-probe/1",
        },
        method="GET",
    )
    with urllib.request.urlopen(
        request,
        timeout=8,
        context=ssl._create_unverified_context(),
    ) as response:
        payload = json.loads(response.read(4 * 1024 * 1024).decode("utf-8"))
    fans = payload.get("Fans")
    if not isinstance(fans, Sequence) or isinstance(fans, (str, bytes)):
        return {}
    readings: dict[int, FanReading] = {}
    fallback_id = 1
    for item in fans:
        if not isinstance(item, Mapping):
            continue
        fan_id = fan_id_from_payload(item, fallback_id)
        fallback_id += 1
        if fan_id not in ALL_FAN_IDS:
            continue
        readings[fan_id] = FanReading(
            fan_id=fan_id,
            name=str(item.get("Name") or item.get("MemberId") or f"Fan{fan_id}"),
            rpm=fan_rpm(item),
            pwm_pct=fan_pwm(item),
        )
    return readings


def parse_level_section(text: str) -> tuple[dict[int, int], dict[int, int], str]:
    manual: dict[int, int] = {}
    actual: dict[int, int] = {}
    mode = ""
    section: str | None = None
    clean = text.replace("\r", "")
    mode_match = re.search(r"current\s+fan\s+mode\s*:\s*(auto|manual)", clean, re.IGNORECASE)
    if not mode_match:
        mode_match = re.search(r"current\s+mode\s*:\s*(auto|manual)", clean, re.IGNORECASE)
    if mode_match:
        mode = mode_match.group(1).lower()
    for raw in clean.splitlines():
        line = raw.strip()
        if re.match(r"manual\s+fan\s+level\s*:", line, re.IGNORECASE):
            section = "manual"
            continue
        if re.match(r"actual\s+fan\s+level\s*:", line, re.IGNORECASE):
            section = "actual"
            continue
        if section not in {"manual", "actual"}:
            continue
        for fan, level in re.findall(r"Fan\s*([0-9]{1,2})\s*:\s*([0-9]{1,3})", line, re.IGNORECASE):
            fan_id = int(fan)
            if fan_id not in ALL_FAN_IDS:
                continue
            target = manual if section == "manual" else actual
            target[fan_id] = int(level)
    return manual, actual, mode


def read_cooling_levels(transport: SshIpmcTransport) -> tuple[dict[int, int], dict[int, int], str]:
    output = transport._execute(("ipmcget", "-d", "coolingdeviceinfo", "-v", "fan"))
    return parse_level_section(output)


def read_npu_rows() -> list[dict[str, Any]]:
    completed = subprocess.run(
        ["npu-smi", "info"],
        stdin=subprocess.DEVNULL,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
        timeout=8,
        check=False,
    )
    if completed.returncode != 0:
        raise RuntimeError("npu-smi info failed: " + completed.stderr[-500:])
    rows = []
    for summary in parse_npu_summary(completed.stdout):
        npu_id = int(summary.device_id)
        rows.append(
            {
                "logical_npu_id": npu_id,
                "card_id": int(summary.card_id),
                "chip_id": int(summary.chip_id),
                "drawer": DRAWER_BY_NPU_ID.get(npu_id, "unknown"),
                "active_training": npu_id in ACTIVE_TRAINING_NPU_IDS,
                "temperature_c": float(summary.temperature_c),
                "power_w": float(summary.power_w),
                "utilization_pct": float(summary.aicore_pct),
                "health": str(summary.health),
            }
        )
    return rows


def phase_for_elapsed(elapsed: float, baseline_s: float, release_at_s: float, duration_s: float) -> str:
    if elapsed < 0:
        return "startup"
    if elapsed < baseline_s:
        return "baseline_auto_pwm80"
    if elapsed < release_at_s:
        return "drawer0_target_pwm_manual_hold"
    if elapsed < duration_s:
        return "recovery_auto"
    return "complete"


def open_csv(path: Path, fields: Sequence[str]) -> tuple[Any, csv.DictWriter]:
    stream = path.open("w", encoding="utf-8", newline="", buffering=1)
    writer = csv.DictWriter(stream, fieldnames=list(fields))
    writer.writeheader()
    return stream, writer


def terminate_process(process: subprocess.Popen[str], events: Path) -> None:
    if process.poll() is not None:
        return
    append_event(events, "training_terminate", pid=process.pid)
    try:
        os.killpg(process.pid, signal.SIGTERM)
    except ProcessLookupError:
        return
    try:
        process.wait(timeout=30)
        return
    except subprocess.TimeoutExpired:
        append_event(events, "training_kill", pid=process.pid)
        os.killpg(process.pid, signal.SIGKILL)
        process.wait(timeout=10)


def set_all_fans(transport: SshIpmcTransport, level: int, events: Path) -> None:
    for fan_id in ALL_FAN_IDS:
        transport.set_level(fan_id, level)
    append_event(events, "set_all_fans", level=level)


def set_target_fans(transport: SshIpmcTransport, fan_ids: Sequence[int], level: int, events: Path) -> None:
    for fan_id in fan_ids:
        transport.set_level(int(fan_id), level)
    append_event(events, "set_target_fans", fan_ids=list(fan_ids), level=level)


def wait_for_training_ready(marker: Path, process: subprocess.Popen[str], timeout_s: float, events: Path) -> None:
    deadline = time.monotonic() + timeout_s
    while time.monotonic() < deadline:
        if marker.is_file():
            append_event(events, "training_ready", marker=str(marker))
            return
        rc = process.poll()
        if rc is not None:
            raise RuntimeError(f"training exited before ready marker, rc={rc}")
        time.sleep(1.0)
    raise TimeoutError(f"training ready marker was not created within {timeout_s:.0f}s")


def build_summary(output_dir: Path, started_utc: str, completed_utc: str, status: str) -> dict[str, Any]:
    fan_csv = output_dir / "fan_timeseries.csv"
    npu_csv = output_dir / "npu_temperature_timeseries.csv"
    summary: dict[str, Any] = {
        "schema_version": "1.0",
        "status": status,
        "started_utc": started_utc,
        "completed_utc": completed_utc,
        "outputs": {
            "fan_timeseries_csv": str(fan_csv),
            "fan_timeseries_jsonl": str(output_dir / "fan_timeseries.jsonl"),
            "npu_temperature_timeseries_csv": str(npu_csv),
            "npu_temperature_timeseries_jsonl": str(output_dir / "npu_temperature_timeseries.jsonl"),
            "events_jsonl": str(output_dir / "events.jsonl"),
        },
        "fan_rows": 0,
        "npu_rows": 0,
        "fan_rpm_by_drawer": {},
        "npu_temp_by_drawer": {},
    }
    if fan_csv.is_file():
        fan_values: dict[str, list[float]] = {}
        with fan_csv.open(encoding="utf-8", newline="") as stream:
            for row in csv.DictReader(stream):
                summary["fan_rows"] += 1
                if row.get("redfish_rpm"):
                    fan_values.setdefault(row.get("drawer") or "unknown", []).append(float(row["redfish_rpm"]))
        summary["fan_rpm_by_drawer"] = {
            drawer: {"min": min(values), "mean": sum(values) / len(values), "max": max(values)}
            for drawer, values in fan_values.items()
            if values
        }
    if npu_csv.is_file():
        temp_values: dict[str, list[float]] = {}
        with npu_csv.open(encoding="utf-8", newline="") as stream:
            for row in csv.DictReader(stream):
                summary["npu_rows"] += 1
                if row.get("temperature_c"):
                    key = "%s_%s" % (
                        row.get("drawer") or "unknown",
                        "active" if row.get("active_training") == "True" else "idle",
                    )
                    temp_values.setdefault(key, []).append(float(row["temperature_c"]))
        summary["npu_temp_by_drawer"] = {
            drawer: {"min": min(values), "mean": sum(values) / len(values), "max": max(values)}
            for drawer, values in temp_values.items()
            if values
        }
    return summary


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", type=Path, required=True)
    parser.add_argument("--run-id", required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--site-config", type=Path, required=True)
    parser.add_argument("--credentials-env-file", type=Path, required=True)
    parser.add_argument("--training-cmd", type=Path, required=True)
    parser.add_argument("--duration-s", type=float, default=600.0)
    parser.add_argument("--baseline-s", type=float, default=120.0)
    parser.add_argument("--release-at-s", type=float, default=420.0)
    parser.add_argument("--sample-interval-s", type=float, default=2.0)
    parser.add_argument("--manual-timeout-s", type=int, default=700)
    parser.add_argument("--baseline-pwm", type=int, default=80)
    parser.add_argument("--target-pwm", type=int, default=20)
    parser.add_argument("--boost-pwm", type=int, default=95)
    parser.add_argument("--npu-hard-stop-c", type=float, default=75.0)
    parser.add_argument("--training-ready-timeout-s", type=float, default=600.0)
    parser.add_argument("--thermal-path", default="/redfish/v1/Chassis/1/Thermal")
    args = parser.parse_args()

    if args.baseline_s <= 0 or args.release_at_s <= args.baseline_s or args.duration_s <= args.release_at_s:
        raise SystemExit("duration must satisfy 0 < baseline < release_at < duration")
    if args.sample_interval_s <= 0:
        raise SystemExit("sample interval must be positive")

    output_dir = args.output_dir.resolve(strict=False)
    output_dir.mkdir(parents=True, exist_ok=True)
    events = output_dir / "events.jsonl"
    started_utc = utc_now()
    append_event(
        events,
        "probe_start",
        run_id=args.run_id,
        drawer0_fan_ids=list(DRAWER0_FAN_IDS),
        active_training_npu_ids=sorted(ACTIVE_TRAINING_NPU_IDS),
        baseline_s=args.baseline_s,
        release_at_s=args.release_at_s,
        duration_s=args.duration_s,
        sample_interval_s=args.sample_interval_s,
    )

    load_credentials(args.credentials_env_file)
    bmc_endpoint = os.environ.get("HGNN_BMC_ENDPOINT", "").strip()
    bmc_username = os.environ.get("HGNN_BMC_USERNAME", "").strip()
    bmc_password = os.environ.get("HGNN_BMC_PASSWORD", "").strip()
    if not (bmc_endpoint and bmc_username and bmc_password):
        raise SystemExit("HGNN_BMC_ENDPOINT/HGNN_BMC_USERNAME/HGNN_BMC_PASSWORD are required")

    env = os.environ.copy()
    env["HGNN_RUN_ID"] = args.run_id
    env.setdefault("HGNN_NPUS_PER_NODE", "8")
    env.setdefault("HGNN_TP", "4")
    env.setdefault("HGNN_PP", "2")
    env.setdefault("HGNN_ASCEND_RT_VISIBLE_DEVICES", "0,1,2,3,4,5,6,7")
    env.setdefault("HGNN_EXPECTED_NPU_IDS", "0,1,2,3,4,5,6,7")
    env.setdefault("HGNN_EXPECTED_PROFILE_RANKS", "8")
    env.setdefault("HGNN_TORCH_NPU_AIC_METRIC", "ResourceConflictRatio")
    env.setdefault(
        "HGNN_TORCH_NPU_PROFILE_DIR",
        str(args.root / "runtime" / "profiles" / args.run_id),
    )
    env.setdefault(
        "HGNN_PROFILE_CONTROL_PATH",
        str(args.root / "runtime" / "manifests" / args.run_id / "profile_control.json"),
    )
    env.setdefault(
        "HGNN_TRAINING_READY_MARKER",
        str(args.root / "runtime" / "manifests" / args.run_id / "training_ready.json"),
    )
    Path(env["HGNN_TORCH_NPU_PROFILE_DIR"]).mkdir(parents=True, exist_ok=True)
    Path(env["HGNN_PROFILE_CONTROL_PATH"]).parent.mkdir(parents=True, exist_ok=True)
    Path(env["HGNN_TRAINING_READY_MARKER"]).parent.mkdir(parents=True, exist_ok=True)
    Path(env["HGNN_PROFILE_CONTROL_PATH"]).write_text(
        json.dumps(
            {
                "enabled": True,
                "run_id": args.run_id,
                "policy": "temporary_fan_temp_probe",
                "created_utc": started_utc,
            },
            ensure_ascii=False,
        )
        + "\n",
        encoding="utf-8",
    )
    try:
        Path(env["HGNN_TRAINING_READY_MARKER"]).unlink()
    except FileNotFoundError:
        pass

    fan_stream, fan_writer = open_csv(output_dir / "fan_timeseries.csv", FAN_FIELDS)
    npu_stream, npu_writer = open_csv(output_dir / "npu_temperature_timeseries.csv", NPU_FIELDS)
    fan_jsonl = (output_dir / "fan_timeseries.jsonl").open("w", encoding="utf-8", buffering=1)
    npu_jsonl = (output_dir / "npu_temperature_timeseries.jsonl").open("w", encoding="utf-8", buffering=1)

    status = "failed"
    training: subprocess.Popen[str] | None = None
    training_log_stream: Any | None = None
    transport: SshIpmcTransport | None = None
    phase_started = False
    t0 = 0.0
    manual_applied = False
    auto_released = False

    try:
        transport = build_ipmc_transport(args.site_config)
        faninfo = transport.read_faninfo()
        append_event(
            events,
            "precheck_faninfo",
            mode=str(faninfo.mode.value),
            timeout_s=faninfo.timeout_s,
            levels=dict(faninfo.levels),
        )
        if faninfo.mode is not FanMode.AUTO:
            raise RuntimeError("precheck requires fan mode auto")

        training_log = output_dir / "training.log"
        append_event(events, "training_start", command=str(args.training_cmd), log=str(training_log))
        training_log_stream = training_log.open("w", encoding="utf-8", buffering=1)
        training = subprocess.Popen(
            ["bash", str(args.training_cmd)],
            cwd=str(args.root),
            env=env,
            stdout=training_log_stream,
            stderr=subprocess.STDOUT,
            text=True,
            start_new_session=True,
        )

        wait_for_training_ready(
            Path(env["HGNN_TRAINING_READY_MARKER"]),
            training,
            args.training_ready_timeout_s,
            events,
        )
        t0 = time.monotonic()
        phase_started = True
        next_sample = time.monotonic()

        while True:
            now = time.monotonic()
            elapsed = now - t0
            if elapsed >= args.duration_s:
                break
            if training.poll() is not None:
                raise RuntimeError(f"training exited during probe, rc={training.returncode}")

            if not manual_applied and elapsed >= args.baseline_s:
                append_event(events, "intervention_start")
                transport.set_manual(args.manual_timeout_s)
                append_event(events, "set_manual", timeout_s=args.manual_timeout_s)
                set_all_fans(transport, args.boost_pwm, events)
                set_all_fans(transport, args.baseline_pwm, events)
                set_target_fans(transport, DRAWER0_FAN_IDS, args.target_pwm, events)
                manual_applied = True

            if not auto_released and elapsed >= args.release_at_s:
                append_event(events, "release_start")
                transport.set_auto()
                append_event(events, "set_auto")
                auto_released = True

            if now < next_sample:
                time.sleep(min(0.2, next_sample - now))
                continue
            next_sample = now + args.sample_interval_s
            phase = phase_for_elapsed(elapsed, args.baseline_s, args.release_at_s, args.duration_s)
            ts = utc_now()

            manual_levels: dict[int, int] = {}
            actual_levels: dict[int, int] = {}
            level_status = "ok"
            try:
                manual_levels, actual_levels, mode = read_cooling_levels(transport)
                if mode:
                    level_status = "ok:" + mode
            except Exception as error:  # noqa: BLE001 - diagnostics must keep sampling.
                level_status = f"ipmc_error:{type(error).__name__}:{error}"
                append_event(events, "coolingdeviceinfo_error", error=level_status)

            redfish_fans: dict[int, FanReading] = {}
            redfish_status = "ok"
            try:
                redfish_fans = fetch_redfish_fans(
                    bmc_endpoint,
                    bmc_username,
                    bmc_password,
                    args.thermal_path,
                )
            except (urllib.error.URLError, TimeoutError, OSError, json.JSONDecodeError) as error:
                redfish_status = f"redfish_error:{type(error).__name__}:{error}"
                append_event(events, "redfish_error", error=redfish_status)

            for fan_id in ALL_FAN_IDS:
                reading = redfish_fans.get(fan_id, FanReading(fan_id=fan_id))
                row = {
                    "ts_utc": ts,
                    "elapsed_s": round(elapsed, 3),
                    "phase": phase,
                    "fan_id": fan_id,
                    "drawer": DRAWER_BY_FAN_ID.get(fan_id, "unknown"),
                    "manual_level_pct": manual_levels.get(fan_id),
                    "actual_level_pct": actual_levels.get(fan_id),
                    "redfish_rpm": reading.rpm,
                    "redfish_pwm_pct": reading.pwm_pct,
                    "redfish_name": reading.name,
                    "status": f"{level_status};{redfish_status}",
                }
                fan_writer.writerow(row)
                fan_jsonl.write(json.dumps(row, ensure_ascii=False, sort_keys=True) + "\n")

            npu_status = "ok"
            try:
                npu_rows = read_npu_rows()
            except Exception as error:  # noqa: BLE001
                npu_status = f"npu_smi_error:{type(error).__name__}:{error}"
                npu_rows = []
                append_event(events, "npu_smi_error", error=npu_status)
            for row_base in npu_rows:
                if (
                    row_base["active_training"]
                    and row_base["temperature_c"] >= args.npu_hard_stop_c
                ):
                    raise RuntimeError(
                        "NPU temperature hard stop reached: "
                        f"npu={row_base['logical_npu_id']} temp={row_base['temperature_c']}"
                    )
                row = {
                    "ts_utc": ts,
                    "elapsed_s": round(elapsed, 3),
                    "phase": phase,
                    **row_base,
                    "status": npu_status,
                }
                npu_writer.writerow(row)
                npu_jsonl.write(json.dumps(row, ensure_ascii=False, sort_keys=True) + "\n")

        status = "completed"
        append_event(events, "probe_complete")
        return 0
    except KeyboardInterrupt:
        status = "interrupted"
        append_event(events, "probe_interrupted")
        return 130
    except Exception as error:  # noqa: BLE001 - always try explicit auto release below.
        append_event(events, "probe_failed", error=f"{type(error).__name__}: {error}")
        print(f"PROBE_FAILED {type(error).__name__}: {error}", file=sys.stderr)
        return 1
    finally:
        try:
            if transport is not None:
                transport.set_auto()
                append_event(events, "final_set_auto")
        except Exception as error:  # noqa: BLE001
            append_event(events, "final_set_auto_failed", error=f"{type(error).__name__}: {error}")
        if training is not None:
            try:
                terminate_process(training, events)
            except Exception as error:  # noqa: BLE001
                append_event(events, "training_terminate_failed", error=f"{type(error).__name__}: {error}")
        if transport is not None:
            transport.close()
        try:
            fan_stream.close()
            npu_stream.close()
            fan_jsonl.close()
            npu_jsonl.close()
            if training_log_stream is not None:
                training_log_stream.close()
        except Exception:
            pass
        completed_utc = utc_now()
        summary = build_summary(output_dir, started_utc, completed_utc, status)
        summary.update(
            {
                "phase_started": phase_started,
                "manual_applied": manual_applied,
                "auto_released": auto_released,
                "relative_t0_monotonic_s": t0 if phase_started else None,
                "drawer0_fan_ids": list(DRAWER0_FAN_IDS),
                "active_drawer0_npu_ids": sorted(DRAWER0_ACTIVE_NPU_IDS),
                "active_drawer2_npu_ids": sorted(DRAWER2_ACTIVE_NPU_IDS),
            }
        )
        write_json(output_dir / "summary.json", summary)
        print(f"TEMP_PROBE_OUTPUT={output_dir}")
        print(f"TEMP_PROBE_SUMMARY={output_dir / 'summary.json'}")


if __name__ == "__main__":
    raise SystemExit(main())
