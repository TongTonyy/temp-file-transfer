#!/usr/bin/env bash
set -Eeuo pipefail
umask 077

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd -P)"
REPO_ROOT="$(cd "$SCRIPT_DIR/../../.." && pwd -P)"
PACKAGE_NAME="hgnn_f01_qwen3_campaign_v0.3.4"

if [[ -n "${HGNN_ROOT:-}" ]]; then
  ROOT="$HGNN_ROOT"
elif [[ -d "$REPO_ROOT/campaigns/$PACKAGE_NAME/workload" ]]; then
  ROOT="$REPO_ROOT/campaigns/$PACKAGE_NAME"
elif [[ -d "$PWD/workload" && -d "$PWD/app" ]]; then
  ROOT="$(pwd -P)"
else
  ROOT="/root/hgnn_910c_readiness/$PACKAGE_NAME"
fi

export HGNN_CAMPAIGN_ROOT_OVERRIDE="$ROOT"
cd "$ROOT"

# shellcheck disable=SC1091
. "$ROOT/workload/common.sh"
campaign_init

RUN_ID="${HGNN_TEMP_PROBE_RUN_ID:-$(date -u +%Y%m%dT%H%M%SZ)-drawer0-pwm20-fan-temp-probe}"
OUTPUT_DIR="$RUNTIME/outputs/temp_probe/$RUN_ID"
mkdir -p "$OUTPUT_DIR"

export HGNN_RUN_ID="$RUN_ID"
export HGNN_NPUS_PER_NODE="${HGNN_NPUS_PER_NODE:-8}"
export HGNN_TP="${HGNN_TP:-4}"
export HGNN_PP="${HGNN_PP:-2}"
export HGNN_ASCEND_RT_VISIBLE_DEVICES="${HGNN_ASCEND_RT_VISIBLE_DEVICES:-0,1,2,3,4,5,6,7}"
export HGNN_EXPECTED_NPU_IDS="${HGNN_EXPECTED_NPU_IDS:-0,1,2,3,4,5,6,7}"
export HGNN_EXPECTED_PROFILE_RANKS="${HGNN_EXPECTED_PROFILE_RANKS:-8}"
export HGNN_TORCH_NPU_AIC_METRIC="${HGNN_TORCH_NPU_AIC_METRIC:-ResourceConflictRatio}"
export HGNN_TORCH_NPU_PROFILE_DIR="$RUNTIME/profiles/$RUN_ID"
export HGNN_PROFILE_CONTROL_PATH="$RUNTIME/manifests/$RUN_ID/profile_control.json"
export HGNN_TRAINING_READY_MARKER="$RUNTIME/manifests/$RUN_ID/training_ready.json"

SITE_CONFIG="${HGNN_SITE_CONFIG_OVERRIDE:-$ROOT/config/site.drawer0.local.yaml}"
if [[ ! -f "$SITE_CONFIG" ]]; then
  echo "缺少 site 配置: $SITE_CONFIG" >&2
  exit 2
fi

PYTHON_SCRIPT="$SCRIPT_DIR/drawer0_pwm30_fan_temp_probe.py"
if [[ ! -f "$PYTHON_SCRIPT" ]]; then
  PYTHON_SCRIPT="$ROOT/tools/offline/full83_910c/drawer0_pwm30_fan_temp_probe.py"
fi
if [[ ! -f "$PYTHON_SCRIPT" ]]; then
  echo "缺少临时 probe Python 脚本: $PYTHON_SCRIPT" >&2
  exit 2
fi

echo "TEMP_PROBE_RUN_ID=$RUN_ID"
echo "TEMP_PROBE_OUTPUT_DIR=$OUTPUT_DIR"
echo "TEMP_PROBE_SITE_CONFIG=$SITE_CONFIG"
echo "TEMP_PROBE_DRAWER0_FANS=1,2,3,4,13"
echo "TEMP_PROBE_DRAWER0_TARGET_PWM=${HGNN_TEMP_PROBE_TARGET_PWM:-20}"
echo "TEMP_PROBE_ACTIVE_DRAWER2_NPUS=0,1,2,3"
echo "TEMP_PROBE_ACTIVE_DRAWER0_NPUS=4,5,6,7"
echo "TEMP_PROBE_TIMING baseline=${HGNN_TEMP_PROBE_BASELINE_S:-120} release_at=${HGNN_TEMP_PROBE_RELEASE_AT_S:-420} duration=${HGNN_TEMP_PROBE_DURATION_S:-600} sample_interval=${HGNN_TEMP_PROBE_SAMPLE_INTERVAL_S:-2}"

exec "$HGNN_PYTHON" "$PYTHON_SCRIPT" \
  --root "$ROOT" \
  --run-id "$RUN_ID" \
  --output-dir "$OUTPUT_DIR" \
  --site-config "$SITE_CONFIG" \
  --credentials-env-file "$CREDENTIALS" \
  --training-cmd "$ROOT/workload/launch_training.sh" \
  --baseline-s "${HGNN_TEMP_PROBE_BASELINE_S:-120}" \
  --release-at-s "${HGNN_TEMP_PROBE_RELEASE_AT_S:-420}" \
  --duration-s "${HGNN_TEMP_PROBE_DURATION_S:-600}" \
  --sample-interval-s "${HGNN_TEMP_PROBE_SAMPLE_INTERVAL_S:-2}" \
  --manual-timeout-s "${HGNN_TEMP_PROBE_MANUAL_TIMEOUT_S:-700}" \
  --baseline-pwm "${HGNN_TEMP_PROBE_BASELINE_PWM:-80}" \
  --target-pwm "${HGNN_TEMP_PROBE_TARGET_PWM:-20}" \
  --boost-pwm "${HGNN_TEMP_PROBE_BOOST_PWM:-95}" \
  --npu-hard-stop-c "${HGNN_TEMP_PROBE_NPU_HARD_STOP_C:-75}"
