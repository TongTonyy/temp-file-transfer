#!/usr/bin/env bash
set -Eeuo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd -P)"
export HGNN_TEMP_PROBE_TARGET_PWM="${HGNN_TEMP_PROBE_TARGET_PWM:-20}"
exec bash "$SCRIPT_DIR/run_drawer0_pwm30_fan_temp_probe_910c.sh" "$@"
