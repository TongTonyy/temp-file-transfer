#!/bin/bash
# P1 plan Step 1: formal collection of F2 + F4 (25 steps each, plog on).
# Precondition: Step 0 gate = pass/conditional (decided on the local machine).
# No on-site parsing. Output: p1_f2_f4_raw.tar.gz
set -u
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"

bash "$SCRIPT_DIR/collect_env_info.sh" "$SCRIPT_DIR/env_info_step1.txt"

ONLY=F2,F4 bash "$SCRIPT_DIR/run_p0b_anchors.sh"

STAGE="$SCRIPT_DIR/p1_f2_f4_raw"
rm -rf "$STAGE"
for name in F2 F4; do
  D="$SCRIPT_DIR/results_p0b_anchors/$name"
  mkdir -p "$STAGE/$name"
  [ -d "$D/plog" ] && cp -r "$D/plog" "$STAGE/$name/plog"
  for f in step_time.csv power_mem.csv real_tokens.csv token_scope_check.json validate_report.json; do
    cp "$D/$f" "$STAGE/$name/$f" 2>/dev/null || true
  done
  cp "$D/train.log" "$STAGE/$name/train_stdout.log" 2>/dev/null || true
done
cp "$SCRIPT_DIR/env_info_step1.txt" "$STAGE/env_info.txt"
cat > "$STAGE/README.md" <<EOF
# P1 Step 1 raw package: F2 + F4
- F2: pp=4 tp=2 dp=2 mb=1 sp=1 z=0
- F4: pp=2 tp=2 dp=4 mb=1 sp=1 z=3
- TRAIN_ITERS=${TRAIN_ITERS:-25}; plog env per configs/lineA_anchors.json
- collected: $(date '+%F %T')
EOF
tar czf "$SCRIPT_DIR/p1_f2_f4_raw.tar.gz" -C "$SCRIPT_DIR" p1_f2_f4_raw
echo "[step1] packed $SCRIPT_DIR/p1_f2_f4_raw.tar.gz ($(du -h "$SCRIPT_DIR/p1_f2_f4_raw.tar.gz" | cut -f1))"
