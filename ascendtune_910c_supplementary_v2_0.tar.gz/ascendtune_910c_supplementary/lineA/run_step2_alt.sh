#!/bin/bash
# P1 plan Step 2: supplementary collection F1-alt + F3-alt (PP=1 boundary,
# TP=4/TP=8 coverage). No on-site parsing. Output: p1_f1alt_f3alt_raw.tar.gz
set -u
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"

bash "$SCRIPT_DIR/collect_env_info.sh" "$SCRIPT_DIR/env_info_step2.txt"

ONLY=F1-alt,F3-alt bash "$SCRIPT_DIR/run_p0b_anchors.sh"

STAGE="$SCRIPT_DIR/p1_f1alt_f3alt_raw"
rm -rf "$STAGE"
for name in F1-alt F3-alt; do
  D="$SCRIPT_DIR/results_p0b_anchors/$name"
  mkdir -p "$STAGE/$name"
  [ -d "$D/plog" ] && cp -r "$D/plog" "$STAGE/$name/plog"
  for f in step_time.csv power_mem.csv real_tokens.csv token_scope_check.json validate_report.json; do
    cp "$D/$f" "$STAGE/$name/$f" 2>/dev/null || true
  done
  cp "$D/train.log" "$STAGE/$name/train_stdout.log" 2>/dev/null || true
done
cat > "$STAGE/README.md" <<EOF
# P1 Step 2 raw package: F1-alt + F3-alt
- F1-alt: pp=1 tp=4 dp=4 mb=2 sp=0 z=0 (PP=1 boundary + TP=4 + SP=0)
- F3-alt: pp=1 tp=8 dp=2 mb=2 sp=1 z=0 (PP=1 boundary + TP=8 + SP=1)
- TRAIN_ITERS=${TRAIN_ITERS:-25}; collected: $(date '+%F %T')
EOF
tar czf "$SCRIPT_DIR/p1_f1alt_f3alt_raw.tar.gz" -C "$SCRIPT_DIR" p1_f1alt_f3alt_raw
echo "[step2] packed $SCRIPT_DIR/p1_f1alt_f3alt_raw.tar.gz ($(du -h "$SCRIPT_DIR/p1_f1alt_f3alt_raw.tar.gz" | cut -f1))"
