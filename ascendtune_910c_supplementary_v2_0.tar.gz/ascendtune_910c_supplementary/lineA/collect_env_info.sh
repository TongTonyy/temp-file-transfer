#!/bin/bash
# Collect environment version info required by the P1 plan (Step 0 report).
set -u
OUT=${1:?usage: bash collect_env_info.sh env_info.txt}
{
  echo "=== date ==="; date '+%F %T %z'
  echo "=== host ==="; hostname; uname -a
  echo "=== CANN version ==="
  cat /usr/local/Ascend/ascend-toolkit/latest/version.cfg 2>/dev/null || echo "(version.cfg not found)"
  echo "=== driver/firmware (npu-smi -v) ==="
  npu-smi -v 2>/dev/null || true
  echo "=== python ==="; which python3; python3 --version
  echo "=== torch / torch_npu ==="
  python3 -c "import torch, torch_npu; print('torch', torch.__version__); print('torch_npu', torch_npu.__version__)" 2>&1
  echo "=== MindSpeed-LLM ==="
  echo "MSLLM_DIR=$MSLLM_DIR"
  git -C "$MSLLM_DIR" rev-parse HEAD 2>/dev/null || echo "(not a git checkout)"
  git -C "$MSLLM_DIR" log -1 --format='%ci %s' 2>/dev/null || true
  echo "=== plog env vars ==="
  echo "HCCL_ENTRY_LOG_ENABLE=${HCCL_ENTRY_LOG_ENABLE:-unset}"
  echo "HCCL_DEBUG_CONFIG=${HCCL_DEBUG_CONFIG:-unset}"
  echo "ASCEND_GLOBAL_LOG_LEVEL=${ASCEND_GLOBAL_LOG_LEVEL:-unset}"
  echo "ASCEND_SLOG_PRINT_TO_STDOUT=${ASCEND_SLOG_PRINT_TO_STDOUT:-unset}"
  echo "=== ascend log dirs (plog actual location) ==="
  find "$HOME/ascend/log" -maxdepth 3 -type d 2>/dev/null || echo "(no $HOME/ascend/log yet)"
  echo "=== disk free ==="; df -h /root "$HOME" 2>/dev/null | sort -u
} > "$OUT" 2>&1
echo "[env_info] wrote $OUT"
