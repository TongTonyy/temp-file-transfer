#!/bin/bash
# P1 plan Step 0: smoke run -- F2 config, 3-5 steps, collect plog and return
# for LOCAL analysis. No on-site parsing. Output: p1_step0_plog_smoke.tar.gz
set -u
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
PKG_DIR="$(cd "$SCRIPT_DIR/.." && pwd)"

export TRAIN_ITERS=${TRAIN_ITERS:-5}
echo "[step0] TRAIN_ITERS=$TRAIN_ITERS, anchor=F2 only"

bash "$SCRIPT_DIR/collect_env_info.sh" "$SCRIPT_DIR/env_info_step0.txt"

# fresh smoke output dir
export OUT_ROOT="$SCRIPT_DIR/results_step0_smoke"
rm -rf "$OUT_ROOT"
ONLY=F2 bash "$SCRIPT_DIR/run_p0b_anchors.sh"

# ---- pack per plan section 2.3: raw files only, no filtering/preprocessing
STAGE="$SCRIPT_DIR/p1_step0_plog_smoke"
rm -rf "$STAGE"
mkdir -p "$STAGE/plog"
D="$OUT_ROOT/F2"
[ -d "$D/plog" ] && cp -r "$D/plog/." "$STAGE/plog/"
cp "$D/train.log" "$STAGE/train_stdout.log" 2>/dev/null || true
cp "$D/step_time.csv" "$STAGE/step_time.csv" 2>/dev/null || true
cp "$SCRIPT_DIR/env_info_step0.txt" "$STAGE/env_info.txt"
cat > "$STAGE/README.md" <<EOF
# P1 Step 0 plog smoke package
- anchor: F2 (pp=4 tp=2 dp=2 mb=1 sp=1 z=0), TRAIN_ITERS=$TRAIN_ITERS
- plog env: HCCL_ENTRY_LOG_ENABLE=1, HCCL_DEBUG_CONFIG=ALG,TASK,RESOURCE,AIV_OPS_EXC, ASCEND_GLOBAL_LOG_LEVEL=1
- plog collected from \$HOME/ascend/log/run (time-window filtered by run start, content unfiltered)
- run status: $(cat "$D/run_status.txt" 2>/dev/null || echo unknown)
- plog file count: $(find "$STAGE/plog" -type f | wc -l)
- collected: $(date '+%F %T')
EOF
tar czf "$SCRIPT_DIR/p1_step0_plog_smoke.tar.gz" -C "$SCRIPT_DIR" p1_step0_plog_smoke
echo "[step0] packed $SCRIPT_DIR/p1_step0_plog_smoke.tar.gz"
echo "[step0] plog files: $(find "$STAGE/plog" -type f | wc -l), total size: $(du -sh "$STAGE/plog" | cut -f1)"
echo "[step0] upload this tarball; field-availability analysis happens locally"
