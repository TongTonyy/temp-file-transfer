# 故障链数据采集进度记录

最后更新：2026-08-31

本文档用于在本机长期记录 910C 故障链数据采集的批次、故障注入对象、强度配置、实际执行情况、失败点和后续续跑位置。后续每次从 910C 拿回新数据或发生中断，都应更新本文档。

## 统一采集设定

- 硬件平台：Ascend 910C 集群。
- 故障类型：F01 cooling-zone degradation，模拟 drawer 散热区域退化。
- control/sham PWM：80。
- fault PWM：75。
- 当前强度等级：`s1`，即 PWM 从 80 降到 75，`pwm_delta_from_control = -5`。
- 每个 run 的采样设计：8 个 sampled profiling segment。
- 每个 run 的采样步数：32 active profiler steps。
- rank 数：16。
- 主要 metric family：`MemoryAccess`、`ResourceConflictRatio`。
- 重要限制：`MemoryAccess` 与 `ResourceConflictRatio` 是不同 run 采集，不应默认视为严格同步多模态特征。
- 风扇遥测限制：当前数据集显式记录了目标受控 fan ids、目标 PWM、control PWM 和 target logical NPU ids；采集流程会在 preflight/verify/hold/release 等阶段读取 `faninfo` 作为安全和回读校验，但还没有把“受控风扇 vs 非受控自动风扇”的连续转速比例曲线整理为标准训练字段。
- 当前 active 故障注入逻辑更接近“全风扇进入手动模式，非目标风扇保持 baseline PWM 80，目标 drawer 风扇降至 PWM 75”，不是“仅目标风扇手动固定，其余风扇保持自动并随负载升速”的实验设计。

## 硬件注入对象

### drawer0_s1

- root cause：`drawer0_cooling_zone`
- fault object type：`cooling_zone_fan_group`
- 注入 drawer：`drawer0`
- target fan ids：`[1, 2, 3, 4, 13]`
- target logical NPU ids：`[4, 5, 6, 7, 12, 13, 14, 15]`
- hardware target id：`drawer0_s1_pwm75_fans_1_2_3_4_13_logical_npus_4_5_6_7_12_13_14_15`

### drawer2_s1

- root cause：`drawer2_cooling_zone`
- fault object type：`cooling_zone_fan_group`
- 注入 drawer：`drawer2`
- target fan ids：`[9, 10, 11, 12, 15]`
- target logical NPU ids：`[0, 1, 2, 3, 8, 9, 10, 11]`
- hardware target id：`drawer2_s1_pwm75_fans_9_10_11_12_15_logical_npus_0_1_2_3_8_9_10_11`

### control/sham

- condition：`manual_baseline_sham`
- root cause：`none`
- fault object type：`no_fault_control`
- 注入 drawer：`none`
- target fan ids：`[]`
- target logical NPU ids：`[]`
- hardware target id：`manual_baseline_sham_pwm80_no_fault`

## 批次 1：r29 / dataset_v1 / 4 group

- campaign id：`20260825T070605Z-r29-sampled-300s`
- 本机数据集：`returns/extracted/sampled_data/dataset_v1_hw_explicit`
- 本机交付包：`returns/extracted/sampled_data/dataset_v1_hw_explicit.tar.gz`
- 状态：已完成并已生成硬件对象显式版。
- group 数：4。
- sample 数：512。
- long metric rows：10205。
- 覆盖硬件对象：`drawer0_s1` 与 `manual_baseline_sham_pwm80_no_fault`。
- 覆盖 group：
  - `control_memory_access`
  - `control_resource_conflict`
  - `fault_memory_access`
  - `fault_resource_conflict`
- 重要记录：最早 4 group 小规模数据中，`MemoryAccess` 采集过程曾出现执行失败并重新采集，导致内存指标与其他指标不是同一个训练任务中的严格同步采集。后续使用时，应把不同 metric family 视为不同 run 条件下的独立观测，不要直接拼接成同一时刻的多模态特征。

## 批次 2：r30 / dataset_v2 / 10 group

- campaign id：`20260827T093257Z-r30-expanded-sampled`
- 本机数据集：`returns/extracted/sampled_data/dataset_v2_hw_explicit`
- 本机交付包：`returns/extracted/sampled_data/dataset_v2_hw_explicit.tar.gz`
- 910C return bundle：`20260827T093257Z-r30-expanded-sampled-r30-expanded-sampled-dataset.tar.gz`
- 状态：已完成并已生成硬件对象显式版。
- group 数：10。
- sample 数：1280。
- long metric rows：25976。
- 总执行时间：`R30_RUN_TOTAL_S=27231.012` 秒，约 7.56 小时。
- 覆盖硬件对象：`drawer0_s1`、`drawer2_s1`、`manual_baseline_sham_pwm80_no_fault`。
- 覆盖 group：
  - `d0_rep2_control_memory_access`
  - `d0_rep2_control_resource_conflict`
  - `d0_rep2_fault_memory_access`
  - `d0_rep2_fault_resource_conflict`
  - `d0_rep3_control_memory_access`
  - `d0_rep3_control_resource_conflict`
  - `d0_rep3_fault_memory_access`
  - `d0_rep3_fault_resource_conflict`
  - `d2_fault_memory_access`
  - `d2_fault_resource_conflict`

## 批次 3：r31 / planned 30 group / 当前 partial 18 group

- campaign id：`20260829T092554Z-r31-balanced-30run`
- 目标：新增 30 group，与已有 r30 10 group 合并后形成 40 group 更平衡数据集。
- 当前状态：计划 30 group，目前成功 18 group，第 19 group 失败后暂停。
- partial 18-run bundle 上传状态：已上传到 GitHub Release `r30-dataset-20260827`。
- partial 18-run bundle URL：`https://github.com/TongTonyy/temp-file-transfer/releases/download/r30-dataset-20260827/20260829T092554Z-r31-balanced-30run-r31-partial-18run-sampled-dataset.tar.gz`
- partial 18-run sha256 URL：`https://github.com/TongTonyy/temp-file-transfer/releases/download/r30-dataset-20260827/20260829T092554Z-r31-balanced-30run-r31-partial-18run-sampled-dataset.tar.gz.sha256`
- partial 18-run bundle size：417294002 bytes，约 398 MiB。
- partial 18-run bundle digest：`sha256:86bbda3959bf2092ba2811a5485c9fba06198e4d0dec933b72cb3efff7c70514`
- partial 18-run 上传时间：2026-08-31 06:37:19 UTC 至 2026-08-31 06:37:51 UTC，约等于 2026-08-31 14:37:19 至 14:37:51 UTC+8。
- 当前 910C 主日志：`/root/hgnn_910c_readiness/hgnn_f01_qwen3_campaign_v0.3.4/runtime/logs/r31_balanced_30run_20260830T134057Z.log`
- 恢复启动时间记录：`R31_STAGE_UTC=20260830T134100Z`，即 2026-08-30 21:41:00 UTC+8。
- 第 19 group：`d2_rep3_control_resource_conflict`
- 第 19 run id：`20260829T092554Z-r31-balanced-30run-d2_rep3_control_resource_conflict-a1`
- 第 19 group 条件：`manual_baseline_sham`
- 第 19 group metric family：`ResourceConflictRatio`
- 第 19 group drawer：`drawer2`
- 第 19 group 失败信息：`formal runner 失败，rc=1；rc=2 也视为批次失败`
- 第 19 group 失败时间：2026-08-31 09:11:58 UTC+8，约等于 2026-08-31 01:11:58 UTC。该时间来自 910C 上 `runtime/logs/r31_balanced_30run_20260830T134057Z.log` 与 failed formal output dir 的最新 mtime。
- 第 19 group profile root 最后写入时间：2026-08-31 09:11:15 UTC+8。
- 第 19 group sample plan 写入时间：2026-08-31 09:02:55 UTC+8。
- 第 19 group 失败日志行号：`R31_GROUP_INDEX=19/30` 在 3470 行，`R31_GROUP_START=d2_rep3_control_resource_conflict` 在 3472 行，`formal runner 失败，rc=1；rc=2 也视为批次失败` 在 3489 行。
- 潜在干扰记录：失败后观察到同事程序 `weekend_phase_campaign.py --phase E005A` 正在使用 NPU 0/1。该外部程序可能影响本轮采集，但仅作为相关性记录，不能仅凭当前日志确认因果。

### r31 当前已完成 group

1. `d0_rep4_control_resource_conflict`
2. `d0_rep4_fault_resource_conflict`
3. `d0_rep4_control_memory_access`
4. `d0_rep4_fault_memory_access`
5. `d0_rep5_control_resource_conflict`
6. `d0_rep5_fault_resource_conflict`
7. `d0_rep5_control_memory_access`
8. `d0_rep5_fault_memory_access`
9. `d0_rep6_control_resource_conflict`
10. `d0_rep6_fault_resource_conflict`
11. `d0_rep6_control_memory_access`
12. `d0_rep6_fault_memory_access`
13. `d2_rep1_control_resource_conflict`
14. `d2_rep1_control_memory_access`
15. `d2_rep2_control_resource_conflict`
16. `d2_rep2_fault_resource_conflict`
17. `d2_rep2_control_memory_access`
18. `d2_rep2_fault_memory_access`

### r31 后续续跑位置

后续继续采集时，应复用同一个 campaign id：

```text
HGNN_R31_CAMPAIGN_ID=20260829T092554Z-r31-balanced-30run
```

预期行为：

- 第 1-18 group：检测为完成并跳过。
- 第 19 group：从 `d2_rep3_control_resource_conflict` 开始重新跑。
- 第 20-30 group：继续顺序执行。

如果希望第 19 group 完整重跑，应先清理第 19 run 的 profile、formal output、manifest、gate 和 runtime/data 残留，再启动续跑。

## 本机待回填项

- r31 第 19 run 的精确失败时间：等待 910C 上通过 `stat`/mtime 命令输出后回填。
- r31 partial 18-run bundle 文件名和 sha256：已于 2026-08-31 回填，见 r31 批次记录。
- r31 后续第 19-30 group 完成情况：等待后续续跑后回填。

## 批次 4：Full-83 时序采集交付包 / 待上传 910C

- 本机交付包：`returns/extracted/sampled_data/full83_910c_collection_delivery_20260831.tar.gz`
- 本机 sha256：`returns/extracted/sampled_data/full83_910c_collection_delivery_20260831.tar.gz.sha256`
- 目标：重新在 910C 上采集 `node_features.yaml` 合同中的完整 83 指标时序数据。
- 重要说明：该方案不从当前 `dataset_v1`/`dataset_v2` 中补挖，而是提供新的 `full83` 测试版和正式版采集入口。
- 测试版默认时长：`duration=60s`、`baseline=12s`、`release_at=42s`，即正式版时长压缩 10 倍。
- 正式版默认时长：`duration=600s`、`baseline=120s`、`release_at=420s`，与既有 v1/v2/r31 的 F01 故障时序保持一致。
- 默认 group 矩阵：沿用 r31 的 30 group 设计，覆盖 drawer0/drawer2、control/fault、`MemoryAccess`/`ResourceConflictRatio`。
- 非中断策略：采集过程中持续输出 83 指标逐项状态；单项指标不可采集只写入 `missing`、`degraded` 或 `unsupported_with_evidence`，不因此中断训练和其它指标采集。
- 输出时序表：`processed/time_series_83.parquet`、`processed/features_long.parquet`、`processed/features_wide.parquet`。
- 输出覆盖报告：`contract/metric_coverage_83.json`。
- 910C 命令文档：`tools/offline/full83_910c/COMMANDS_910C_zh.md`。
