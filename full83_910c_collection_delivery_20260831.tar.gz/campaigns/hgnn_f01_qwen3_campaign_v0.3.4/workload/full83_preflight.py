#!/usr/bin/env python3
"""Non-blocking full-83 capability preflight for Ascend 910C."""

from __future__ import annotations

import argparse
import os
import shutil
import socket
import subprocess
import sys
import time
from pathlib import Path
from typing import Any, Mapping, Sequence

from full83_common import (
    atomic_json,
    load_metric_specs,
    metric_matrix_rows,
    write_csv,
)


def _command_exists(name: str) -> bool:
    return shutil.which(name) is not None


def _path_exists(value: str | None) -> bool:
    return bool(value) and Path(value).expanduser().exists()


def _socket_exists(value: str | None) -> bool:
    return bool(value) and Path(value).expanduser().exists()


def _run_quick(argv: Sequence[str], timeout_s: float = 5.0) -> Mapping[str, Any]:
    try:
        completed = subprocess.run(
            list(argv),
            text=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            timeout=timeout_s,
            check=False,
        )
    except Exception as exc:  # noqa: BLE001 - this is a diagnostic probe.
        return {"ok": False, "error": f"{type(exc).__name__}: {exc}"}
    return {
        "ok": completed.returncode == 0,
        "returncode": completed.returncode,
        "stdout_head": completed.stdout[:500],
        "stderr_head": completed.stderr[:500],
    }


def _probe_dcmi() -> Mapping[str, Any]:
    try:
        from hgnn_collect.collectors.dcmi import probe_dcmi_aicore
    except Exception as exc:  # noqa: BLE001
        return {"available": False, "error": f"import failed: {exc}"}
    try:
        return dict(probe_dcmi_aicore(os.environ.get("HGNN_DCMI_LIBRARY") or None))
    except Exception as exc:  # noqa: BLE001
        return {"available": False, "error": f"{type(exc).__name__}: {exc}"}


def _probe_tcp_endpoint(url: str | None) -> Mapping[str, Any]:
    if not url:
        return {"available": False, "reason": "HGNN_BMC_ENDPOINT is empty"}
    try:
        from urllib.parse import urlsplit

        parsed = urlsplit(url)
        if not parsed.hostname:
            return {"available": False, "reason": "endpoint host missing"}
        port = parsed.port or (443 if parsed.scheme == "https" else 80)
        with socket.create_connection((parsed.hostname, port), timeout=3):
            return {"available": True, "host": parsed.hostname, "port": port}
    except Exception as exc:  # noqa: BLE001
        return {"available": False, "reason": f"{type(exc).__name__}: {exc}"}


def probe_capabilities(root: Path) -> dict[str, Mapping[str, Any]]:
    bmc_env_ok = all(
        os.environ.get(name)
        for name in ("HGNN_BMC_ENDPOINT", "HGNN_BMC_USERNAME", "HGNN_BMC_PASSWORD")
    )
    training_socket = (
        os.environ.get("FULL83_TRAINING_EVENT_SOCKET")
        or os.environ.get("HGNN_TRAINING_EVENT_SOCKET")
    )
    vendor_plugin = (
        os.environ.get("FULL83_VENDOR_METRIC_PLUGIN")
        or os.environ.get("HGNN_VENDOR_METRIC_PLUGIN")
    )
    capabilities: dict[str, Mapping[str, Any]] = {
        "procfs": {
            "available": Path("/proc/stat").is_file()
            and Path("/proc/meminfo").is_file()
            and Path("/proc/diskstats").is_file(),
            "source": "procfs",
        },
        "psi": {
            "available": Path("/proc/pressure/memory").is_file()
            or Path("/proc/pressure/io").is_file(),
            "source": "procfs",
        },
        "cpu_frequency": {
            "available": Path("/sys/devices/system/cpu").is_dir(),
            "source": "sysfs",
        },
        "net_sysfs": {
            "available": Path("/sys/class/net").is_dir(),
            "source": "sysfs",
        },
        "tc_read": {"available": _command_exists("tc"), "source": "tc"},
        "ethtool_stats": {
            "available": _command_exists("ethtool"),
            "source": "ethtool",
        },
        "nic_ddm": {
            "available": _path_exists(os.environ.get("FULL83_ETHTOOL_EEPROM_HELPER")),
            "source": "root_owned_ethtool_eeprom_helper",
            "env": "FULL83_ETHTOOL_EEPROM_HELPER",
        },
        "nic_queue": {
            "available": bool(vendor_plugin),
            "source": "vendor_or_driver_plugin",
        },
        "nic_ber": {
            "available": bool(vendor_plugin),
            "source": "vendor_or_switch_plugin",
        },
        "rdma_counters": {
            "available": Path("/sys/class/infiniband").is_dir() or bool(vendor_plugin),
            "source": "rdma_hw_counters_or_vendor_plugin",
        },
        "npu_summary": {
            "available": _command_exists("npu-smi"),
            "source": "npu-smi",
            "probe": _run_quick(["npu-smi", "info"], timeout_s=8)
            if _command_exists("npu-smi")
            else None,
        },
        "npu_memory": {"available": _command_exists("npu-smi"), "source": "npu-smi"},
        "npu_ecc": {"available": _command_exists("npu-smi"), "source": "npu-smi"},
        "npu_usages": {"available": _command_exists("npu-smi"), "source": "npu-smi"},
        "npu_health": {"available": _command_exists("npu-smi"), "source": "npu-smi"},
        "npu_clock": {"available": False, "source": "dcmi"},
        "npu_throttle": {
            "available": bool(vendor_plugin),
            "source": "dcmi_or_vendor_plugin",
        },
        "npu_runtime_queue": {
            "available": bool(vendor_plugin),
            "source": "torch_npu_or_vendor_plugin",
        },
        "npu_context_switch": {
            "available": bool(vendor_plugin),
            "source": "vendor_plugin",
        },
        "npu_runtime_log": {
            "available": bool(training_socket),
            "source": "training_sidecar_torch_npu_memory_stats",
        },
        "bmc": {
            "available": bmc_env_ok,
            "source": "redfish",
            "endpoint_probe": _probe_tcp_endpoint(os.environ.get("HGNN_BMC_ENDPOINT")),
        },
        "perf": {
            "available": _socket_exists(os.environ.get("FULL83_PERF_SOCKET")),
            "source": "root_owned_perf_exporter",
            "env": "FULL83_PERF_SOCKET",
        },
        "uncore_pmu": {
            "available": _socket_exists(os.environ.get("FULL83_UNCORE_PMU_SOCKET")),
            "source": "root_owned_uncore_pmu_exporter",
            "env": "FULL83_UNCORE_PMU_SOCKET",
        },
        "host_ras": {
            "available": _socket_exists(os.environ.get("FULL83_RAS_SOCKET")),
            "source": "rasdaemon_or_edac_exporter",
            "env": "FULL83_RAS_SOCKET",
        },
        "kernel_log": {
            "available": _socket_exists(os.environ.get("FULL83_JOURNAL_SOCKET")),
            "source": "filtered_kernel_journal_exporter",
            "env": "FULL83_JOURNAL_SOCKET",
        },
        "pcie_aer": {
            "available": Path("/sys/bus/pci/devices").is_dir(),
            "source": "pcie_sysfs",
        },
        "pcie_link": {
            "available": Path("/sys/bus/pci/devices").is_dir(),
            "source": "pcie_sysfs",
        },
        "pcie_temperature": {
            "available": bool(vendor_plugin) or bmc_env_ok,
            "source": "bmc_sensor_map_or_vendor_plugin",
        },
        "pcie_replay": {
            "available": bool(vendor_plugin),
            "source": "vendor_plugin_or_pcie_controller_counter",
        },
        "msprof_aicore": {
            "available": _command_exists("msprof") or _path_exists(os.environ.get("HGNN_MSPROF_PY")),
            "source": "cann_msprof",
        },
        "msprof_hbm": {
            "available": _command_exists("msprof") or _path_exists(os.environ.get("HGNN_MSPROF_PY")),
            "source": "cann_msprof",
        },
        "msprof_hccl": {
            "available": _command_exists("msprof") or _path_exists(os.environ.get("HGNN_MSPROF_PY")),
            "source": "cann_msprof",
        },
        "training_instrumentation": {
            "available": bool(training_socket),
            "source": "training_event_sidecar",
            "env": "FULL83_TRAINING_EVENT_SOCKET",
        },
        "workload": {
            "available": (root / "workload/reference/tune_qwen3_14b_4K_full_ptd.sh").is_file(),
            "source": "training_script",
        },
        "hccl_test": {
            "available": bool(os.environ.get("FULL83_HCCL_TEST_BIN")),
            "source": "hccl_test",
            "env": "FULL83_HCCL_TEST_BIN",
        },
    }
    dcmi = _probe_dcmi()
    capabilities["npu_clock"] = {
        **capabilities["npu_clock"],
        "available": bool(dcmi.get("available")),
        "probe": dcmi,
    }
    return capabilities


def _metric_status(metric: Any, capability: Mapping[str, Any]) -> tuple[str, str]:
    if bool(capability.get("available")):
        if metric.support_status in {"hardware_dependent", "probe_required"}:
            return "collectable", "capability probe is available on this host"
        return "collectable", "capability available"
    if metric.support_action in {"redesign_or_vendor_api", "probe_then_require"}:
        return "unsupported_with_evidence", metric.support_solution
    if metric.support_status in {
        "site_config_required",
        "admin_helper_required",
        "admin_and_hardware_required",
        "training_instrumentation_required",
        "collector_required",
    }:
        return "missing", metric.support_solution or "required site capability is not configured"
    return "degraded", metric.support_solution or "capability not observed during preflight"


def run_preflight(
    *,
    root: Path,
    node_schema: Path,
    metric_support: Path,
    output_dir: Path,
) -> Mapping[str, Any]:
    specs = load_metric_specs(node_schema, metric_support)
    capabilities = probe_capabilities(root)
    rows: list[dict[str, Any]] = []
    counts: dict[str, int] = {}
    for spec in specs:
        capability = capabilities.get(spec.required_capability, {"available": False})
        status, reason = _metric_status(spec, capability)
        counts[status] = counts.get(status, 0) + 1
        row = {
            **metric_matrix_rows([spec])[0],
            "preflight_status": status,
            "preflight_reason": reason,
            "capability_available": bool(capability.get("available")),
            "capability_source": str(capability.get("source", "")),
        }
        rows.append(row)
        print(
            "FULL83_PREFLIGHT_METRIC "
            f"metric_id={spec.metric_id} "
            f"capability={spec.required_capability} "
            f"status={status} "
            f"source={row['capability_source']} "
            f"reason={reason[:180]}",
            flush=True,
        )
    payload = {
        "schema_version": "full83.preflight.v1",
        "status": "complete_non_blocking",
        "created_utc_ns": time.time_ns(),
        "metric_count": len(specs),
        "status_counts": counts,
        "capabilities": capabilities,
        "metrics": rows,
        "non_blocking": True,
    }
    output_dir.mkdir(parents=True, exist_ok=True)
    atomic_json(output_dir / "full83_preflight_report.json", payload)
    write_csv(output_dir / "metric_collection_matrix_83.csv", rows)
    print(f"FULL83_PREFLIGHT_REPORT={output_dir / 'full83_preflight_report.json'}")
    print(f"FULL83_PREFLIGHT_STATUS_COUNTS={counts}")
    return payload


def main(argv: Sequence[str] | None = None) -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", type=Path, required=True)
    parser.add_argument("--node-schema", type=Path, required=True)
    parser.add_argument("--metric-support", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    args = parser.parse_args(argv)
    run_preflight(
        root=args.root.resolve(strict=True),
        node_schema=args.node_schema.resolve(strict=True),
        metric_support=args.metric_support.resolve(strict=True),
        output_dir=args.output_dir.resolve(strict=False),
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
