#!/usr/bin/env python3
"""Materialize a non-blocking full83 collector config for one run."""

from __future__ import annotations

import argparse
import os
from pathlib import Path
from typing import Any, Mapping, Sequence

import yaml

from full83_common import atomic_text


def _has_bmc_env() -> bool:
    return all(
        os.environ.get(name)
        for name in ("HGNN_BMC_ENDPOINT", "HGNN_BMC_USERNAME", "HGNN_BMC_PASSWORD")
    )


def _path_env(name: str) -> str | None:
    value = os.environ.get(name)
    if not value:
        return None
    return str(Path(value).expanduser())


def materialize_config(
    *,
    template: Path,
    output: Path,
    mode: str,
    duration_s: int,
    baseline_s: int,
    release_at_s: int,
    enable_bmc: str,
) -> Mapping[str, Any]:
    payload = yaml.safe_load(template.read_text(encoding="utf-8"))
    if not isinstance(payload, dict):
        raise ValueError("collector config template must be a mapping")
    onset_end = min(release_at_s, baseline_s + max(1, int((release_at_s - baseline_s) * 0.25)))
    payload["dataset_version"] = f"1.0.0-hsh-f01-full83-{mode}"
    payload["duration_s"] = int(duration_s)
    payload["phase_boundaries_s"] = [0, int(baseline_s), int(onset_end), int(release_at_s), int(duration_s)]
    payload["data_root"] = "../data/hsh_f01_full83"
    bmc_available = _has_bmc_env()
    bmc_enabled = (
        enable_bmc == "always"
        or (enable_bmc == "auto" and bmc_available)
    )
    collectors = payload.setdefault("collectors", {})
    collectors.setdefault("bmc", {})["enabled"] = bool(bmc_enabled)
    site = payload.setdefault("site", {})
    bmc = site.setdefault("bmc", {})
    bmc["enabled"] = bool(bmc_enabled)
    bmc["sensor_map_path"] = (
        _path_env("FULL83_BMC_SENSOR_MAP")
        or str(template.parent / "hsh_f01_bmc_sensor_map.template.yaml")
    )
    helpers = site.setdefault("privileged_helpers", {})
    helper_env_map = {
        "perf_socket": "FULL83_PERF_SOCKET",
        "ras_socket": "FULL83_RAS_SOCKET",
        "ethtool_eeprom_helper": "FULL83_ETHTOOL_EEPROM_HELPER",
        "pcie_config_helper": "FULL83_PCIE_CONFIG_HELPER",
        "journal_helper": "FULL83_JOURNAL_SOCKET",
    }
    for key, env_name in helper_env_map.items():
        value = _path_env(env_name)
        if value:
            helpers[key] = value
    training = site.setdefault("training", {})
    training_socket = _path_env("FULL83_TRAINING_EVENT_SOCKET")
    if training_socket:
        training["enabled"] = True
        training["event_socket"] = training_socket
    vendor = site.setdefault("vendor_api", {})
    dcmi_library = _path_env("HGNN_DCMI_LIBRARY")
    if dcmi_library:
        vendor["dcmi_library"] = dcmi_library
    plugin = _path_env("FULL83_VENDOR_METRIC_PLUGIN")
    if plugin:
        vendor["metric_plugin"] = plugin
    output.parent.mkdir(parents=True, exist_ok=True)
    atomic_text(output, yaml.safe_dump(payload, allow_unicode=True, sort_keys=False))
    print(f"FULL83_EFFECTIVE_COLLECTOR_CONFIG={output}")
    print(f"FULL83_EFFECTIVE_BMC_ENABLED={int(bmc_enabled)}")
    return payload


def main(argv: Sequence[str] | None = None) -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--template", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--mode", choices=("test", "full"), required=True)
    parser.add_argument("--duration-s", type=int, required=True)
    parser.add_argument("--baseline-s", type=int, required=True)
    parser.add_argument("--release-at-s", type=int, required=True)
    parser.add_argument("--enable-bmc", choices=("auto", "always", "never"), default="auto")
    args = parser.parse_args(argv)
    materialize_config(
        template=args.template.resolve(strict=True),
        output=args.output.resolve(strict=False),
        mode=args.mode,
        duration_s=args.duration_s,
        baseline_s=args.baseline_s,
        release_at_s=args.release_at_s,
        enable_bmc=args.enable_bmc,
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
