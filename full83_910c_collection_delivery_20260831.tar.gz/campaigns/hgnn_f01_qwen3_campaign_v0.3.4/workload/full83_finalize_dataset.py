#!/usr/bin/env python3
"""Finalize full83 test/formal group manifests."""

from __future__ import annotations

import argparse
from pathlib import Path
from typing import Any, Mapping, Sequence

from r27_state import discover_telemetry_root
from torch_npu_offline_common import atomic_json, load_json


def finalize_dataset(
    *,
    root: Path,
    extraction_root: Path,
    campaign_id: str,
    mode: str,
    output: Path,
    expected_groups: int | None,
    preflight_report: Path | None,
) -> Mapping[str, Any]:
    group_paths = sorted((extraction_root / "groups").glob("*.json"))
    if not group_paths:
        raise SystemExit("no full83 groups found")
    if expected_groups is not None and len(group_paths) != expected_groups:
        raise SystemExit(f"expected {expected_groups} groups, observed {len(group_paths)}")
    entries: list[Mapping[str, Any]] = []
    incomplete: list[str] = []
    for group_path in group_paths:
        group = load_json(group_path)
        run_id = str(group["run_id"])
        if group.get("status") != "complete":
            incomplete.append(str(group.get("key", group_path.stem)))
        cleanup = extraction_root / "provenance/full83/cleanup" / run_id / "cleanup_report.json"
        cleanup_report = load_json(cleanup.resolve(strict=True))
        entries.append(
            {
                "key": group["key"],
                "run_id": run_id,
                "condition": group["condition"],
                "metric": group["metric"],
                "mode": mode,
                "segment_count": group.get("segment_count"),
                "complete_segment_count": group.get("complete_segment_count"),
                "telemetry_root": discover_telemetry_root(root, run_id),
                "profile_root": "",
                "profile_root_deleted": True,
                "profile_plans_root": cleanup_report["profile_plans_output"],
                "raw_cleanup_report": str(cleanup),
                "group_extraction_manifest": str(group_path),
                "sample_plan": group.get("sample_plan", ""),
                "full83_monitor_report": str(
                    extraction_root / "provenance/full83/monitor" / run_id / "monitor.json"
                ),
            }
        )
    manifest = {
        "schema_version": "full83.dataset_manifest.v1",
        "status": "complete" if not incomplete else "complete_with_incomplete_groups",
        "mode": mode,
        "campaign_id": campaign_id,
        "group_count": len(entries),
        "expected_group_count": expected_groups,
        "incomplete_groups": incomplete,
        "preflight_report": str(preflight_report) if preflight_report else "",
        "entries": entries,
        "non_blocking_metric_collection": True,
        "time_series_policy": "raw_observations_plus_profiler_segments_plus_explicit_missing_rows",
    }
    atomic_json(output, manifest)
    print(f"FULL83_DATASET_MANIFEST={output}")
    print(f"FULL83_DATASET_GROUPS={len(entries)}")
    print(f"FULL83_INCOMPLETE_GROUPS={len(incomplete)}")
    return manifest


def main(argv: Sequence[str] | None = None) -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", type=Path, required=True)
    parser.add_argument("--extraction-root", type=Path, required=True)
    parser.add_argument("--campaign-id", required=True)
    parser.add_argument("--mode", choices=("test", "full"), required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--expected-groups", type=int)
    parser.add_argument("--preflight-report", type=Path)
    args = parser.parse_args(argv)
    finalize_dataset(
        root=args.root.resolve(strict=True),
        extraction_root=args.extraction_root.resolve(strict=True),
        campaign_id=args.campaign_id,
        mode=args.mode,
        output=args.output.resolve(strict=False),
        expected_groups=args.expected_groups,
        preflight_report=args.preflight_report,
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
