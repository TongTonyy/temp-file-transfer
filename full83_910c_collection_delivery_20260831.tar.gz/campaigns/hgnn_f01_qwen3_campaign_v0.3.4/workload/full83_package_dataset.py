#!/usr/bin/env python3
"""Package full83 extracted time-series artifacts for transfer."""

from __future__ import annotations

import argparse
import os
import re
import tarfile
import tempfile
from pathlib import Path
from typing import Any, Iterable, Mapping

from package_extracted_dataset import forbidden
from torch_npu_offline_common import atomic_json, load_json, sha256


def regular_files(root: Path) -> Iterable[Path]:
    if not root.exists() or root.is_symlink():
        return
    if root.is_file():
        yield root
        return
    for path in sorted(root.rglob("*")):
        if path.is_file() and not path.is_symlink():
            yield path


def add_tree(
    selected: dict[str, Path],
    excluded: list[Mapping[str, str]],
    root: Path,
    arc_root: str,
) -> None:
    for path in regular_files(root):
        reason = forbidden(path)
        if reason:
            excluded.append({"path": str(path), "reason": reason})
            continue
        relative = path.relative_to(root) if root.is_dir() else Path(path.name)
        arcname = (Path(arc_root) / relative).as_posix()
        previous = selected.get(arcname)
        if previous is not None and previous != path:
            raise ValueError(f"archive path collision: {arcname}")
        selected[arcname] = path.resolve(strict=True)


def campaign_root_from_manifest(manifest: Path) -> Path:
    resolved = manifest.resolve(strict=True)
    try:
        root = resolved.parents[3]
    except IndexError as error:
        raise ValueError("dataset manifest path is too shallow") from error
    if root.joinpath("runtime").resolve(strict=True) != resolved.parents[2]:
        raise ValueError("dataset manifest is not below runtime/manifests/<campaign>")
    return root


def select_payload(
    dataset_manifest: Path,
    extraction_root: Path,
) -> tuple[dict[str, Path], list[Mapping[str, str]], Mapping[str, Any], Path]:
    dataset = load_json(dataset_manifest.resolve(strict=True))
    entries = dataset.get("entries")
    if not isinstance(entries, list):
        raise SystemExit("dataset entries missing")
    campaign_id = str(dataset.get("campaign_id") or dataset_manifest.parent.name)
    campaign_root = campaign_root_from_manifest(dataset_manifest)
    runtime = campaign_root / "runtime"
    selected: dict[str, Path] = {}
    excluded: list[Mapping[str, str]] = []
    add_tree(selected, excluded, extraction_root.resolve(strict=True), f"dataset/{campaign_id}/extracted")
    add_tree(selected, excluded, dataset_manifest.parent, f"dataset/{campaign_id}/manifests")
    for entry in entries:
        if not isinstance(entry, Mapping):
            continue
        run_id = str(entry["run_id"])
        telemetry_root = Path(str(entry["telemetry_root"]))
        add_tree(selected, excluded, telemetry_root, f"dataset/{campaign_id}/runs/{run_id}/telemetry")
        add_tree(selected, excluded, runtime / "outputs/formal" / run_id, f"dataset/{campaign_id}/runs/{run_id}/formal")
        add_tree(selected, excluded, runtime / "manifests" / run_id, f"dataset/{campaign_id}/runs/{run_id}/runtime_manifests")
        plans_root = Path(str(entry.get("profile_plans_root", "")))
        add_tree(selected, excluded, plans_root, f"dataset/{campaign_id}/runs/{run_id}/profile_plans")
    return selected, excluded, dataset, campaign_root


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--dataset-manifest", type=Path, required=True)
    parser.add_argument("--extraction-root", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--bundle-label", default="full83-timeseries-dataset")
    args = parser.parse_args()
    extraction_manifest = load_json(
        args.extraction_root.resolve(strict=True) / "dataset_extraction_manifest.json"
    )
    if extraction_manifest.get("status") != "complete":
        raise SystemExit("full83 extraction is not complete")
    selected, excluded, dataset, _campaign_root = select_payload(
        args.dataset_manifest, args.extraction_root.resolve(strict=True)
    )
    campaign_id = str(dataset.get("campaign_id") or args.dataset_manifest.parent.name)
    output_dir = args.output_dir.resolve(strict=False)
    output_dir.mkdir(parents=True, exist_ok=True)
    if not re.fullmatch(r"[A-Za-z0-9_.-]+", args.bundle_label):
        raise SystemExit("unsafe bundle label")
    bundle = output_dir / f"{campaign_id}-{args.bundle_label}.tar.gz"
    temporary_bundle = bundle.with_suffix(bundle.suffix + ".tmp")
    inventory: list[Mapping[str, Any]] = []
    sums: list[str] = []
    for arcname, path in sorted(selected.items()):
        reason = forbidden(Path(arcname))
        if reason:
            raise SystemExit(f"forbidden archive member selected: {arcname}: {reason}")
        digest = sha256(path)
        inventory.append(
            {
                "archive_path": arcname,
                "source_path": str(path),
                "size_bytes": path.stat().st_size,
                "sha256": digest,
            }
        )
        sums.append(f"{digest}  {arcname}")
    with tempfile.TemporaryDirectory(prefix=".full83-package-", dir=output_dir) as temp:
        metadata_root = Path(temp)
        internal_root = Path(f"dataset/{campaign_id}/package")
        package_manifest = metadata_root / "package_manifest.json"
        atomic_json(
            package_manifest,
            {
                "schema_version": "full83.package.v1",
                "status": "complete",
                "campaign_id": campaign_id,
                "payload_file_count": len(inventory),
                "payload_size_bytes": sum(item["size_bytes"] for item in inventory),
                "raw_profiler_trace_included": False,
                "non_blocking_metric_collection": True,
                "files": inventory,
                "excluded_files": excluded,
            },
        )
        package_arc = (internal_root / "package_manifest.json").as_posix()
        sums.append(f"{sha256(package_manifest)}  {package_arc}")
        sum_file = metadata_root / "SHA256SUMS"
        sum_file.write_text("\n".join(sums) + "\n", encoding="utf-8")
        with tarfile.open(str(temporary_bundle), mode="w|gz") as archive:
            for arcname, path in sorted(selected.items()):
                archive.add(path, arcname=arcname, recursive=False)
            archive.add(package_manifest, arcname=package_arc, recursive=False)
            archive.add(sum_file, arcname=(internal_root / "SHA256SUMS").as_posix())
    os.replace(temporary_bundle, bundle)
    checksum = Path(str(bundle) + ".sha256")
    checksum.write_text(f"{sha256(bundle)}  {bundle.name}\n", encoding="utf-8")
    print(f"FULL83_DATASET_BUNDLE={bundle}")
    print(f"FULL83_DATASET_BUNDLE_SHA256={checksum}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
