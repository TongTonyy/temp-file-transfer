#!/usr/bin/env python3
"""Build r29-compatible sample plans for full83 test and formal runs."""

from __future__ import annotations

import argparse
from pathlib import Path
from typing import Any, Mapping, Sequence

from r29_sample_plan import DEFAULT_SEGMENTS, SCHEMA_VERSION, validate_sample_plan
from torch_npu_offline_common import atomic_json


def build_sample_plan(
    *,
    run_id: str,
    metric: str,
    condition: str,
    duration_s: float,
    baseline_s: float,
    release_at_s: float,
    time_scale: float,
) -> Mapping[str, Any]:
    fault_window_s = release_at_s - baseline_s
    if fault_window_s <= 0:
        raise ValueError("release_at_s must be greater than baseline_s")
    segments: list[Mapping[str, Any]] = []
    for segment_id, phase, offset_s, active_steps in DEFAULT_SEGMENTS:
        target_s = baseline_s + offset_s * time_scale
        if target_s < 0 or target_s > duration_s:
            raise ValueError(f"sample target out of campaign bounds: {segment_id}")
        boundary = (
            "fault_apply"
            if "fault" in phase and "release" not in phase
            else "fault_release"
            if "release" in phase
            else "recovery"
        )
        segments.append(
            {
                "segment_id": segment_id,
                "phase": phase,
                "boundary": boundary,
                "target_s": target_s,
                "offset_from_fault_apply_s": target_s - baseline_s,
                "offset_from_fault_release_s": target_s - release_at_s,
                "active_steps": active_steps,
                "full83_time_scale": time_scale,
            }
        )
    plan = {
        "schema_version": SCHEMA_VERSION,
        "run_id": run_id,
        "condition": condition,
        "metric": metric,
        "duration_s": duration_s,
        "baseline_s": baseline_s,
        "release_at_s": release_at_s,
        "fault_window_s": fault_window_s,
        "segment_count": len(segments),
        "total_active_steps": sum(int(row["active_steps"]) for row in segments),
        "segments": segments,
        "aggregation_policy": "full83_timeseries_with_sampled_profiler_segments",
        "full83_time_scale": time_scale,
    }
    validate_sample_plan(plan)
    return plan


def main(argv: Sequence[str] | None = None) -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--run-id", required=True)
    parser.add_argument("--metric", required=True)
    parser.add_argument("--condition", required=True)
    parser.add_argument("--duration-s", type=float, required=True)
    parser.add_argument("--baseline-s", type=float, required=True)
    parser.add_argument("--release-at-s", type=float, required=True)
    parser.add_argument("--time-scale", type=float, default=1.0)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    plan = build_sample_plan(
        run_id=args.run_id,
        metric=args.metric,
        condition=args.condition,
        duration_s=args.duration_s,
        baseline_s=args.baseline_s,
        release_at_s=args.release_at_s,
        time_scale=args.time_scale,
    )
    atomic_json(args.output, plan)
    print(f"FULL83_SAMPLE_PLAN={args.output}")
    print(f"FULL83_SAMPLE_SEGMENTS={plan['segment_count']}")
    print(f"FULL83_SAMPLE_ACTIVE_STEPS={plan['total_active_steps']}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
