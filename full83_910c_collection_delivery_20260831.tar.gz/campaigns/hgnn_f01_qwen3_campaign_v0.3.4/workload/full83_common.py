#!/usr/bin/env python3
"""Shared helpers for 910C full-83 time-series collection."""

from __future__ import annotations

import csv
import hashlib
import json
import os
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Iterable, Mapping, Sequence

import yaml


CONTRACT_METRIC_COUNT = 83
PROFILER_TARGETS = {
    "npu.aicore_stall_ratio",
    "hbm.read_gbps",
    "hbm.write_gbps",
    "global_task.comm_compute_overlap_pct",
    "global_task.step_time_ms",
}
TRAINING_CAPABILITIES = {
    "training_instrumentation",
    "workload",
    "npu_runtime_log",
}
BMC_CAPABILITIES = {"bmc"}


@dataclass(frozen=True)
class MetricSpec:
    metric_id: str
    node_type: str
    kind: str
    unit: str
    raw_hz: float
    aggregates: tuple[str, ...]
    required_capability: str
    expected_source: str
    normalize: bool
    applies_to: str
    applicability_attribute: str | None
    zero_evidence_metric: str | None
    support_status: str
    support_action: str
    support_solution: str


def atomic_text(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(text, encoding="utf-8")
    os.replace(tmp, path)


def atomic_json(path: Path, value: Mapping[str, Any]) -> None:
    atomic_text(
        path,
        json.dumps(value, ensure_ascii=False, indent=2, sort_keys=True) + "\n",
    )


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def load_json(path: Path) -> Mapping[str, Any]:
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, Mapping):
        raise ValueError(f"JSON root must be an object: {path}")
    return value


def load_yaml(path: Path) -> Mapping[str, Any]:
    value = yaml.safe_load(path.read_text(encoding="utf-8"))
    if not isinstance(value, Mapping):
        raise ValueError(f"YAML root must be an object: {path}")
    return value


def expected_source(metric_id: str, capability: str) -> str:
    if metric_id in PROFILER_TARGETS:
        return "profiler" if capability != "workload" else "profiler+training"
    if capability in TRAINING_CAPABILITIES:
        return "training"
    if capability in BMC_CAPABILITIES:
        return "bmc"
    return "collector"


def load_metric_specs(node_schema: Path, metric_support: Path) -> list[MetricSpec]:
    node_payload = load_yaml(node_schema)
    support_payload = load_yaml(metric_support)
    support_metrics = support_payload.get("metrics", {})
    if not isinstance(support_metrics, Mapping):
        support_metrics = {}
    specs: list[MetricSpec] = []
    for node_type, node_config in node_payload.get("node_types", {}).items():
        if not isinstance(node_config, Mapping):
            continue
        for item in node_config.get("features", []):
            if not isinstance(item, Mapping):
                continue
            metric_id = str(item["id"])
            capability = str(item.get("required_capability", ""))
            support = support_metrics.get(metric_id, {})
            if not isinstance(support, Mapping):
                support = {}
            c910 = support.get("ascend910c", {})
            if not isinstance(c910, Mapping):
                c910 = {}
            specs.append(
                MetricSpec(
                    metric_id=metric_id,
                    node_type=str(node_type),
                    kind=str(item.get("kind", "")),
                    unit=str(item.get("unit", "")),
                    raw_hz=float(item.get("raw_hz", 0) or 0),
                    aggregates=tuple(str(v) for v in item.get("aggregates", [])),
                    required_capability=capability,
                    expected_source=expected_source(metric_id, capability),
                    normalize=bool(item.get("normalize", False)),
                    applies_to=str(item.get("applies_to", "physical")),
                    applicability_attribute=(
                        str(item["applicability_attribute"])
                        if item.get("applicability_attribute") is not None
                        else None
                    ),
                    zero_evidence_metric=(
                        str(item["zero_evidence_metric"])
                        if item.get("zero_evidence_metric") is not None
                        else None
                    ),
                    support_status=str(c910.get("status", "collect_if_capable")),
                    support_action=str(c910.get("action", "collect")),
                    support_solution=str(support.get("solution", "")),
                )
            )
    metric_ids = [spec.metric_id for spec in specs]
    if len(metric_ids) != CONTRACT_METRIC_COUNT or len(set(metric_ids)) != CONTRACT_METRIC_COUNT:
        raise ValueError(
            f"node metric contract must contain {CONTRACT_METRIC_COUNT} unique metrics, "
            f"got {len(metric_ids)}"
        )
    return sorted(specs, key=lambda spec: spec.metric_id)


def specs_by_metric(specs: Sequence[MetricSpec]) -> dict[str, MetricSpec]:
    return {spec.metric_id: spec for spec in specs}


def metric_matrix_rows(specs: Sequence[MetricSpec]) -> list[dict[str, Any]]:
    return [
        {
            "metric_id": spec.metric_id,
            "node_type": spec.node_type,
            "kind": spec.kind,
            "unit": spec.unit,
            "raw_hz": spec.raw_hz,
            "required_capability": spec.required_capability,
            "expected_source": spec.expected_source,
            "aggregates": "|".join(spec.aggregates),
            "applies_to": spec.applies_to,
            "applicability_attribute": spec.applicability_attribute or "",
            "zero_evidence_metric": spec.zero_evidence_metric or "",
            "ascend910c_status": spec.support_status,
            "ascend910c_action": spec.support_action,
            "collection_solution": spec.support_solution,
        }
        for spec in specs
    ]


def write_csv(path: Path, rows: Sequence[Mapping[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    fieldnames: list[str] = []
    for row in rows:
        for key in row:
            if key not in fieldnames:
                fieldnames.append(str(key))
    with tmp.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        writer.writeheader()
        for row in rows:
            writer.writerow({key: row.get(key, "") for key in fieldnames})
    os.replace(tmp, path)


def write_parquet(path: Path, rows: Sequence[Mapping[str, Any]]) -> None:
    import pyarrow as pa
    import pyarrow.parquet as pq

    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    all_keys: list[str] = []
    for row in rows:
        for key in row:
            if key not in all_keys:
                all_keys.append(str(key))
    normalized = [{key: row.get(key) for key in all_keys} for row in rows]
    table = pa.Table.from_pylist(normalized)
    pq.write_table(table, tmp, compression="zstd", compression_level=9)
    os.replace(tmp, path)


def value_from_observation(row: Mapping[str, Any]) -> Any:
    for key in ("value_f64", "value_i64", "value_str", "value_bool"):
        if row.get(key) is not None:
            return row.get(key)
    return None


def phase_for_t_idx(t_idx: int | None, duration_s: float, baseline_s: float, release_at_s: float) -> str:
    if t_idx is None:
        return "unknown"
    if t_idx < 0 or t_idx > duration_s:
        return "out_of_window"
    if t_idx < baseline_s:
        return "baseline"
    if t_idx < release_at_s:
        return "fault_active"
    return "recovery"


def iter_regular_files(root: Path) -> Iterable[Path]:
    if not root.exists() or root.is_symlink():
        return
    if root.is_file():
        yield root
        return
    for path in sorted(root.rglob("*")):
        if path.is_file() and not path.is_symlink():
            yield path
