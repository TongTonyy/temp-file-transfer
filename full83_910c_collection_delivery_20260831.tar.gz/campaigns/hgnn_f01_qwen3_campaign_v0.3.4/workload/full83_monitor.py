#!/usr/bin/env python3
"""Continuously report full-83 metric collection progress for one run."""

from __future__ import annotations

import argparse
import json
import signal
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterator, Mapping, Sequence

import pyarrow as pa

from full83_common import atomic_json, load_json, load_metric_specs


STOP = False


def _handle_stop(signum: int, frame: object) -> None:  # noqa: ARG001
    global STOP
    STOP = True


def _compression_from_path(path: Path) -> str:
    if path.suffix == ".zst":
        return "zstd"
    if path.suffix == ".gz":
        return "gzip"
    return "uncompressed"


def iter_jsonl(path: Path) -> Iterator[dict[str, Any]]:
    raw_stream = pa.OSFile(str(path), "rb")
    compression = _compression_from_path(path)
    stream: pa.NativeFile
    if compression == "uncompressed":
        stream = raw_stream
    else:
        stream = pa.CompressedInputStream(raw_stream, compression)
    buffer = b""
    try:
        while True:
            chunk = stream.read(1024 * 1024)
            if not chunk:
                break
            buffer += chunk
            lines = buffer.split(b"\n")
            buffer = lines.pop()
            for line in lines:
                if line:
                    yield json.loads(line)
        if buffer:
            yield json.loads(buffer)
    finally:
        stream.close()
        if not raw_stream.closed:
            raw_stream.close()


def summarize_run(run_dir: Path, metric_ids: set[str]) -> dict[str, dict[str, Any]]:
    summary = {
        metric_id: {
            "samples": 0,
            "ok_samples": 0,
            "non_ok_samples": 0,
            "last_ts_utc_ns": None,
            "last_status": "not_seen",
        }
        for metric_id in metric_ids
    }
    observations = run_dir / "raw" / "observations"
    if not observations.is_dir():
        return summary
    for path in sorted(observations.glob("collector=*/part-*.jsonl.*")):
        if path.name.endswith(".tmp"):
            continue
        try:
            rows = iter_jsonl(path)
            for row in rows:
                metric_id = str(row.get("metric_id", ""))
                if metric_id not in summary:
                    continue
                item = summary[metric_id]
                item["samples"] += 1
                status = str(row.get("status", "unknown"))
                if status == "ok" and row.get("observed") is True:
                    item["ok_samples"] += 1
                else:
                    item["non_ok_samples"] += 1
                item["last_status"] = status
                item["last_ts_utc_ns"] = row.get("ts_utc_ns")
        except Exception as exc:  # noqa: BLE001
            print(
                f"FULL83_MONITOR_READ_ERROR path={path} error={type(exc).__name__}:{exc}",
                flush=True,
            )
    return summary


def _ts_text(value: Any) -> str:
    if value is None:
        return "none"
    try:
        return datetime.fromtimestamp(int(value) / 1_000_000_000, timezone.utc).isoformat()
    except Exception:  # noqa: BLE001
        return str(value)


def load_preflight_status(path: Path | None) -> dict[str, str]:
    if path is None or not path.is_file():
        return {}
    try:
        payload = load_json(path)
    except Exception:  # noqa: BLE001
        return {}
    rows = payload.get("metrics", [])
    if not isinstance(rows, list):
        return {}
    return {
        str(row.get("metric_id")): str(row.get("preflight_status"))
        for row in rows
        if isinstance(row, Mapping)
    }


def monitor(args: argparse.Namespace) -> int:
    signal.signal(signal.SIGTERM, _handle_stop)
    signal.signal(signal.SIGINT, _handle_stop)
    specs = load_metric_specs(args.node_schema.resolve(strict=True), args.metric_support.resolve(strict=True))
    metric_ids = {spec.metric_id for spec in specs}
    preflight = load_preflight_status(args.preflight_report)
    started = time.monotonic()
    iteration = 0
    run_dir = args.telemetry_root
    while not STOP:
        iteration += 1
        summary = summarize_run(run_dir, metric_ids)
        observed = sum(1 for row in summary.values() if row["ok_samples"] > 0)
        non_ok = sum(1 for row in summary.values() if row["non_ok_samples"] > 0)
        print(
            "FULL83_MONITOR_SUMMARY "
            f"run_id={args.run_id} iteration={iteration} "
            f"observed_metrics={observed}/83 non_ok_metrics={non_ok} "
            f"elapsed_s={time.monotonic() - started:.1f}",
            flush=True,
        )
        for spec in specs:
            row = summary[spec.metric_id]
            status = (
                "observed"
                if row["ok_samples"] > 0
                else preflight.get(spec.metric_id, "pending")
            )
            print(
                "FULL83_MONITOR_METRIC "
                f"run_id={args.run_id} metric_id={spec.metric_id} "
                f"capability={spec.required_capability} status={status} "
                f"samples={row['samples']} ok={row['ok_samples']} "
                f"non_ok={row['non_ok_samples']} "
                f"last_status={row['last_status']} "
                f"last_utc={_ts_text(row['last_ts_utc_ns'])}",
                flush=True,
            )
        atomic_json(
            args.output,
            {
                "schema_version": "full83.monitor.v1",
                "run_id": args.run_id,
                "iteration": iteration,
                "observed_metrics": observed,
                "metric_count": len(specs),
                "telemetry_root": str(run_dir),
                "summary": summary,
                "updated_utc_ns": time.time_ns(),
            },
        )
        if args.duration_s and time.monotonic() - started >= args.duration_s:
            break
        deadline = time.monotonic() + args.interval_s
        while not STOP and time.monotonic() < deadline:
            time.sleep(min(1.0, deadline - time.monotonic()))
    print(f"FULL83_MONITOR_STOP run_id={args.run_id}", flush=True)
    return 0


def main(argv: Sequence[str] | None = None) -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--run-id", required=True)
    parser.add_argument("--telemetry-root", type=Path, required=True)
    parser.add_argument("--node-schema", type=Path, required=True)
    parser.add_argument("--metric-support", type=Path, required=True)
    parser.add_argument("--preflight-report", type=Path)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--interval-s", type=float, default=30.0)
    parser.add_argument("--duration-s", type=float, default=0.0)
    args = parser.parse_args(argv)
    return monitor(args)


if __name__ == "__main__":
    raise SystemExit(main())
