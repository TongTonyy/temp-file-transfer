#!/usr/bin/env python3
"""Validate full83 time-series artifacts without failing on missing metrics."""

from __future__ import annotations

import argparse
from pathlib import Path
from typing import Any, Mapping, Sequence

import pyarrow.parquet as pq

from full83_common import atomic_json, load_json, load_metric_specs


def validate_dataset(
    *,
    dataset_manifest: Path,
    extraction_root: Path,
    node_schema: Path,
    metric_support: Path,
    output: Path,
) -> Mapping[str, Any]:
    manifest = load_json(dataset_manifest.resolve(strict=True))
    entries = manifest.get("entries", [])
    if not isinstance(entries, list) or not entries:
        raise SystemExit("dataset manifest entries missing")
    specs = load_metric_specs(node_schema.resolve(strict=True), metric_support.resolve(strict=True))
    coverage_path = extraction_root / "contract/metric_coverage_83.json"
    time_series_path = extraction_root / "processed/time_series_83.parquet"
    features_long_path = extraction_root / "processed/features_long.parquet"
    features_wide_path = extraction_root / "processed/features_wide.parquet"
    required_files = [coverage_path, time_series_path, features_long_path, features_wide_path]
    missing_files = [str(path) for path in required_files if not path.is_file()]
    if missing_files:
        raise SystemExit("missing full83 artifact files: " + ", ".join(missing_files))
    coverage = load_json(coverage_path)
    metrics = coverage.get("metrics", [])
    if not isinstance(metrics, list) or len(metrics) != 83:
        raise SystemExit("metric coverage must contain 83 rows")
    expected_ids = {spec.metric_id for spec in specs}
    observed_ids = {str(row.get("metric_id")) for row in metrics if isinstance(row, Mapping)}
    if observed_ids != expected_ids:
        raise SystemExit("metric coverage ids do not match node_features.yaml")
    time_series_rows = pq.read_table(time_series_path, columns=["metric_id"]).num_rows
    long_rows = pq.read_table(features_long_path, columns=["metric_id"]).num_rows
    wide_rows = pq.read_table(features_wide_path).num_rows
    status_counts: dict[str, int] = {}
    frequency_counts: dict[str, int] = {}
    for row in metrics:
        if isinstance(row, Mapping):
            status = str(row.get("status", "unknown"))
            status_counts[status] = status_counts.get(status, 0) + 1
            frequency = str(row.get("frequency_status", "unknown"))
            frequency_counts[frequency] = frequency_counts.get(frequency, 0) + 1
    validation = {
        "schema_version": "full83.validation.v1",
        "status": "complete_with_explicit_metric_statuses",
        "dataset_manifest": str(dataset_manifest.resolve(strict=True)),
        "entry_count": len(entries),
        "metric_count": len(metrics),
        "time_series_rows": time_series_rows,
        "features_long_rows": long_rows,
        "features_wide_rows": wide_rows,
        "metric_status_counts": status_counts,
        "frequency_status_counts": frequency_counts,
        "missing_metric_status_is_nonfatal": True,
        "required_files": [str(path) for path in required_files],
    }
    atomic_json(output, validation)
    print(f"FULL83_VALIDATION_REPORT={output}")
    print(f"FULL83_VALIDATION_STATUS_COUNTS={status_counts}")
    print(f"FULL83_VALIDATION_FREQUENCY_COUNTS={frequency_counts}")
    return validation


def main(argv: Sequence[str] | None = None) -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--dataset-manifest", type=Path, required=True)
    parser.add_argument("--extraction-root", type=Path, required=True)
    parser.add_argument("--node-schema", type=Path, required=True)
    parser.add_argument("--metric-support", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    validate_dataset(
        dataset_manifest=args.dataset_manifest,
        extraction_root=args.extraction_root.resolve(strict=True),
        node_schema=args.node_schema,
        metric_support=args.metric_support,
        output=args.output.resolve(strict=False),
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
