#!/usr/bin/env bash
set -Eeuo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd -P)"
export FULL83_MODE="full"
export FULL83_DURATION_S="${FULL83_DURATION_S:-600}"
export FULL83_BASELINE_S="${FULL83_BASELINE_S:-120}"
export FULL83_RELEASE_AT_S="${FULL83_RELEASE_AT_S:-420}"
export FULL83_TIME_SCALE="${FULL83_TIME_SCALE:-1.0}"
export FULL83_COOLDOWN_S="${FULL83_COOLDOWN_S:-300}"
exec "$SCRIPT_DIR/run_full83_910c_collection.sh" full
