# 910C Full-83 指标时序采集交付包

本目录用于在 910C 上重新采集完整 83 指标时序数据，不从既有 `dataset_v1` 或 `dataset_v2` 中补挖。

核心目标：

- 按 `app/schemas/node_features.yaml` 的 83 指标合同采集时序数据。
- 采集过程中持续输出每个指标当前是否可采集、样本数、最近时间戳和缺失原因。
- 单项指标不可采集时不中断采集，统一写入 coverage 和时序表状态字段。
- 同一套交付包同时包含短时测试版和正式版。

## 版本

测试版：

- 默认 `duration=60s`
- 默认 `baseline=12s`
- 默认 `release_at=42s`
- profiling segment 时间点按正式版 0.1 倍缩放
- 默认 cooldown 为 `30s`
- 用于验证所有指标是否能按频率持续采集和落盘

正式版：

- 默认 `duration=600s`
- 默认 `baseline=120s`
- 默认 `release_at=420s`
- 与之前 v1/v2/r31 的 F01 故障注入时长和条件保持一致
- 默认 cooldown 为 `300s`

## 主要文件

- `run_full83_910c_collection.sh`：主入口，支持 `preflight/test/full/resume/status/package`
- `run_full83_910c_test.sh`：短时测试版快捷入口
- `run_full83_910c_formal.sh`：正式版快捷入口
- `full83_collector.yaml`：full83 collector 模板副本
- `site_full83.template.env`：910C 环境变量模板
- `site_full83.template.yaml`：额外站点能力说明模板
- `metric_collection_matrix_83.csv`：83 指标采集来源、频率和 910C 策略矩阵
- `COMMANDS_910C_zh.md`：完整执行命令

## 输出数据

采集完成后，返回包中重点查看：

- `dataset/<campaign_id>/extracted/processed/time_series_83.parquet`
- `dataset/<campaign_id>/extracted/processed/features_long.parquet`
- `dataset/<campaign_id>/extracted/processed/features_wide.parquet`
- `dataset/<campaign_id>/extracted/contract/metric_coverage_83.json`
- `dataset/<campaign_id>/extracted/metadata/full83_metric_dictionary_zh.md`
- `dataset/<campaign_id>/extracted/metadata/data_collection_protocol_zh.md`

`metric_coverage_83.json` 中的 `frequency_status` 用于判断测试版是否按频率跑通。常见状态包括 `meets_required_frequency`、`below_required_frequency`、`no_observed_series`、`event_metric_observed` 和 `event_metric_not_observed`。

## iBMC 与 HGNN_IPMC_PASSWORD

`HGNN_IPMC_PASSWORD` 是原 F01 active runner 沿用的变量名，实际含义是 iBMC SSH 登录密码。训练节点通过 SSH 登录 iBMC 后，在 iBMC 终端执行 `ipmcget/ipmcset` 控制或读取风扇；不存在另一套需要单独认证的 IPMC 系统。

`time_series_83.parquet` 同时包含三类记录：

- `collector_raw`：实时 collector 直接采到的指标。
- `profiler_segment`：sampled msprof 解析出的 profiling 指标。
- `availability_placeholder`：没有采到数值的指标，占位记录只说明状态和原因，不写假 0。

## 非中断策略

以下情况不会中断采集：

- 某个 BMC/Redfish 字段缺失。
- 某个 perf/uncore/NIC/RDMA/helper 未配置。
- 某个厂商 API 或硬件计数器不可用。
- 某个指标只有 preflight 证据、没有时序数值。

以下情况会中断：

- 训练任务无法启动。
- F01 风扇注入或自动回滚失败。
- 磁盘空间不足。
- profile raw 超过安全上限。
- CANN profile 解析/清理失败，导致无法安全释放 profile raw 空间。

## 先测试后正式

建议顺序：

1. 填写 `config/credentials.env` 和 drawer site config。
2. 运行 smoke gate：`02_preflight.sh`、`03_smoke_drawer0.sh`、`04_smoke_drawer2.sh`。
3. 运行 full83 preflight。
4. 运行短时测试版。
5. 查看测试版 coverage：如果关键指标链路可用，再运行正式版。

完整命令见 `COMMANDS_910C_zh.md`。
