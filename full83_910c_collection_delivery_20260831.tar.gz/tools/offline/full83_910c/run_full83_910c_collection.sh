#!/usr/bin/env bash
set -Eeuo pipefail
umask 077

ACTION="${1:-test}"
PACKAGE_NAME="hgnn_f01_qwen3_campaign_v0.3.4"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd -P)"
REPO_ROOT="$(cd "$SCRIPT_DIR/../../.." && pwd -P)"
if [[ -n "${HGNN_ROOT:-}" ]]; then
  ROOT="$HGNN_ROOT"
elif [[ -d "$REPO_ROOT/campaigns/$PACKAGE_NAME/workload" ]]; then
  ROOT="$REPO_ROOT/campaigns/$PACKAGE_NAME"
elif [[ -d "$PWD/workload" && -d "$PWD/app" ]]; then
  ROOT="$(pwd -P)"
else
  ROOT="/root/hgnn_910c_readiness/$PACKAGE_NAME"
fi
ROOT="$(cd "$ROOT" && pwd -P)"
cd "$ROOT"
export HGNN_CAMPAIGN_ROOT_OVERRIDE="$ROOT"

# shellcheck disable=SC1091
. "$ROOT/workload/common.sh"

WORKLOAD="$ROOT/workload"
NODE_SCHEMA="$ROOT/app/schemas/node_features.yaml"
METRIC_SUPPORT="$ROOT/app/schemas/metric_support.yaml"
FULL83_TEMPLATE_CONFIG="$ROOT/app/configs/hsh_f01_full83_collector.yaml"
PACKAGE_DIR="$ROOT/runtime/return_bundles"
PARSE_WORKERS="${FULL83_PARSE_WORKERS:-4}"
EXTRACT_WORKERS="${FULL83_EXTRACT_WORKERS:-8}"
MIN_FREE_GIB="${FULL83_MIN_FREE_GIB:-500}"
MAX_RAW_GROUP_GIB="${FULL83_MAX_RAW_GROUP_GIB:-300}"
FULL83_BMC_MODE="${FULL83_ENABLE_BMC:-auto}"
FULL83_MODE="${FULL83_MODE:-}"
FULL83_MONITOR_INTERVAL_S="${FULL83_MONITOR_INTERVAL_S:-30}"
FULL83_REQUIRE_SMOKE_GATES="${FULL83_REQUIRE_SMOKE_GATES:-1}"
FULL83_ROOT_APPROVAL_VALUE="I_ACKNOWLEDGE_HARDENED_ROOT_EXECUTION"

if [[ "$ACTION" == "test" ]]; then
  MODE="test"
elif [[ "$ACTION" == "full" ]]; then
  MODE="full"
elif [[ "$ACTION" == "resume" ]]; then
  MODE="${FULL83_MODE:-test}"
else
  MODE="${FULL83_MODE:-test}"
fi

if [[ "$MODE" == "test" ]]; then
  DURATION_S="${FULL83_DURATION_S:-60}"
  BASELINE_S="${FULL83_BASELINE_S:-12}"
  RELEASE_AT_S="${FULL83_RELEASE_AT_S:-42}"
  TIME_SCALE="${FULL83_TIME_SCALE:-0.1}"
  COOLDOWN_S="${FULL83_COOLDOWN_S:-30}"
  DEFAULT_CAMPAIGN_SUFFIX="full83-test"
else
  DURATION_S="${FULL83_DURATION_S:-600}"
  BASELINE_S="${FULL83_BASELINE_S:-120}"
  RELEASE_AT_S="${FULL83_RELEASE_AT_S:-420}"
  TIME_SCALE="${FULL83_TIME_SCALE:-1.0}"
  COOLDOWN_S="${FULL83_COOLDOWN_S:-300}"
  DEFAULT_CAMPAIGN_SUFFIX="full83-formal"
fi

DEPLOY_STAMP="$(date -u +%Y%m%dT%H%M%SZ)"
CAMPAIGN_ID="${FULL83_CAMPAIGN_ID:-${DEPLOY_STAMP}-${DEFAULT_CAMPAIGN_SUFFIX}}"
EXTRACTION_ROOT="$ROOT/runtime/extracted_targets_full83/$CAMPAIGN_ID"
MANIFEST_ROOT="$ROOT/runtime/manifests/$CAMPAIGN_ID"
PREFLIGHT_ROOT="$ROOT/runtime/gates/full83_preflight/$CAMPAIGN_ID"
DEPLOY_LOG="$ROOT/runtime/logs/full83_${MODE}_${DEPLOY_STAMP}.log"
mkdir -p "$EXTRACTION_ROOT/groups" "$MANIFEST_ROOT" "$PACKAGE_DIR" "$PREFLIGHT_ROOT" "$ROOT/runtime/logs"
exec > >(tee -a "$DEPLOY_LOG") 2>&1

GROUP_KEYS=()
GROUP_CONDITIONS=()
GROUP_METRICS=()
GROUP_DRAWERS=()

add_group() {
  GROUP_KEYS+=("$1")
  GROUP_CONDITIONS+=("$2")
  GROUP_METRICS+=("$3")
  GROUP_DRAWERS+=("$4")
}

for rep in 4 5 6; do
  add_group "d0_rep${rep}_control_resource_conflict" "manual_baseline_sham" "ResourceConflictRatio" "drawer0"
  add_group "d0_rep${rep}_fault_resource_conflict" "drawer0_s1" "ResourceConflictRatio" "drawer0"
  add_group "d0_rep${rep}_control_memory_access" "manual_baseline_sham" "MemoryAccess" "drawer0"
  add_group "d0_rep${rep}_fault_memory_access" "drawer0_s1" "MemoryAccess" "drawer0"
done

add_group "d2_rep1_control_resource_conflict" "manual_baseline_sham" "ResourceConflictRatio" "drawer2"
add_group "d2_rep1_control_memory_access" "manual_baseline_sham" "MemoryAccess" "drawer2"
for rep in 2 3 4 5; do
  add_group "d2_rep${rep}_control_resource_conflict" "manual_baseline_sham" "ResourceConflictRatio" "drawer2"
  add_group "d2_rep${rep}_fault_resource_conflict" "drawer2_s1" "ResourceConflictRatio" "drawer2"
  add_group "d2_rep${rep}_control_memory_access" "manual_baseline_sham" "MemoryAccess" "drawer2"
  add_group "d2_rep${rep}_fault_memory_access" "drawer2_s1" "MemoryAccess" "drawer2"
done

MAX_GROUPS="${FULL83_MAX_GROUPS:-30}"
if (( MAX_GROUPS < ${#GROUP_KEYS[@]} )); then
  GROUP_KEYS=("${GROUP_KEYS[@]:0:MAX_GROUPS}")
  GROUP_CONDITIONS=("${GROUP_CONDITIONS[@]:0:MAX_GROUPS}")
  GROUP_METRICS=("${GROUP_METRICS[@]:0:MAX_GROUPS}")
  GROUP_DRAWERS=("${GROUP_DRAWERS[@]:0:MAX_GROUPS}")
fi
GROUP_COUNT="${#GROUP_KEYS[@]}"

full83_stage() {
  echo "============================================================"
  echo "FULL83_STAGE=$1"
  echo "FULL83_STAGE_NAME=$2"
  echo "FULL83_STAGE_UTC=$(date -u +%Y%m%dT%H%M%SZ)"
  echo "============================================================"
}

full83_now_ms() {
  "$HGNN_PYTHON" - <<'PY'
import time
print(int(time.monotonic() * 1000))
PY
}

full83_elapsed_s() {
  "$HGNN_PYTHON" - "$1" "$2" <<'PY'
import sys
print(f"{(int(sys.argv[2]) - int(sys.argv[1])) / 1000:.3f}")
PY
}

full83_dir_bytes() {
  "$HGNN_PYTHON" - "$1" <<'PY'
import sys
from pathlib import Path
root = Path(sys.argv[1])
total = 0
if root.exists():
    for path in root.rglob("*"):
        try:
            if path.is_file() and not path.is_symlink():
                total += path.stat().st_size
        except OSError:
            pass
print(total)
PY
}

full83_init() {
  require_campaign_root
  resolve_llm_python
  prepare_runtime_dirs
  export PYTHONPATH="$ROOT/app/src:$WORKLOAD${PYTHONPATH:+:$PYTHONPATH}"
  if [[ -f "$CREDENTIALS" && ! -L "$CREDENTIALS" ]]; then
    if [[ "$(stat -c '%a' "$CREDENTIALS")" != "600" ]]; then
      echo "credentials.env 权限必须为 0600: $CREDENTIALS" >&2
      exit 2
    fi
    set -a
    # shellcheck disable=SC1090
    . "$CREDENTIALS"
    set +a
  else
    echo "FULL83_CREDENTIALS_WARNING=missing_credentials_env path=$CREDENTIALS"
  fi
}

full83_require_active_credentials() {
  if [[ "$(id -u)" -eq 0 && "${HGNN_CAMPAIGN_ROOT_APPROVAL:-}" != "$FULL83_ROOT_APPROVAL_VALUE" ]]; then
    echo "root 执行必须设置 HGNN_CAMPAIGN_ROOT_APPROVAL=$FULL83_ROOT_APPROVAL_VALUE" >&2
    exit 2
  fi
  [[ -f "$CREDENTIALS" && ! -L "$CREDENTIALS" ]] || {
    echo "缺少普通文件 $CREDENTIALS；active F01 运行至少需要 IPMC 密码和审批 token" >&2
    exit 2
  }
  : "${HGNN_IPMC_PASSWORD:?credentials.env 缺少 HGNN_IPMC_PASSWORD}"
  : "${HGNN_F01_ACTIVE_APPROVAL:?credentials.env 缺少 HGNN_F01_ACTIVE_APPROVAL}"
}

full83_make_effective_config() {
  local run_id="$1" output="$MANIFEST_ROOT/${run_id}_full83_collector.yaml"
  "$HGNN_PYTHON" "$WORKLOAD/full83_make_collector_config.py" \
    --template "$FULL83_TEMPLATE_CONFIG" \
    --output "$output" \
    --mode "$MODE" \
    --duration-s "$DURATION_S" \
    --baseline-s "$BASELINE_S" \
    --release-at-s "$RELEASE_AT_S" \
    --enable-bmc "$FULL83_BMC_MODE"
  printf '%s\n' "$output"
}

full83_run_preflight() {
  mkdir -p "$PREFLIGHT_ROOT"
  "$HGNN_PYTHON" "$WORKLOAD/full83_preflight.py" \
    --root "$ROOT" \
    --node-schema "$NODE_SCHEMA" \
    --metric-support "$METRIC_SUPPORT" \
    --output-dir "$PREFLIGHT_ROOT"
}

full83_group_completed() {
  local key="$1" run_id="$2" group_manifest cleanup_report
  group_manifest="$EXTRACTION_ROOT/groups/$key.json"
  cleanup_report="$EXTRACTION_ROOT/provenance/full83/cleanup/$run_id/cleanup_report.json"
  [[ -f "$group_manifest" && -f "$cleanup_report" ]] || return 1
  "$HGNN_PYTHON" - "$group_manifest" "$cleanup_report" "$run_id" <<'PY'
import json
import sys
from pathlib import Path
group = json.loads(Path(sys.argv[1]).read_text(encoding="utf-8"))
cleanup = json.loads(Path(sys.argv[2]).read_text(encoding="utf-8"))
run_id = sys.argv[3]
if group.get("status") != "complete" or group.get("run_id") != run_id:
    raise SystemExit(1)
if cleanup.get("status") != "complete" or cleanup.get("run_id") != run_id:
    raise SystemExit(1)
profile_root = Path(str(cleanup.get("profile_root", "")))
if profile_root.exists():
    raise SystemExit(1)
PY
}

full83_predict_staging_telemetry_root() {
  local run_id="$1"
  printf '%s\n' "$RUNTIME/data/versions/1.0.0-hsh-f01-full83-${MODE}/campaigns/ascend910c-hsh-f01-full83/runs/${run_id}.staging"
}

full83_start_monitor() {
  local run_id="$1" telemetry_root="$2" output="$3"
  "$HGNN_PYTHON" "$WORKLOAD/full83_monitor.py" \
    --run-id "$run_id" \
    --telemetry-root "$telemetry_root" \
    --node-schema "$NODE_SCHEMA" \
    --metric-support "$METRIC_SUPPORT" \
    --preflight-report "$PREFLIGHT_ROOT/full83_preflight_report.json" \
    --output "$output" \
    --interval-s "$FULL83_MONITOR_INTERVAL_S" \
    --duration-s "$((DURATION_S + 120))" &
  FULL83_MONITOR_PID=$!
}

full83_stop_monitor() {
  local pid="${1:-}"
  [[ -n "$pid" ]] || return 0
  if kill -0 "$pid" 2>/dev/null; then
    kill "$pid" 2>/dev/null || true
  fi
  wait "$pid" 2>/dev/null || true
}

full83_cooldown() {
  local run_id="$1"
  local output="$EXTRACTION_ROOT/provenance/full83/cooldown/${run_id}.json"
  mkdir -p "$(dirname "$output")"
  echo "FULL83_COOLDOWN_START run_id=$run_id seconds=$COOLDOWN_S"
  "$HGNN_PYTHON" - "$COOLDOWN_S" "$output" <<'PY'
import json
import sys
import time
from pathlib import Path
seconds = int(float(sys.argv[1]))
output = Path(sys.argv[2])
started = time.time_ns()
time.sleep(max(0, seconds))
payload = {
    "schema_version": "full83.cooldown.v1",
    "status": "complete",
    "duration_s": seconds,
    "started_utc_ns": started,
    "completed_utc_ns": time.time_ns(),
}
output.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")
PY
  echo "FULL83_COOLDOWN_COMPLETE run_id=$run_id"
}

full83_run_group() {
  local index="$1" key="$2" condition="$3" metric="$4" drawer="$5"
  local run_id profile_root gate_dir sample_plan parse_report cleanup_report group_manifest
  local monitor_report monitor_pid telemetry_staging started ended raw_bytes raw_gib effective_config
  run_id="${CAMPAIGN_ID}-${key}-a1"
  profile_root="$ROOT/runtime/profiles/$run_id"
  gate_dir="$ROOT/runtime/gates/full83_group_gate/$CAMPAIGN_ID/$run_id"
  sample_plan="$MANIFEST_ROOT/${run_id}_sample_plan.json"
  parse_report="$EXTRACTION_ROOT/provenance/full83/parse/$run_id/parse_report.json"
  cleanup_report="$EXTRACTION_ROOT/provenance/full83/cleanup/$run_id/cleanup_report.json"
  group_manifest="$EXTRACTION_ROOT/groups/$key.json"
  monitor_report="$EXTRACTION_ROOT/provenance/full83/monitor/$run_id/monitor.json"
  echo "FULL83_GROUP_INDEX=${index}/${GROUP_COUNT}"
  if full83_group_completed "$key" "$run_id"; then
    echo "FULL83_GROUP_SKIP_COMPLETED=$key"
    echo "RUN_ID=$run_id"
    return 0
  fi
  mkdir -p "$gate_dir" "$(dirname "$parse_report")" "$(dirname "$cleanup_report")" "$(dirname "$monitor_report")"
  echo "FULL83_GROUP_START=$key"
  echo "RUN_ID=$run_id"
  echo "FULL83_MODE=$MODE"
  echo "FULL83_CONDITION=$condition"
  echo "FULL83_DRAWER=$drawer"
  echo "AIC_METRIC=$metric"
  effective_config="$(full83_make_effective_config "$run_id" | tail -n 1)"
  COLLECTOR_CONFIG="$effective_config"
  export COLLECTOR_CONFIG
  "$HGNN_PYTHON" "$WORKLOAD/full83_sample_plan.py" \
    --run-id "$run_id" \
    --metric "$metric" \
    --condition "$condition" \
    --duration-s "$DURATION_S" \
    --baseline-s "$BASELINE_S" \
    --release-at-s "$RELEASE_AT_S" \
    --time-scale "$TIME_SCALE" \
    --output "$sample_plan"
  telemetry_staging="$(full83_predict_staging_telemetry_root "$run_id")"
  FULL83_MONITOR_PID=""
  full83_start_monitor "$run_id" "$telemetry_staging" "$monitor_report"
  monitor_pid="$FULL83_MONITOR_PID"
  started="$(full83_now_ms)"
  export HGNN_FORMAL_DURATION="$DURATION_S"
  export HGNN_FORMAL_BASELINE="$BASELINE_S"
  export HGNN_FORMAL_RELEASE_AT="$RELEASE_AT_S"
  export HGNN_TORCH_NPU_AIC_METRIC="$metric"
  export HGNN_R29_SAMPLE_PLAN_PATH="$sample_plan"
  set +e
  run_formal "$condition" "$drawer" "$run_id"
  rc=$?
  set -e
  full83_stop_monitor "$monitor_pid"
  if (( rc != 0 )); then
    echo "FULL83_FORMAL_RUN_FAILED run_id=$run_id rc=$rc" >&2
    return "$rc"
  fi
  raw_bytes="$(full83_dir_bytes "$profile_root")"
  raw_gib="$("$HGNN_PYTHON" - "$raw_bytes" <<'PY'
import sys
print(int(int(sys.argv[1]) // (1024 ** 3)))
PY
)"
  echo "FULL83_RAW_PROFILE_BYTES_AFTER_COLLECT=$raw_bytes"
  echo "FULL83_RAW_PROFILE_GIB_AFTER_COLLECT=$raw_gib"
  if (( raw_gib > MAX_RAW_GROUP_GIB )); then
    echo "FULL83_RAW_GROUP_TOO_LARGE=${raw_gib}GiB>${MAX_RAW_GROUP_GIB}GiB" >&2
    return 2
  fi
  local parse_argv=(
    "$HGNN_PYTHON" "$WORKLOAD/r29_parse_segments.py"
    --profile-root "$profile_root"
    --metric "$metric"
    --sample-plan "$sample_plan"
    --cache-root "$gate_dir/parse_cache"
    --output "$parse_report"
    --max-workers "$PARSE_WORKERS"
  )
  if [[ -n "${HGNN_MSPROF_PY:-}" ]]; then
    parse_argv+=(--msprof-py "$HGNN_MSPROF_PY")
  fi
  "${parse_argv[@]}"
  "$HGNN_PYTHON" "$WORKLOAD/r29_extract_segments.py" \
    --profile-root "$profile_root" \
    --output-root "$EXTRACTION_ROOT" \
    --run-id "$run_id" \
    --key "$key" \
    --condition "$condition" \
    --metric "$metric" \
    --sample-plan "$sample_plan" \
    --parse-report "$parse_report" \
    --max-workers "$EXTRACT_WORKERS" \
    --trust-complete-reports
  "$HGNN_PYTHON" "$WORKLOAD/r29_cleanup_sampled_profile.py" \
    --root "$ROOT" \
    --profile-root "$profile_root" \
    --extraction-root "$EXTRACTION_ROOT" \
    --group-manifest "$EXTRACTION_ROOT/$run_id/r29_group_extraction_manifest.json" \
    --run-id "$run_id" \
    --profile-plans-output "$EXTRACTION_ROOT/provenance/full83/profile_plans/$run_id" \
    --cleanup-report "$cleanup_report"
  "$HGNN_PYTHON" - "$EXTRACTION_ROOT/$run_id/r29_group_extraction_manifest.json" "$group_manifest" "$monitor_report" <<'PY'
import json
import sys
from pathlib import Path
source = json.loads(Path(sys.argv[1]).read_text(encoding="utf-8"))
source["schema_version"] = "full83.group_extraction.v1"
source["full83_monitor_report"] = sys.argv[3]
Path(sys.argv[2]).write_text(json.dumps(source, ensure_ascii=False, indent=2, sort_keys=True) + "\n", encoding="utf-8")
PY
  ended="$(full83_now_ms)"
  echo "FULL83_GROUP_TOTAL_S=$(full83_elapsed_s "$started" "$ended")"
  echo "FULL83_GROUP_COMPLETE=$key"
  if (( index < GROUP_COUNT )); then
    full83_cooldown "$run_id"
  fi
}

full83_status() {
  "$HGNN_PYTHON" - "$EXTRACTION_ROOT" "$GROUP_COUNT" <<'PY'
import json
import sys
from pathlib import Path
root = Path(sys.argv[1])
expected = int(sys.argv[2])
groups = sorted((root / "groups").glob("*.json"))
complete = []
for path in groups:
    payload = json.loads(path.read_text(encoding="utf-8"))
    if payload.get("status") == "complete":
        complete.append(payload.get("key", path.stem))
print(f"FULL83_STATUS_GROUPS={len(complete)}/{expected}")
for index, key in enumerate(complete, start=1):
    print(f"{index:02d} {key}")
PY
}

full83_finalize_extract_validate_package() {
  local dataset_manifest validation_report bundle_label
  dataset_manifest="$MANIFEST_ROOT/full83_${MODE}_dataset_manifest.json"
  validation_report="$ROOT/runtime/gates/full83_validation_${CAMPAIGN_ID}.json"
  "$HGNN_PYTHON" "$WORKLOAD/full83_finalize_dataset.py" \
    --root "$ROOT" \
    --extraction-root "$EXTRACTION_ROOT" \
    --campaign-id "$CAMPAIGN_ID" \
    --mode "$MODE" \
    --output "$dataset_manifest" \
    --expected-groups "$GROUP_COUNT" \
    --preflight-report "$PREFLIGHT_ROOT/full83_preflight_report.json"
  "$HGNN_PYTHON" "$WORKLOAD/full83_extract_timeseries.py" \
    --dataset-manifest "$dataset_manifest" \
    --extraction-root "$EXTRACTION_ROOT" \
    --node-schema "$NODE_SCHEMA" \
    --metric-support "$METRIC_SUPPORT" \
    --preflight-report "$PREFLIGHT_ROOT/full83_preflight_report.json"
  "$HGNN_PYTHON" "$WORKLOAD/full83_validate_dataset.py" \
    --dataset-manifest "$dataset_manifest" \
    --extraction-root "$EXTRACTION_ROOT" \
    --node-schema "$NODE_SCHEMA" \
    --metric-support "$METRIC_SUPPORT" \
    --output "$validation_report"
  bundle_label="full83-${MODE}-timeseries-dataset"
  "$HGNN_PYTHON" "$WORKLOAD/full83_package_dataset.py" \
    --dataset-manifest "$dataset_manifest" \
    --extraction-root "$EXTRACTION_ROOT" \
    --output-dir "$PACKAGE_DIR" \
    --bundle-label "$bundle_label"
}

full83_run_campaign() {
  full83_stage "1/6" "初始化与容量检查"
  full83_init
  full83_require_active_credentials
  echo "FULL83_CAMPAIGN_ID=$CAMPAIGN_ID"
  echo "FULL83_MODE=$MODE"
  echo "FULL83_GROUP_COUNT=$GROUP_COUNT"
  echo "FULL83_LOG=$DEPLOY_LOG"
  FREE_GIB="$("$HGNN_PYTHON" - "$ROOT" <<'PY'
import shutil
import sys
print(shutil.disk_usage(sys.argv[1]).free // (1024 ** 3))
PY
)"
  echo "FULL83_FREE_GIB=$FREE_GIB"
  if (( FREE_GIB < MIN_FREE_GIB )); then
    echo "可用空间不足${MIN_FREE_GIB}GiB，拒绝启动" >&2
    exit 2
  fi
  full83_stage "2/6" "非阻塞83指标能力验证"
  full83_run_preflight
  full83_stage "3/6" "Ascend环境与安全门禁"
  ASCEND_ENV=""
  for candidate in /usr/local/Ascend/ascend-toolkit/set_env.sh /usr/local/Ascend/ascend-toolkit/latest/set_env.sh; do
    [[ -f "$candidate" ]] && { ASCEND_ENV="$candidate"; break; }
  done
  [[ -n "$ASCEND_ENV" ]] || { echo "未找到Ascend环境脚本" >&2; exit 2; }
  set +u
  # shellcheck disable=SC1090
  source "$ASCEND_ENV"
  set -u
  export HGNN_MSPROF_PY="${HGNN_MSPROF_PY:-/usr/local/Ascend/cann-8.5.2/tools/profiler/profiler_tool/analysis/msprof/msprof.py}"
  if [[ "$FULL83_REQUIRE_SMOKE_GATES" == "1" ]]; then
    require_smoke_gate "drawer0"
    require_smoke_gate "drawer2"
  fi
  full83_stage "4/6" "full83 ${MODE} group采集"
  for ((i = 0; i < GROUP_COUNT; i++)); do
    full83_run_group "$((i + 1))" "${GROUP_KEYS[$i]}" "${GROUP_CONDITIONS[$i]}" "${GROUP_METRICS[$i]}" "${GROUP_DRAWERS[$i]}"
  done
  full83_stage "5/6" "时序提取验证与打包"
  full83_finalize_extract_validate_package
  full83_stage "6/6" "完成"
  echo "FULL83_COMPLETE=1"
}

case "$ACTION" in
  preflight)
    full83_init
    echo "FULL83_CAMPAIGN_ID=$CAMPAIGN_ID"
    echo "FULL83_MODE=$MODE"
    full83_run_preflight
    ;;
  test|full|resume)
    full83_run_campaign
    ;;
  status)
    full83_init
    full83_status
    ;;
  package)
    full83_init
    full83_finalize_extract_validate_package
    ;;
  *)
    echo "用法: $0 {preflight|test|full|resume|status|package}" >&2
    exit 2
    ;;
esac
