#!/usr/bin/env bash
set -Eeuo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd -P)"
export FULL83_MODE="test"
export FULL83_DURATION_S="${FULL83_DURATION_S:-60}"
export FULL83_BASELINE_S="${FULL83_BASELINE_S:-12}"
export FULL83_RELEASE_AT_S="${FULL83_RELEASE_AT_S:-42}"
export FULL83_TIME_SCALE="${FULL83_TIME_SCALE:-0.1}"
export FULL83_COOLDOWN_S="${FULL83_COOLDOWN_S:-30}"
exec "$SCRIPT_DIR/run_full83_910c_collection.sh" test
