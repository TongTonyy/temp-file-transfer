# 910C Full-83 完整执行命令

以下命令假设 910C 上把交付仓库 clone 到：

```bash
/root/hgnn_910c_readiness/910c_full83_delivery
```

如果你的 clone 目录不同，请相应修改 `CLONE_ROOT`。

## 1. clone 交付文件并设置路径

```bash
set -Eeuo pipefail

BASE="/root/hgnn_910c_readiness"
REPO_URL="https://github.com/TongTonyy/temp-file-transfer.git"
CLONE_ROOT="$BASE/910c_full83_delivery"
CAMPAIGN_ROOT="$CLONE_ROOT/campaigns/hgnn_f01_qwen3_campaign_v0.3.4"

mkdir -p "$BASE"
rm -rf "$CLONE_ROOT"
git clone "$REPO_URL" "$CLONE_ROOT"
cd "$CLONE_ROOT"

if [ -f returns/extracted/sampled_data/full83_910c_collection_delivery_20260831.tar.gz ]; then
  sha256sum -c returns/extracted/sampled_data/full83_910c_collection_delivery_20260831.tar.gz.sha256
  tar -xzf returns/extracted/sampled_data/full83_910c_collection_delivery_20260831.tar.gz -C "$CLONE_ROOT"
fi

export HGNN_ROOT="$CAMPAIGN_ROOT"
export HGNN_CAMPAIGN_ROOT_OVERRIDE="$CAMPAIGN_ROOT"
export HGNN_CAMPAIGN_ROOT_APPROVAL=I_ACKNOWLEDGE_HARDENED_ROOT_EXECUTION

(
  cd tools/offline/full83_910c
  sha256sum -c SHA256SUMS
)
```

## 2. 准备凭据

```bash
cd "$CAMPAIGN_ROOT"
mkdir -p config

cat > "$CAMPAIGN_ROOT/config/credentials.env" <<'EOF'
HGNN_BMC_ENDPOINT=https://10.3.40.67
HGNN_BMC_USERNAME=Administrator
HGNN_BMC_PASSWORD=Huawei@#1234
HGNN_BMC_INSECURE=1
HGNN_IPMC_PASSWORD=Huawei@#1234
HGNN_F01_ACTIVE_APPROVAL=F01-QWEN3-910C-ACTIVE-v0.3.4
EOF
chmod 600 "$CAMPAIGN_ROOT/config/credentials.env"
```

上述变量含义：

- `HGNN_BMC_ENDPOINT`
- `HGNN_BMC_USERNAME`
- `HGNN_BMC_PASSWORD`
- `HGNN_IPMC_PASSWORD`
- `HGNN_F01_ACTIVE_APPROVAL`

`HGNN_IPMC_PASSWORD` 不是另一套 IPMC 系统密码，它实际保存的是登录 iBMC 后执行 `ipmcget/ipmcset` 所使用的 iBMC SSH 密码；当前与 `HGNN_BMC_PASSWORD` 相同。

如果有 BMC 传感器映射：

```bash
cp "$CAMPAIGN_ROOT/app/configs/hsh_f01_bmc_sensor_map.template.yaml" \
  "$CAMPAIGN_ROOT/config/full83_bmc_sensor_map.yaml"
vi "$CAMPAIGN_ROOT/config/full83_bmc_sensor_map.yaml"
```

然后在 `credentials.env` 中设置：

```bash
FULL83_BMC_SENSOR_MAP=/root/hgnn_910c_readiness/910c_full83_delivery/campaigns/hgnn_f01_qwen3_campaign_v0.3.4/config/full83_bmc_sensor_map.yaml
```

## 3. 确认 drawer site config

需要已有：

```bash
ls -lh "$CAMPAIGN_ROOT/config/site.drawer0.local.yaml" \
       "$CAMPAIGN_ROOT/config/site.drawer2.local.yaml"
```

如果缺失，先从模板复制并填写 iBMC host、host key、审批 token、drawer 等信息：

```bash
cp "$CAMPAIGN_ROOT/app/configs/hsh_f01_active_site.template.yaml" \
  "$CAMPAIGN_ROOT/config/site.drawer0.local.yaml"
cp "$CAMPAIGN_ROOT/app/configs/hsh_f01_active_site.template.yaml" \
  "$CAMPAIGN_ROOT/config/site.drawer2.local.yaml"

vi "$CAMPAIGN_ROOT/config/site.drawer0.local.yaml"
vi "$CAMPAIGN_ROOT/config/site.drawer2.local.yaml"
```

## 4. 运行原有 F01 安全 gate

```bash
cd "$CAMPAIGN_ROOT"

bash ./02_preflight.sh
bash ./03_smoke_drawer0.sh
bash ./04_smoke_drawer2.sh
```

## 5. 运行 full83 非阻塞 preflight

```bash
cd "$CLONE_ROOT"

bash tools/offline/full83_910c/run_full83_910c_collection.sh preflight
```

输出中会出现：

```text
FULL83_PREFLIGHT_METRIC metric_id=... capability=... status=...
FULL83_PREFLIGHT_STATUS_COUNTS=...
```

这些结果只说明每个指标当前是否可采，不会因为某项不可采集而退出。

## 6. 先运行短时测试版

默认测试版是正式时长的 1/10：

```bash
cd "$CLONE_ROOT"

export FULL83_MAX_GROUPS=30
export FULL83_MONITOR_INTERVAL_S=10

bash tools/offline/full83_910c/run_full83_910c_test.sh
```

如果想先只跑 1 个 group 快速确认脚本链路：

```bash
export FULL83_MAX_GROUPS=1
bash tools/offline/full83_910c/run_full83_910c_test.sh
```

运行时会持续输出：

```text
FULL83_MONITOR_SUMMARY run_id=... observed_metrics=.../83 ...
FULL83_MONITOR_METRIC run_id=... metric_id=... status=... samples=... last_utc=...
```

## 7. 查询测试版进度

如果没有固定 campaign id，先从日志中找：

```bash
ls -lt "$CAMPAIGN_ROOT/runtime/logs"/full83_test_*.log
```

如果你已经知道 campaign id：

```bash
export FULL83_MODE=test
export FULL83_CAMPAIGN_ID="替换为日志中的 FULL83_CAMPAIGN_ID"

bash "$CLONE_ROOT/tools/offline/full83_910c/run_full83_910c_collection.sh" status
```

## 8. 续跑测试版

```bash
export FULL83_MODE=test
export FULL83_CAMPAIGN_ID="替换为原测试版 FULL83_CAMPAIGN_ID"
export FULL83_MAX_GROUPS=30

bash "$CLONE_ROOT/tools/offline/full83_910c/run_full83_910c_collection.sh" resume
```

已完成 group 会自动跳过。

## 9. 查看测试版 coverage

```bash
TEST_CAMPAIGN_ID="替换为测试版 FULL83_CAMPAIGN_ID"
TEST_ROOT="$CAMPAIGN_ROOT/runtime/extracted_targets_full83/$TEST_CAMPAIGN_ID"

python3 - <<'PY' "$TEST_ROOT/contract/metric_coverage_83.json"
import json, sys
from pathlib import Path
data = json.loads(Path(sys.argv[1]).read_text())
print("STATUS_COUNTS=", data.get("status_counts"))
freq = {}
for row in data.get("metrics", []):
    freq[row.get("frequency_status")] = freq.get(row.get("frequency_status"), 0) + 1
print("FREQUENCY_COUNTS=", freq)
for row in data.get("metrics", []):
    print(
        row["metric_id"],
        row["status"],
        row.get("frequency_status"),
        row.get("mean_effective_hz"),
        row.get("frequency_threshold_hz"),
        row.get("preflight_reason"),
    )
PY
```

## 10. 测试通过后运行正式版

```bash
cd "$CLONE_ROOT"

unset FULL83_MAX_GROUPS
export FULL83_MONITOR_INTERVAL_S=30

bash tools/offline/full83_910c/run_full83_910c_formal.sh
```

正式版默认：

- `duration=600`
- `baseline=120`
- `release_at=420`
- `cooldown=300`
- `FULL83_MAX_GROUPS=30`

## 11. 续跑正式版

```bash
export FULL83_MODE=full
export FULL83_CAMPAIGN_ID="替换为原正式版 FULL83_CAMPAIGN_ID"

bash "$CLONE_ROOT/tools/offline/full83_910c/run_full83_910c_collection.sh" resume
```

## 12. 单独重新打包

如果采集已经完成但打包失败：

```bash
export FULL83_MODE=full
export FULL83_CAMPAIGN_ID="替换为正式版 FULL83_CAMPAIGN_ID"

bash "$CLONE_ROOT/tools/offline/full83_910c/run_full83_910c_collection.sh" package
```

## 13. 校验返回包

```bash
cd "$CAMPAIGN_ROOT"

ls -lh runtime/return_bundles/*full83*timeseries-dataset.tar.gz \
       runtime/return_bundles/*full83*timeseries-dataset.tar.gz.sha256

sha256sum -c runtime/return_bundles/*full83*timeseries-dataset.tar.gz.sha256
```

## 14. 上传 GitHub Release

```bash
OWNER="TongTonyy"
REPO="temp-file-transfer"
TAG="r30-dataset-20260827"

read -r -s -p "GitHub PAT: " GITHUB_TOKEN; echo

curl -sS \
  -H "Authorization: Bearer $GITHUB_TOKEN" \
  -H "Accept: application/vnd.github+json" \
  "https://api.github.com/user" \
  | python3 -c 'import sys,json; d=json.load(sys.stdin); print("LOGIN=", d.get("login")); print("MESSAGE=", d.get("message"))'

RELEASE_ID="$(curl -sS \
  -H "Authorization: Bearer $GITHUB_TOKEN" \
  -H "Accept: application/vnd.github+json" \
  "https://api.github.com/repos/$OWNER/$REPO/releases/tags/$TAG" \
  | python3 -c 'import sys,json; print(json.load(sys.stdin)["id"])')"

echo "RELEASE_ID=$RELEASE_ID"

for FILE in "$CAMPAIGN_ROOT"/runtime/return_bundles/*full83*timeseries-dataset.tar.gz*; do
  NAME="$(basename "$FILE")"
  echo "UPLOAD=$NAME"
  curl -L -f -X POST \
    -H "Authorization: Bearer $GITHUB_TOKEN" \
    -H "Accept: application/vnd.github+json" \
    -H "Content-Type: application/octet-stream" \
    "https://uploads.github.com/repos/$OWNER/$REPO/releases/$RELEASE_ID/assets?name=$NAME" \
    --data-binary @"$FILE"
  echo
done

unset GITHUB_TOKEN
```
