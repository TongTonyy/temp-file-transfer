# AscendTune 910C 补充实验采集包（线 A/B/C/D）

对应需求文档《AscendTune 补充实验采集需求总文档 v1.0》。所有配置均在 `configs/*.json` 中显式列出，采集脚本不写死任何 p/t/d/b/sp/z/recompute。

## 环境前置（最重要，历史第一坑）

```bash
tmux new -s supp        # 网页终端会断连，必须 tmux
export PATH=/root/miniconda3/envs/llm_env/bin:$PATH
which torchrun          # 必须是 /root/miniconda3/envs/llm_env/bin/torchrun
python3 --version       # 必须 >= 3.10（系统 3.9 会在 import 阶段 TypeError）
bash self_check.sh      # dry-run 自检，生成 self_check_report.json
```

自检 FAIL 的项必须先解决再采集。

## 各线运行

```bash
# 线 D（纯计算，先跑，1 分钟）：审计历史 HCCL trace 是否存在
python3 lineD/summarize_historical_hccl.py configs/lineD_historical.json lineD/historical_hccl_trace_summary.csv

# 线 B（最高优先级，约 1 天内）：P1 通信 microbench
bash lineB/run_p1_comm.sh 2>&1 | tee lineB/p1_comm.log
# 只重跑某一个： ONLY=s_overlap bash lineB/run_p1_comm.sh

# 线 A（次高优先级，4 必采约 4-6 小时；含可选约 +2-3 小时）
bash lineA/run_p0b_anchors.sh 2>&1 | tee lineA/p0b.log
RUN_OPTIONAL=1 bash lineA/run_p0b_anchors.sh   # 含 F1b/F3b

# 线 C（可选，不阻塞 P0/P1）
bash lineC/run_rho_kernel.sh 2>&1 | tee lineC/rho.log
```

## 打包交付

```bash
bash pack_results.sh
# 产出 p0b_anchors_raw.tar.gz / p1_comm_microbench_raw.tar.gz / rho_kernel_microbench_raw.tar.gz
# 以及 lineD/historical_hccl_trace_summary.csv
```

## 数据格式（与 v1/V2 对齐）

- `step_time.csv`：`step,step_time_ms,timestamp`，仅第 6-25 步（前 5 步 warmup 不计）
- `real_tokens.csv`：`iteration,tokens_numel_allranks,tokens_nonpad_allranks`，25 行
- `power_mem.csv`：`ts_unix,card,power_w,die0_hbm_used_mb,die1_hbm_used_mb`
- 线 A 每配置另有：`token_scope_check.json`、`validate_report.json`、`hccl_trace/`、`config_note.txt`

## 预计时长

| 线 | 时长 |
|---|---|
| D | < 5 分钟 |
| B | q 表 + P2P + s_overlap，合计约 3-6 小时 |
| A | 每配置约 50-70 分钟（参照 V2 实测），4 必采约 4-5 小时 |
| C | 约 1-3 小时（可选） |
