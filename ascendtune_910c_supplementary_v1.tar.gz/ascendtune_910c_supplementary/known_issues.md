# Known Issues（继承 v1/V2 实测踩坑 + 本包对策）

## 通用

1. **系统 Python 3.9 陷阱**：堡垒机网页终端里 `conda activate` 可能静默失效（已实测发生 2 次），导致 torchrun 跑到 `/usr/local/lib64/python3.9`，报 `TypeError: unsupported operand type(s) for |: 'type' and 'NoneType'`。对策：一律用 `export PATH=/root/miniconda3/envs/llm_env/bin:$PATH`，跑前 `which torchrun` 验证，`self_check.sh` 会卡这项。
2. **HCCL 端口残留（EJ0003）**：前一个 torchrun 刚退出就启动下一个会偶发 `Failed to bind the IP port`。对策：本包所有组间串行间隔（线 A 60s、线 B 20s）+ 失败自动 retry 1 次（等 90s 换端口）。
3. **torchrun 参数缩写冲突**：传给训练脚本的参数一律放在脚本名之后；microbench 参数不用 `--m/--n/--k` 这类单字母（曾被 torchrun 当成自己的 `--max-restarts` 等）。
4. **网页终端吞行**：交互式 `cp` 覆盖确认会吃掉下一行输入；本包全部用 `cat a > b`，脚本内无交互命令。
5. **token 计数假 PASS**：这版 MindSpeed-LLM 的 `forward_step` 是 SFTTrainer 类方法，模块级钩子装不上，会输出行数正常但全 0 的 real_tokens.csv。本包线 A 使用 2026-11-08 实测有效的 loss_func 类方法钩子版 wrapper，`validate_anchor.py` 会显式检测全 0。

## 线 A

6. **HCCL trace 可能采不到**：`HCCL_TRACE=1` 在这台机器是否生效未验证。若 `hccl_trace/` 为空，会写入 `TRACE_UNAVAILABLE.txt` 并在 validate warnings 里报告——此时需要线下确认该 CANN 版本的 trace 开关（如 msprof），不能默默跳过。
7. **F1/F2/F3 是 z=0（无 distributed optimizer）**：2026-11-07 实测 z=0 在 pp1/tp4/mb1 时已 OOM（峰值 58.3 GiB）。F1 mb=4 大概率 OOM——按需求文档这属于**要采集的验证目标**，OOM 就标 FAIL 并保留日志，不允许改 p/t/d/b/sp/z。
8. **F4（z=3）OOM 特判**：optimizer state all-gather 可能推高显存峰值；若两次 attempt 都 OOM，按需求允许仅以 sp=0 追加一次 attempt 3。
9. **PP>1 的 real_tokens 口径**：F2/F4 可能是 local shard（~1/pp 或 1/(pp*tp)），`token_scope_check.json` 只记录不修正，修正留给冻结验证阶段。
10. **统计窗口严格第 6-25 步**：step_time.csv 由脚本自动截取，不要手改。

## 线 B

11. **建组开销**：所有 group 在计时前创建并 warmup（历史上不 warmup 会让 alpha 显著偏高）。
12. **q_dp=1.7608 复核**：q_table.csv 出来后，优先核对 group_size=16（DP 场景）的 q 值；若实测显著低于 1.76（如 1.3-1.4），说明历史值被 anchor residual 污染，需在报告中明确指出。
13. **s_overlap 真并发验证**：本包用 per-stream npu Event 分别计时 GEMM 和 comm；若 `serialized_suspect=1` 或 `s_overlap_compute == s_overlap_comm` 全相等，说明并发窗口没建立（GEMM 太快/通信被排队），fit 脚本会打 WARNING，必须报告而不是照用数据。
14. **group_size=16 拓扑退化**：单机 16 卡可能走 ring 而非 mesh，q 表若发现 g16 与 g8 模式完全不同，分开拟合，不要混。

## 线 C

15. **融合算子版本一致性**：`impl` 列记录实际跑的实现（fused_* / ref_* / unavailable）；ref_* 的 rho 只能当下界参考，不能与 fused 混用。
16. **recompute=1 = forward×2**，不是 forward+backward，做 rho 换算时注意。

## 线 D

17. **历史 trace 大概率不存在**：v1/V2 运行时未开 trace；线 D 输出若为空属预期，由线 A 的 F1-F4 trace 替代（前提是坑 6 解决）。
