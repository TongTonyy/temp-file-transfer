#!/usr/bin/env python3
"""Line D: historical HCCL trace audit (pure computation, no new measurement).

Scans the v1/V2 result roots for hccl_trace directories, summarizes per-anchor
trace availability, and prints a coverage report against the key config axes
(PP=1 / PP>1, SP=0/1, TP=2/4/8). If nothing is found, the CSV still gets a
header plus an explicit NOT FOUND note, per the requirements.
"""
from __future__ import annotations

import csv
import json
import os
import sys


def main():
    cfg_path = sys.argv[1]
    out_csv = sys.argv[2]
    with open(cfg_path, encoding="utf-8") as f:
        cfg = json.load(f)

    fields = ["anchor_id", "p", "t", "d", "sp", "z",
              "tp_allreduce_ms", "dp_reducescatter_ms", "dp_allgather_ms",
              "p2p_ms", "total_comm_ms"]
    rows = []
    for a in cfg["known_anchors"]:
        found_files = []
        for root_dir in cfg["search_roots"]:
            for dirpath, dirnames, filenames in os.walk(root_dir):
                if os.path.basename(dirpath) in cfg["trace_dir_names"] and a["anchor_id"] in dirpath:
                    for fn in filenames:
                        if fn.endswith("TRACE_UNAVAILABLE.txt"):
                            continue
                        found_files.append(os.path.join(dirpath, fn))
        row = {k: a[k] for k in ("p", "t", "d", "sp", "z")}
        row["anchor_id"] = a["anchor_id"]
        if found_files:
            # parsing of vendor-specific trace formats is out of scope here;
            # record presence and let the modeling step parse them.
            row.update({k: "trace_present" for k in fields[6:]})
            print(f"[lineD] {a['anchor_id']}: {len(found_files)} trace file(s)")
        else:
            row.update({k: "" for k in fields[6:]})
            print(f"[lineD] {a['anchor_id']}: NO trace found")
        rows.append(row)

    with open(out_csv, "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=fields)
        w.writeheader()
        w.writerows(rows)

    found = [r for r in rows if r["total_comm_ms"]]
    print(f"\n[lineD] trace coverage: {len(found)}/{len(rows)} anchors")
    if not found:
        print("[lineD] NO historical HCCL trace exists; F1-F4 traces from line A "
              "are REQUIRED as replacement (see requirements doc section 5.2).")
    else:
        axes = {
            "PP=1 anchor": any(r["p"] == 1 for r in found),
            "PP>1 anchor": any(r["p"] > 1 for r in found),
            "SP=0 anchor": any(r["sp"] == 0 for r in found),
            "SP=1 anchor": any(r["sp"] == 1 for r in found),
            "TP=2": any(r["t"] == 2 for r in found),
            "TP=4": any(r["t"] == 4 for r in found),
            "TP=8": any(r["t"] == 8 for r in found),
        }
        for k, v in axes.items():
            print(f"[lineD] coverage {k}: {'YES' if v else 'NO'}")
    print(f"[lineD] wrote {out_csv}")


if __name__ == "__main__":
    main()
