# 线 D：历史 HCCL trace 汇总（纯计算，最先跑）

- `python3 summarize_historical_hccl.py ../configs/lineD_historical.json historical_hccl_trace_summary.csv`
- 扫描 search_roots 下各锚点的 hccl_trace/，输出覆盖度报告
- 若无历史 trace（预期如此），输出空表并在日志中明确报告，由线 A 的 F1-F4 trace 替代
