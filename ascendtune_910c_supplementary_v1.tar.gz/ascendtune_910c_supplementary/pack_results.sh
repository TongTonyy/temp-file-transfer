#!/bin/bash
# Pack per-line raw results into the deliverable tarballs named by the
# requirements doc. git push on the server usually has no credentials --
# upload the tarballs via the GitHub release-asset flow instead.
set -u
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$SCRIPT_DIR"

pack() {
  local name=$1; shift
  local items=()
  for p in "$@"; do [ -e "$p" ] && items+=("$p"); done
  tar czf "$name" "${items[@]}" 2>/dev/null && echo "[pack] $name ($(du -h "$name" | cut -f1))" || echo "[pack] $name: nothing to pack"
}

pack p0b_anchors_raw.tar.gz lineA/results_p0b_anchors configs/lineA_anchors.json lineA/run_p0b_anchors.sh lineA/validate_anchor.py lineA/README.md known_issues.md
pack p1_comm_microbench_raw.tar.gz lineB/results_p1_comm configs/lineB_comm.json lineB/p1_comm_bench_910c.py lineB/run_p1_comm.sh lineB/fit_p1_tables.py lineB/README.md known_issues.md
pack rho_kernel_microbench_raw.tar.gz lineC/results_rho_kernel configs/lineC_rho_kernel.json lineC/rho_kernel_bench_910c.py lineC/run_rho_kernel.sh lineC/README.md known_issues.md

if [ -f lineD/historical_hccl_trace_summary.csv ]; then
  echo "[pack] lineD/historical_hccl_trace_summary.csv (plain csv, no tar needed)"
fi
cp -f self_check_report.json self_check_report_latest.json 2>/dev/null || true
echo "[done]"
