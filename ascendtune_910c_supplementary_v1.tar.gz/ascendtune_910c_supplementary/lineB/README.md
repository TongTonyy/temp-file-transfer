# 线 B：P1 通信 microbench（最高优先级）

- 配置：`../configs/lineB_comm.json`（q 表 / P2P / s_overlap 全部参数显式列出）
- 运行：`bash run_p1_comm.sh`；单跑一个 sweep：`ONLY=q_table|p2p_table|s_overlap bash run_p1_comm.sh`
- 输出：`results_p1_comm/`（*_raw.csv + q_table.csv / p2p_table.csv / s_overlap_table.csv）
- BW_theoretical 默认 392 GB/s（HCCS 规格占位），与实际不符时改 configs/lineB_comm.json 的 bw_theoretical_gbps 后重跑 fit_p1_tables.py 即可，无需重测
