#!/usr/bin/env python3
"""Assemble final line-B tables from raw microbench CSVs.

Inputs (in OUT_ROOT):
  q_table_raw.csv, p2p_table_raw.csv, s_overlap_raw.csv

Outputs (in OUT_ROOT):
  q_table.csv        op, group_size, msg_size, BW_actual_GBps, BW_theoretical_GBps, q, alpha_ms
  p2p_table.csv      msg_size, alpha_ms, beta_GBps, q_p2p, measured_ms
  s_overlap_table.csv (as spec'd in the requirements, plus serialized_suspect)
"""
from __future__ import annotations

import csv
import json
import os
import sys


def read_rows(path):
    if not os.path.exists(path):
        return []
    with open(path, newline="", encoding="utf-8") as f:
        return list(csv.DictReader(f))


def write_rows(path, rows, fields):
    with open(path, "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=fields)
        w.writeheader()
        w.writerows(rows)
    print(f"[fit] wrote {path} ({len(rows)} rows)")


def fit_q_table(out_root, bw_theo):
    raw = read_rows(os.path.join(out_root, "q_table_raw.csv"))
    if not raw:
        print("[fit] q_table_raw.csv missing, skipped")
        return
    # alpha per (op, group_size): latency of the smallest message
    alpha = {}
    for r in raw:
        key = (r["op"], int(r["group_size"]))
        ms = float(r["avg_s"]) * 1e3
        size = int(r["msg_size_bytes"])
        if key not in alpha or size < alpha[key][0]:
            alpha[key] = (size, ms)
    rows = []
    for r in raw:
        key = (r["op"], int(r["group_size"]))
        bw = float(r["BW_actual_GBps"])
        rows.append({
            "op": r["op"], "group_size": r["group_size"],
            "msg_size": r["msg_size_bytes"],
            "BW_actual_GBps": r["BW_actual_GBps"],
            "BW_theoretical_GBps": bw_theo,
            "q": round(bw_theo / bw, 4) if bw > 0 else "",
            "alpha_ms": round(alpha[key][1], 6),
        })
    write_rows(os.path.join(out_root, "q_table.csv"), rows,
               ["op", "group_size", "msg_size", "BW_actual_GBps", "BW_theoretical_GBps", "q", "alpha_ms"])


def fit_p2p_table(out_root, bw_theo):
    raw = read_rows(os.path.join(out_root, "p2p_table_raw.csv"))
    if not raw:
        print("[fit] p2p_table_raw.csv missing, skipped")
        return
    xs = [int(r["msg_size_bytes"]) for r in raw]          # bytes
    ys = [float(r["avg_s"]) * 1e3 for r in raw]           # ms
    n = len(xs)
    sx, sy = sum(xs), sum(ys)
    sxx = sum(x * x for x in xs)
    sxy = sum(x * y for x, y in zip(xs, ys))
    denom = n * sxx - sx * sx
    slope = (n * sxy - sx * sy) / denom if denom else 0.0   # ms per byte
    alpha_ms = (sy - slope * sx) / n
    beta_gbps = (1.0 / slope) / 1e6 if slope > 0 else 0.0   # bytes/ms -> GB/s
    rows = []
    for r in raw:
        rows.append({
            "msg_size": r["msg_size_bytes"],
            "alpha_ms": round(alpha_ms, 6),
            "beta_GBps": round(beta_gbps, 4),
            "q_p2p": round(bw_theo / beta_gbps, 4) if beta_gbps > 0 else "",
            "measured_ms": round(float(r["avg_s"]) * 1e3, 6),
        })
    write_rows(os.path.join(out_root, "p2p_table.csv"), rows,
               ["msg_size", "alpha_ms", "beta_GBps", "q_p2p", "measured_ms"])


def fit_s_overlap(out_root):
    raw = read_rows(os.path.join(out_root, "s_overlap_raw.csv"))
    if not raw:
        print("[fit] s_overlap_raw.csv missing, skipped")
        return
    fields = ["collective_type", "group_size", "T_gemm_alone_ms", "T_comm_alone_ms",
              "T_gemm_concurrent_ms", "T_comm_concurrent_ms",
              "s_overlap_compute", "s_overlap_comm", "serialized_suspect"]
    write_rows(os.path.join(out_root, "s_overlap_table.csv"),
               [{k: r[k] for k in fields} for r in raw], fields)
    # sanity: s_overlap_compute == s_overlap_comm everywhere is suspicious
    same = all(abs(float(r["s_overlap_compute"]) - float(r["s_overlap_comm"])) < 1e-3 for r in raw)
    if same:
        print("[fit][WARNING] s_overlap_compute == s_overlap_comm for ALL rows; "
              "verify with HCCL trace that GEMM and comm truly overlapped "
              "(GEMM too fast / comm serialized).")


def main():
    out_root, cfg_path = sys.argv[1], sys.argv[2]
    with open(cfg_path, encoding="utf-8") as f:
        cfg = json.load(f)
    bw_theo = float(cfg["bw_theoretical_gbps"])
    fit_q_table(out_root, bw_theo)
    fit_p2p_table(out_root, bw_theo)
    fit_s_overlap(out_root)


if __name__ == "__main__":
    main()
