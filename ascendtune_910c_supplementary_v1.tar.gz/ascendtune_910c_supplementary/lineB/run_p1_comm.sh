#!/bin/bash
# Line B driver: q_table / p2p_table / s_overlap. Runs on 16 NPUs via torchrun.
# Each sub-benchmark is a separate torchrun call -> independent and re-runnable.
#
# Usage:  bash run_p1_comm.sh                 # all three
#         ONLY=s_overlap bash run_p1_comm.sh  # just one
set -u
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
PKG_DIR="$(cd "$SCRIPT_DIR/.." && pwd)"
# shellcheck disable=SC1091
source "$PKG_DIR/common_env.sh"

OUT_ROOT=${OUT_ROOT:-$SCRIPT_DIR/results_p1_comm}
CFG="$PKG_DIR/configs/lineB_comm.json"
BENCH="$SCRIPT_DIR/p1_comm_bench_910c.py"
PORT=${BASE_PORT:-9100}
mkdir -p "$OUT_ROOT"

run_mode() {
  local mode=$1
  local raw="$OUT_ROOT/${mode}_raw.csv"
  local dir="$OUT_ROOT/${mode}"
  PORT=$((PORT + 1))
  mkdir -p "$dir"
  echo "======================================================================"
  echo "[$(date '+%F %T')] lineB mode=$mode (port $PORT)"
  echo "======================================================================"
  torchrun \
    --nproc_per_node "$NPUS_PER_NODE" \
    --nnodes 1 \
    --node_rank 0 \
    --master_addr "$MASTER_ADDR" \
    --master_port "$PORT" \
    "$BENCH" --mode "$mode" --config "$CFG" --out "$raw" \
    > "$dir/run.log" 2>&1
  local rc=$?
  echo "$rc" > "$dir/exit_code.txt"
  if [ "$rc" != "0" ]; then
    echo "[warn] mode=$mode rc=$rc; retrying once after 90s (HCCL port release)"
    sleep 90
    PORT=$((PORT + 1))
    torchrun \
      --nproc_per_node "$NPUS_PER_NODE" \
      --nnodes 1 \
      --node_rank 0 \
      --master_addr "$MASTER_ADDR" \
      --master_port "$PORT" \
      "$BENCH" --mode "$mode" --config "$CFG" --out "$raw" \
      > "$dir/run_retry.log" 2>&1
    rc=$?
    echo "$rc" > "$dir/exit_code.txt"
  fi
  [ "$rc" = "0" ] && echo "PASS" > "$dir/run_status.txt" || echo "FAIL rc=$rc" > "$dir/run_status.txt"
  cat "$dir/run_status.txt"
  sleep 20  # HCCL port release between modes
}

for mode in q_table p2p_table s_overlap; do
  if [ -n "${ONLY:-}" ] && [ "$ONLY" != "$mode" ]; then continue; fi
  run_mode "$mode"
done

# fit / assemble final tables (pure python, rank-free)
python3 "$SCRIPT_DIR/fit_p1_tables.py" "$OUT_ROOT" "$CFG"
echo "[done] results in $OUT_ROOT"
