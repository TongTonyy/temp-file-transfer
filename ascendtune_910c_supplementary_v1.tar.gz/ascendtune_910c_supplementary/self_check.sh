#!/bin/bash
# Dry-run self check for the whole supplementary package.
# Writes self_check_report.json; exits 0 only if all checks pass.
# Run BEFORE any collection:  bash self_check.sh
set -u
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
# shellcheck disable=SC1091
source "$SCRIPT_DIR/common_env.sh"

python3 - "$SCRIPT_DIR" <<'PY'
import json, os, shutil, subprocess, sys

pkg = sys.argv[1]
report = {"checks": [], "passed": True}

def check(name, ok, detail=""):
    report["checks"].append({"name": name, "ok": bool(ok), "detail": detail})
    if not ok:
        report["passed"] = False
    print(f"[{'OK' if ok else 'FAIL'}] {name} {detail}")

# 1. python env (the #1 historical pitfall: system python3.9 breaks everything)
v = sys.version_info
check("python>=3.10", v >= (3, 10), f"running {v.major}.{v.minor}")
torchrun = shutil.which("torchrun") or ""
check("torchrun in llm_env", "llm_env" in torchrun, torchrun or "torchrun not found")

try:
    import torch_npu  # noqa
    check("torch_npu importable", True)
except Exception as e:
    check("torch_npu importable", False, str(e))

# 2. paths
msllm = os.environ.get("MSLLM_DIR", "/root/MindSpeed-LLM")
check("MSLLM_DIR exists", os.path.isdir(msllm), msllm)
for key, default in [("DATA_PATH", None), ("TOKENIZER_PATH", None), ("CKPT_WEIGHTS_DIR", None)]:
    p = os.environ.get(key, default)
    check(f"{key} exists", bool(p) and os.path.exists(p), str(p))

# 3. checkpoints required by line A anchors
cfg = json.load(open(os.path.join(pkg, "configs", "lineA_anchors.json")))
ckpt_root = os.environ.get("CKPT_WEIGHTS_DIR", os.path.join(msllm, "model_weights"))
world = int(os.environ.get("NPUS_PER_NODE", "16"))
for a in cfg["anchors"]:
    tp, pp = a["tp"], a["pp"]
    dp = world // (pp * tp)
    name = f"qwen3_mcore-{tp}TP{dp}DP" if tp > 1 else (f"qwen3_mcore-{pp}PP{dp}DP" if pp > 1 else f"qwen3_mcore-{dp}DP")
    ok = os.path.isdir(os.path.join(ckpt_root, name))
    check(f"ckpt for {a['name']} ({name})", ok)

# 4. scripts parse
import py_compile, glob
for f in glob.glob(os.path.join(pkg, "**", "*.py"), recursive=True):
    try:
        py_compile.compile(f, doraise=True)
        check(f"py_compile {os.path.relpath(f, pkg)}", True)
    except Exception as e:
        check(f"py_compile {os.path.relpath(f, pkg)}", False, str(e))

with open(os.path.join(pkg, "self_check_report.json"), "w", encoding="utf-8") as f:
    json.dump(report, f, indent=2, ensure_ascii=False)
print("[self-check] report ->", os.path.join(pkg, "self_check_report.json"))
sys.exit(0 if report["passed"] else 1)
PY
