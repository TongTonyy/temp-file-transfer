# 线 C：rho kernel microbench（可选）

- 单卡运行，不依赖分布式：`bash run_rho_kernel.sh`（`DEVICE_ID=n` 换卡）
- 输出：`results_rho_kernel/rho_kernel_table.csv`
- 注意 impl 列：fused_* 才可与训练场景对标
