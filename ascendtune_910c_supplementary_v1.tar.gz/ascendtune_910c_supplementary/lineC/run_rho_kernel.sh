#!/bin/bash
# Line C driver: rho kernel microbenchmark (optional, single NPU card).
set -u
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
PKG_DIR="$(cd "$SCRIPT_DIR/.." && pwd)"
# shellcheck disable=SC1091
source "$PKG_DIR/common_env.sh"

OUT_ROOT=${OUT_ROOT:-$SCRIPT_DIR/results_rho_kernel}
mkdir -p "$OUT_ROOT"

python3 "$SCRIPT_DIR/rho_kernel_bench_910c.py" \
  --config "$PKG_DIR/configs/lineC_rho_kernel.json" \
  --out "$OUT_ROOT/rho_kernel_table.csv" \
  --device-id "${DEVICE_ID:-0}" 2>&1 | tee "$OUT_ROOT/run.log"

echo "[done] results in $OUT_ROOT"
