#!/usr/bin/env python3
"""Line C (optional): rho kernel microbenchmark, single NPU card.

Measures per-kernel forward time for the shapes that the F1-F4 anchors cover.
Fused torch_npu implementations are used when available; the `impl` column
records what actually ran (`fused_*` vs `ref_*`) so systematic rho offsets
are traceable.

recompute=1 measures forward + recomputed forward (2x forward), per the
requirements -- NOT forward+backward.
"""
from __future__ import annotations

import argparse
import csv
import json
import os
import statistics

import torch
import torch_npu  # noqa: F401


def sync():
    torch.npu.synchronize()


def bench(fn, warmup, iters, repeats):
    for _ in range(warmup):
        fn()
    torch.npu.synchronize()
    reps = []
    for _ in range(repeats):
        import time
        t0 = time.perf_counter()
        for _ in range(iters):
            fn()
        sync()
        reps.append((time.perf_counter() - t0) / iters)
    return statistics.median(reps)


def flops_gemm(rows, k, n):
    return 2 * rows * k * n


def make_kernel(ktype, b, s, h, t, dims):
    """Return (fn, flops, impl). t slices hidden/head dims (single card, no comm)."""
    tokens = b * s
    h = dims["hidden"] // t
    ffn = dims["ffn_hidden"] // t
    dev = "npu"
    if ktype == "gemm_mha_qkv":
        x = torch.randn(tokens, dims["hidden"], device=dev, dtype=torch.bfloat16)
        w = torch.randn(dims["hidden"], 3 * h, device=dev, dtype=torch.bfloat16)
        return (lambda: torch.matmul(x, w)), flops_gemm(tokens, dims["hidden"], 3 * h), "matmul"
    if ktype == "gemm_mlp_up":
        x = torch.randn(tokens, dims["hidden"], device=dev, dtype=torch.bfloat16)
        w = torch.randn(dims["hidden"], ffn, device=dev, dtype=torch.bfloat16)
        return (lambda: torch.matmul(x, w)), flops_gemm(tokens, dims["hidden"], ffn), "matmul"
    if ktype == "gemm_mlp_down":
        x = torch.randn(tokens, ffn, device=dev, dtype=torch.bfloat16)
        w = torch.randn(ffn, dims["hidden"], device=dev, dtype=torch.bfloat16)
        return (lambda: torch.matmul(x, w)), flops_gemm(tokens, ffn, dims["hidden"]), "matmul"
    if ktype == "flash_attention":
        heads = dims["num_attention_heads"] // t
        d = dims["head_dim"]
        q = torch.randn(b, heads, s, d, device=dev, dtype=torch.bfloat16)
        kk = torch.randn(b, dims["num_query_groups"] // t, s, d, device=dev, dtype=torch.bfloat16)
        v = torch.randn_like(kk)
        kk = kk.repeat_interleave(heads // dims["num_query_groups"], dim=1)
        v = v.repeat_interleave(heads // dims["num_query_groups"], dim=1)
        fl = 4 * b * heads * s * s * d  # fwd only
        if hasattr(torch.nn.functional, "scaled_dot_product_attention"):
            def fn():
                torch.nn.functional.scaled_dot_product_attention(q, kk, v)
            return fn, fl, "sdpa"
        return None, fl, "unavailable"
    if ktype == "rmsnorm":
        x = torch.randn(tokens, h, device=dev, dtype=torch.bfloat16)
        w = torch.randn(h, device=dev, dtype=torch.bfloat16)
        eps = 1e-6
        fused = getattr(torch_npu, "npu_rms_norm", None)
        if fused is not None:
            return (lambda: fused(x, w, epsilon=eps)), 8 * tokens * h, "fused_rms_norm"
        def ref():
            var = x.float().pow(2).mean(-1, keepdim=True)
            return (x.float() * torch.rsqrt(var + eps) * w.float()).to(torch.bfloat16)
        return ref, 8 * tokens * h, "ref_rmsnorm"
    if ktype == "swiglu":
        x = torch.randn(tokens, 2 * ffn, device=dev, dtype=torch.bfloat16)
        fused = getattr(torch_npu, "npu_swiglu", None)
        if fused is not None:
            return (lambda: fused(x, dim=-1)), 6 * tokens * ffn, "fused_swiglu"
        def ref():
            a, bb = x.chunk(2, dim=-1)
            return torch.nn.functional.silu(a) * bb
        return ref, 6 * tokens * ffn, "ref_swiglu"
    if ktype == "lmhead":
        x = torch.randn(tokens, dims["hidden"], device=dev, dtype=torch.bfloat16)
        w = torch.randn(dims["hidden"], dims["vocab"], device=dev, dtype=torch.bfloat16)
        return (lambda: torch.matmul(x, w)), flops_gemm(tokens, dims["hidden"], dims["vocab"]), "matmul"
    raise ValueError(ktype)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--device-id", type=int, default=0)
    args = ap.parse_args()

    with open(args.config, encoding="utf-8") as f:
        cfg = json.load(f)
    dims = cfg["model_dims"]
    torch.npu.set_device(args.device_id)

    kernels = list(cfg["sweep"]["kernel_types"])
    if cfg["sweep"].get("lmhead_optional"):
        kernels.append("lmhead")

    exists = os.path.exists(args.out)
    with open(args.out, "a", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        if not exists:
            w.writerow(["kernel_type", "b", "s", "h", "t", "sp", "recompute",
                        "t_ms", "FLOPs", "rho_inv", "impl", "repeats"])
        total = (len(kernels) * len(cfg["sweep"]["micro_batch"]) * len(cfg["sweep"]["tp"])
                 * len(cfg["sweep"]["sp"]) * len(cfg["sweep"]["recompute"]))
        done = 0
        for kt in kernels:
            for b in cfg["sweep"]["micro_batch"]:
                for t in cfg["sweep"]["tp"]:
                    for sp in cfg["sweep"]["sp"]:
                        for rc in cfg["sweep"]["recompute"]:
                            done += 1
                            fn, fl, impl = make_kernel(kt, b, dims["seq_len"], dims["hidden"], t, dims)
                            if fn is None:
                                w.writerow([kt, b, dims["seq_len"], dims["hidden"], t, sp, rc,
                                            "", fl, "", "unavailable", 0])
                                continue
                            def measured():
                                fn()
                                if rc == 1:
                                    fn()  # recompute = second forward
                            t_med = bench(measured, cfg["warmup"], cfg["iters_per_rep"], cfg["repeats"])
                            t_ms = t_med * 1e3
                            rho_inv = t_ms / (fl / 1e9) if fl else ""  # ms per GFLOP
                            w.writerow([kt, b, dims["seq_len"], dims["hidden"], t, sp, rc,
                                        round(t_ms, 6), fl, round(rho_inv, 9) if rho_inv != "" else "",
                                        impl, cfg["repeats"]])
                            f.flush()
                            if done % 50 == 0:
                                print(f"[rho] {done}/{total}", flush=True)
    print(f"[done] rho kernel table -> {args.out}")


if __name__ == "__main__":
    main()
