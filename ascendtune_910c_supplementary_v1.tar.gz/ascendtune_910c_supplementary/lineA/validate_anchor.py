#!/usr/bin/env python3
"""Per-anchor validation for line A (P0-B).

Checks one anchor result directory and writes validate_report.json +
token_scope_check.json. Also usable in --dry-run mode to verify the output
contract on an existing directory without re-running anything.

Usage:
  python3 validate_anchor.py <anchor_dir> <config_json> <anchor_name>
"""
from __future__ import annotations

import csv
import json
import os
import re
import sys

STEP_MIN, STEP_MAX = 6, 25   # statistical window (warmup steps 1-5 excluded)
EXPECTED_ROWS_TOKENS = 25    # all steps counted (incl. warmup)
EXPECTED_ROWS_STEPS = 20


def load_csv(path):
    with open(path, newline="", encoding="utf-8") as f:
        return list(csv.DictReader(f))


def main():
    anchor_dir, cfg_path, name = sys.argv[1], sys.argv[2], sys.argv[3]
    with open(cfg_path, encoding="utf-8") as f:
        cfg = json.load(f)
    anchor = next(a for a in cfg["anchors"] if a["name"] == name)
    g = cfg["model"]["global_batch"]
    s = cfg["model"]["seq_len"]
    warnings = []
    passed = True

    # ---- step_time.csv: steps 6-25, 20 rows, sane values
    step_rows = load_csv(os.path.join(anchor_dir, "step_time.csv"))
    steps = [int(r["step"]) for r in step_rows]
    if steps != list(range(STEP_MIN, STEP_MAX + 1)):
        passed = False
        warnings.append(f"step_time.csv steps != {STEP_MIN}..{STEP_MAX} contiguous (got {len(steps)} rows)")
    vals = [float(r["step_time_ms"]) for r in step_rows]
    if vals:
        med = sorted(vals)[len(vals) // 2]
        for st, v in zip(steps, vals):
            if v <= 0 or v > 10 * med:
                warnings.append(f"step {st}: step_time_ms={v} anomalous (median {med})")

    # ---- real_tokens.csv: 25 rows, columns match v1/V2
    tok_rows = load_csv(os.path.join(anchor_dir, "real_tokens.csv"))
    if len(tok_rows) != EXPECTED_ROWS_TOKENS:
        passed = False
        warnings.append(f"real_tokens.csv rows={len(tok_rows)}, expected {EXPECTED_ROWS_TOKENS}")
    numels = [int(r["tokens_numel_allranks"]) for r in tok_rows]
    nonpad = [int(r["tokens_nonpad_allranks"]) for r in tok_rows]
    if numels and all(v == 0 for v in numels):
        passed = False
        warnings.append("real_tokens.csv all zero: token hook broken, do NOT treat as valid")

    # ---- token scope check: global vs local shard
    expected_global = g * s
    mean_numel = sum(numels) / len(numels) if numels else 0
    ratio = mean_numel / expected_global if expected_global else 0
    if abs(ratio - 1.0) < 0.15:
        scope = "global"
        note = "token count covers the full global batch"
    elif abs(ratio - 1.0 / anchor["pp"]) < 0.15:
        scope = "local_shard"
        note = f"token count ~1/pp={anchor['pp']} of global; record only, do NOT correct here"
    elif abs(ratio - 1.0 / (anchor["pp"] * anchor["tp"])) < 0.15:
        scope = "local_shard"
        note = f"token count ~1/(pp*tp)={anchor['pp']*anchor['tp']} of global; record only"
    else:
        scope = "unknown"
        note = f"ratio={ratio:.4f} matches neither global nor 1/pp nor 1/(pp*tp)"
    mean_nonpad = sum(nonpad) / len(nonpad) if nonpad else 0
    token_scope = {
        "config_name": name,
        "raw_tokens_effective": round(mean_nonpad, 1),
        "expected_global_tokens": expected_global,
        "ratio": round(ratio, 4),
        "scope": scope,
        "note": note,
    }
    with open(os.path.join(anchor_dir, "token_scope_check.json"), "w", encoding="utf-8") as f:
        json.dump(token_scope, f, indent=2, ensure_ascii=False)

    # ---- power_mem.csv: columns match sampler v1/V2; power within bounds
    pm_path = os.path.join(anchor_dir, "power_mem.csv")
    if os.path.exists(pm_path):
        pm = load_csv(pm_path)
        cols = list(pm[0].keys()) if pm else []
        if cols != ["ts_unix", "card", "power_w", "die0_hbm_used_mb", "die1_hbm_used_mb"]:
            warnings.append(f"power_mem.csv columns differ from v1/V2: {cols}")
        lo = cfg["power_bounds"]["p_idle_min_w"]
        hi = cfg["power_bounds"]["p_max_w"]
        bad = [r for r in pm if r["power_w"] and not (lo <= float(r["power_w"]) <= hi)]
        if bad:
            warnings.append(f"{len(bad)} power samples outside [{lo}, {hi}] W")
        if len(pm) < 10:
            warnings.append(f"power_mem.csv only {len(pm)} samples; sampler may have died early")
    else:
        passed = False
        warnings.append("power_mem.csv missing")

    # ---- hccl_trace presence
    trace_dir = os.path.join(anchor_dir, "hccl_trace")
    trace_files = []
    if os.path.isdir(trace_dir):
        for root, _, files in os.walk(trace_dir):
            trace_files += [os.path.join(root, x) for x in files if not x.endswith("TRACE_UNAVAILABLE.txt")]
    if not trace_files:
        warnings.append("hccl_trace/ empty: trace unavailable on this stack, see known_issues.md")

    report = {"config_name": name, "passed": passed, "warnings": warnings, "token_scope": scope}
    with open(os.path.join(anchor_dir, "validate_report.json"), "w", encoding="utf-8") as f:
        json.dump(report, f, indent=2, ensure_ascii=False)
    print(json.dumps(report, ensure_ascii=False))
    return 0 if passed else 1


if __name__ == "__main__":
    sys.exit(main())
