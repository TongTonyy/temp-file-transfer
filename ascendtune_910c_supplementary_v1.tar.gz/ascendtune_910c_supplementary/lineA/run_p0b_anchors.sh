#!/bin/bash
# Line A: P0-B new training anchors (F1-F4 required, F1b/F3b optional).
# Config source of truth: ../configs/lineA_anchors.json (parsed at runtime;
# nothing is hardcoded here except paths).
#
# Usage:
#   bash run_p0b_anchors.sh                 # required 4 anchors only
#   RUN_OPTIONAL=1 bash run_p0b_anchors.sh  # all 6
set -u
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
PKG_DIR="$(cd "$SCRIPT_DIR/.." && pwd)"
# shellcheck disable=SC1091
source "$PKG_DIR/common_env.sh"

CFG="$PKG_DIR/configs/lineA_anchors.json"
OUT_ROOT=${OUT_ROOT:-$SCRIPT_DIR/results_p0b_anchors}
ENTRY=${ENTRY:-posttrain_gpt_lab_v3.py}
BASE_PORT=${BASE_PORT:-9600}
mkdir -p "$OUT_ROOT"

# deploy the PROVEN token-counting wrapper (loss_func class-hook version,
# validated 2026-11-08: module-level forward hooks never install on this
# MindSpeed-LLM and silently yield all-zero real_tokens.csv)
cat "$SCRIPT_DIR/$ENTRY" > "$MSLLM_DIR/$ENTRY" || { echo "[error] deploy wrapper failed"; exit 2; }

zero_args() {
  python3 - "$CFG" "$1" <<'PY'
import json, sys
cfg = json.load(open(sys.argv[1]))
print(cfg["zero_flag_bundles"][sys.argv[2]])
PY
}

extract_step_times() {
  python3 - "$1/train.log" "$1/step_time.csv" <<'PY'
import re, sys
log, out = sys.argv[1], sys.argv[2]
pat = re.compile(r"\[(\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2})\]\s*iteration\s+(\d+)/.*?elapsed time per iteration \(ms\):\s*([0-9.]+)")
rows = []
for line in open(log, errors="ignore"):
    m = pat.search(line)
    if m:
        rows.append((int(m.group(2)), float(m.group(3)), m.group(1)))
with open(out, "w") as f:
    f.write("step,step_time_ms,timestamp\n")
    for step, ms, ts in rows:
        if 6 <= step <= 25:   # statistical window: warmup steps 1-5 excluded
            f.write(f"{step},{ms},{ts}\n")
PY
}

run_attempt() {
  # args: name pp tp dp mb sp recompute zero_args port attempt
  local name=$1 pp=$2 tp=$3 dp=$4 mb=$5 sp=$6 recompute=$7 zargs=$8 port=$9 attempt=${10}
  local dir="$OUT_ROOT/$name"
  local ckpt="$CKPT_WEIGHTS_DIR/$(ckpt_name "$tp" "$pp" "$dp")"
  mkdir -p "$dir" "$dir/hccl_trace"
  local extra="$zargs"
  [ "$sp" = "1" ] && extra="$extra --sequence-parallel"
  case "$recompute" in
    full) extra="$extra --recompute-granularity full --recompute-method uniform --recompute-num-layers 1" ;;
    off) : ;;
    *) echo "[error] unknown recompute=$recompute"; return 3 ;;
  esac

  cat > "$dir/launch.sh" <<EOF
#!/bin/bash
source "$PKG_DIR/common_env.sh"
cd "$MSLLM_DIR"
export TOK_OUT="$dir/real_tokens.csv"
export TP_SIZE_FALLBACK=$tp
export HCCL_TRACE=1
export HCCL_TRACE_DIR="$dir/hccl_trace"
torchrun \\
  --nproc_per_node "$NPUS_PER_NODE" \\
  --nnodes 1 \\
  --node_rank 0 \\
  --master_addr "$MASTER_ADDR" \\
  --master_port "$port" \\
  "$ENTRY" \\
  \$(base_qwen_args "$pp" "$tp" "$mb" "$ckpt") \\
  $extra
EOF
  chmod +x "$dir/launch.sh"

  echo "======================================================================"
  echo "[$(date '+%F %T')] anchor=$name attempt=$attempt pp=$pp tp=$tp dp=$dp mb=$mb sp=$sp recompute=$recompute zargs=[$zargs] port=$port"
  echo "======================================================================"
  SAMPLE_INTERVAL_SEC=${SAMPLE_INTERVAL_SEC:-1} bash "$PKG_DIR/sampler_power_mem.sh" "$dir/power_mem.csv" &
  local sampler_pid=$!
  sleep 5
  (cd "$dir" && bash launch.sh > "train_attempt${attempt}.log" 2>&1)
  local rc=$?
  cp "$dir/train_attempt${attempt}.log" "$dir/train.log"
  sleep 3
  kill "$sampler_pid" 2>/dev/null || true
  wait "$sampler_pid" 2>/dev/null || true
  echo "$rc" > "$dir/exit_code.txt"
  return "$rc"
}

token_rows() {
  local f="$1/real_tokens.csv"
  [ -f "$f" ] && echo $(( $(wc -l < "$f") - 1 )) || echo 0
}

run_anchor() {
  local name=$1 pp=$2 tp=$3 dp=$4 mb=$5 sp=$6 z=$7 recompute=$8
  local dir="$OUT_ROOT/$name"
  local ckpt="$CKPT_WEIGHTS_DIR/$(ckpt_name "$tp" "$pp" "$dp")"
  local iters=${TRAIN_ITERS:-25}
  mkdir -p "$dir"

  if [ ! -d "$ckpt" ]; then
    echo "[warn] $name SKIPPED: checkpoint dir missing: $ckpt"
    echo "FAIL missing_ckpt" > "$dir/run_status.txt"
    return 0
  fi

  local zargs; zargs="$(zero_args "$z")"
  local port=$(( BASE_PORT + RANDOM % 500 ))
  local attempt rc
  for attempt in 1 2; do
    run_attempt "$name" "$pp" "$tp" "$dp" "$mb" "$sp" "$recompute" "$zargs" "$port" "$attempt"
    rc=$?
    if [ "$rc" = "0" ] && [ "$(token_rows "$dir")" = "$iters" ]; then
      break
    fi
    echo "[warn] $name attempt $attempt failed (rc=$rc token_rows=$(token_rows "$dir")); waiting 90s for HCCL release"
    pkill -f torchrun 2>/dev/null; sleep 90
    port=$((port + 100))
  done

  # F4 (z=3) OOM fallback: one extra attempt with sp off (p/t/d/b unchanged)
  if [ "$rc" != "0" ] && [ "$name" = "F4" ] && [ "$sp" = "1" ] && grep -qi "out of memory" "$dir/train.log"; then
    echo "[warn] F4 OOM with sp=1; extra attempt with sp=0 (allowed by requirements)"
    run_attempt "$name" "$pp" "$tp" "$dp" "$mb" 0 "$recompute" "$zargs" $((port + 100)) 3
    rc=$?
    echo "oom_sp_off_retry=1" >> "$dir/config_note.txt"
  fi

  extract_step_times "$dir"
  if [ -z "$(ls -A "$dir/hccl_trace" 2>/dev/null)" ]; then
    echo "HCCL trace not produced by HCCL_TRACE=1 on this stack; see known_issues.md (line A, item 6)" \
      > "$dir/hccl_trace/TRACE_UNAVAILABLE.txt"
  fi
  python3 "$SCRIPT_DIR/validate_anchor.py" "$dir" "$CFG" "$name" > "$dir/validate_stdout.txt" 2>&1

  if [ "$rc" = "0" ] && [ "$(token_rows "$dir")" = "$iters" ]; then
    echo "PASS rc=0 tok_rows_ok" > "$dir/run_status.txt"
  else
    echo "FAIL rc=$rc token_rows=$(token_rows "$dir")" > "$dir/run_status.txt"
  fi
  cat "$dir/run_status.txt"
}

# ---- main loop over JSON configs (required first; optional only if RUN_OPTIONAL=1)
python3 - "$CFG" <<'PY' > "$OUT_ROOT/anchors_to_run.tsv"
import json, sys
cfg = json.load(open(sys.argv[1]))
for a in cfg["anchors"]:
    print("\t".join([a["name"], str(a["pp"]), str(a["tp"]), str(a["dp"]),
                     str(a["micro_batch"]), str(a["sp"]), str(a["z"]),
                     a["recompute"], "1" if a["required"] else "0"]))
PY

first=1
while IFS=$'\t' read -r name pp tp dp mb sp z recompute required; do
  if [ "$required" != "1" ] && [ "${RUN_OPTIONAL:-0}" != "1" ]; then
    echo "[skip] $name (optional; set RUN_OPTIONAL=1 to include)"
    continue
  fi
  if [ "$first" = "0" ]; then
    sleep 60  # let HCCL ports/processes from the previous anchor fully release
  fi
  first=0
  run_anchor "$name" "$pp" "$tp" "$dp" "$mb" "$sp" "$z" "$recompute"
done < "$OUT_ROOT/anchors_to_run.tsv"

echo "[done] results in $OUT_ROOT"
