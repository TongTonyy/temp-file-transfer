# 线 A：P0-B 新训练锚点

- 配置：`../configs/lineA_anchors.json`（F1-F4 必采，F1b/F3b 可选）
- 运行：`bash run_p0b_anchors.sh`（可选锚点加 `RUN_OPTIONAL=1`）
- 输出：`results_p0b_anchors/<anchor>/`（step_time.csv / real_tokens.csv / power_mem.csv / token_scope_check.json / validate_report.json / hccl_trace/）
- 失败策略：自动 retry 1 次（等 90s 换端口）；F4 OOM 追加 sp=0 一次；仍失败标 FAIL 继续下一组
- 预计：每组 50-70 分钟
