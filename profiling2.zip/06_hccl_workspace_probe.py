# 06_hccl_workspace_probe.py — HCCL 通信缓冲（workspace）显存占用实测
# 背景：ground truth cfg_02/12（d=8 大通信组）在 HcclReduceScatter 上分配 420MB
#       缓冲失败。HCCL workspace 不进 torch allocator、不出现在任何解析显存公式，
#       是 L2 剪枝必须量化的隐式显存项。
# 方法：torch.npu.mem_get_info() 读"设备级"空闲显存（含 HCCL 自己的分配），
#       在每个 (组规模, 算子, 消息量) 首次集合通信前后取差值。
# 用法：torchrun --nproc_per_node=16 06_hccl_workspace_probe.py
#       （需要整机 16 rank；输出 profiling_out/hccl_workspace.csv）
import os
import csv
import torch
import torch.distributed as dist
import torch_npu  # noqa: F401

OPS = ["all_reduce", "reduce_scatter", "all_gather"]
MSG_MB = [64, 256, 1024]
GROUP_SIZES = [2, 4, 8, 16]


def free_mb():
    free, _ = torch.npu.mem_get_info()
    return free / 1024 / 1024


def run_op(op, buf, group):
    gs = dist.get_world_size(group)
    if op == "all_reduce":
        dist.all_reduce(buf, group=group)
    elif op == "reduce_scatter":
        out = torch.empty(buf.numel() // gs, device=buf.device, dtype=buf.dtype)
        dist.reduce_scatter_tensor(out, buf, group=group)
    elif op == "all_gather":
        out = torch.empty(buf.numel() * gs, device=buf.device, dtype=buf.dtype)
        dist.all_gather_into_tensor(out, buf, group=group)


def main():
    dist.init_process_group(backend="hccl")
    rank = dist.get_rank()
    world = dist.get_world_size()
    torch.npu.set_device(rank)
    dev = f"npu:{rank}"

    rows = []
    for gs in GROUP_SIZES:
        if gs > world:
            continue
        # 连续块分组（与真实 TP/DP 组一致）
        groups = []
        for start in range(0, world, gs):
            members = list(range(start, start + gs))
            groups.append((members, dist.new_group(members)))
        my = next((g for m, g in groups if rank in m), None)
        dist.barrier()
        for op in OPS:
            for mb in MSG_MB:
                numel = mb * 1024 * 1024 // 2  # bf16
                buf = torch.randn(numel, device=dev, dtype=torch.bfloat16)
                torch.npu.synchronize()
                dist.barrier()
                before = free_mb()
                try:
                    run_op(op, buf, my)   # 首次：触发 HCCL workspace 分配
                    torch.npu.synchronize()
                    run_op(op, buf, my)   # 二次：确认已分配完毕
                    torch.npu.synchronize()
                    after = free_mb()
                    delta = before - after
                except RuntimeError as e:
                    delta = -1
                    print(f"[rank{rank}] {op} gs={gs} msg={mb}MB FAILED: {str(e)[:80]}",
                          flush=True)
                    torch.npu.empty_cache()
                rows.append([gs, op, mb, round(before, 1), round(after, 1), round(delta, 1)])
                if rank == 0:
                    print(rows[-1], flush=True)
                del buf
                torch.npu.empty_cache()
                dist.barrier()

    if rank == 0:
        os.makedirs("profiling_out", exist_ok=True)
        with open("profiling_out/hccl_workspace.csv", "w", newline="") as fo:
            w = csv.writer(fo)
            w.writerow(["group_size", "op", "msg_mb",
                        "free_before_mb", "free_after_mb", "hccl_delta_mb"])
            w.writerows(rows)
        print("done -> profiling_out/hccl_workspace.csv")
    dist.destroy_process_group()


if __name__ == "__main__":
    main()
