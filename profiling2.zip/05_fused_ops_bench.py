# 05_fused_ops_bench.py — Qwen3-14B 融合算子耗时采集（单 rank 可跑）
# 目的：01 脚本测的是"散装" linear/bmm，实际训练走融合算子。
#       本脚本补齐白盒模型真正需要的三类融合路径：
#   A) npu_fusion_attention（GQA: 40 Q 头 / 8 KV 头，head_dim=128，s=4096）
#   B) LM head 全链路：vocab 投影(5120->151936) + cross_entropy（词表是 Llama2 的 3 倍）
#   C) 逐元素算子：RMSNorm / SwiGLU（memory-bound，按 t 切分后的形状）
# 用法：python 05_fused_ops_bench.py   （输出 profiling_out/fused_ops_qwen3.csv）
import os
import csv
import torch
import torch_npu  # noqa: F401

H, FFN, V = 5120, 17408, 151936
N_HEAD, N_KV, HEAD_DIM = 40, 8, 128
S = 4096
WARMUP, REPEAT = 5, 20


def timed(fn, backward=False):
    """fn() 返回标量 loss（backward=True 时）或 None。返回 ms/次。"""
    for _ in range(WARMUP):
        out = fn()
        if backward and out is not None:
            out.backward()
    torch.npu.synchronize()
    s_ev, e_ev = torch.npu.Event(True), torch.npu.Event(True)
    s_ev.record()
    for _ in range(REPEAT):
        out = fn()
        if backward and out is not None:
            out.backward()
    e_ev.record()
    torch.npu.synchronize()
    return s_ev.elapsed_time(e_ev) / REPEAT


rows = []


def rec(name, t, b, detail, fwd, fb):
    rows.append([name, t, b, detail, round(fwd, 4), round(fb, 4)])
    print(rows[-1], flush=True)


# ---------- A) 融合注意力（GQA） ----------
def bench_fa(t, b, dev):
    hq, hkv = N_HEAD // t, N_KV // t
    # BSH 布局：q (B,S,hq*D)，k/v (B,S,hkv*D)
    q = torch.randn(b, S, hq * HEAD_DIM, device=dev, dtype=torch.bfloat16, requires_grad=True)
    k = torch.randn(b, S, hkv * HEAD_DIM, device=dev, dtype=torch.bfloat16, requires_grad=True)
    v = torch.randn(b, S, hkv * HEAD_DIM, device=dev, dtype=torch.bfloat16, requires_grad=True)

    def fwd_only():
        out = torch_npu.npu_fusion_attention(
            q, k, v, hq, "BSH",
            scale=1.0 / (HEAD_DIM ** 0.5),
            keep_prob=1.0, pre_tockens=2147483647, next_tockens=0)  # 全因果
        return out[0].sum()

    fwd = timed(fwd_only, backward=True)          # 含 fwd+bwd 的总时长
    # 单独 fwd：不求导
    with torch.no_grad():
        f_only = timed(lambda: torch_npu.npu_fusion_attention(
            q, k, v, hq, "BSH", scale=1.0,
            keep_prob=1.0, pre_tockens=2147483647, next_tockens=0)[0])
    return f_only, fwd - f_only


# ---------- B) LM head：投影 + CE ----------
def bench_lmhead(t, b, dev):
    tokens = b * S
    w = torch.randn(V // t, H, device=dev, dtype=torch.bfloat16)  # 词表并行切 N
    x = torch.randn(tokens, H, device=dev, dtype=torch.bfloat16, requires_grad=True)
    tgt = torch.randint(0, V // t, (tokens,), device=dev)

    def full():
        logits = torch.matmul(x, w.t())
        return torch.nn.functional.cross_entropy(logits.float(), tgt)

    fb = timed(full, backward=True)
    with torch.no_grad():
        f_only = timed(full)
    return f_only, fb - f_only


# ---------- C) RMSNorm / SwiGLU ----------
def bench_elementwise(t, b, dev):
    tokens = b * S
    x = torch.randn(tokens, H, device=dev, dtype=torch.bfloat16, requires_grad=True)
    g = torch.randn(H, device=dev, dtype=torch.bfloat16)

    def rmsnorm():
        var = x.pow(2).mean(-1, keepdim=True)
        return (x * torch.rsqrt(var + 1e-6) * g).sum()

    f_rms = timed(rmsnorm, backward=True)

    x1 = torch.randn(tokens, FFN // t, device=dev, dtype=torch.bfloat16, requires_grad=True)
    x2 = torch.randn(tokens, FFN // t, device=dev, dtype=torch.bfloat16, requires_grad=True)

    def swiglu():
        return (torch.nn.functional.silu(x1) * x2).sum()

    f_sw = timed(swiglu, backward=True)
    return f_rms, f_sw


def main():
    dev = "npu:0"
    torch.npu.set_device(0)
    for t in (1, 2, 4, 8):
        for b in (1, 4, 16):
            # A) FA
            try:
                f, bw = bench_fa(t, b, dev)
                rec("fa_gqa", t, b, f"hq={N_HEAD//t},hkv={N_KV//t},s={S}", f, bw)
            except Exception as e:
                rec("fa_gqa", t, b, "ERR:" + str(e)[:80], -1, -1)
                torch.npu.empty_cache()
            # B) LM head
            try:
                f, bw = bench_lmhead(t, b, dev)
                rec("lmhead_ce", t, b, f"V/t={V//t},tokens={b*S}", f, bw)
            except Exception as e:
                rec("lmhead_ce", t, b, "ERR:" + str(e)[:80], -1, -1)
                torch.npu.empty_cache()
            # C) elementwise
            try:
                f_rms, f_sw = bench_elementwise(t, b, dev)
                rec("rmsnorm", t, b, f"tokens={b*S},h={H}", f_rms, -1)
                rec("swiglu", t, b, f"tokens={b*S},ffn/t={FFN//t}", f_sw, -1)
            except Exception as e:
                rec("elementwise", t, b, "ERR:" + str(e)[:80], -1, -1)
                torch.npu.empty_cache()

    os.makedirs("profiling_out", exist_ok=True)
    with open("profiling_out/fused_ops_qwen3.csv", "w", newline="") as fo:
        w = csv.writer(fo)
        w.writerow(["op", "tp", "b", "detail", "fwd_ms", "bwd_ms"])
        w.writerows(rows)
    print("done -> profiling_out/fused_ops_qwen3.csv")


if __name__ == "__main__":
    main()
