# 01_kernel_bench.py — Qwen3-14B 线性层/注意力 kernel 耗时采集（单 rank 可跑）
# 目的：为白盒模型的 T_F 项与 rho(b,s,h,t) 提供实测数据
# 变更（vs Llama2-13B 版）：
#   1) FFN 13824 -> 17408；词表 32000 -> 151936
#   2) GQA：QKV 投影输出 = (40Q + 8K + 8V) * 128 = 7168，按 t 切分
#   3) 行并行层（attn_o / ffn_dn）的 K 维按 t 切分，修正形状方向
#   4) 新增注意力分数 bmm（QK^T 与 PV），供白盒模型注意力项标定
# 用法：python 01_kernel_bench.py
import os
import csv
import torch
import torch_npu  # noqa: F401

H, FFN, V = 5120, 17408, 151936
N_HEAD, N_KV, HEAD_DIM = 40, 8, 128
S = 4096
WARMUP, REPEAT = 5, 20


def bench_linear(tokens, in_f, out_f, device="npu:0"):
    """返回 (fwd_ms, bwd_ms)。用 Linear 近似训练中的 matmul+反传。"""
    lin = torch.nn.Linear(in_f, out_f, bias=False).to(device).to(torch.bfloat16)
    x = torch.randn(tokens, in_f, device=device, dtype=torch.bfloat16,
                    requires_grad=True)
    for _ in range(WARMUP):
        y = lin(x)
        y.sum().backward()
        x.grad = None
    torch.npu.synchronize()
    s_ev, e_ev = torch.npu.Event(True), torch.npu.Event(True)
    s_ev.record()
    for _ in range(REPEAT):
        y = lin(x)
    e_ev.record(); torch.npu.synchronize()
    fwd = s_ev.elapsed_time(e_ev) / REPEAT
    s_ev.record()
    for _ in range(REPEAT):
        y = lin(x)
        y.sum().backward()
        x.grad = None
    e_ev.record(); torch.npu.synchronize()
    fb = s_ev.elapsed_time(e_ev) / REPEAT
    return fwd, fb - fwd  # bwd ≈ fb - fwd


def bench_bmm(batch, m, k, n, device="npu:0"):
    """注意力分数类 bmm：返回 (fwd_ms, bwd_ms)。"""
    a = torch.randn(batch, m, k, device=device, dtype=torch.bfloat16,
                    requires_grad=True)
    bm = torch.randn(batch, k, n, device=device, dtype=torch.bfloat16,
                     requires_grad=True)
    for _ in range(WARMUP):
        y = torch.bmm(a, bm)
        y.sum().backward()
        a.grad = None; bm.grad = None
    torch.npu.synchronize()
    s_ev, e_ev = torch.npu.Event(True), torch.npu.Event(True)
    s_ev.record()
    for _ in range(REPEAT):
        y = torch.bmm(a, bm)
    e_ev.record(); torch.npu.synchronize()
    fwd = s_ev.elapsed_time(e_ev) / REPEAT
    s_ev.record()
    for _ in range(REPEAT):
        y = torch.bmm(a, bm)
        y.sum().backward()
        a.grad = None; bm.grad = None
    e_ev.record(); torch.npu.synchronize()
    fb = s_ev.elapsed_time(e_ev) / REPEAT
    del a, bm, y
    return fwd, fb - fwd


def flops(tokens, in_f, out_f):
    return 2 * tokens * in_f * out_f * 3  # fwd+bwd ≈ 3x fwd


rows = []
for t in (1, 2, 4, 8):
    heads_per_rank = N_HEAD // t
    qkv_out = (N_HEAD + 2 * N_KV) * HEAD_DIM // t   # 7168 / t
    shapes = {
        # 列并行：K=H 不切，N 按 t 切
        "qkv":    ("linear", H, qkv_out),
        "ffn_up": ("linear", H, 2 * FFN // t),       # gate+up 合并
        "vocab":  ("linear", H, V // t),             # LM head（词表并行）
        # 行并行：K 按 t 切，N=H 不切
        "attn_o": ("linear", H // t, H),
        "ffn_dn": ("linear", FFN // t, H),
        # 注意力分数（每 rank heads_per_rank 个头；融合算子前的理论形状）
        "attn_qk": ("bmm", heads_per_rank, S, HEAD_DIM, S),
        "attn_pv": ("bmm", heads_per_rank, S, S, HEAD_DIM),
    }
    for b in (1, 2, 4, 8, 16):
        tokens = b * S
        for name, spec in shapes.items():
            try:
                if spec[0] == "linear":
                    _, fi, fo = spec
                    fwd, bwd = bench_linear(tokens, fi, fo)
                    tf = flops(tokens, fi, fo) / ((fwd + bwd) / 1e3) / 1e12
                    rows.append([name, t, b, fi, fo,
                                 round(fwd, 4), round(bwd, 4), round(tf, 2)])
                else:
                    _, batch, m, k, n = spec
                    # tokens 维度体现在 batch 里：序列长固定 S，b 不改变注意力形状，
                    # 但微批 b 次调用 -> 总耗时 = b 次 bmm
                    fwd1, bwd1 = bench_bmm(batch * b, m, k, n)
                    fl = 2 * (batch * b) * m * k * n * 3
                    tf = fl / ((fwd1 + bwd1) / 1e3) / 1e12
                    rows.append([name, t, b, f"{batch*b}x{m}x{k}", n,
                                 round(fwd1, 4), round(bwd1, 4), round(tf, 2)])
                print(rows[-1], flush=True)
            except RuntimeError as e:
                rows.append([name, t, b, "OOM/ERR", "", str(e)[:60], "", ""])
                torch.npu.empty_cache()

os.makedirs("profiling_out", exist_ok=True)
with open("profiling_out/kernel_times_qwen3.csv", "w", newline="") as f:
    w = csv.writer(f)
    w.writerow(["layer", "tp", "b", "in_f", "out_f",
                "fwd_ms", "bwd_ms", "tflops_total"])
    w.writerows(rows)
print("done -> profiling_out/kernel_times_qwen3.csv")
