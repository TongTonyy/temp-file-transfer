# profiling2 补充采集包（Qwen3-14B 换模后的缺口）

## 为什么需要这次补测

换模 Llama2-13B → Qwen3-14B 后，模型相关标定有三块缺口：

1. `01_kernel_bench.py`（已在上一版 zip 中更新为 Qwen3 形状，**尚未跑过**）
   —— FFN 13824→17408、GQA(40Q/8KV)、词表 32000→151936 的 linear/bmm 耗时。
2. `05_fused_ops_bench.py`（本包新增）—— 实际训练走的是**融合算子**：
   - npu_fusion_attention（GQA 非对称头数下的真实表现）
   - LM head 全链路（vocab 投影 + cross_entropy，词表 15 万是 Llama2 的 3 倍）
   - RMSNorm / SwiGLU（memory-bound 项）
3. `06_hccl_workspace_probe.py`（本包新增）—— ground truth 中 cfg_02/12
   因 HCCL ReduceScatter 分配 420MB 通信缓冲失败。HCCL workspace 不进
   torch allocator、不在任何解析显存公式里，必须实测量化（L2 剪枝判据用）。

## 不需要重测

- `02_hccl_bench.py` 带宽查表（硬件属性，与模型无关）—— 已有数据继续有效
- `03_overlap_bench.py` 掩盖率（硬件调度属性）—— 74% 结论继续有效
- `04_power_sampler.sh` —— 功耗已在 ground truth 中同步采集

## 在 910C 上执行（llm_env 环境）

```bash
cd /root/hgnn_910c_readiness/profiling   # 或解压后的目录
mkdir -p profiling_out

# 1) Qwen3 形状 kernel bench（单卡，约 5-8 分钟）
python 01_kernel_bench.py

# 2) 融合算子（单卡，约 5-8 分钟）
python 05_fused_ops_bench.py

# 3) HCCL workspace 探针（整机 16 rank，约 3-5 分钟）
torchrun --nproc_per_node=16 06_hccl_workspace_probe.py
```

## 产出文件（全部在 profiling_out/ 下）

- `kernel_times_qwen3.csv` —— 算子耗时（01）
- `fused_ops_qwen3.csv` —— 融合算子耗时（05）
- `hccl_workspace.csv` —— 通信缓冲占用（06）

跑完后把 profiling_out/ 整个目录打包传回即可。
