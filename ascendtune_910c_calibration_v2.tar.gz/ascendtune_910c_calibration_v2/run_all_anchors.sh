#!/bin/bash
# Run all anchors listed in anchors.conf (pipe-separated, # = comment).
# Each line: name|tp|pp|micro_batch|global_batch|zero_args|repeat

set -u
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
CONF=${CONF:-$SCRIPT_DIR/anchors.conf}

if [ ! -f "$CONF" ]; then
  echo "[error] anchors config not found: $CONF"
  exit 1
fi

total=0
while IFS='|' read -r name tp pp mb gb zero_args repeat; do
  case "$name" in
    ''|\#*) continue ;;
  esac
  repeat=${repeat:-1}
  for i in $(seq 1 "$repeat"); do
    run_name="$name"
    if [ "$i" -gt 1 ]; then
      run_name="${name}_rep${i}"
    fi
    total=$((total + 1))
    echo "######################################################################"
    echo "# anchor $total: $run_name (tp=$tp pp=$pp mb=$mb gb=$gb)"
    echo "######################################################################"
    ANCHOR_NAME="$run_name" TP="$tp" PP="$pp" MICRO_BATCH="$mb" \
      GLOBAL_BATCH="$gb" ZERO_ARGS="$zero_args" \
      TRAIN_ITERS="${TRAIN_ITERS:-25}" \
      bash "$SCRIPT_DIR/run_training_anchor.sh"
  done
done < "$CONF"

echo "[done] $total anchor runs finished; results in $SCRIPT_DIR/results_anchors/"
