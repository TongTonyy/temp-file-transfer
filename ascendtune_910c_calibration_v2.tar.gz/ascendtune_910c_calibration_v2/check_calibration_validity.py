#!/usr/bin/env python3
"""Check energy-calibration results against the validity criteria.

Usage: python3 check_calibration_validity.py [results_dir]

Checks (from ENERGY_CALIBRATION_REQUIREMENTS):
  - every experiment dir has exit_code.txt == 0
  - idle has >= 120 whole-machine power samples
  - bench_metrics rows for compute/memory/comm have world_size == 16
  - compute/memory/vector mean whole-machine power >= idle mean * 1.05
  - collective latency is (near-)monotonic in message size
Writes validity_report.txt into the results dir and prints a summary.
"""
import csv
import os
import re
import sys

ROOT = sys.argv[1] if len(sys.argv) > 1 else "results_energy_calibration_v2"

POWER_DELTA_MIN = 1.05  # mean power must be >= 5% above idle
MONO_TOL = 0.9          # latency may drop at most 10% between consecutive sizes


def mean_total_power(csv_path):
    """Sum per-card power per timestamp, return (n_samples, mean_total_w)."""
    per_ts = {}
    with open(csv_path, newline="", encoding="utf-8") as f:
        for row in csv.DictReader(f):
            try:
                p = float(row["power_w"])
            except (KeyError, TypeError, ValueError):
                continue
            ts = row.get("ts_unix", "")
            per_ts[ts] = per_ts.get(ts, 0.0) + p
    vals = list(per_ts.values())
    if not vals:
        return 0, 0.0
    return len(vals), sum(vals) / len(vals)


def main():
    problems = []
    oks = []

    # ---- exit codes -------------------------------------------------------
    exp_dirs = sorted(
        d for d in os.listdir(ROOT)
        if os.path.isdir(os.path.join(ROOT, d))
    )
    for d in exp_dirs:
        ec_file = os.path.join(ROOT, d, "exit_code.txt")
        if not os.path.exists(ec_file):
            problems.append(f"[exit] {d}: exit_code.txt missing")
            continue
        rc = open(ec_file, encoding="utf-8").read().strip()
        if rc != "0":
            problems.append(f"[exit] {d}: exit_code={rc}")
        else:
            oks.append(f"[exit] {d}: rc=0")

    # ---- idle -------------------------------------------------------------
    idle_csv = os.path.join(ROOT, "idle", "power_mem.csv")
    idle_mean = 0.0
    if os.path.exists(idle_csv):
        n_idle, idle_mean = mean_total_power(idle_csv)
        if n_idle < 120:
            problems.append(f"[idle] only {n_idle} samples (<120)")
        else:
            oks.append(f"[idle] {n_idle} samples, mean total power {idle_mean:.1f} W")
    else:
        problems.append("[idle] idle/power_mem.csv missing")

    # ---- bench metrics: world_size and latency ----------------------------
    metrics_path = os.path.join(ROOT, "bench_metrics.csv")
    bench_rows = []
    if os.path.exists(metrics_path):
        with open(metrics_path, newline="", encoding="utf-8") as f:
            bench_rows = list(csv.DictReader(f))
        for row in bench_rows:
            if row["mode"] in ("compute_gemm", "memory_copy", "vector_norm",
                               "swiglu_elementwise", "all_reduce", "all_gather",
                               "reduce_scatter", "all_reduce_group", "p2p_ring"):
                if row["world_size"] != "16":
                    problems.append(
                        f"[world] {row['metric']}: world_size={row['world_size']} (must be 16)")
    else:
        problems.append("[bench] bench_metrics.csv missing")

    # ---- power deltas vs idle --------------------------------------------
    if idle_mean > 0:
        for d in exp_dirs:
            if d == "idle":
                continue
            p = os.path.join(ROOT, d, "power_mem.csv")
            if not os.path.exists(p):
                problems.append(f"[power] {d}: power_mem.csv missing")
                continue
            n, mean_p = mean_total_power(p)
            if n == 0:
                problems.append(f"[power] {d}: no parseable power samples")
                continue
            ratio = mean_p / idle_mean
            tag = "OK " if ratio >= POWER_DELTA_MIN else "LOW"
            line = f"[power] {d}: {mean_p:.1f} W vs idle {idle_mean:.1f} W (x{ratio:.3f}) {tag}"
            (oks if ratio >= POWER_DELTA_MIN else problems).append(line)

    # ---- collective latency monotonicity ----------------------------------
    coll = {}
    for row in bench_rows:
        if row["mode"] in ("all_reduce", "all_gather", "reduce_scatter"):
            m = re.search(r"_(\d+)$", row["metric"])
            if m:
                coll.setdefault(row["mode"], []).append((int(m.group(1)), float(row["avg_s"])))
    for mode, pts in coll.items():
        pts.sort()
        mono = all(b >= a * MONO_TOL for (_, a), (_, b) in zip(pts, pts[1:]))
        line = (f"[mono] {mode}: " +
                " -> ".join(f"{n / 1e6:.0f}M:{t * 1e3:.2f}ms" for n, t in pts) +
                (" OK" if mono else " NON-MONOTONIC"))
        (oks if mono else problems).append(line)

    # ---- report ------------------------------------------------------------
    lines = ["=== AscendTune 910C energy calibration validity report ===", ""]
    lines.append(f"--- PASS ({len(oks)}) ---")
    lines += oks
    lines.append("")
    lines.append(f"--- PROBLEMS ({len(problems)}) ---")
    lines += problems if problems else ["(none)"]
    lines.append("")
    lines.append("OVERALL: " + ("PASS" if not problems else "INCOMPLETE - fix the items above"))
    report = "\n".join(lines)
    print(report)
    with open(os.path.join(ROOT, "validity_report.txt"), "w", encoding="utf-8") as f:
        f.write(report + "\n")


if __name__ == "__main__":
    main()
