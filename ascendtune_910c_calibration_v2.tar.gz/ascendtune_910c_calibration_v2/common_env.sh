#!/bin/bash
# Common environment for AscendTune 910C calibration scripts.

set -u

export MSLLM_DIR=${MSLLM_DIR:-/root/MindSpeed-LLM}
export DATA_PATH=${DATA_PATH:-$MSLLM_DIR/finetune_dataset/alpaca}
export TOKENIZER_PATH=${TOKENIZER_PATH:-$MSLLM_DIR/model_from_hf/qwen3-14b-hf}
export CKPT_WEIGHTS_DIR=${CKPT_WEIGHTS_DIR:-$MSLLM_DIR/model_weights}
export NPUS_PER_NODE=${NPUS_PER_NODE:-16}
export MASTER_ADDR=${MASTER_ADDR:-localhost}
export GLOBAL_BATCH=${GLOBAL_BATCH:-1024}
export SEQ_LEN=${SEQ_LEN:-4096}
export MAX_POS=${MAX_POS:-40960}
export TRAIN_ITERS=${TRAIN_ITERS:-25}
export LOG_INTERVAL=${LOG_INTERVAL:-1}
export ASCEND_TOOLKIT_ENV=${ASCEND_TOOLKIT_ENV:-/usr/local/Ascend/ascend-toolkit/set_env.sh}

if [ -f "$ASCEND_TOOLKIT_ENV" ]; then
  # shellcheck disable=SC1090
  source "$ASCEND_TOOLKIT_ENV"
fi

export CUDA_DEVICE_MAX_CONNECTIONS=${CUDA_DEVICE_MAX_CONNECTIONS:-1}
export PYTORCH_NPU_ALLOC_CONF=${PYTORCH_NPU_ALLOC_CONF:-expandable_segments:True}

ckpt_name() {
  local tp=$1
  local pp=$2
  local dp=$3
  if [ "$tp" -gt 1 ]; then
    echo "qwen3_mcore-${tp}TP${dp}DP"
  elif [ "$pp" -gt 1 ]; then
    echo "qwen3_mcore-${pp}PP${dp}DP"
  else
    echo "qwen3_mcore-${dp}DP"
  fi
}

base_qwen_args() {
  local pp=$1
  local tp=$2
  local micro_bsz=$3
  local ckpt=$4
  cat <<EOF
--use-mcore-models
--tensor-model-parallel-size ${tp}
--pipeline-model-parallel-size ${pp}
--spec mindspeed_llm.tasks.models.spec.qwen3_spec layer_spec
--kv-channels 128
--qk-layernorm
--num-layers 40
--hidden-size 5120
--use-rotary-position-embeddings
--untie-embeddings-and-output-weights
--num-attention-heads 40
--ffn-hidden-size 17408
--max-position-embeddings ${MAX_POS}
--seq-length ${SEQ_LEN}
--train-iters ${TRAIN_ITERS}
--micro-batch-size ${micro_bsz}
--global-batch-size ${GLOBAL_BATCH}
--make-vocab-size-divisible-by 1
--use-flash-attn
--padded-vocab-size 151936
--rotary-base 1000000
--disable-bias-linear
--swiglu
--tokenizer-type PretrainedFromHF
--tokenizer-name-or-path ${TOKENIZER_PATH}
--normalization RMSNorm
--position-embedding-type rope
--norm-epsilon 1e-6
--hidden-dropout 0
--attention-dropout 0
--no-gradient-accumulation-fusion
--attention-softmax-in-fp32
--no-masked-softmax-fusion
--group-query-attention
--num-query-groups 8
--seed 42
--bf16
--min-lr 1.25e-7
--weight-decay 1e-1
--lr-warmup-fraction 0.01
--clip-grad 1.0
--adam-beta1 0.9
--adam-beta2 0.95
--lr 1.25e-6
--ckpt-format torch
--data-path ${DATA_PATH}
--split 100,0,0
--log-interval ${LOG_INTERVAL}
--save-interval 10000
--eval-interval 10000
--eval-iters 0
--log-throughput
--finetune
--stage sft
--is-instruction-dataset
--prompt-type qwen3
--no-pad-to-seq-lengths
--distributed-backend nccl
--transformer-impl local
--load ${ckpt}
--no-load-optim
--no-load-rng
--exit-on-missing-checkpoint
EOF
}
