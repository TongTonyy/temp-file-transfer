#!/bin/bash
# Sample 910C card power and die HBM usage. Stop by killing the process.

set -u

OUT=${1:?usage: bash sampler_power_mem.sh output.csv}
INTERVAL=${SAMPLE_INTERVAL_SEC:-1}

npu-smi info > "${OUT}.raw_snapshot.txt" 2>&1 || true
echo "ts_unix,card,power_w,die0_hbm_used_mb,die1_hbm_used_mb" > "$OUT"

warned=0
while true; do
  ts=$(date +%s)
  lines=$(npu-smi info 2>/dev/null | awk -F'|' -v ts="$ts" '
    $2 ~ /Ascend910/ {
      split($2, a, " "); cur = a[1]
      split($4, p, " "); v = (p[1] == "-" ? "" : p[1])
      if (!(cur in seen)) { seen[cur] = 1; order[++nc] = cur; pw[cur] = v }
      else if (pw[cur] == "") pw[cur] = v
      next
    }
    $3 ~ /0000:/ {
      split($2, a, " "); die = a[1] + 1
      n = split($4, b, " ")
      hbm[cur, die] = b[n-2]
      next
    }
    END {
      for (i = 1; i <= nc; i++) {
        c = order[i]
        printf "%s,%s,%s,%s,%s\n", ts, c, pw[c], hbm[c, 1], hbm[c, 2]
      }
    }')
  if [ -n "$lines" ]; then
    echo "$lines" >> "$OUT"
  elif [ "$warned" = "0" ]; then
    echo "[sampler] npu-smi parse returned empty; inspect ${OUT}.raw_snapshot.txt" >&2
    warned=1
  fi
  sleep "$INTERVAL"
done
