# -*- coding: utf-8 -*-
"""MindSpeed-LLM training wrapper v3.1: hook loss_func on ALL trainer classes.

Place this file in $MSLLM_DIR and launch it instead of posttrain_gpt.py.
Validated on Atlas-800I A3 with MindSpeed-LLM (SFTTrainer hierarchy):
hooks every class defining loss_func so the overriding subclass is covered,
and counts tokens from the loss_mask passed as input_tensor.
"""
import atexit
import csv
import os
import runpy
import sys

_tok = {"all": 0, "real": 0, "step": 0, "rows": 0}
_state = {"file": None, "writer": None, "loss_hook": False, "train_hook": False, "grab_fail": 0}


def _rank0():
    return os.environ.get("RANK", "0") == "0"


def _writer():
    if _state["writer"] is None:
        _state["file"] = open("real_tokens.csv", "w", newline="", encoding="utf-8")
        _state["writer"] = csv.writer(_state["file"])
        _state["writer"].writerow(["iteration", "tokens_numel_allranks", "tokens_nonpad_allranks"])
    return _state["writer"]


def _install_loss_hook():
    candidates = [
        "mindspeed_llm.tasks.posttrain.sft.sft_trainer",
        "mindspeed_llm.tasks.posttrain.ldt_sft.ldt_sft_trainer",
    ]
    for module_name in candidates:
        try:
            module = __import__(module_name, fromlist=["*"])
        except Exception:
            continue
        hooked = []
        for attr_name in dir(module):
            cls = getattr(module, attr_name)
            if not (isinstance(cls, type) and "loss_func" in cls.__dict__):
                continue
            raw = cls.__dict__["loss_func"]
            is_static = isinstance(raw, staticmethod)
            orig = raw.__func__ if is_static else raw

            def wrapped_loss_func(*args, __orig=orig, **kwargs):
                try:
                    input_tensor = args[0] if args else kwargs.get("input_tensor")
                    if input_tensor is not None:
                        lm = input_tensor[..., 1:]
                        _tok["all"] += int(lm.numel())
                        _tok["real"] += int(lm.sum())
                except Exception:
                    _state["grab_fail"] += 1
                return __orig(*args, **kwargs)

            if is_static:
                setattr(cls, "loss_func", staticmethod(wrapped_loss_func))
            else:
                setattr(cls, "loss_func", wrapped_loss_func)
            hooked.append(attr_name)
        if hooked:
            _state["loss_hook"] = True
            if _rank0():
                print(f"[TOKCOUNT] installed loss_func hook on {module_name}: {','.join(hooked)}", flush=True)
            return


def _install_train_step_hook():
    candidates = [
        "mindspeed_llm.training.training",
        "megatron.training.training",
    ]
    for module_name in candidates:
        try:
            module = __import__(module_name, fromlist=["train_step"])
            orig = getattr(module, "train_step")
        except Exception:
            continue

        def wrapped_train_step(*args, __orig=orig, **kwargs):
            _tok["all"] = 0
            _tok["real"] = 0
            ret = __orig(*args, **kwargs)
            try:
                import torch
                import torch.distributed as dist
                _tok["step"] += 1
                t = torch.tensor([_tok["all"], _tok["real"]], dtype=torch.long).npu()
                dist.all_reduce(t, group=dist.group.WORLD)
                if dist.get_rank() == 0:
                    _writer().writerow([_tok["step"], int(t[0]), int(t[1])])
                    _state["file"].flush()
                    _tok["rows"] += 1
            except Exception:
                _state["grab_fail"] += 1
            return ret

        setattr(module, "train_step", wrapped_train_step)
        _state["train_hook"] = True
        if _rank0():
            print(f"[TOKCOUNT] installed train_step hook on {module_name}", flush=True)
        return


def _install_token_counter():
    _install_loss_hook()
    _install_train_step_hook()
    if _rank0():
        print(
            f"[TOKCOUNT] loss_hook={_state['loss_hook']} "
            f"train_hook={_state['train_hook']} metric=loss_mask.sum",
            flush=True,
        )


@atexit.register
def _report_memory_and_tokens():
    try:
        import torch
        import torch_npu  # noqa: F401
        rank = os.environ.get("RANK", "?")
        alloc = torch.npu.max_memory_allocated() / 1024**3
        reserved = torch.npu.max_memory_reserved() / 1024**3
        print(
            f"[MEMREPORT rank {rank}] max_allocated={alloc:.2f} GiB "
            f"max_reserved={reserved:.2f} GiB capacity=61.28 GiB",
            flush=True,
        )
    except Exception as exc:
        print(f"[MEMREPORT] failed: {exc}", flush=True)
    if _rank0():
        print(
            f"[TOKCOUNT] rows={_tok['rows']} grab_fail={_state['grab_fail']} "
            f"loss_hook={_state['loss_hook']} train_hook={_state['train_hook']}",
            flush=True,
        )
    if _state["file"]:
        _state["file"].close()


_install_token_counter()

_here = os.path.dirname(os.path.abspath(__file__))
sys.argv[0] = os.path.join(_here, "posttrain_gpt.py")
runpy.run_path(sys.argv[0], run_name="__main__")
