#!/bin/bash
# Pack calibration v2 results and optionally push through a GitHub repo.

set -u
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
ARCHIVE=${ARCHIVE:-ascendtune_910c_calibration_v2_results.tar.gz}

cd "$SCRIPT_DIR" || exit 1
tar czf "$ARCHIVE" --ignore-failed-read \
  results_energy_calibration_v2 \
  results_anchors \
  ./*.log 2>/dev/null || true
echo "[pack] wrote $SCRIPT_DIR/$ARCHIVE"

if git rev-parse --is-inside-work-tree >/dev/null 2>&1; then
  git add "$ARCHIVE" 2>/dev/null || true
  git commit -m "Add AscendTune 910C calibration v2 results" || true
  git push || true
  echo "[git] attempted commit and push"
else
  echo "[git] not inside a git repo; upload $ARCHIVE via the GitHub release flow"
fi
