#!/usr/bin/env bash
set -Eeuo pipefail
umask 077

ROOT="${HGNN_ROOT:-/root/hgnn_910c_readiness/hgnn_f01_qwen3_campaign_v0.3.4}"
DEPLOY_STAMP="$(date -u +%Y%m%dT%H%M%SZ)"
CAMPAIGN_ID="${HGNN_R31_CAMPAIGN_ID:-${DEPLOY_STAMP}-r31-balanced-30run}"
WORKLOAD="$ROOT/workload"
PARSE_WORKERS="${HGNN_R31_PARSE_WORKERS:-4}"
EXTRACT_WORKERS="${HGNN_R31_EXTRACT_WORKERS:-8}"
MIN_FREE_GIB="${HGNN_R31_MIN_FREE_GIB:-500}"
MAX_RAW_GROUP_GIB="${HGNN_R31_MAX_RAW_GROUP_GIB:-300}"
DURATION_S="${HGNN_R31_DURATION_S:-600}"
BASELINE_S="${HGNN_R31_BASELINE_S:-120}"
RELEASE_AT_S="${HGNN_R31_RELEASE_AT_S:-420}"
MAX_GROUPS="${HGNN_R31_MAX_GROUPS:-30}"

[[ -d "$ROOT" ]] || { echo "campaign目录不存在: $ROOT" >&2; exit 2; }
cd "$ROOT"
mkdir -p runtime/logs runtime/gates runtime/manifests runtime/return_bundles
DEPLOY_LOG="$ROOT/runtime/logs/r31_balanced_30run_${DEPLOY_STAMP}.log"
exec > >(tee -a "$DEPLOY_LOG") 2>&1

# shellcheck disable=SC1091
. "$ROOT/workload/common.sh"
resolve_llm_python

EXTRACTION_ROOT="$ROOT/runtime/extracted_targets_r31/$CAMPAIGN_ID"
MANIFEST_ROOT="$ROOT/runtime/manifests/$CAMPAIGN_ID"
PACKAGE_DIR="$ROOT/runtime/return_bundles"
mkdir -p "$EXTRACTION_ROOT/groups" "$MANIFEST_ROOT" "$PACKAGE_DIR"

GROUP_KEYS=()
GROUP_CONDITIONS=()
GROUP_METRICS=()
GROUP_DRAWERS=()

add_group() {
  GROUP_KEYS+=("$1")
  GROUP_CONDITIONS+=("$2")
  GROUP_METRICS+=("$3")
  GROUP_DRAWERS+=("$4")
}

# Existing r30 10-run dataset already contains:
# drawer0 control/fault repeats 2-3 for both metric families, plus drawer2 fault repeat 1.
# These 30 runs complete the merged 40-run design to 5 repeats per
# drawer x label x metric-family cell.
for rep in 4 5 6; do
  add_group "d0_rep${rep}_control_resource_conflict" "manual_baseline_sham" "ResourceConflictRatio" "drawer0"
  add_group "d0_rep${rep}_fault_resource_conflict" "drawer0_s1" "ResourceConflictRatio" "drawer0"
  add_group "d0_rep${rep}_control_memory_access" "manual_baseline_sham" "MemoryAccess" "drawer0"
  add_group "d0_rep${rep}_fault_memory_access" "drawer0_s1" "MemoryAccess" "drawer0"
done

add_group "d2_rep1_control_resource_conflict" "manual_baseline_sham" "ResourceConflictRatio" "drawer2"
add_group "d2_rep1_control_memory_access" "manual_baseline_sham" "MemoryAccess" "drawer2"
for rep in 2 3 4 5; do
  add_group "d2_rep${rep}_control_resource_conflict" "manual_baseline_sham" "ResourceConflictRatio" "drawer2"
  add_group "d2_rep${rep}_fault_resource_conflict" "drawer2_s1" "ResourceConflictRatio" "drawer2"
  add_group "d2_rep${rep}_control_memory_access" "manual_baseline_sham" "MemoryAccess" "drawer2"
  add_group "d2_rep${rep}_fault_memory_access" "drawer2_s1" "MemoryAccess" "drawer2"
done

if (( MAX_GROUPS < ${#GROUP_KEYS[@]} )); then
  GROUP_KEYS=("${GROUP_KEYS[@]:0:MAX_GROUPS}")
  GROUP_CONDITIONS=("${GROUP_CONDITIONS[@]:0:MAX_GROUPS}")
  GROUP_METRICS=("${GROUP_METRICS[@]:0:MAX_GROUPS}")
  GROUP_DRAWERS=("${GROUP_DRAWERS[@]:0:MAX_GROUPS}")
fi
GROUP_COUNT="${#GROUP_KEYS[@]}"

r31_stage() {
  echo "============================================================"
  echo "R31_STAGE=$1/7"
  echo "R31_STAGE_NAME=$2"
  echo "R31_STAGE_UTC=$(date -u +%Y%m%dT%H%M%SZ)"
  echo "============================================================"
}

r31_now_ms() {
  "$HGNN_PYTHON" - <<'PY'
import time
print(int(time.monotonic() * 1000))
PY
}

r31_elapsed_s() {
  "$HGNN_PYTHON" - "$1" "$2" <<'PY'
import sys
print(f"{(int(sys.argv[2]) - int(sys.argv[1])) / 1000:.3f}")
PY
}

r31_dir_bytes() {
  "$HGNN_PYTHON" - "$1" <<'PY'
import sys
from pathlib import Path
root = Path(sys.argv[1])
total = 0
if root.exists():
    for path in root.rglob("*"):
        try:
            if path.is_file() and not path.is_symlink():
                total += path.stat().st_size
        except OSError:
            pass
print(total)
PY
}

r31_check_profiles_safe() {
  "$HGNN_PYTHON" - "$ROOT/runtime/profiles" "$CAMPAIGN_ID" <<'PY'
import sys
from pathlib import Path
root = Path(sys.argv[1])
campaign_id = sys.argv[2]
if not root.exists():
    raise SystemExit(0)
items = [p for p in root.iterdir() if p.name != ".keep"]
foreign = [p for p in items if not p.name.startswith(campaign_id + "-")]
local = [p for p in items if p.name.startswith(campaign_id + "-")]
if foreign:
    print("R31_FOREIGN_STALE_PROFILE_ROOTS=" + ",".join(str(p) for p in sorted(foreign)))
    raise SystemExit(1)
if local:
    print("R31_CAMPAIGN_PROFILE_RESIDUE=" + ",".join(str(p) for p in sorted(local)))
PY
}

r31_cleanup_failed_residue() {
  local run_id="$1" key="$2"
  local group_manifest="$EXTRACTION_ROOT/groups/$key.json"
  local cleanup_report="$EXTRACTION_ROOT/provenance/r31/cleanup/$run_id/cleanup_report.json"
  [[ -f "$group_manifest" && -f "$cleanup_report" ]] && return 0
  echo "R31_CLEAN_FAILED_RESIDUE=$run_id"
  rm -rf "$ROOT/runtime/profiles/$run_id"
  rm -rf "$ROOT/runtime/outputs/formal/$run_id"
  rm -rf "$ROOT/runtime/manifests/$run_id"
  rm -rf "$ROOT/runtime/gates/r31_group_gate/$CAMPAIGN_ID/$run_id"
  "$HGNN_PYTHON" - "$ROOT/runtime/data" "$run_id" <<'PY'
import shutil
import sys
from pathlib import Path
root = Path(sys.argv[1]).resolve()
run_id = sys.argv[2]
if not root.exists():
    raise SystemExit(0)
for name in (run_id, run_id + ".staging"):
    for path in list(root.rglob(name)):
        resolved = path.resolve()
        if not resolved.is_relative_to(root):
            raise SystemExit(f"unsafe runtime/data cleanup path: {resolved}")
        if "runs" not in resolved.parts:
            raise SystemExit(f"unexpected runtime/data cleanup path: {resolved}")
        if resolved.is_dir():
            print(f"R31_DELETE_COLLECTOR_RUN_DIR={resolved}")
            shutil.rmtree(resolved)
PY
}

r31_group_completed() {
  local key="$1" run_id="$2" group_manifest cleanup_report
  group_manifest="$EXTRACTION_ROOT/groups/$key.json"
  cleanup_report="$EXTRACTION_ROOT/provenance/r31/cleanup/$run_id/cleanup_report.json"
  [[ -f "$group_manifest" && -f "$cleanup_report" ]] || return 1
  "$HGNN_PYTHON" - "$group_manifest" "$cleanup_report" "$run_id" <<'PY'
import json
import sys
from pathlib import Path
group = json.loads(Path(sys.argv[1]).read_text(encoding="utf-8"))
cleanup = json.loads(Path(sys.argv[2]).read_text(encoding="utf-8"))
run_id = sys.argv[3]
if group.get("status") != "complete" or group.get("run_id") != run_id:
    raise SystemExit(1)
if cleanup.get("status") != "complete" or cleanup.get("run_id") != run_id:
    raise SystemExit(1)
profile_root = Path(str(cleanup.get("profile_root", "")))
if profile_root.exists():
    raise SystemExit(1)
PY
}

r31_run_group() {
  local index="$1" key="$2" condition="$3" metric="$4" drawer="$5"
  local run_id profile_root gate_dir sample_plan parse_report started ended cleanup_report group_manifest raw_bytes raw_gib
  run_id="${CAMPAIGN_ID}-${key}-a1"
  profile_root="$ROOT/runtime/profiles/$run_id"
  gate_dir="$ROOT/runtime/gates/r31_group_gate/$CAMPAIGN_ID/$run_id"
  sample_plan="$MANIFEST_ROOT/${run_id}_sample_plan.json"
  parse_report="$EXTRACTION_ROOT/provenance/r31/parse/$run_id/parse_report.json"
  cleanup_report="$EXTRACTION_ROOT/provenance/r31/cleanup/$run_id/cleanup_report.json"
  group_manifest="$EXTRACTION_ROOT/groups/$key.json"
  echo "R31_GROUP_INDEX=${index}/${GROUP_COUNT}"
  if r31_group_completed "$key" "$run_id"; then
    echo "R31_GROUP_SKIP_COMPLETED=$key"
    echo "RUN_ID=$run_id"
    return 0
  fi
  r31_cleanup_failed_residue "$run_id" "$key"
  mkdir -p "$gate_dir" "$(dirname "$parse_report")" "$(dirname "$cleanup_report")"
  echo "R31_GROUP_START=$key"
  echo "RUN_ID=$run_id"
  echo "AIC_METRIC=$metric"
  echo "R31_CONDITION=$condition"
  echo "R31_DRAWER=$drawer"
  "$HGNN_PYTHON" "$WORKLOAD/r29_sample_plan.py" \
    --run-id "$run_id" --metric "$metric" --condition "$condition" \
    --duration-s "$DURATION_S" --baseline-s "$BASELINE_S" \
    --release-at-s "$RELEASE_AT_S" --output "$sample_plan"
  started="$(r31_now_ms)"
  export HGNN_FORMAL_DURATION="$DURATION_S"
  export HGNN_FORMAL_BASELINE="$BASELINE_S"
  export HGNN_FORMAL_RELEASE_AT="$RELEASE_AT_S"
  export HGNN_TORCH_NPU_AIC_METRIC="$metric"
  export HGNN_R29_SAMPLE_PLAN_PATH="$sample_plan"
  run_formal "$condition" "$drawer" "$run_id"
  raw_bytes="$(r31_dir_bytes "$profile_root")"
  raw_gib="$("$HGNN_PYTHON" - "$raw_bytes" <<'PY'
import sys
print(int(int(sys.argv[1]) // (1024 ** 3)))
PY
)"
  echo "R31_RAW_PROFILE_BYTES_AFTER_COLLECT=$raw_bytes"
  echo "R31_RAW_PROFILE_GIB_AFTER_COLLECT=$raw_gib"
  if (( raw_gib > MAX_RAW_GROUP_GIB )); then
    echo "R31_RAW_GROUP_TOO_LARGE=${raw_gib}GiB>${MAX_RAW_GROUP_GIB}GiB" >&2
    exit 2
  fi
  local parse_argv=(
    "$HGNN_PYTHON" "$WORKLOAD/r29_parse_segments.py"
    --profile-root "$profile_root"
    --metric "$metric"
    --sample-plan "$sample_plan"
    --cache-root "$gate_dir/parse_cache"
    --output "$parse_report"
    --max-workers "$PARSE_WORKERS"
  )
  if [[ -n "${HGNN_MSPROF_PY:-}" ]]; then
    parse_argv+=(--msprof-py "$HGNN_MSPROF_PY")
  fi
  "${parse_argv[@]}"
  "$HGNN_PYTHON" "$WORKLOAD/r29_extract_segments.py" \
    --profile-root "$profile_root" --output-root "$EXTRACTION_ROOT" \
    --run-id "$run_id" --key "$key" --condition "$condition" \
    --metric "$metric" --sample-plan "$sample_plan" \
    --parse-report "$parse_report" --max-workers "$EXTRACT_WORKERS" \
    --trust-complete-reports
  cp "$EXTRACTION_ROOT/$run_id/r29_group_extraction_manifest.json" "$group_manifest"
  "$HGNN_PYTHON" "$WORKLOAD/r29_cleanup_sampled_profile.py" \
    --root "$ROOT" --profile-root "$profile_root" \
    --extraction-root "$EXTRACTION_ROOT" \
    --group-manifest "$EXTRACTION_ROOT/$run_id/r29_group_extraction_manifest.json" \
    --run-id "$run_id" \
    --profile-plans-output "$EXTRACTION_ROOT/provenance/r31/profile_plans/$run_id" \
    --cleanup-report "$cleanup_report"
  ended="$(r31_now_ms)"
  echo "R31_GROUP_TOTAL_S=$(r31_elapsed_s "$started" "$ended")"
  echo "R31_GROUP_COMPLETE=$key"
}

r31_stage 1 "启动与容量预检"
R31_RUN_START_MS="$(r31_now_ms)"
echo "R31_CAMPAIGN_ID=$CAMPAIGN_ID"
echo "R31_GROUP_COUNT=$GROUP_COUNT"
echo "R31_LOG=$DEPLOY_LOG"
FREE_GIB="$("$HGNN_PYTHON" - "$ROOT" <<'PY'
import shutil
import sys
print(shutil.disk_usage(sys.argv[1]).free // (1024 ** 3))
PY
)"
echo "R31_FREE_GIB=$FREE_GIB"
if (( FREE_GIB < MIN_FREE_GIB )); then
  echo "可用空间不足${MIN_FREE_GIB}GiB，拒绝启动" >&2
  exit 2
fi
r31_check_profiles_safe

r31_stage 2 "初始化环境"
campaign_init
ASCEND_ENV=""
for candidate in /usr/local/Ascend/ascend-toolkit/set_env.sh /usr/local/Ascend/ascend-toolkit/latest/set_env.sh; do
  [[ -f "$candidate" ]] && { ASCEND_ENV="$candidate"; break; }
done
[[ -n "$ASCEND_ENV" ]] || { echo "未找到Ascend环境脚本" >&2; exit 2; }
set +u
# shellcheck disable=SC1090
source "$ASCEND_ENV"
set -u
export HGNN_MSPROF_PY="${HGNN_MSPROF_PY:-/usr/local/Ascend/cann-8.5.2/tools/profiler/profiler_tool/analysis/msprof/msprof.py}"

r31_stage 3 "平衡扩展group运行"
require_smoke_gate "drawer0"
require_smoke_gate "drawer2"
for ((i = 0; i < GROUP_COUNT; i++)); do
  r31_run_group "$((i + 1))" "${GROUP_KEYS[$i]}" "${GROUP_CONDITIONS[$i]}" "${GROUP_METRICS[$i]}" "${GROUP_DRAWERS[$i]}"
done

r31_stage 4 "最终manifest"
DATASET_MANIFEST="$MANIFEST_ROOT/r31_dataset_manifest.json"
"$HGNN_PYTHON" "$WORKLOAD/r31_finalize_balanced_dataset.py" \
  --root "$ROOT" --extraction-root "$EXTRACTION_ROOT" \
  --campaign-id "$CAMPAIGN_ID" --output "$DATASET_MANIFEST" \
  --expected-groups "$GROUP_COUNT"

r31_stage 5 "最终打包"
"$HGNN_PYTHON" "$WORKLOAD/r29_package_sampled_dataset.py" \
  --dataset-manifest "$DATASET_MANIFEST" \
  --extraction-root "$EXTRACTION_ROOT" \
  --output-dir "$PACKAGE_DIR" \
  --bundle-label "r31-balanced-30run-sampled-dataset"

r31_stage 6 "完成"
R31_RUN_END_MS="$(r31_now_ms)"
echo "R31_RUN_TOTAL_S=$(r31_elapsed_s "$R31_RUN_START_MS" "$R31_RUN_END_MS")"
echo "R31_COMPLETE=1"
