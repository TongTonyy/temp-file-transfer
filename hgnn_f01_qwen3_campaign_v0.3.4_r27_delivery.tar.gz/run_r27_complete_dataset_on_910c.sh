#!/usr/bin/env bash
set -Eeuo pipefail
umask 077

ROOT="${HGNN_ROOT:-/root/hgnn_910c_readiness/hgnn_f01_qwen3_campaign_v0.3.4}"
SOURCE_CAMPAIGN_ID="${HGNN_R27_SOURCE_CAMPAIGN_ID:-20260814T041544Z-r13-full-dataset}"
SOURCE_MANIFEST="$ROOT/runtime/manifests/$SOURCE_CAMPAIGN_ID/r13_dataset_manifest.json"
R25_ROOT="$ROOT/runtime/extracted_targets_r25/$SOURCE_CAMPAIGN_ID"
DEPLOY_STAMP="$(date -u +%Y%m%dT%H%M%SZ)"
DEFAULT_CAMPAIGN_ID="${HGNN_R27_CAMPAIGN_ID:-${DEPLOY_STAMP}-r27-selective-recapture}"
STATE_PATH="$ROOT/runtime/gates/r27_selective_recapture_progress.json"
AUDIT_PATH="$ROOT/runtime/gates/r27_audit_contract.json"
DEPLOY_LOG="$ROOT/runtime/logs/r27_selective_recapture_${DEPLOY_STAMP}.log"
WORKLOAD="$ROOT/workload"
STATE_PY="$WORKLOAD/r27_state.py"
NODE_SCHEMA="$ROOT/app/schemas/node_features.yaml"
PARSE_WORKERS="${HGNN_R27_PARSE_WORKERS:-4}"
MIN_FREE_GIB="${HGNN_R27_MIN_FREE_GIB:-800}"

CANARY_DURATION="${HGNN_R27_CANARY_DURATION:-180}"
CANARY_BASELINE="${HGNN_R27_CANARY_BASELINE:-36}"
CANARY_RELEASE="${HGNN_R27_CANARY_RELEASE:-126}"

HGNN_PYTHON="${HGNN_PYTHON:-}"

[[ -d "$ROOT" ]] || {
  echo "campaign目录不存在: $ROOT" >&2
  exit 2
}
cd "$ROOT"
mkdir -p runtime/logs runtime/gates runtime/manifests runtime/return_bundles
exec > >(tee -a "$DEPLOY_LOG") 2>&1

# shellcheck disable=SC1091
. "$ROOT/workload/common.sh"
resolve_llm_python

r27_stage() {
  echo "============================================================"
  echo "R27_STAGE=$1/14"
  echo "R27_STAGE_NAME=$2"
  echo "R27_STAGE_UTC=$(date -u +%Y%m%dT%H%M%SZ)"
  echo "============================================================"
}

r27_progress() {
  "$HGNN_PYTHON" "$STATE_PY" "$@"
}

if [[ -f "$STATE_PATH" ]]; then
  CAMPAIGN_ID="$("$HGNN_PYTHON" "$STATE_PY" resolve-campaign-id \
    --progress-path "$STATE_PATH" \
    --default-campaign-id "$DEFAULT_CAMPAIGN_ID")"
else
  CAMPAIGN_ID="$DEFAULT_CAMPAIGN_ID"
fi

DATASET_MANIFEST="$ROOT/runtime/manifests/$CAMPAIGN_ID/r27_dataset_manifest.json"
EXTRACTION_ROOT="$ROOT/runtime/extracted_targets_r25/$CAMPAIGN_ID"
CONTRACT_ROOT="$EXTRACTION_ROOT/contract"
ALIGNMENT_REPORT="$ROOT/runtime/gates/r27_alignment_${CAMPAIGN_ID}.json"
VALIDATION_REPORT="$ROOT/runtime/gates/r27_dataset_validation_${CAMPAIGN_ID}.json"
PACKAGE_DIR="$ROOT/runtime/return_bundles"
mkdir -p "$ROOT/runtime/manifests/$CAMPAIGN_ID" "$EXTRACTION_ROOT" "$PACKAGE_DIR"

r27_discover_telemetry() {
  local run_id="$1"
  r27_progress discover-telemetry --root "$ROOT" --run-id "$run_id" \
    | awk -F= '/R27_TELEMETRY_ROOT/{print $2}'
}

r27_parse_and_gate_run() {
  local run_id="$1" metric="$2" mode="$3" profile_root="$4" gate_dir="$5"
  local inventory parse_report schema_report gate_report parse_cache
  mkdir -p "$gate_dir"
  inventory="$gate_dir/${metric}_collection_inventory.json"
  parse_report="$gate_dir/${metric}_cann_parse_report.json"
  schema_report="$gate_dir/${metric}_schema_audit.json"
  gate_report="$gate_dir/r27_profiler_gate_report.json"
  parse_cache="$gate_dir/parse_cache"

  if [[ -n "${HGNN_R27_PARSE_GATE_COMMAND:-}" ]]; then
    # shellcheck disable=SC2086
    eval HGNN_R27_GATE_RUN_ID="$run_id" \
      HGNN_R27_GATE_METRIC="$metric" \
      HGNN_R27_GATE_MODE="$mode" \
      HGNN_R27_GATE_PROFILE_ROOT="$profile_root" \
      HGNN_R27_GATE_OUTPUT_DIR="$gate_dir" \
      $HGNN_R27_PARSE_GATE_COMMAND
    return $?
  fi

  "$HGNN_PYTHON" "$WORKLOAD/inventory_torch_npu_profile.py" \
    --input-root "$profile_root" \
    --output "$inventory" \
    --metric "$metric" \
    --expected-ranks 16 \
    --mode "$mode" || return 1

  local parse_argv=(
    "$HGNN_PYTHON" "$WORKLOAD/r27_parse_sessions.py"
    --profile-root "$profile_root"
    --metric "$metric"
    --cache-root "$parse_cache"
    --output "$parse_report"
    --max-workers "$PARSE_WORKERS"
  )
  if [[ "${HGNN_R27_MOCK_CANN:-}" == "1" || "${HGNN_R27_MOCK_RUN:-}" == "1" ]]; then
    parse_argv+=(--mock)
  elif [[ -n "${HGNN_MSPROF_PY:-}" ]]; then
    parse_argv+=(--msprof-py "$HGNN_MSPROF_PY")
  fi
  "${parse_argv[@]}" || return 1

  "$HGNN_PYTHON" "$WORKLOAD/validate_r27_profiler_schema.py" \
    --metric-root "$profile_root/$metric" \
    --metric "$metric" \
    --output "$schema_report" \
    --expected-ranks 16 \
    --mode "$mode" || return 1

  local schema_status
  schema_status="$("$HGNN_PYTHON" - "$schema_report" <<'PY'
import json
import sys
from pathlib import Path
print(json.loads(Path(sys.argv[1]).read_text(encoding="utf-8")).get("status"))
PY
)"
  [[ "$schema_status" == "pass" ]] || {
    echo "schema audit failed for $run_id metric=$metric mode=$mode" >&2
    return 1
  }

  "$HGNN_PYTHON" - "$inventory" "$gate_report" "$run_id" "$metric" "$mode" <<'PY'
import json
import sys
from pathlib import Path
inventory = json.loads(Path(sys.argv[1]).read_text(encoding="utf-8"))
payload = {
    "schema_version": "1.0",
    "report_type": "r27_profiler_gate",
    "run_id": sys.argv[3],
    "metric": sys.argv[4],
    "mode": sys.argv[5],
    "status": inventory.get("status"),
}
if payload["status"] != "collection_complete":
    raise SystemExit("profiler gate failed: inventory incomplete")
Path(sys.argv[2]).write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")
print(f"R27_PROFILER_GATE={sys.argv[2]}")
PY
}

r27_revalidate_completed_run() {
  local key="$1" metric="$2" mode="$3"
  local row run_id profile_root gate_dir
  row="$("$HGNN_PYTHON" - "$STATE_PATH" "$key" <<'PY'
import json
import sys
from pathlib import Path
state = json.loads(Path(sys.argv[1]).read_text(encoding="utf-8"))
row = state["runs"][sys.argv[2]]
print(json.dumps(row))
PY
)"
  run_id="$(printf '%s' "$row" | "$HGNN_PYTHON" -c 'import json,sys; print(json.load(sys.stdin)["run_id"])')"
  profile_root="$(printf '%s' "$row" | "$HGNN_PYTHON" -c 'import json,sys; print(json.load(sys.stdin).get("profile_root",""))')"
  [[ -n "$profile_root" ]] || profile_root="$ROOT/runtime/profiles/$run_id"
  gate_dir="$ROOT/runtime/gates/r27_resume_gate/$run_id"
  echo "R27_REVALIDATE=$key run_id=$run_id"
  r27_parse_and_gate_run "$run_id" "$metric" "$mode" "$profile_root" "$gate_dir"
}

r27_execute_canary_run() {
  local key="$1" metric="$2"
  local run_id gate_dir profile_root rc telemetry_root
  if [[ "$(r27_progress should-skip --progress-path "$STATE_PATH" --key "$key")" == "yes" ]]; then
    echo "R27_SKIP_CANARY=$key"
    r27_revalidate_completed_run "$key" "$metric" "canary"
    return $?
  fi
  while true; do
    if ! run_id="$(r27_progress begin --progress-path "$STATE_PATH" --key "$key" 2>&1 | awk -F= '/R27_RUN_ID/{print $2}')"; then
      echo "R27_CANARY_EXHAUSTED=$key" >&2
      return 1
    fi
    [[ -n "$run_id" ]] || return 1
    echo "R27_CONDITION=$key"
    echo "R27_ATTEMPT=$(grep -o 'a[0-9]\+' <<<"$run_id" || true)"
    echo "RUN_ID=$run_id"
    echo "AIC_METRIC=$metric"
    echo "R27_BACKEND=${HGNN_R27_MOCK_RUN:-live}"

    export HGNN_FORMAL_DURATION="$CANARY_DURATION"
    export HGNN_FORMAL_BASELINE="$CANARY_BASELINE"
    export HGNN_FORMAL_RELEASE_AT="$CANARY_RELEASE"
    export HGNN_PROFILE_INVENTORY_MODE="canary"
    export HGNN_TORCH_NPU_AIC_METRIC="$metric"
    profile_root="$ROOT/runtime/profiles/$run_id"
    gate_dir="$ROOT/runtime/gates/r27_canary_gate/$run_id"

    if [[ "${HGNN_R27_MOCK_RUN:-}" == "1" ]]; then
    export HGNN_R27_MOCK_TIMESTAMP_US="$("$HGNN_PYTHON" - "$WORKLOAD" "$CANARY_BASELINE" "$CANARY_RELEASE" <<'PY'
import sys
sys.path.insert(0, sys.argv[1])
from r27_state import mock_profiler_timestamp_us
print(mock_profiler_timestamp_us(baseline_s=float(sys.argv[2]), release_at_s=float(sys.argv[3])))
PY
)"
    "$HGNN_PYTHON" - "$profile_root" "$metric" "$WORKLOAD" "$ROOT" "$run_id" \
      "$CANARY_DURATION" "$CANARY_BASELINE" "$CANARY_RELEASE" <<'PY'
import sys
from pathlib import Path
sys.path.insert(0, sys.argv[3])
from r27_state import materialize_mock_profile_root, materialize_mock_run_sidecars
profile_root = Path(sys.argv[1])
metric = sys.argv[2]
root = Path(sys.argv[4])
run_id = sys.argv[5]
materialize_mock_profile_root(profile_root, metric, effective_steps=4)
materialize_mock_run_sidecars(
    root,
    run_id,
    condition="manual_baseline_sham",
    duration_s=float(sys.argv[6]),
    baseline_s=float(sys.argv[7]),
    release_at_s=float(sys.argv[8]),
)
print(f"R27_MOCK_PROFILE={profile_root}")
PY
      rc=0
    else
      set +e
      RUN_ID="$run_id" "$ROOT/20_manual_sham_training.sh"
      rc=$?
      set -e
    fi
    if ((rc != 0)); then
      r27_progress finish --progress-path "$STATE_PATH" --key "$key" --status failed \
        --detail "canary_run_rc=$rc" || true
      echo "R27_CANARY_ATTEMPT_FAILED=$key rc=$rc" >&2
      continue
    fi
    if ! r27_parse_and_gate_run "$run_id" "$metric" "canary" "$profile_root" "$gate_dir"; then
      r27_progress finish --progress-path "$STATE_PATH" --key "$key" --status failed \
        --detail "canary_gate_failed" || true
      echo "R27_CANARY_GATE_FAILED=$key" >&2
      continue
    fi
    telemetry_root="$(r27_discover_telemetry "$run_id" || true)"
    r27_progress finish --progress-path "$STATE_PATH" --key "$key" --status complete \
      --detail "$gate_dir/r27_profiler_gate_report.json" \
      --profile-root "$profile_root" \
      --telemetry-root "$telemetry_root" \
      --all-ranks-complete
    echo "R27_CANARY_COMPLETE=$key"
    return 0
  done
}

r27_execute_formal_group() {
  local key="$1"
  local spec_json condition metric script drawer run_id profile_root gate_dir rc telemetry_root
  if [[ "$(r27_progress should-skip --progress-path "$STATE_PATH" --key "$key")" == "yes" ]]; then
    echo "R27_SKIP_FORMAL=$key"
    spec_json="$("$HGNN_PYTHON" - "$STATE_PATH" "$key" <<'PY'
import json
import sys
from pathlib import Path
state = json.loads(Path(sys.argv[1]).read_text(encoding="utf-8"))
print(json.dumps(state["runs"][sys.argv[2]]))
PY
)"
    if [[ "$(printf '%s' "$spec_json" | "$HGNN_PYTHON" -c 'import json,sys; print(json.load(sys.stdin).get("status"))')" == "reused" ]]; then
      return 0
    fi
    metric="$(printf '%s' "$spec_json" | "$HGNN_PYTHON" -c 'import json,sys; print(json.load(sys.stdin).get("metric",""))')"
    [[ -n "$metric" ]] || {
      metric="$("$HGNN_PYTHON" - "$STATE_PATH" "$key" <<'PY'
import json
import sys
from pathlib import Path
state = json.loads(Path(sys.argv[1]).read_text(encoding="utf-8"))
for item in state["plan"]:
    if item["key"] == sys.argv[2]:
        print(item["metric"])
        break
PY
)"
    }
    r27_revalidate_completed_run "$key" "$metric" "formal"
    return $?
  fi
  if [[ "$(r27_progress can-run-fault --progress-path "$STATE_PATH")" != "yes" ]]; then
    echo "R27_FAULT_BLOCKED=$key canary_not_passed" >&2
    return 2
  fi
  spec_json="$("$HGNN_PYTHON" - "$STATE_PATH" "$key" <<'PY'
import json
import sys
from pathlib import Path
state = json.loads(Path(sys.argv[1]).read_text(encoding="utf-8"))
key = sys.argv[2]
for item in state["plan"]:
    if item["key"] == key:
        print(json.dumps(item))
        break
else:
    raise SystemExit(f"unknown key {key}")
PY
)"
  condition="$(printf '%s' "$spec_json" | "$HGNN_PYTHON" -c 'import json,sys; print(json.load(sys.stdin)["condition"])')"
  metric="$(printf '%s' "$spec_json" | "$HGNN_PYTHON" -c 'import json,sys; print(json.load(sys.stdin)["metric"])')"
  script="$(printf '%s' "$spec_json" | "$HGNN_PYTHON" -c 'import json,sys; print(json.load(sys.stdin)["script"])')"
  drawer="$(printf '%s' "$spec_json" | "$HGNN_PYTHON" -c 'import json,sys; print(json.load(sys.stdin)["drawer"])')"

  while true; do
    if ! run_id="$(r27_progress begin --progress-path "$STATE_PATH" --key "$key" 2>&1 | awk -F= '/R27_RUN_ID/{print $2}')"; then
      echo "R27_FORMAL_EXHAUSTED=$key" >&2
      return 1
    fi
    [[ -n "$run_id" ]] || return 1
    echo "R27_CONDITION=$key"
    echo "R27_ATTEMPT=$(grep -o 'a[0-9]\+' <<<"$run_id" || true)"
    echo "RUN_ID=$run_id"
    echo "CONDITION=$condition"
    echo "AIC_METRIC=$metric"
    echo "R27_BACKEND=${HGNN_R27_MOCK_RUN:-live}"

    export HGNN_FORMAL_DURATION="600"
    export HGNN_FORMAL_BASELINE="120"
    export HGNN_FORMAL_RELEASE_AT="420"
    export HGNN_PROFILE_INVENTORY_MODE="formal"
    export HGNN_TORCH_NPU_AIC_METRIC="$metric"
    profile_root="$ROOT/runtime/profiles/$run_id"
    gate_dir="$ROOT/runtime/gates/r27_formal_gate/$run_id"

    if [[ "${HGNN_R27_MOCK_RUN:-}" == "1" ]]; then
      export HGNN_R27_MOCK_TIMESTAMP_US="$("$HGNN_PYTHON" - "$WORKLOAD" "120" "420" <<'PY'
import sys
sys.path.insert(0, sys.argv[1])
from r27_state import mock_profiler_timestamp_us
print(mock_profiler_timestamp_us(baseline_s=float(sys.argv[2]), release_at_s=float(sys.argv[3])))
PY
)"
      "$HGNN_PYTHON" - "$profile_root" "$metric" "$WORKLOAD" "$ROOT" "$run_id" \
        "600" "120" "420" "$condition" <<'PY'
import sys
from pathlib import Path
sys.path.insert(0, sys.argv[3])
from r27_state import materialize_mock_profile_root, materialize_mock_run_sidecars
profile_root = Path(sys.argv[1])
metric = sys.argv[2]
root = Path(sys.argv[4])
run_id = sys.argv[5]
materialize_mock_profile_root(profile_root, metric, effective_steps=120)
materialize_mock_run_sidecars(
    root,
    run_id,
    condition=sys.argv[9],
    duration_s=float(sys.argv[6]),
    baseline_s=float(sys.argv[7]),
    release_at_s=float(sys.argv[8]),
)
print(f"R27_MOCK_PROFILE={profile_root}")
PY
      rc=0
    else
      set +e
      RUN_ID="$run_id" "$ROOT/$script"
      rc=$?
      set -e
    fi
    if ((rc != 0)); then
      r27_progress finish --progress-path "$STATE_PATH" --key "$key" --status failed \
        --detail "formal_run_rc=$rc" || true
      echo "R27_FORMAL_ATTEMPT_FAILED=$key rc=$rc" >&2
      continue
    fi
    if ! r27_parse_and_gate_run "$run_id" "$metric" "formal" "$profile_root" "$gate_dir"; then
      r27_progress finish --progress-path "$STATE_PATH" --key "$key" --status failed \
        --detail "formal_gate_failed" || true
      echo "R27_FORMAL_GATE_FAILED=$key" >&2
      continue
    fi
    telemetry_root="$(r27_discover_telemetry "$run_id")"
    r27_progress complete-group --progress-path "$STATE_PATH" --key "$key" \
      --profile-root "$profile_root" \
      --telemetry-root "$telemetry_root"
    echo "R27_FORMAL_COMPLETE=$key"
    du -sh "$profile_root" || true
    return 0
  done
}

r27_stage 1 "启动与遗留进程检查"
echo "R27_STARTED=$DEPLOY_STAMP"
echo "R27_CAMPAIGN_ID=$CAMPAIGN_ID"
echo "R27_STATE=$STATE_PATH"
echo "R27_AUDIT=$AUDIT_PATH"
echo "R27_LOG=$DEPLOY_LOG"
if [[ "${HGNN_R27_SKIP_PROCESS_CHECK:-}" != "1" ]] && \
  pgrep -af 'torchrun|posttrain_gpt|msprof' >runtime/logs/r27_process_check.txt; then
  echo "检测到遗留训练或Profiler进程，拒绝启动：" >&2
  while IFS= read -r process; do echo "$process" >&2; done \
    <runtime/logs/r27_process_check.txt
  exit 2
fi
[[ "$MIN_FREE_GIB" =~ ^[0-9]+$ ]] || {
  echo "HGNN_R27_MIN_FREE_GIB必须是非负整数" >&2
  exit 2
}
FREE_GIB="$("$HGNN_PYTHON" - "$ROOT" <<'PY'
import shutil
import sys
print(shutil.disk_usage(sys.argv[1]).free // (1024 ** 3))
PY
)"
echo "R27_FREE_GIB=$FREE_GIB"
if [[ "${HGNN_R27_MOCK_RUN:-}" != "1" ]] && ((FREE_GIB < MIN_FREE_GIB)); then
  echo "可用空间不足${MIN_FREE_GIB}GiB，拒绝开始补采" >&2
  exit 2
fi

ASCEND_ENV=""
for candidate in \
  /usr/local/Ascend/ascend-toolkit/set_env.sh \
  /usr/local/Ascend/ascend-toolkit/latest/set_env.sh
do
  [[ -f "$candidate" ]] && { ASCEND_ENV="$candidate"; break; }
done
if [[ "${HGNN_R27_MOCK_RUN:-}" != "1" ]]; then
  [[ -n "$ASCEND_ENV" ]] || {
    echo "未找到Ascend环境脚本" >&2
    exit 2
  }
  set +u
  # shellcheck disable=SC1090
  source "$ASCEND_ENV"
  set -u
  export HGNN_MSPROF_PY="${HGNN_MSPROF_PY:-/usr/local/Ascend/cann-8.5.2/tools/profiler/profiler_tool/analysis/msprof/msprof.py}"
  [[ -f "$HGNN_MSPROF_PY" ]] || {
    echo "msprof.py不存在: $HGNN_MSPROF_PY" >&2
    exit 2
  }
fi

r27_stage 2 "读取旧r13 manifest与r25 extraction root"
[[ -f "$SOURCE_MANIFEST" && ! -L "$SOURCE_MANIFEST" ]] || {
  echo "缺少源dataset manifest: $SOURCE_MANIFEST" >&2
  exit 2
}
[[ -d "$R25_ROOT" ]] || {
  echo "缺少r25 extraction root: $R25_ROOT" >&2
  exit 2
}
echo "R27_SOURCE_MANIFEST=$SOURCE_MANIFEST"
echo "R27_R25_ROOT=$R25_ROOT"

r27_stage 3 "深审计r25 extraction contract"
"$HGNN_PYTHON" "$WORKLOAD/audit_r25_extraction_contract.py" \
  --dataset-manifest "$SOURCE_MANIFEST" \
  --extraction-root "$R25_ROOT" \
  --output "$AUDIT_PATH"

r27_stage 4 "初始化或恢复r27 progress state"
campaign_init
r27_progress init \
  --progress-path "$STATE_PATH" \
  --campaign-id "$CAMPAIGN_ID" \
  --source-campaign-id "$SOURCE_CAMPAIGN_ID" \
  --source-dataset-manifest "$SOURCE_MANIFEST" \
  --audit-report "$AUDIT_PATH"
CAMPAIGN_ID="$(r27_progress resolve-campaign-id \
  --progress-path "$STATE_PATH" \
  --default-campaign-id "$CAMPAIGN_ID")"
DATASET_MANIFEST="$ROOT/runtime/manifests/$CAMPAIGN_ID/r27_dataset_manifest.json"
EXTRACTION_ROOT="$ROOT/runtime/extracted_targets_r25/$CAMPAIGN_ID"
mkdir -p "$ROOT/runtime/manifests/$CAMPAIGN_ID" "$EXTRACTION_ROOT"

r27_stage 5 "Canary前置检查(smoke gate，不启动fault)"
require_smoke_gate "drawer0"
PREFLIGHT_ID="${DEPLOY_STAMP}-r27-preflight"
export HGNN_TORCH_NPU_AIC_METRIC=ResourceConflictRatio
HGNN_RUN_ID="$PREFLIGHT_ID" ./workload/check_training_prereqs.sh
if [[ "${HGNN_R27_MOCK_RUN:-}" != "1" ]]; then
  ACTIVE_PREFLIGHT="$ROOT/runtime/outputs/preflight/$PREFLIGHT_ID"
  mkdir -p "$ACTIVE_PREFLIGHT"
  "$HGNN_PYTHON" "$RUNNER" preflight \
    --site-config "$(site_for_drawer drawer0)" \
    --credentials-env-file "$CREDENTIALS" \
    --collector-config "$COLLECTOR_CONFIG" \
    --output-dir "$ACTIVE_PREFLIGHT"
fi
echo "R27_CANARY_PREFLIGHT=PASS"

r27_stage 6 "Canary ResourceConflictRatio采集+CANN解析+schema"
r27_execute_canary_run canary_resource_conflict ResourceConflictRatio

r27_stage 7 "Canary MemoryAccess采集+CANN解析+schema"
r27_execute_canary_run canary_memory_access MemoryAccess

r27_stage 8 "Canary双family解锁fault组"
r27_progress mark-canary-passed --progress-path "$STATE_PATH"
echo "R27_CANARY_UNLOCK_FAULT_GROUPS=1"

r27_stage 9 "Formal重采 control_resource_conflict"
r27_execute_formal_group control_resource_conflict

r27_stage 10 "Formal重采 fault_resource_conflict"
r27_execute_formal_group fault_resource_conflict

r27_stage 11 "Formal重采 fault_memory_access"
r27_execute_formal_group fault_memory_access

r27_stage 12 "Formal control_memory_access或复用标记"
if [[ "$(
  "$HGNN_PYTHON" - "$STATE_PATH" <<'PY'
import json
import sys
from pathlib import Path
state = json.loads(Path(sys.argv[1]).read_text(encoding="utf-8"))
print("skip" if state.get("reuse_control_memory") else "run")
PY
)" == "run" ]]; then
  r27_execute_formal_group control_memory_access
else
  echo "R27_SKIP_REUSED=control_memory_access"
fi

r27_stage 13 "构建manifest+64 extraction+对齐+83终验"
r27_progress build-manifest \
  --progress-path "$STATE_PATH" \
  --root "$ROOT" \
  --output "$DATASET_MANIFEST"
echo "R27_DATASET_MANIFEST=$DATASET_MANIFEST"

mkdir -p "$CONTRACT_ROOT"
"$HGNN_PYTHON" "$WORKLOAD/prepare_r23_extraction_contract.py" \
  --dataset-manifest "$DATASET_MANIFEST" \
  --node-schema "$NODE_SCHEMA" \
  --output-root "$CONTRACT_ROOT"

"$HGNN_PYTHON" "$WORKLOAD/r27_reuse_r25_sessions.py" \
  --dataset-manifest "$DATASET_MANIFEST" \
  --source-r25-root "$R25_ROOT" \
  --target-r25-root "$EXTRACTION_ROOT"

"$HGNN_PYTHON" "$WORKLOAD/extract_r25_real_csv_metrics.py" \
  --selection-manifest "$CONTRACT_ROOT/r23_selection_manifest.json" \
  --output-root "$EXTRACTION_ROOT" \
  --r23-output-root "$EXTRACTION_ROOT" \
  --metric-coverage "$CONTRACT_ROOT/metric_coverage_83.json" \
  --max-workers "${HGNN_R27_EXTRACT_WORKERS:-8}" \
  --trust-complete-reports

"$HGNN_PYTHON" "$WORKLOAD/r27_validate_alignment.py" \
  --root "$ROOT" \
  --dataset-manifest "$DATASET_MANIFEST" \
  --extraction-root "$EXTRACTION_ROOT" \
  --output "$ALIGNMENT_REPORT"

"$HGNN_PYTHON" "$WORKLOAD/r27_validate_dataset_83.py" \
  --dataset-manifest "$DATASET_MANIFEST" \
  --extraction-root "$EXTRACTION_ROOT" \
  --metric-coverage "$CONTRACT_ROOT/metric_coverage_83.json" \
  --alignment-report "$ALIGNMENT_REPORT" \
  --output "$VALIDATION_REPORT"

R27_PROVENANCE="$EXTRACTION_ROOT/provenance/r27"
mkdir -p "$R27_PROVENANCE"
cp "$AUDIT_PATH" "$R27_PROVENANCE/audit_contract.json"
cp "$ALIGNMENT_REPORT" "$R27_PROVENANCE/alignment_report.json"
cp "$VALIDATION_REPORT" "$R27_PROVENANCE/dataset_validation_83.json"
cp "$STATE_PATH" "$R27_PROVENANCE/progress.json"

r27_stage 14 "打包最终dataset bundle"
"$HGNN_PYTHON" "$WORKLOAD/package_extracted_dataset.py" \
  --dataset-manifest "$DATASET_MANIFEST" \
  --extraction-root "$EXTRACTION_ROOT" \
  --output-dir "$PACKAGE_DIR" \
  --bundle-label "r27-extracted-dataset"

BUNDLE_PATH="$PACKAGE_DIR/${CAMPAIGN_ID}-r27-extracted-dataset.tar.gz"
BUNDLE_SHA="${BUNDLE_PATH}.sha256"
[[ -n "$BUNDLE_PATH" && -f "$BUNDLE_PATH" ]] || {
  echo "missing dataset bundle under $PACKAGE_DIR" >&2
  exit 2
}
echo "R27_COMPLETE=1"
echo "R27_DATASET_BUNDLE=$(readlink -f "$BUNDLE_PATH")"
echo "R27_DATASET_BUNDLE_SHA256=$(readlink -f "$BUNDLE_SHA")"
echo "R27_DATASET_MANIFEST=$DATASET_MANIFEST"
echo "R27_EXTRACTION_ROOT=$EXTRACTION_ROOT"
echo "R27_LOG=$DEPLOY_LOG"
