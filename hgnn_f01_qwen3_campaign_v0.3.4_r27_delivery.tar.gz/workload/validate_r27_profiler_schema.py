#!/usr/bin/env python3
"""Audit existing CSV or SQLite profiler schema and data for one metric root."""

from __future__ import annotations

import argparse
import csv
import json
import math
import re
import sqlite3
from pathlib import Path
from typing import Any, Iterable, Mapping, Sequence

from extract_r25_real_csv_metrics import (
    COMMON_COLUMNS,
    IDENTITY_COLUMNS,
    MEMORY_COLUMNS,
    RESOURCE_COLUMNS,
    RESOURCE_COMPONENTS,
    discover_csv_slices,
    discover_split_memory_sqlite_sources,
    discover_sqlite_files,
    discover_sqlite_sources,
    inspect_csv_schema,
    inspect_split_sqlite_schema,
    inspect_sqlite_schema,
    iter_split_memory_sqlite_rows,
    quote_identifier,
    required_columns,
)
from torch_npu_offline_common import atomic_json, numeric


SESSION_RE = re.compile(r"^rank_(\d+)_.*_ascend_pt$")
GATE_MODES = {
    "formal": {"min_data_rows": 1},
    "canary": {"min_data_rows": 1},
}


def _finite_positive(value: Any) -> float | None:
    number = numeric(value)
    if number is None or not math.isfinite(number) or number <= 0:
        return None
    return number


def _finite_non_negative(value: Any) -> float | None:
    number = numeric(value)
    if number is None or not math.isfinite(number) or number < 0:
        return None
    return number


def csv_has_valid_data(
    files: Sequence[Path], metric_family: str, min_rows: int
) -> tuple[bool, str, int]:
    valid_rows = 0
    for path in files:
        try:
            with path.open(encoding="utf-8-sig", newline="") as stream:
                reader = csv.DictReader(stream)
                if reader.fieldnames is None:
                    continue
                for row in reader:
                    if metric_family == "ResourceConflictRatio":
                        cycles = _finite_positive(row.get("aiv_total_cycles"))
                        if cycles is None:
                            continue
                        conflict = any(
                            _finite_non_negative(row.get(column)) is not None
                            for column in RESOURCE_COMPONENTS
                        )
                        if conflict:
                            valid_rows += 1
                    elif metric_family == "MemoryAccess":
                        start = _finite_positive(row.get("Task Start Time(us)"))
                        if start is None:
                            continue
                        memory = any(
                            _finite_non_negative(row.get(column)) is not None
                            for column in MEMORY_COLUMNS
                        )
                        if memory:
                            valid_rows += 1
                    if valid_rows >= min_rows:
                        return True, "ok", valid_rows
        except (OSError, UnicodeDecodeError, csv.Error) as error:
            return False, f"{type(error).__name__}: {error}", valid_rows
    return False, "no_valid_data_rows", valid_rows


def sqlite_has_valid_data(
    sources: Sequence[Mapping[str, Any]],
    metric_family: str,
    min_rows: int,
) -> tuple[bool, str, int]:
    valid_rows = 0
    for source in sources:
        database = Path(str(source["database"]))
        table = str(source["table"])
        columns = tuple(str(column) for column in source.get("columns", []))
        if not columns:
            continue
        query = (
            f"SELECT {', '.join(quote_identifier(column) for column in columns)} "
            f"FROM {quote_identifier(table)} LIMIT 64"
        )
        connection: sqlite3.Connection | None = None
        try:
            connection = sqlite3.connect(
                database.resolve(strict=True).as_uri() + "?mode=ro",
                uri=True,
                timeout=5.0,
            )
            connection.execute("PRAGMA query_only=ON")
            for row in connection.execute(query):
                payload = dict(zip(columns, row))
                if metric_family == "ResourceConflictRatio":
                    cycles = _finite_positive(payload.get("aiv_total_cycles"))
                    if cycles is None:
                        continue
                    conflict = any(
                        _finite_non_negative(payload.get(column)) is not None
                        for column in RESOURCE_COMPONENTS
                    )
                    if conflict:
                        valid_rows += 1
                elif metric_family == "MemoryAccess":
                    start = _finite_positive(payload.get("Task Start Time(us)"))
                    if start is None:
                        continue
                    memory = any(
                        _finite_non_negative(payload.get(column)) is not None
                        for column in MEMORY_COLUMNS
                    )
                    if memory:
                        valid_rows += 1
                if valid_rows >= min_rows:
                    return True, "ok", valid_rows
        except sqlite3.Error as error:
            return False, f"sqlite_error:{error}", valid_rows
        finally:
            if connection is not None:
                connection.close()
    return False, "no_valid_sqlite_rows", valid_rows


def split_sqlite_has_valid_data(
    sources: Sequence[Mapping[str, Any]], min_rows: int
) -> tuple[bool, str, int]:
    valid_rows = 0
    try:
        for row in iter_split_memory_sqlite_rows(sources):
            start = _finite_positive(row.get("Task Start Time(us)"))
            if start is None:
                continue
            memory = any(
                _finite_non_negative(row.get(column)) is not None
                for column in MEMORY_COLUMNS
            )
            if memory:
                valid_rows += 1
            if valid_rows >= min_rows:
                return True, "ok", valid_rows
    except sqlite3.Error as error:
        return False, f"split_sqlite_error:{error}", valid_rows
    return False, "no_valid_split_sqlite_rows", valid_rows


def discover_sessions(metric_root: Path, expected_ranks: int) -> dict[int, Path]:
    sessions: dict[int, Path] = {}
    for path in metric_root.iterdir():
        match = SESSION_RE.fullmatch(path.name)
        if match is None or not path.is_dir() or path.is_symlink():
            continue
        rank = int(match.group(1))
        if rank in sessions:
            raise SystemExit(f"duplicate session for rank {rank}")
        sessions[rank] = path.resolve(strict=True)
    if set(sessions) != set(range(expected_ranks)):
        missing = sorted(set(range(expected_ranks)) - set(sessions))
        raise SystemExit(f"missing sessions for ranks: {missing}")
    return sessions


def audit_session(
    session: Path,
    metric_family: str,
    min_rows: int,
) -> Mapping[str, Any]:
    csv_files = discover_csv_slices(session)
    csv_schema = inspect_csv_schema(csv_files, metric_family)
    sqlite_sources = discover_sqlite_sources(session, metric_family)
    sqlite_schema = inspect_sqlite_schema(sqlite_sources, metric_family)
    split_sources: tuple[Mapping[str, Any], ...] = ()
    split_schema: Mapping[str, Any] | None = None
    if metric_family == "MemoryAccess" and not sqlite_sources:
        split_sources = discover_split_memory_sqlite_sources(session)
        if split_sources:
            split_schema = inspect_split_sqlite_schema(split_sources)

    backend = "missing"
    schema: Mapping[str, Any] = {"status": "missing", "metric_family": metric_family}
    data_ok = False
    data_reason = "no_backend"
    valid_rows = 0

    if csv_schema.get("status") == "valid":
        backend = "existing_real_op_summary_csv"
        schema = csv_schema
        data_ok, data_reason, valid_rows = csv_has_valid_data(
            csv_files, metric_family, min_rows
        )
    elif sqlite_schema.get("status") == "valid":
        backend = "existing_real_sqlite"
        schema = sqlite_schema
        data_ok, data_reason, valid_rows = sqlite_has_valid_data(
            sqlite_sources, metric_family, min_rows
        )
    elif split_schema is not None and split_schema.get("status") == "valid":
        backend = "existing_real_sqlite_split_join"
        schema = split_schema
        data_ok, data_reason, valid_rows = split_sqlite_has_valid_data(
            split_sources, min_rows
        )

    passed = backend != "missing" and data_ok
    return {
        "session": str(session.resolve(strict=True)),
        "backend": backend,
        "schema": schema,
        "csv_file_count": len(csv_files),
        "sqlite_database_count": len(discover_sqlite_files(session)),
        "required_columns": list(required_columns(metric_family)),
        "resource_cycle_column": RESOURCE_COLUMNS[0],
        "resource_conflict_columns": list(RESOURCE_COMPONENTS),
        "memory_kb_columns": list(MEMORY_COLUMNS),
        "time_columns": list(COMMON_COLUMNS),
        "identity_columns": list(IDENTITY_COLUMNS),
        "valid_data_rows": valid_rows,
        "data_status": data_reason,
        "status": "pass" if passed else "fail",
        "reasons": [] if passed else [data_reason if backend != "missing" else "schema_missing"],
    }


def audit_metric_root(
    metric_root: Path,
    metric_family: str,
    expected_ranks: int,
    mode: str,
) -> Mapping[str, Any]:
    min_rows = GATE_MODES[mode]["min_data_rows"]
    if not metric_root.is_dir() or metric_root.is_symlink():
        raise SystemExit(f"missing metric root: {metric_root}")
    sessions = discover_sessions(metric_root.resolve(strict=True), expected_ranks)
    ranks: list[Mapping[str, Any]] = []
    failures: list[str] = []
    for rank in range(expected_ranks):
        row = dict(audit_session(sessions[rank], metric_family, min_rows))
        row["rank"] = rank
        ranks.append(row)
        if row["status"] != "pass":
            failures.append(f"rank_{rank}:{','.join(row['reasons'])}")

    return {
        "schema_version": "1.0",
        "report_type": "r27_profiler_schema_audit",
        "gate_kind": "schema_and_data",
        "mode": mode,
        "metric_family": metric_family,
        "metric_root": str(metric_root.resolve(strict=True)),
        "expected_ranks": expected_ranks,
        "status": "pass" if not failures else "fail",
        "failed_ranks": failures,
        "ranks": ranks,
    }


def main() -> int:
    parser = argparse.ArgumentParser(
        description=(
            "Audit 16 rank sessions under one metric root for real CSV/SQLite "
            "schema and non-empty metric data."
        )
    )
    parser.add_argument("--metric-root", type=Path, required=True)
    parser.add_argument("--metric", required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--expected-ranks", type=int, default=16)
    parser.add_argument(
        "--mode",
        choices=sorted(GATE_MODES),
        default="formal",
    )
    args = parser.parse_args()
    if args.metric not in {"ResourceConflictRatio", "MemoryAccess"}:
        raise SystemExit("unsupported metric")
    if args.expected_ranks < 1:
        raise SystemExit("expected-ranks must be positive")

    report = audit_metric_root(
        args.metric_root.resolve(strict=True),
        args.metric,
        args.expected_ranks,
        args.mode,
    )
    output = args.output.resolve(strict=False)
    atomic_json(output, report)
    print(f"R27_SCHEMA_AUDIT={output}")
    if report["status"] != "pass":
        raise SystemExit(
            "schema audit failed: " + ", ".join(report["failed_ranks"])
        )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
