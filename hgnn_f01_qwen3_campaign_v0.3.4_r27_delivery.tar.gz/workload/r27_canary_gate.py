#!/usr/bin/env python3
"""Canary/formal profiler gate CLI for runner integration (no training)."""

from __future__ import annotations

import argparse
import json
import subprocess
import sys
from pathlib import Path
from typing import Any, Mapping

from torch_npu_offline_common import atomic_json


METRIC_FAMILIES = ("ResourceConflictRatio", "MemoryAccess")


def _profile_root_for_metric(
    metric: str,
    default_root: Path,
    overrides: Mapping[str, Path | None],
) -> Path:
    override = overrides.get(metric)
    return default_root if override is None else override


def _run_stage(
    argv: list[str], label: str
) -> subprocess.CompletedProcess[str]:
    completed = subprocess.run(
        argv,
        text=True,
        capture_output=True,
        check=False,
    )
    if completed.returncode != 0:
        detail = completed.stderr.strip() or completed.stdout.strip()
        raise SystemExit(f"{label} failed: {detail}")
    return completed


def gate_profile_root(
    default_profile_root: Path,
    output_dir: Path,
    mode: str,
    expected_ranks: int,
    inventory_script: Path,
    schema_script: Path,
    *,
    metric_profile_roots: Mapping[str, Path | None] | None = None,
) -> Mapping[str, Any]:
    output_dir.mkdir(parents=True, exist_ok=True)
    overrides = metric_profile_roots or {}
    metrics: dict[str, Any] = {}
    for metric in METRIC_FAMILIES:
        profile_root = _profile_root_for_metric(
            metric, default_profile_root, overrides
        ).resolve(strict=True)
        inventory_output = output_dir / f"{metric}_collection_inventory.json"
        schema_output = output_dir / f"{metric}_schema_audit.json"
        _run_stage(
            [
                sys.executable,
                str(inventory_script),
                "--input-root",
                str(profile_root),
                "--output",
                str(inventory_output),
                "--metric",
                metric,
                "--expected-ranks",
                str(expected_ranks),
                "--mode",
                mode,
            ],
            f"collection inventory ({metric})",
        )
        _run_stage(
            [
                sys.executable,
                str(schema_script),
                "--metric-root",
                str(profile_root / metric),
                "--metric",
                metric,
                "--output",
                str(schema_output),
                "--expected-ranks",
                str(expected_ranks),
                "--mode",
                mode,
            ],
            f"schema audit ({metric})",
        )
        metrics[metric] = {
            "profile_root": str(profile_root),
            "collection_inventory": str(inventory_output),
            "schema_audit": str(schema_output),
            "collection_status": json.loads(
                inventory_output.read_text(encoding="utf-8")
            ).get("status"),
            "schema_status": json.loads(
                schema_output.read_text(encoding="utf-8")
            ).get("status"),
        }

    failed = [
        metric
        for metric, payload in metrics.items()
        if payload["collection_status"] != "collection_complete"
        or payload["schema_status"] != "pass"
    ]
    report = {
        "schema_version": "1.0",
        "report_type": "r27_profiler_gate",
        "gate_kind": "collection_plus_schema",
        "mode": mode,
        "profile_root": str(default_profile_root.resolve(strict=True)),
        "expected_ranks": expected_ranks,
        "metric_families": list(METRIC_FAMILIES),
        "status": "pass" if not failed else "fail",
        "failed_metrics": failed,
        "metrics": metrics,
    }
    return report


def main() -> int:
    parser = argparse.ArgumentParser(
        description=(
            "Run collection inventory and schema audit for both metric families "
            "without launching training."
        )
    )
    parser.add_argument(
        "--profile-root",
        type=Path,
        required=True,
        help="Default profile root when a metric-specific override is absent",
    )
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument(
        "--resource-profile-root",
        type=Path,
        default=None,
        help="Override profile root for ResourceConflictRatio",
    )
    parser.add_argument(
        "--memory-profile-root",
        type=Path,
        default=None,
        help="Override profile root for MemoryAccess",
    )
    parser.add_argument(
        "--mode",
        choices=("canary", "formal"),
        default="canary",
    )
    parser.add_argument("--expected-ranks", type=int, default=16)
    args = parser.parse_args()
    if args.expected_ranks < 1:
        raise SystemExit("expected-ranks must be positive")

    workload_dir = Path(__file__).resolve().parent
    report = gate_profile_root(
        args.profile_root.resolve(strict=True),
        args.output_dir.resolve(strict=False),
        args.mode,
        args.expected_ranks,
        workload_dir / "inventory_torch_npu_profile.py",
        workload_dir / "validate_r27_profiler_schema.py",
        metric_profile_roots={
            "ResourceConflictRatio": args.resource_profile_root,
            "MemoryAccess": args.memory_profile_root,
        },
    )
    output = args.output_dir / "r27_profiler_gate_report.json"
    atomic_json(output, report)
    print(f"R27_PROFILER_GATE={output}")
    if report["status"] != "pass":
        raise SystemExit(
            "profiler gate failed: " + ", ".join(report["failed_metrics"])
        )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
