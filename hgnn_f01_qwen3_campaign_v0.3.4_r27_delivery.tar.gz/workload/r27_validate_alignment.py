#!/usr/bin/env python3
"""Validate temporal alignment across profiler, protocol, and telemetry per run."""

from __future__ import annotations

import argparse
import csv
import json
import math
from pathlib import Path
from typing import Any, Mapping, Sequence

from audit_r25_extraction_contract import read_parquet_rows
from prepare_r23_extraction_contract import EXPECTED_CASE_SPECS
from torch_npu_offline_common import atomic_json, load_dataset_entries, load_json

CANONICAL_NAME = "canonical_profiler_metrics.parquet"
REPORT_NAME = "r25_session_report.json"


def _finite_us(value: Any) -> float | None:
    if isinstance(value, bool):
        return None
    if isinstance(value, str):
        text = value.strip()
        if not text:
            return None
        try:
            value = float(text)
        except ValueError:
            return None
    if isinstance(value, (int, float)):
        number = float(value)
        return number if math.isfinite(number) else None
    return None


def _intervals_overlap(a_min: float, a_max: float, b_min: float, b_max: float) -> bool:
    return a_min <= b_max and b_min <= a_max


def _profile_window(
    root: Path,
    run_id: str,
    formal_root: Path,
) -> tuple[float, float, Mapping[str, Any]]:
    protocol_path = formal_root / "protocol_report.json"
    if not protocol_path.is_file():
        raise SystemExit(f"missing protocol report: {protocol_path}")
    protocol = load_json(protocol_path)
    if protocol.get("status") != "complete" or protocol.get("passed") is not True:
        raise SystemExit(f"protocol not complete: {protocol_path}")

    control_path = root / "runtime/manifests" / run_id / "profile_control.json"
    if control_path.is_file():
        control = load_json(control_path)
        commands = control.get("commands", [])
        by_command = {
            str(item.get("command")): item
            for item in commands
            if isinstance(item, Mapping)
        }
        start_ns = _finite_us(by_command.get("start", {}).get("utc_ns"))
        stop_ns = _finite_us(by_command.get("stop", {}).get("utc_ns"))
        if start_ns is not None and stop_ns is not None and start_ns < stop_ns:
            return start_ns / 1000.0, stop_ns / 1000.0, protocol

    events_path = formal_root / "intervention_events.jsonl"
    if events_path.is_file():
        command_times: dict[str, float] = {}
        for line in events_path.read_text(
            encoding="utf-8", errors="replace"
        ).splitlines():
            try:
                event = json.loads(line)
            except json.JSONDecodeError:
                continue
            if (
                event.get("record_type") == "profile_control_command"
                and event.get("command") in {"start", "stop"}
            ):
                utc_ns = _finite_us(event.get("utc_ns", event.get("ts_utc_ns")))
                if utc_ns is not None:
                    command_times[str(event["command"])] = utc_ns
        if (
            "start" in command_times
            and "stop" in command_times
            and command_times["start"] < command_times["stop"]
        ):
            return (
                command_times["start"] / 1000.0,
                command_times["stop"] / 1000.0,
                protocol,
            )

    raise SystemExit(
        f"absolute profiler start/stop UTC anchors unavailable for {run_id}"
    )


def _telemetry_window(telemetry_root: Path) -> tuple[float, float]:
    candidates = [
        telemetry_root / "normalized/nodes/npu.csv",
        telemetry_root / "normalized/nodes/global_task.csv",
        telemetry_root / "raw/npu.csv",
    ]
    for path in candidates:
        if not path.is_file():
            continue
        timestamps: list[float] = []
        with path.open(encoding="utf-8", newline="") as stream:
            reader = csv.DictReader(stream)
            for row in reader:
                for key in (
                    "timestamp_us",
                    "time_us",
                    "ts_bucket_start_utc_ns",
                    "ts_utc_ns",
                    "time",
                    "timestamp",
                ):
                    value = _finite_us(row.get(key))
                    if value is not None:
                        if key.endswith("_ns"):
                            value /= 1000.0
                        elif key in {"time", "timestamp"} and value < 1e12:
                            value *= 1_000_000.0
                        timestamps.append(value)
                        break
        if timestamps:
            return min(timestamps), max(timestamps)
    raise SystemExit(f"telemetry timestamps unavailable under {telemetry_root}")


def _canonical_window(extraction_root: Path, run_id: str, rank: int) -> tuple[float, float]:
    parquet = extraction_root / run_id / f"rank_{rank}" / CANONICAL_NAME
    if not parquet.is_file():
        raise SystemExit(f"missing canonical parquet: {parquet}")
    rows = read_parquet_rows(parquet)
    bins = [
        value
        for row in rows
        if (value := _finite_us(row.get("profiler_time_bin_us"))) is not None
    ]
    if not bins:
        raise SystemExit(f"canonical parquet has no profiler_time_bin_us: {parquet}")
    return min(bins), max(bins)


def _training_step_source(root: Path, run_id: str, telemetry_root: Path) -> Mapping[str, Any]:
    global_task = telemetry_root / "normalized/nodes/global_task.csv"
    if global_task.is_file():
        with global_task.open(encoding="utf-8", newline="") as stream:
            reader = csv.DictReader(stream)
            for row in reader:
                if any(key in row for key in ("Step Time(us)", "step_time_ms", "Step")):
                    return {
                        "source": "collector_global_task",
                        "path": str(global_task),
                        "present": True,
                    }
    logs = sorted((root / "runtime/logs").glob(f"*{run_id}*"))
    for path in logs:
        text = path.read_text(encoding="utf-8", errors="replace")
        if "iteration" in text and "Step Time" in text:
            return {"source": "training_log", "path": str(path), "present": True}
    return {
        "source": "missing",
        "path": "",
        "present": False,
        "reason": "no training step_time in collector or logs",
    }


def audit_run(
    *,
    root: Path,
    extraction_root: Path,
    entry: Mapping[str, Any],
) -> Mapping[str, Any]:
    run_id = str(entry["run_id"])
    formal_root = root / "runtime/outputs/formal" / run_id
    telemetry_root = Path(str(entry["telemetry_root"]))
    proto_min, proto_max, protocol = _profile_window(
        root, run_id, formal_root
    )
    tele_min, tele_max = _telemetry_window(telemetry_root)
    rank_rows: list[Mapping[str, Any]] = []
    reasons: list[str] = []
    for rank in range(16):
        rank_report = extraction_root / run_id / f"rank_{rank}" / REPORT_NAME
        if not rank_report.is_file():
            reasons.append(f"missing_extraction_report:rank_{rank}")
            continue
        try:
            can_min, can_max = _canonical_window(extraction_root, run_id, rank)
        except SystemExit as error:
            reasons.append(str(error))
            continue
        overlap_protocol = _intervals_overlap(can_min, can_max, proto_min, proto_max)
        overlap_telemetry = _intervals_overlap(can_min, can_max, tele_min, tele_max)
        if not overlap_protocol:
            reasons.append(f"rank_{rank}:profiler_protocol_no_overlap")
        if not overlap_telemetry:
            reasons.append(f"rank_{rank}:profiler_telemetry_no_overlap")
        rank_rows.append(
            {
                "rank": rank,
                "canonical_min_us": can_min,
                "canonical_max_us": can_max,
                "overlap_protocol": overlap_protocol,
                "overlap_telemetry": overlap_telemetry,
            }
        )
    training = _training_step_source(root, run_id, telemetry_root)
    if not training.get("present"):
        reasons.append(f"{run_id}:training_step_time_missing")
    verified = not reasons and len(rank_rows) == 16
    return {
        "run_id": run_id,
        "key": entry.get("key"),
        "verified": verified,
        "protocol_window_us": {"min": proto_min, "max": proto_max},
        "telemetry_window_us": {"min": tele_min, "max": tele_max},
        "protocol_condition": protocol.get("condition"),
        "training_step_time": training,
        "rank_rows": rank_rows,
        "rejection_reasons": sorted(set(reasons)),
    }


def audit_dataset(
    *,
    root: Path,
    dataset_manifest: Path,
    extraction_root: Path,
) -> Mapping[str, Any]:
    entries = load_dataset_entries(dataset_manifest)
    if {str(item["key"]) for item in entries} != set(EXPECTED_CASE_SPECS):
        raise SystemExit("dataset manifest keys mismatch")
    runs = [
        audit_run(root=root, extraction_root=extraction_root, entry=entry)
        for entry in entries
    ]
    failed = [row for row in runs if not row.get("verified")]
    return {
        "schema_version": "r27.alignment.v1",
        "status": "pass" if not failed else "fail",
        "dataset_manifest": str(dataset_manifest.resolve(strict=True)),
        "extraction_root": str(extraction_root.resolve(strict=False)),
        "run_count": len(runs),
        "verified_run_count": sum(1 for row in runs if row.get("verified")),
        "runs": runs,
    }


def main(argv: Sequence[str] | None = None) -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", type=Path, required=True)
    parser.add_argument("--dataset-manifest", type=Path, required=True)
    parser.add_argument("--extraction-root", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    report = audit_dataset(
        root=args.root.resolve(strict=True),
        dataset_manifest=args.dataset_manifest,
        extraction_root=args.extraction_root,
    )
    atomic_json(args.output, report)
    print(f"R27_ALIGNMENT_REPORT={args.output}")
    if report["status"] != "pass":
        reasons = []
        for row in report["runs"]:
            reasons.extend(row.get("rejection_reasons", []))
        raise SystemExit("alignment failed: " + "; ".join(sorted(set(reasons))[:8]))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
