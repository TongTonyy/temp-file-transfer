#!/usr/bin/env python3
"""Final 83-metric and 64-session dataset validation for r27 pipeline."""

from __future__ import annotations

import argparse
from pathlib import Path
from typing import Any, Mapping, Sequence

from audit_r25_extraction_contract import audit_group
from prepare_r23_extraction_contract import (
    EXPECTED_CASE_SPECS,
    PROFILER_TARGETS,
    load_metric_contract,
)
from torch_npu_offline_common import atomic_json, load_dataset_entries, load_json

REPORT_NAME = "r25_session_report.json"


def _load_coverage(path: Path) -> Mapping[str, Any]:
    return load_json(path)


def validate_dataset(
    *,
    dataset_manifest: Path,
    extraction_root: Path,
    metric_coverage_path: Path,
    alignment_report: Path | None = None,
) -> Mapping[str, Any]:
    manifest = load_json(dataset_manifest)
    entries = load_dataset_entries(dataset_manifest)
    coverage = _load_coverage(metric_coverage_path)
    metrics = coverage.get("metrics")
    if not isinstance(metrics, list) or len(metrics) != 83:
        raise SystemExit(
            f"metric_coverage must contain 83 metrics, observed "
            f"{len(metrics) if isinstance(metrics, list) else 'invalid'}"
        )
    metric_ids = [str(row.get("metric_id", "")) for row in metrics]
    if not all(metric_ids) or len(set(metric_ids)) != 83:
        raise SystemExit("metric_coverage must contain 83 unique non-empty metric ids")
    progress_path = extraction_root / "r25_extraction_progress.json"
    if not progress_path.is_file():
        raise SystemExit(f"missing extraction progress: {progress_path}")
    progress = load_json(progress_path)
    sessions = progress.get("sessions", {})
    complete = [
        key
        for key, row in sessions.items()
        if isinstance(row, Mapping) and row.get("status") == "complete"
    ]
    if len(complete) != 64:
        raise SystemExit(
            f"expected 64 complete extraction sessions, observed {len(complete)}"
        )
    merge_mode = str(manifest.get("merge_mode", ""))
    semantics = manifest.get("session_semantics", {})
    if merge_mode == "new48_reused16":
        if semantics.get("new_sessions") != 48 or semantics.get("reused_sessions") != 16:
            raise SystemExit("merge semantics mismatch for new48_reused16")
    elif merge_mode == "new64":
        if semantics.get("new_sessions") != 64 or semantics.get("reused_sessions") != 0:
            raise SystemExit("merge semantics mismatch for new64")
    else:
        raise SystemExit(f"unknown merge_mode: {merge_mode}")

    groups = [
        audit_group(entry, extraction_root)
        for entry in entries
        if str(entry.get("key")) in EXPECTED_CASE_SPECS
    ]
    for group in groups:
        if group.get("verified_session_count") != 16:
            raise SystemExit(
                f"{group['key']} deep verification is not 16/16: "
                f"{group.get('verified_session_count')}"
            )

    profiler_rows = [
        row for row in metrics if row.get("metric_id") in PROFILER_TARGETS
    ]
    if len(profiler_rows) != 5:
        raise SystemExit(f"expected 5 profiler contract rows, observed {len(profiler_rows)}")

    missing_profiler = [
        str(row.get("metric_id"))
        for row in profiler_rows
        if row.get("status") not in {"extracted", "training_log_packaged_for_local_extraction"}
    ]
    step_time = next(
        (row for row in metrics if row.get("metric_id") == "global_task.step_time_ms"),
        None,
    )
    step_time_ok = False
    if isinstance(step_time, Mapping):
        status = str(step_time.get("status", ""))
        if status == "training_log_packaged_for_local_extraction":
            for entry in entries:
                logs = list(
                    Path(str(entry.get("telemetry_root", ""))).glob("**/*")
                )
                if any(path.suffix in {".csv", ".log", ".json"} for path in logs):
                    step_time_ok = True
                    break
        elif status == "extracted":
            step_time_ok = True
    if not step_time_ok:
        raise SystemExit("global_task.step_time_ms source not evidenced")

    if missing_profiler:
        raise SystemExit(
            "profiler contract metrics not extracted: "
            + ", ".join(missing_profiler)
        )

    if alignment_report is None or not alignment_report.is_file():
        raise SystemExit("alignment report is required")
    alignment = load_json(alignment_report)
    if alignment.get("status") != "pass" or alignment.get("verified_run_count") != 4:
        raise SystemExit("alignment report is not a four-run pass")

    pairs = manifest.get("pairs")
    if not isinstance(pairs, Mapping):
        raise SystemExit("dataset manifest pairs missing")
    by_key = {str(entry["key"]): entry for entry in entries}
    expected_pairs = {
        "resource_conflict": {
            "control": by_key["control_resource_conflict"]["run_id"],
            "fault": by_key["fault_resource_conflict"]["run_id"],
        },
        "memory_access": {
            "control": by_key["control_memory_access"]["run_id"],
            "fault": by_key["fault_memory_access"]["run_id"],
        },
    }
    if pairs != expected_pairs:
        raise SystemExit("dataset manifest pair run ids do not match entries")

    source_evidence: dict[str, list[str]] = {
        "collector": [],
        "training": [],
        "protocol": [],
        "profiler": [],
    }
    for entry in entries:
        run_id = str(entry["run_id"])
        telemetry = Path(str(entry.get("telemetry_root", "")))
        required_telemetry = (
            telemetry / "manifest.json",
            telemetry / "normalized/nodes/npu.csv",
            telemetry / "normalized/nodes/hbm.csv",
            telemetry / "normalized/nodes/global_task.csv",
        )
        missing = [str(path) for path in required_telemetry if not path.is_file()]
        if missing:
            raise SystemExit(
                f"{run_id} collector evidence missing: {', '.join(missing)}"
            )
        source_evidence["collector"].extend(str(path) for path in required_telemetry)
        formal = (
            dataset_manifest.resolve(strict=True).parents[2]
            / "outputs/formal"
            / run_id
        )
        protocol = formal / "protocol_report.json"
        events = formal / "intervention_events.jsonl"
        if not protocol.is_file() or not events.is_file():
            raise SystemExit(f"{run_id} protocol/event evidence missing")
        source_evidence["protocol"].extend((str(protocol), str(events)))
        training_row = next(
            row
            for row in alignment["runs"]
            if str(row.get("run_id")) == run_id
        )
        training_path = Path(
            str(training_row.get("training_step_time", {}).get("path", ""))
        )
        if not training_path.is_file():
            raise SystemExit(f"{run_id} training step-time evidence missing")
        source_evidence["training"].append(str(training_path))
        source_evidence["profiler"].append(
            str(extraction_root / run_id)
        )

    return {
        "schema_version": "r27.dataset_validation.v1",
        "status": "complete_with_declared_proxies",
        "metric_count": 83,
        "profiler_target_count": 5,
        "complete_session_count": len(complete),
        "merge_mode": merge_mode,
        "pairs": pairs,
        "source_evidence": {
            key: sorted(set(paths)) for key, paths in source_evidence.items()
        },
        "groups_verified_16_of_16": [group["key"] for group in groups],
        "missing_profiler_statuses": missing_profiler,
        "metric_coverage_path": str(metric_coverage_path.resolve(strict=True)),
        "dataset_manifest": str(dataset_manifest.resolve(strict=True)),
    }


def main(argv: Sequence[str] | None = None) -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--dataset-manifest", type=Path, required=True)
    parser.add_argument("--extraction-root", type=Path, required=True)
    parser.add_argument("--metric-coverage", type=Path, required=True)
    parser.add_argument("--alignment-report", type=Path, default=None)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    report = validate_dataset(
        dataset_manifest=args.dataset_manifest,
        extraction_root=args.extraction_root,
        metric_coverage_path=args.metric_coverage,
        alignment_report=args.alignment_report,
    )
    atomic_json(args.output, report)
    print(f"R27_DATASET_VALIDATION={args.output}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
