#!/usr/bin/env python3
"""Copy trusted r25 rank outputs for reused runs into a new extraction root."""

from __future__ import annotations

import argparse
import shutil
from pathlib import Path
from typing import Sequence

from audit_r25_extraction_contract import REUSABLE_IF_ALL_VERIFIED_KEY
from torch_npu_offline_common import load_dataset_entries, load_json


def copy_reused_run(
    *,
    source_root: Path,
    target_root: Path,
    run_id: str,
) -> int:
    copied = 0
    for rank in range(16):
        src = source_root / run_id / f"rank_{rank}"
        dst = target_root / run_id / f"rank_{rank}"
        if not src.is_dir():
            raise SystemExit(f"missing reusable source rank: {src}")
        shutil.copytree(src, dst, dirs_exist_ok=True)
        for required in (
            "r25_session_report.json",
            "canonical_profiler_metrics.parquet",
        ):
            if not (dst / required).is_file():
                raise SystemExit(
                    f"reused rank copy is incomplete: {dst / required}"
                )
        copied += 1
    return copied


def main(argv: Sequence[str] | None = None) -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--dataset-manifest", type=Path, required=True)
    parser.add_argument("--source-r25-root", type=Path, required=True)
    parser.add_argument("--target-r25-root", type=Path, required=True)
    args = parser.parse_args(argv)
    manifest = load_json(args.dataset_manifest)
    entries = {str(item["key"]): item for item in load_dataset_entries(args.dataset_manifest)}
    if not manifest.get("reuse_control_memory", False):
        if entries.get(REUSABLE_IF_ALL_VERIFIED_KEY, {}).get("source") == "reused":
            pass
    entry = entries.get(REUSABLE_IF_ALL_VERIFIED_KEY)
    if entry is None or entry.get("source") != "reused":
        print("R27_REUSE_R25=skipped")
        return 0
    run_id = str(entry["run_id"])
    copied = copy_reused_run(
        source_root=args.source_r25_root.resolve(strict=True),
        target_root=args.target_r25_root.resolve(strict=False),
        run_id=run_id,
    )
    print(f"R27_REUSE_R25=complete run_id={run_id} copied_ranks={copied}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
