#!/usr/bin/env bash
set -Eeuo pipefail
umask 077
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
OUTPUT_ROOT="${HGNN_OUTPUT_ROOT:-$(cd "$ROOT/.." && pwd)/910c_f01_f09_outputs}"
DATA_ROOT="${HGNN_DATA_ROOT:-$OUTPUT_ROOT/hgnn_data}"
mkdir -p "$OUTPUT_ROOT" "$DATA_ROOT"
export PYTHONPATH="$ROOT/src${PYTHONPATH:+:$PYTHONPATH}"

python3 - <<'PY'
import importlib.util, json, os, shutil, sys
mods = {name: importlib.util.find_spec(name) is not None
        for name in ("yaml", "pydantic", "numpy", "pyarrow", "torch", "torch_npu")}
commands = {name: shutil.which(name) is not None
            for name in ("npu-smi", "ip", "tc", "ping", "rdma", "ethtool",
                         "ipmitool", "curl", "chronyc", "timedatectl", "perf")}
paths = {
    "cgroup_v2": os.path.isfile("/sys/fs/cgroup/cgroup.controllers"),
    "cgroup_v2_writable": os.access("/sys/fs/cgroup", os.W_OK),
    "apei_einj": os.path.isfile("/sys/kernel/debug/apei/einj/available_error_type"),
    "edac": os.path.isdir("/sys/devices/system/edac/mc"),
}
print(json.dumps({"python": sys.version, "modules": mods,
                  "commands": commands, "paths": paths}, indent=2))
PY

python3 "$ROOT/bin/collect_f01_f09.py" preflight \
  --config "$ROOT/config/campaign.yaml" \
  --safety-limits "$ROOT/config/safety_limits.yaml" \
  --faults all --output-root "$OUTPUT_ROOT" --data-root "$DATA_ROOT" \
  --continue-on-blocked
