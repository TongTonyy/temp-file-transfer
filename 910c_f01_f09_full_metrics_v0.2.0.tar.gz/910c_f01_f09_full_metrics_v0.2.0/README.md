# Ascend 910C F01-F09 全指标采集运行包 v0.2.0

本包遵循 fail-closed：proof、权限、隔离、厂商阈值或后端缺失时，故障保持
`blocked`，只输出能力证据；绝不把未采指标写成 0，也不把 synthetic 当硬件证据。

## 复制后

```bash
cd 910c_f01_f09_full_metrics_v0.2.0
sha256sum -c SHA256SUMS
cp env.template env.local
chmod 600 env.local
# 编辑 env.local 后
set -a; . ./env.local; set +a
./00_preflight.sh
./10_collect_baseline.sh             # 默认 10 个 300 秒 no-op 对照
./20_run_f03_f04.sh
./30_run_f07_f08.sh
./40_run_f02_f05.sh
./50_run_f01_f06_f09.sh
./90_package_results.sh
```

## 单类、单强度、重复

```bash
FAULTS=F03 INTENSITIES=10 REPEATS=10 ./20_run_f03_f04.sh
FAULTS=F08 INTENSITIES=20 REPEATS=3 ./30_run_f07_f08.sh
```

每个有效 run 的目标时间轴为 300 秒：T0=[0,60)，T1=[60,240)，
T2=[240,300)。三强度时每档 60 秒；单强度时该强度保持 180 秒。
只有 required 指标覆盖率达到 95% 且时间轴完整时，run 才标记 `passed`；
否则标记 `incomplete_metrics`，注入证据仍保留但不得进入完整训练集。

F01/F02/F05/F06/F09 在当前交付中仍可能因未审计硬件/运行时后端保持 blocked，
这是安全设计，不是脚本失败。先保存 preflight、baseline 和 blocked 报告，
待现场 proof/后端齐全后重跑对应批次。
