#!/usr/bin/env bash
set -Eeuo pipefail
umask 077
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
FAULTS="${1:?fault list required}"
DEFAULT_INTENSITIES="${2:-10,20,40}"
DEFAULT_REPEATS="${3:-1}"
OUTPUT_ROOT="${HGNN_OUTPUT_ROOT:-$(cd "$ROOT/.." && pwd)/910c_f01_f09_outputs}"
DATA_ROOT="${HGNN_DATA_ROOT:-$OUTPUT_ROOT/hgnn_data}"
INTENSITIES="${INTENSITIES:-$DEFAULT_INTENSITIES}"
REPEATS="${REPEATS:-$DEFAULT_REPEATS}"
mkdir -p "$OUTPUT_ROOT" "$DATA_ROOT"
export PYTHONPATH="$ROOT/src${PYTHONPATH:+:$PYTHONPATH}"

if [[ "$(id -u)" -eq 0 && "${HGNN_CAMPAIGN_ROOT_APPROVAL:-}" != \
  "I_ACKNOWLEDGE_HARDENED_ROOT_EXECUTION" ]]; then
  echo "root 执行必须显式设置 HGNN_CAMPAIGN_ROOT_APPROVAL" >&2
  exit 2
fi

for ((repeat=1; repeat<=REPEATS; repeat++)); do
  echo "batch faults=$FAULTS intensities=$INTENSITIES repeat=$repeat/$REPEATS"
  python3 "$ROOT/bin/collect_f01_f09.py" run \
    --config "$ROOT/config/campaign.yaml" \
    --safety-limits "$ROOT/config/safety_limits.yaml" \
    --faults "$FAULTS" \
    --intensities "$INTENSITIES" \
    --output-root "$OUTPUT_ROOT" \
    --data-root "$DATA_ROOT" \
    --continue-on-blocked
done
