from __future__ import annotations

import asyncio
import hashlib
import json
import os
import signal
import shutil
import socket
import subprocess
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Iterable

from hgnn_collect.models import ClockQuality


@dataclass
class CommandResult:
    argv: list[str]
    returncode: int
    stdout: str
    stderr: str
    duration_us: int
    timed_out: bool = False


async def run_command(
    argv: Iterable[str],
    *,
    timeout_s: float,
    env: dict[str, str] | None = None,
    cwd: Path | None = None,
    start_new_session: bool = False,
) -> CommandResult:
    command = [str(item) for item in argv]
    started = time.monotonic_ns()
    try:
        process = await asyncio.create_subprocess_exec(
            *command,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
            env=env,
            cwd=str(cwd) if cwd else None,
            start_new_session=start_new_session,
        )
        stdout_bytes, stderr_bytes = await asyncio.wait_for(
            process.communicate(), timeout=timeout_s
        )
        return CommandResult(
            argv=command,
            returncode=process.returncode,
            stdout=stdout_bytes.decode("utf-8", errors="replace"),
            stderr=stderr_bytes.decode("utf-8", errors="replace"),
            duration_us=max(0, (time.monotonic_ns() - started) // 1_000),
        )
    except TimeoutError:
        if "process" in locals():
            try:
                if start_new_session:
                    os.killpg(process.pid, signal.SIGTERM)
                else:
                    process.terminate()
            except ProcessLookupError:
                pass
            try:
                await asyncio.wait_for(process.wait(), timeout=2)
            except TimeoutError:
                try:
                    if start_new_session:
                        os.killpg(process.pid, signal.SIGKILL)
                    else:
                        process.kill()
                except ProcessLookupError:
                    pass
                await process.wait()
        return CommandResult(
            argv=command,
            returncode=124,
            stdout="",
            stderr=f"command timed out after {timeout_s}s",
            duration_us=max(0, (time.monotonic_ns() - started) // 1_000),
            timed_out=True,
        )
    except FileNotFoundError as error:
        return CommandResult(
            argv=command,
            returncode=127,
            stdout="",
            stderr=str(error),
            duration_us=max(0, (time.monotonic_ns() - started) // 1_000),
        )


def run_command_sync(argv: Iterable[str], timeout_s: float = 5.0) -> CommandResult:
    command = [str(item) for item in argv]
    started = time.monotonic_ns()
    try:
        completed = subprocess.run(
            command,
            capture_output=True,
            text=True,
            timeout=timeout_s,
            check=False,
        )
        return CommandResult(
            argv=command,
            returncode=completed.returncode,
            stdout=completed.stdout,
            stderr=completed.stderr,
            duration_us=max(0, (time.monotonic_ns() - started) // 1_000),
        )
    except subprocess.TimeoutExpired as error:
        return CommandResult(
            argv=command,
            returncode=124,
            stdout=error.stdout or "",
            stderr=error.stderr or f"command timed out after {timeout_s}s",
            duration_us=max(0, (time.monotonic_ns() - started) // 1_000),
            timed_out=True,
        )
    except FileNotFoundError as error:
        return CommandResult(
            argv=command,
            returncode=127,
            stdout="",
            stderr=str(error),
            duration_us=max(0, (time.monotonic_ns() - started) // 1_000),
        )


def atomic_write_json(path: Path, payload: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    with temporary.open("w", encoding="utf-8") as handle:
        json.dump(payload, handle, ensure_ascii=False, indent=2, sort_keys=True)
        handle.flush()
        os.fsync(handle.fileno())
    temporary.replace(path)


def sha256_file(path: Path, chunk_size: int = 1024 * 1024) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        while chunk := handle.read(chunk_size):
            digest.update(chunk)
    return digest.hexdigest()


def sha256_text(value: str) -> str:
    return hashlib.sha256(value.encode("utf-8")).hexdigest()


def parse_cpu_list(value: str) -> set[int]:
    cpus: set[int] = set()
    for part in value.strip().split(","):
        if not part:
            continue
        if "-" in part:
            start, end = part.split("-", 1)
            cpus.update(range(int(start), int(end) + 1))
        else:
            cpus.add(int(part))
    return cpus


def read_text(path: Path, default: str = "") -> str:
    try:
        return path.read_text(encoding="utf-8", errors="replace").strip()
    except OSError:
        return default


def read_int(path: Path) -> int | None:
    value = read_text(path)
    try:
        return int(value)
    except (TypeError, ValueError):
        return None


def detect_clock_quality() -> ClockQuality:
    result = run_command_sync(["timedatectl", "show", "--property=NTPSynchronized", "--value"])
    if result.returncode == 0 and result.stdout.strip().lower() == "yes":
        return ClockQuality.NTP_SYNCED
    return ClockQuality.UNKNOWN


def qdisc_snapshot() -> dict[str, Any]:
    result = run_command_sync(["tc", "-s", "-j", "qdisc", "show"], timeout_s=5)
    if result.returncode == 0:
        try:
            return {"format": "json", "value": json.loads(result.stdout)}
        except json.JSONDecodeError:
            pass
    fallback = run_command_sync(["tc", "-s", "qdisc", "show"], timeout_s=5)
    return {
        "format": "text",
        "value": fallback.stdout.strip(),
        "returncode": fallback.returncode,
        "stderr": fallback.stderr.strip(),
    }


def canonical_hash(payload: Any) -> str:
    encoded = json.dumps(
        payload, ensure_ascii=False, sort_keys=True, separators=(",", ":")
    ).encode("utf-8")
    return hashlib.sha256(encoded).hexdigest()


def host_id() -> str:
    return socket.gethostname().split(".")[0]


def command_exists(name: str) -> bool:
    return shutil.which(name) is not None


@dataclass
class RateTracker:
    previous: dict[str, tuple[int, int]] = field(default_factory=dict)

    def rate(self, key: str, value: int, ts_mono_ns: int) -> tuple[float | None, str | None]:
        old = self.previous.get(key)
        self.previous[key] = (value, ts_mono_ns)
        if old is None:
            return None, "WARMUP_COUNTER"
        previous_value, previous_ts = old
        elapsed = (ts_mono_ns - previous_ts) / 1_000_000_000
        if elapsed <= 0:
            return None, "NON_POSITIVE_INTERVAL"
        if value < previous_value:
            return None, "COUNTER_RESET"
        return (value - previous_value) / elapsed, None

