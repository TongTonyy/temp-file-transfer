from __future__ import annotations

from pathlib import Path
from typing import Any, Mapping

import yaml


def load_metric_support_policy(path: Path) -> dict[str, Any]:
    payload = yaml.safe_load(path.read_text(encoding="utf-8"))
    if not isinstance(payload, dict) or "metrics" not in payload:
        raise ValueError(f"invalid metric support policy: {path}")
    return payload


def resolve_metric_policy(
    policy: Mapping[str, Any], metric_id: str, platform_name: str
) -> dict[str, str]:
    override = policy["metrics"].get(metric_id, {})
    resolved = override.get(
        platform_name,
        policy.get("defaults", {}).get(
            platform_name, {"status": "unknown", "action": "probe"}
        ),
    )
    return {"status": str(resolved["status"]), "action": str(resolved["action"])}
