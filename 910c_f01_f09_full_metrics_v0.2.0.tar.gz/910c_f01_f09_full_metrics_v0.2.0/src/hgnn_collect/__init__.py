"""Passive Ascend telemetry collection and HGNN dataset preparation."""

__version__ = "0.1.0"

