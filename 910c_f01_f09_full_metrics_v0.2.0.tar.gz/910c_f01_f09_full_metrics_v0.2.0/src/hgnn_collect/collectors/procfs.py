from __future__ import annotations

import time
from pathlib import Path

from hgnn_collect.collectors.base import BaseCollector, CollectorContext
from hgnn_collect.models import MetricKind, Observation
from hgnn_collect.utils import RateTracker, parse_cpu_list, read_text


def _parse_key_values(path: Path) -> dict[str, int]:
    values: dict[str, int] = {}
    for line in read_text(path).splitlines():
        parts = line.replace(":", " ").split()
        if len(parts) >= 2:
            try:
                values[parts[0]] = int(parts[1])
            except ValueError:
                continue
    return values


class ProcfsCollector(BaseCollector):
    def __init__(self, interval_s: float, critical: bool = True):
        super().__init__("procfs", interval_s, critical)
        self._numa_cpus = self._discover_numa_cpus()
        self._cpu_previous: dict[str, tuple[list[int], int]] = {}
        self._rates = RateTracker()
        self._disk_previous: dict[str, tuple[list[int], int]] = {}

    @staticmethod
    def _discover_numa_cpus() -> dict[str, set[int]]:
        mapping: dict[str, set[int]] = {}
        for node in sorted(Path("/sys/devices/system/node").glob("node[0-9]*")):
            cpulist = read_text(node / "cpulist")
            if cpulist:
                mapping[node.name.removeprefix("node")] = parse_cpu_list(cpulist)
        if not mapping:
            mapping["0"] = set()
        return mapping

    @staticmethod
    def _cpu_lines() -> dict[int, list[int]]:
        rows: dict[int, list[int]] = {}
        for line in read_text(Path("/proc/stat")).splitlines():
            parts = line.split()
            if not parts or not parts[0].startswith("cpu") or parts[0] == "cpu":
                continue
            try:
                cpu_id = int(parts[0][3:])
                rows[cpu_id] = [int(value) for value in parts[1:]]
            except ValueError:
                continue
        return rows

    def _collect_cpu(
        self, context: CollectorContext, now_utc_ns: int, now_mono_ns: int
    ) -> list[Observation]:
        observations: list[Observation] = []
        rows = self._cpu_lines()
        for numa_id, cpus in self._numa_cpus.items():
            selected = [rows[cpu] for cpu in cpus if cpu in rows] if cpus else list(rows.values())
            if not selected:
                continue
            width = max(len(row) for row in selected)
            aggregate = [
                sum(row[index] if index < len(row) else 0 for row in selected)
                for index in range(width)
            ]
            node_id = f"{context.host_id}/cpu_numa/{numa_id}"
            previous = self._cpu_previous.get(numa_id)
            self._cpu_previous[numa_id] = (aggregate, now_mono_ns)
            if previous:
                old, old_ts = previous
                delta = [
                    max(0, value - (old[index] if index < len(old) else 0))
                    for index, value in enumerate(aggregate)
                ]
                total = sum(delta)
                elapsed = max((now_mono_ns - old_ts) / 1_000_000_000, 1e-9)
                if total > 0:
                    metrics = {
                        "cpu_numa.user_pct": 100 * sum(delta[0:2]) / total,
                        "cpu_numa.system_pct": 100
                        * sum(delta[index] for index in (2, 5, 6) if index < len(delta))
                        / total,
                        "cpu_numa.iowait_pct": 100 * (delta[4] if len(delta) > 4 else 0) / total,
                    }
                    for metric_id, value in metrics.items():
                        observations.append(
                            self.observation(
                                context,
                                node_type="cpu_numa",
                                node_id=node_id,
                                metric_id=metric_id,
                                metric_kind=MetricKind.GAUGE,
                                value=float(value),
                                unit="percent",
                                ts_utc_ns=now_utc_ns,
                                ts_mono_ns=now_mono_ns,
                                attributes={"elapsed_s": elapsed},
                            )
                        )
            for index, name in enumerate(
                ("user", "nice", "system", "idle", "iowait", "irq", "softirq", "steal")
            ):
                if index < len(aggregate):
                    observations.append(
                        self.observation(
                            context,
                            node_type="cpu_numa",
                            node_id=node_id,
                            metric_id=f"cpu_numa.{name}_jiffies_total",
                            metric_kind=MetricKind.COUNTER,
                            value=aggregate[index],
                            unit="jiffies",
                            ts_utc_ns=now_utc_ns,
                            ts_mono_ns=now_mono_ns,
                            attributes={"raw_counter": True},
                        )
                    )
        loadavg = read_text(Path("/proc/loadavg")).split()
        if len(loadavg) >= 4 and "/" in loadavg[3]:
            try:
                runnable = int(loadavg[3].split("/", 1)[0])
                observations.append(
                    self.observation(
                        context,
                        node_type="cpu_numa",
                        node_id=f"{context.host_id}/cpu_numa/host_aggregate",
                        metric_id="cpu_numa.run_queue",
                        metric_kind=MetricKind.GAUGE,
                        value=runnable,
                        unit="count",
                        ts_utc_ns=now_utc_ns,
                        ts_mono_ns=now_mono_ns,
                        attributes={"granularity": "host_aggregate"},
                    )
                )
            except ValueError:
                pass
        return observations

    def _collect_softirq(
        self, context: CollectorContext, now_utc_ns: int, now_mono_ns: int
    ) -> list[Observation]:
        total = 0
        for line in read_text(Path("/proc/softirqs")).splitlines()[1:]:
            parts = line.replace(":", " ").split()
            for value in parts[1:]:
                try:
                    total += int(value)
                except ValueError:
                    continue
        rate, flag = self._rates.rate("softirq", total, now_mono_ns)
        observations = [
            self.observation(
                context,
                node_type="cpu_numa",
                node_id=f"{context.host_id}/cpu_numa/host_aggregate",
                metric_id="cpu_numa.softirq_total",
                metric_kind=MetricKind.COUNTER,
                value=total,
                unit="count",
                ts_utc_ns=now_utc_ns,
                ts_mono_ns=now_mono_ns,
                attributes={"raw_counter": True},
            )
        ]
        if rate is not None:
            observations.append(
                self.observation(
                    context,
                    node_type="cpu_numa",
                    node_id=f"{context.host_id}/cpu_numa/host_aggregate",
                    metric_id="cpu_numa.softirq_rate_s",
                    metric_kind=MetricKind.GAUGE,
                    value=float(rate),
                    unit="1/s",
                    ts_utc_ns=now_utc_ns,
                    ts_mono_ns=now_mono_ns,
                )
            )
        elif flag:
            observations[0].quality_flags.append(flag)
        return observations

    def _collect_memory(
        self, context: CollectorContext, now_utc_ns: int, now_mono_ns: int
    ) -> list[Observation]:
        observations: list[Observation] = []
        meminfo = _parse_key_values(Path("/proc/meminfo"))
        total_bytes = meminfo.get("MemTotal", 0) * 1024
        available_bytes = meminfo.get("MemAvailable", 0) * 1024
        node_id = f"{context.host_id}/sys_mem_numa/host_aggregate"
        for metric_id, value, unit in (
            ("sys_mem_numa.available_bytes", available_bytes, "byte"),
            (
                "sys_mem_numa.used_pct",
                100 * (1 - available_bytes / total_bytes) if total_bytes else 0.0,
                "percent",
            ),
        ):
            observations.append(
                self.observation(
                    context,
                    node_type="sys_mem_numa",
                    node_id=node_id,
                    metric_id=metric_id,
                    metric_kind=MetricKind.GAUGE,
                    value=value,
                    unit=unit,
                    ts_utc_ns=now_utc_ns,
                    ts_mono_ns=now_mono_ns,
                    attributes={"granularity": "host_aggregate"},
                )
            )

        for numa_path in sorted(Path("/sys/devices/system/node").glob("node[0-9]*")):
            values: dict[str, int] = {}
            for line in read_text(numa_path / "meminfo").splitlines():
                parts = line.replace(":", " ").split()
                if len(parts) >= 4:
                    try:
                        values[parts[2]] = int(parts[3]) * 1024
                    except ValueError:
                        continue
            if values:
                numa_id = numa_path.name.removeprefix("node")
                available = values.get("MemFree", 0)
                observations.append(
                    self.observation(
                        context,
                        node_type="sys_mem_numa",
                        node_id=f"{context.host_id}/sys_mem_numa/{numa_id}",
                        metric_id="sys_mem_numa.available_bytes",
                        metric_kind=MetricKind.GAUGE,
                        value=available,
                        unit="byte",
                        ts_utc_ns=now_utc_ns,
                        ts_mono_ns=now_mono_ns,
                        attributes={"granularity": "numa_node"},
                    )
                )

        vmstat = _parse_key_values(Path("/proc/vmstat"))
        for raw_name, metric_id in (
            ("pgmajfault", "sys_mem_numa.major_fault_rate_s"),
            ("pgfault", "sys_mem_numa.minor_fault_rate_s"),
            ("numa_miss", "sys_mem_numa.numa_miss_rate_s"),
        ):
            if raw_name not in vmstat:
                continue
            rate, flag = self._rates.rate(raw_name, vmstat[raw_name], now_mono_ns)
            observations.append(
                self.observation(
                    context,
                    node_type="sys_mem_numa",
                    node_id=node_id,
                    metric_id=f"sys_mem_numa.{raw_name}_total",
                    metric_kind=MetricKind.COUNTER,
                    value=vmstat[raw_name],
                    unit="count",
                    quality_flags=[flag] if flag else [],
                    ts_utc_ns=now_utc_ns,
                    ts_mono_ns=now_mono_ns,
                    attributes={"raw_counter": True, "granularity": "host_aggregate"},
                )
            )
            if rate is not None:
                observations.append(
                    self.observation(
                        context,
                        node_type="sys_mem_numa",
                        node_id=node_id,
                        metric_id=metric_id,
                        metric_kind=MetricKind.GAUGE,
                        value=float(rate),
                        unit="1/s",
                        ts_utc_ns=now_utc_ns,
                        ts_mono_ns=now_mono_ns,
                    )
                )

        swap_total = meminfo.get("SwapTotal", 0)
        swap_free = meminfo.get("SwapFree", 0)
        swap_pct = 100 * (swap_total - swap_free) / swap_total if swap_total else 0.0
        storage_id = f"{context.host_id}/storage_swap/host_swap"
        observations.append(
            self.observation(
                context,
                node_type="storage_swap",
                node_id=storage_id,
                metric_id="storage_swap.swap_used_pct",
                metric_kind=MetricKind.GAUGE,
                value=float(swap_pct),
                unit="percent",
                ts_utc_ns=now_utc_ns,
                ts_mono_ns=now_mono_ns,
            )
        )
        for raw_name, metric_id in (
            ("pswpin", "storage_swap.pswpin_rate_s"),
            ("pswpout", "storage_swap.pswpout_rate_s"),
        ):
            if raw_name in vmstat:
                rate, _ = self._rates.rate(raw_name, vmstat[raw_name], now_mono_ns)
                if rate is not None:
                    observations.append(
                        self.observation(
                            context,
                            node_type="storage_swap",
                            node_id=storage_id,
                            metric_id=metric_id,
                            metric_kind=MetricKind.GAUGE,
                            value=float(rate),
                            unit="page/s",
                            ts_utc_ns=now_utc_ns,
                            ts_mono_ns=now_mono_ns,
                        )
                    )
        return observations

    def _collect_psi(
        self, context: CollectorContext, now_utc_ns: int, now_mono_ns: int
    ) -> list[Observation]:
        observations: list[Observation] = []
        mappings = {
            "memory": (
                "sys_mem_numa",
                f"{context.host_id}/sys_mem_numa/host_aggregate",
                "sys_mem_numa.psi_some_pct",
            ),
            "io": (
                "storage_swap",
                f"{context.host_id}/storage_swap/host_swap",
                "storage_swap.io_psi_some_pct",
            ),
        }
        for resource, (node_type, node_id, metric_id) in mappings.items():
            path = Path("/proc/pressure") / resource
            first_line = read_text(path).splitlines()
            if not first_line:
                continue
            fields = dict(
                token.split("=", 1)
                for token in first_line[0].split()[1:]
                if "=" in token
            )
            try:
                value = float(fields["avg10"])
            except (KeyError, ValueError):
                continue
            observations.append(
                self.observation(
                    context,
                    node_type=node_type,
                    node_id=node_id,
                    metric_id=metric_id,
                    metric_kind=MetricKind.GAUGE,
                    value=value,
                    unit="percent",
                    ts_utc_ns=now_utc_ns,
                    ts_mono_ns=now_mono_ns,
                )
            )
        return observations

    def _collect_disks(
        self, context: CollectorContext, now_utc_ns: int, now_mono_ns: int
    ) -> list[Observation]:
        observations: list[Observation] = []
        for line in read_text(Path("/proc/diskstats")).splitlines():
            parts = line.split()
            if len(parts) < 14:
                continue
            name = parts[2]
            if name.startswith(("loop", "ram", "fd")):
                continue
            try:
                values = [int(value) for value in parts[3:]]
            except ValueError:
                continue
            node_id = f"{context.host_id}/storage_swap/{name}"
            previous = self._disk_previous.get(name)
            self._disk_previous[name] = (values, now_mono_ns)
            for index, raw_name in (
                (0, "reads_completed_total"),
                (4, "writes_completed_total"),
                (8, "ios_in_progress"),
                (10, "weighted_io_ms_total"),
            ):
                if index < len(values):
                    observations.append(
                        self.observation(
                            context,
                            node_type="storage_swap",
                            node_id=node_id,
                            metric_id=f"storage_swap.{raw_name}",
                            metric_kind=MetricKind.COUNTER
                            if raw_name.endswith("_total")
                            else MetricKind.GAUGE,
                            value=values[index],
                            unit="count" if "ms" not in raw_name else "ms",
                            ts_utc_ns=now_utc_ns,
                            ts_mono_ns=now_mono_ns,
                            attributes={"raw_counter": raw_name.endswith("_total")},
                        )
                    )
            if previous:
                old, old_ts = previous
                elapsed = (now_mono_ns - old_ts) / 1_000_000_000
                if elapsed > 0:
                    reads = max(0, values[0] - old[0])
                    writes = max(0, values[4] - old[4]) if len(values) > 4 else 0
                    io_ms = max(0, values[3] - old[3]) + max(
                        0, values[7] - old[7]
                    )
                    weighted_ms = max(0, values[10] - old[10]) if len(values) > 10 else 0
                    derived = {
                        "storage_swap.read_iops": (reads / elapsed, "1/s"),
                        "storage_swap.write_iops": (writes / elapsed, "1/s"),
                        "storage_swap.await_ms": (
                            io_ms / max(reads + writes, 1),
                            "ms",
                        ),
                        "storage_swap.queue_depth": (
                            weighted_ms / max(elapsed * 1000, 1e-9),
                            "count",
                        ),
                    }
                    for metric_id, (value, unit) in derived.items():
                        observations.append(
                            self.observation(
                                context,
                                node_type="storage_swap",
                                node_id=node_id,
                                metric_id=metric_id,
                                metric_kind=MetricKind.GAUGE,
                                value=float(value),
                                unit=unit,
                                ts_utc_ns=now_utc_ns,
                                ts_mono_ns=now_mono_ns,
                            )
                        )
        return observations

    async def collect(self, context: CollectorContext) -> list[Observation]:
        now_utc_ns = time.time_ns()
        now_mono_ns = time.monotonic_ns()
        observations: list[Observation] = []
        observations.extend(self._collect_cpu(context, now_utc_ns, now_mono_ns))
        observations.extend(self._collect_softirq(context, now_utc_ns, now_mono_ns))
        observations.extend(self._collect_memory(context, now_utc_ns, now_mono_ns))
        observations.extend(self._collect_psi(context, now_utc_ns, now_mono_ns))
        observations.extend(self._collect_disks(context, now_utc_ns, now_mono_ns))
        return observations

