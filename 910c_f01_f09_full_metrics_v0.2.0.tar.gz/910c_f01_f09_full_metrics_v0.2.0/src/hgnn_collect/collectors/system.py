from __future__ import annotations

import time
from pathlib import Path

from hgnn_collect.collectors.base import BaseCollector, CollectorContext
from hgnn_collect.models import MetricKind, Observation
from hgnn_collect.utils import RateTracker, parse_cpu_list, read_int, read_text


def _sum_aer_file(path: Path) -> int | None:
    if not path.is_file():
        return None
    total = 0
    found = False
    for line in read_text(path).splitlines():
        parts = line.replace(":", " ").split()
        for token in reversed(parts):
            try:
                total += int(token, 0)
                found = True
                break
            except ValueError:
                continue
    return total if found else None


class SystemCollector(BaseCollector):
    def __init__(self, interval_s: float, critical: bool = False):
        super().__init__("system", interval_s, critical)
        self._rates = RateTracker()
        self._numa_cpus = self._discover_numa_cpus()
        self._bridges = self._discover_pci_bridges()

    @staticmethod
    def _discover_numa_cpus() -> dict[str, set[int]]:
        result: dict[str, set[int]] = {}
        for node in Path("/sys/devices/system/node").glob("node[0-9]*"):
            cpus = read_text(node / "cpulist")
            if cpus:
                result[node.name.removeprefix("node")] = parse_cpu_list(cpus)
        return result

    @staticmethod
    def _discover_pci_bridges() -> list[Path]:
        bridges: list[Path] = []
        for device in Path("/sys/bus/pci/devices").glob("*"):
            class_code = read_text(device / "class")
            if class_code.lower().startswith("0x0604"):
                bridges.append(device)
        return sorted(bridges)

    def _cpu_frequency(
        self, context: CollectorContext, now_utc_ns: int, now_mono_ns: int
    ) -> list[Observation]:
        observations: list[Observation] = []
        for numa_id, cpus in self._numa_cpus.items():
            frequencies: list[int] = []
            for cpu in cpus:
                value = read_int(
                    Path(f"/sys/devices/system/cpu/cpu{cpu}/cpufreq/scaling_cur_freq")
                )
                if value is not None:
                    frequencies.append(value)
            if not frequencies:
                continue
            observations.append(
                self.observation(
                    context,
                    node_type="cpu_numa",
                    node_id=f"{context.host_id}/cpu_numa/{numa_id}",
                    metric_id="cpu_numa.freq_mhz",
                    metric_kind=MetricKind.GAUGE,
                    value=sum(frequencies) / len(frequencies) / 1000,
                    unit="MHz",
                    ts_utc_ns=now_utc_ns,
                    ts_mono_ns=now_mono_ns,
                )
            )
        return observations

    def _pcie(
        self, context: CollectorContext, now_utc_ns: int, now_mono_ns: int
    ) -> list[Observation]:
        observations: list[Observation] = []
        files = {
            "aer_dev_correctable": "pcie_switch.aer_correctable_rate_s",
            "aer_dev_nonfatal": "pcie_switch.aer_nonfatal_rate_s",
            "aer_dev_fatal": "pcie_switch.aer_fatal_rate_s",
        }
        for bridge in self._bridges:
            bdf = bridge.name
            node_id = f"{context.host_id}/pcie_switch/{bdf}"
            for filename, metric_id in files.items():
                total = _sum_aer_file(bridge / filename)
                if total is None:
                    continue
                observations.append(
                    self.observation(
                        context,
                        node_type="pcie_switch",
                        node_id=node_id,
                        metric_id=f"pcie_switch.{filename}_total",
                        metric_kind=MetricKind.COUNTER,
                        value=total,
                        unit="count",
                        ts_utc_ns=now_utc_ns,
                        ts_mono_ns=now_mono_ns,
                        attributes={"bdf": bdf, "raw_counter": True},
                    )
                )
                rate, flag = self._rates.rate(
                    f"pcie:{bdf}:{filename}", total, now_mono_ns
                )
                if rate is not None:
                    observations.append(
                        self.observation(
                            context,
                            node_type="pcie_switch",
                            node_id=node_id,
                            metric_id=metric_id,
                            metric_kind=MetricKind.GAUGE,
                            value=float(rate),
                            unit="1/s",
                            ts_utc_ns=now_utc_ns,
                            ts_mono_ns=now_mono_ns,
                        )
                    )
                elif flag:
                    observations[-1].quality_flags.append(flag)
            current_speed = read_text(bridge / "current_link_speed")
            current_width = read_text(bridge / "current_link_width")
            max_speed = read_text(bridge / "max_link_speed")
            max_width = read_text(bridge / "max_link_width")
            if current_speed or current_width:
                degraded = int(
                    bool(max_speed and current_speed and current_speed != max_speed)
                    or bool(max_width and current_width and current_width != max_width)
                )
                observations.append(
                    self.observation(
                        context,
                        node_type="pcie_switch",
                        node_id=node_id,
                        metric_id="pcie_switch.link_degraded_bits",
                        metric_kind=MetricKind.BITSET,
                        value=degraded,
                        unit="bitset",
                        ts_utc_ns=now_utc_ns,
                        ts_mono_ns=now_mono_ns,
                        attributes={
                            "current_speed": current_speed,
                            "current_width": current_width,
                            "max_speed": max_speed,
                            "max_width": max_width,
                        },
                    )
                )
        return observations

    async def collect(self, context: CollectorContext) -> list[Observation]:
        now_utc_ns = time.time_ns()
        now_mono_ns = time.monotonic_ns()
        return self._cpu_frequency(
            context, now_utc_ns, now_mono_ns
        ) + self._pcie(context, now_utc_ns, now_mono_ns)

