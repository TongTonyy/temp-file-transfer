from __future__ import annotations

import asyncio
import re
import time
from dataclasses import dataclass

from hgnn_collect.collectors.base import BaseCollector, CollectorContext
from hgnn_collect.models import MetricKind, Observation, ObservationStatus
from hgnn_collect.utils import run_command, run_command_sync


@dataclass
class NpuSummary:
    device_id: int
    card_id: int
    chip_id: int
    name: str
    health: str
    power_w: float
    temperature_c: float
    aicore_pct: float
    ddr_used_mb: int
    ddr_total_mb: int
    hbm_used_mb: int
    hbm_total_mb: int
    bus_id: str


def parse_npu_summary(output: str) -> list[NpuSummary]:
    rows = [line for line in output.splitlines() if line.lstrip().startswith("|")]
    summaries: list[NpuSummary] = []
    pending: dict[str, object] | None = None
    card_power: dict[int, float] = {}
    for line in rows:
        cells = [cell.strip() for cell in line.split("|")[1:-1]]
        if len(cells) != 3:
            continue
        first = cells[0].split(maxsplit=1)
        if (
            len(first) == 2
            and first[0].isdigit()
            and first[1] not in {"NPU", "Chip"}
            and not first[1].isdigit()
            and re.search(r"\d", cells[2])
        ):
            values = re.match(
                r"^\s*([0-9.]+|-)\s+(-?[0-9.]+)\s+(\d+)\s*/\s*(\d+)\s*$",
                cells[2],
            )
            if values:
                card_id = int(first[0])
                power = (
                    float(values.group(1))
                    if values.group(1) != "-"
                    else card_power.get(card_id)
                )
                if power is not None:
                    card_power[card_id] = power
                pending = {
                    "card_id": card_id,
                    "name": first[1],
                    "health": cells[1],
                    "power_w": power,
                    "temperature_c": float(values.group(2)),
                }
            continue
        if pending is None:
            continue
        second = re.match(
            r"^\s*([0-9.]+)\s+(\d+)\s*/\s*(\d+)\s+(\d+)\s*/\s*(\d+)\s*$",
            cells[2],
        )
        chip_parts = cells[0].split()
        if second and chip_parts and chip_parts[0].isdigit():
            chip_id = int(chip_parts[0])
            device_id = (
                int(chip_parts[1])
                if len(chip_parts) > 1 and chip_parts[1].isdigit()
                else int(pending["card_id"])
            )
            summaries.append(
                NpuSummary(
                    device_id=device_id,
                    card_id=int(pending["card_id"]),
                    chip_id=chip_id,
                    name=str(pending["name"]),
                    health=str(pending["health"]),
                    power_w=float(pending["power_w"] or 0.0),
                    temperature_c=float(pending["temperature_c"]),
                    aicore_pct=float(second.group(1)),
                    ddr_used_mb=int(second.group(2)),
                    ddr_total_mb=int(second.group(3)),
                    hbm_used_mb=int(second.group(4)),
                    hbm_total_mb=int(second.group(5)),
                    bus_id=cells[1],
                )
            )
            pending = None
    return summaries


def parse_key_value_output(output: str) -> dict[str, str]:
    result: dict[str, str] = {}
    for line in output.splitlines():
        if ":" not in line:
            continue
        key, value = line.split(":", 1)
        result[key.strip()] = value.strip()
    return result


def parse_numeric(value: str) -> float | int | None:
    match = re.search(r"-?\d+(?:\.\d+)?", value)
    if not match:
        return None
    parsed = float(match.group(0))
    return int(parsed) if parsed.is_integer() else parsed


def discover_npu_ids() -> list[int]:
    result = run_command_sync(["npu-smi", "info"], timeout_s=8)
    if result.returncode != 0:
        return []
    return [item.device_id for item in parse_npu_summary(result.stdout)]


class NpuSummaryCollector(BaseCollector):
    def __init__(self, interval_s: float, critical: bool = True, timeout_s: float = 3):
        super().__init__("npu_summary", interval_s, critical)
        self.timeout_s = timeout_s

    async def collect(self, context: CollectorContext) -> list[Observation]:
        result = await run_command(["npu-smi", "info"], timeout_s=self.timeout_s)
        now_utc_ns = time.time_ns()
        now_mono_ns = time.monotonic_ns()
        if result.returncode != 0:
            return [
                self.unavailable(
                    context,
                    node_type="npu",
                    node_id=f"{context.host_id}/npu/unknown",
                    metric_id="npu.health_state",
                    metric_kind=MetricKind.CATEGORICAL,
                    unit="state",
                    status=ObservationStatus.SOURCE_ERROR,
                    reason=(result.stderr or result.stdout).strip()[:500],
                )
            ]
        summaries = parse_npu_summary(result.stdout)
        if not summaries:
            return [
                self.unavailable(
                    context,
                    node_type="npu",
                    node_id=f"{context.host_id}/npu/unknown",
                    metric_id="npu.health_state",
                    metric_kind=MetricKind.CATEGORICAL,
                    unit="state",
                    status=ObservationStatus.INVALID,
                    reason="unable to parse npu-smi summary",
                )
            ]
        observations: list[Observation] = []
        for summary in summaries:
            npu_id = f"{context.host_id}/npu/{summary.device_id}"
            hbm_id = f"{context.host_id}/hbm/{summary.device_id}"
            npu_metrics: tuple[tuple[str, MetricKind, object, str], ...] = (
                ("npu.temperature_c", MetricKind.GAUGE, summary.temperature_c, "degC"),
                ("npu.power_w", MetricKind.GAUGE, summary.power_w, "W"),
                ("npu.utilization_pct", MetricKind.GAUGE, summary.aicore_pct, "percent"),
                ("npu.health_state", MetricKind.CATEGORICAL, summary.health, "state"),
                (
                    "npu.ddr_used_bytes",
                    MetricKind.GAUGE,
                    summary.ddr_used_mb * 1024 * 1024,
                    "byte",
                ),
            )
            for metric_id, kind, value, unit in npu_metrics:
                observations.append(
                    self.observation(
                        context,
                        node_type="npu",
                        node_id=npu_id,
                        metric_id=metric_id,
                        metric_kind=kind,
                        value=value,
                        unit=unit,
                        source_latency_us=result.duration_us,
                        ts_utc_ns=now_utc_ns,
                        ts_mono_ns=now_mono_ns,
                        attributes={
                            "device_id": summary.device_id,
                            "card_id": summary.card_id,
                            "chip_id": summary.chip_id,
                            "bus_id": summary.bus_id,
                            "product": summary.name,
                        },
                    )
                )
            hbm_used = summary.hbm_used_mb * 1024 * 1024
            hbm_total = summary.hbm_total_mb * 1024 * 1024
            for metric_id, value, unit in (
                ("hbm.used_bytes", hbm_used, "byte"),
                (
                    "hbm.utilization_pct",
                    100 * hbm_used / hbm_total if hbm_total else 0.0,
                    "percent",
                ),
            ):
                observations.append(
                    self.observation(
                        context,
                        node_type="hbm",
                        node_id=hbm_id,
                        metric_id=metric_id,
                        metric_kind=MetricKind.GAUGE,
                        value=value,
                        unit=unit,
                        source_latency_us=result.duration_us,
                        ts_utc_ns=now_utc_ns,
                        ts_mono_ns=now_mono_ns,
                        attributes={
                            "device_id": summary.device_id,
                            "capacity_bytes": hbm_total,
                            "granularity": "device_aggregate",
                        },
                    )
                )
        return observations


class NpuDetailCollector(BaseCollector):
    def __init__(
        self,
        interval_s: float,
        critical: bool = False,
        timeout_s: float = 3,
        device_ids: list[int] | None = None,
        devices_per_cycle: int = 1,
    ):
        super().__init__("npu_detail", interval_s, critical)
        if devices_per_cycle <= 0:
            raise ValueError("devices_per_cycle must be positive")
        self.timeout_s = timeout_s
        discovered = {
            item.device_id: (item.card_id, item.chip_id)
            for item in parse_npu_summary(
                run_command_sync(["npu-smi", "info"], timeout_s=8).stdout
            )
        }
        self.device_ids = (
            device_ids if device_ids is not None else sorted(discovered)
        )
        self.device_targets = {
            device_id: discovered.get(device_id, (device_id, 0))
            for device_id in self.device_ids
        }
        self.devices_per_cycle = devices_per_cycle
        self._cursor = 0

    async def _query(self, query_type: str, device_id: int):
        card_id, chip_id = self.device_targets[device_id]
        return await run_command(
            [
                "npu-smi",
                "info",
                "-t",
                query_type,
                "-i",
                str(card_id),
                "-c",
                str(chip_id),
            ],
            timeout_s=self.timeout_s,
        )

    async def collect(self, context: CollectorContext) -> list[Observation]:
        if not self.device_ids:
            return [
                self.unavailable(
                    context,
                    node_type="npu",
                    node_id=f"{context.host_id}/npu/unknown",
                    metric_id="npu.health_state",
                    metric_kind=MetricKind.CATEGORICAL,
                    unit="state",
                    status=ObservationStatus.UNSUPPORTED,
                    reason="no NPU devices discovered",
                )
            ]
        selected_count = min(self.devices_per_cycle, len(self.device_ids))
        selected_devices = [
            self.device_ids[(self._cursor + offset) % len(self.device_ids)]
            for offset in range(selected_count)
        ]
        self._cursor = (self._cursor + selected_count) % len(self.device_ids)
        query_types = ("memory", "usages", "health", "ecc")
        requests = [
            (device_id, query_type)
            for device_id in selected_devices
            for query_type in query_types
        ]
        results = await asyncio.gather(
            *(
                self._query(query_type, device_id)
                for device_id, query_type in requests
            )
        )
        now_utc_ns = time.time_ns()
        now_mono_ns = time.monotonic_ns()
        observations: list[Observation] = []
        result_map = {
            request: result
            for request, result in zip(requests, results)
        }
        effective_interval_s = self.interval_s * (
            (len(self.device_ids) + selected_count - 1) // selected_count
        )
        for device_id in selected_devices:
            device_results = {
                query_type: result_map[(device_id, query_type)]
                for query_type in query_types
            }
            parsed = {
                query_type: parse_key_value_output(result.stdout)
                for query_type, result in device_results.items()
                if result.returncode == 0
            }
            npu_id = f"{context.host_id}/npu/{device_id}"
            hbm_id = f"{context.host_id}/hbm/{device_id}"
            card_id, chip_id = self.device_targets[device_id]
            latency = sum(
                result.duration_us for result in device_results.values()
            )

            metric_sources = [
                (
                    "memory",
                    "HBM Temperature(C)",
                    "hbm",
                    hbm_id,
                    "hbm.temperature_c",
                    MetricKind.GAUGE,
                    "degC",
                ),
                (
                    "usages",
                    "HBM Bandwidth Usage Rate(%)",
                    "hbm",
                    hbm_id,
                    "hbm.bandwidth_usage_pct",
                    MetricKind.GAUGE,
                    "percent",
                ),
                (
                    "health",
                    "Health Status",
                    "npu",
                    npu_id,
                    "npu.health_state",
                    MetricKind.CATEGORICAL,
                    "state",
                ),
                (
                    "health",
                    "Error Code",
                    "npu",
                    npu_id,
                    "npu.error_code",
                    MetricKind.CATEGORICAL,
                    "code",
                ),
                (
                    "health",
                    "Error Information",
                    "npu",
                    npu_id,
                    "npu.error_info",
                    MetricKind.CATEGORICAL,
                    "text",
                ),
            ]
            for source, key, node_type, node_id, metric_id, kind, unit in metric_sources:
                value = parsed.get(source, {}).get(key)
                if value is None:
                    continue
                if key in {"Error Code", "Error Information"} and value.upper() in {
                    "NA",
                    "N/A",
                    "NONE",
                    "",
                }:
                    continue
                typed_value = (
                    parse_numeric(value) if kind == MetricKind.GAUGE else value
                )
                if typed_value is None:
                    continue
                observations.append(
                    self.observation(
                        context,
                        node_type=node_type,
                        node_id=node_id,
                        metric_id=metric_id,
                        metric_kind=kind,
                        value=typed_value,
                        unit=unit,
                        source_latency_us=latency,
                        ts_utc_ns=now_utc_ns,
                        ts_mono_ns=now_mono_ns,
                        attributes={
                            "device_id": device_id,
                            "card_id": card_id,
                            "chip_id": chip_id,
                            "source_key": key,
                            "effective_device_interval_s": effective_interval_s,
                            "devices_per_cycle": selected_count,
                        },
                    )
                )

            ecc = parsed.get("ecc", {})
            ecc_metrics = (
                (
                    "HBM Single Bit Aggregate Total Err Cnt",
                    "hbm.ce_count_total",
                ),
                (
                    "HBM Double Bit Aggregate Total Err Cnt",
                    "hbm.ue_count_total",
                ),
            )
            for key, metric_id in ecc_metrics:
                value = ecc.get(key)
                parsed_value = (
                    parse_numeric(value) if value is not None else None
                )
                if parsed_value is None:
                    continue
                observations.append(
                    self.observation(
                        context,
                        node_type="hbm",
                        node_id=hbm_id,
                        metric_id=metric_id,
                        metric_kind=MetricKind.COUNTER,
                        value=int(parsed_value),
                        unit="count",
                        source_latency_us=latency,
                        ts_utc_ns=now_utc_ns,
                        ts_mono_ns=now_mono_ns,
                        attributes={
                            "device_id": device_id,
                            "card_id": card_id,
                            "chip_id": chip_id,
                            "effective_device_interval_s": effective_interval_s,
                            "devices_per_cycle": selected_count,
                        },
                    )
                )
        return observations

