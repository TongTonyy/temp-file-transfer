from __future__ import annotations

import time
from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import Any

from hgnn_collect.models import (
    ClockQuality,
    MetricKind,
    Observation,
    ObservationStatus,
)


@dataclass
class CollectorContext:
    schema_version: str
    run_id: str
    host_id: str
    phase: str
    clock_quality: ClockQuality
    scheduled_mono_ns: int


class BaseCollector(ABC):
    def __init__(self, collector_id: str, interval_s: float, critical: bool = False):
        self.collector_id = collector_id
        self.interval_s = interval_s
        self.critical = critical
        self._sequence = 0

    def _next_sequence(self) -> int:
        sequence = self._sequence
        self._sequence += 1
        return sequence

    def observation(
        self,
        context: CollectorContext,
        *,
        node_type: str,
        node_id: str,
        metric_id: str,
        metric_kind: MetricKind,
        value: float | int | str | bool | None,
        unit: str,
        status: ObservationStatus = ObservationStatus.OK,
        quality_flags: list[str] | None = None,
        source_latency_us: int = 0,
        attributes: dict[str, Any] | None = None,
        ts_utc_ns: int | None = None,
        ts_mono_ns: int | None = None,
    ) -> Observation:
        now_utc_ns = ts_utc_ns or time.time_ns()
        now_mono_ns = ts_mono_ns or time.monotonic_ns()
        payload: dict[str, Any] = {
            "schema_version": context.schema_version,
            "run_id": context.run_id,
            "collector_id": self.collector_id,
            "seq": self._next_sequence(),
            "ts_utc_ns": now_utc_ns,
            "ts_mono_ns": now_mono_ns,
            "clock_quality": context.clock_quality,
            "host_id": context.host_id,
            "node_type": node_type,
            "node_id": node_id,
            "metric_id": metric_id,
            "metric_kind": metric_kind,
            "unit": unit,
            "observed": value is not None and status == ObservationStatus.OK,
            "status": status,
            "quality_flags": quality_flags or [],
            "source_latency_us": source_latency_us,
            "sample_interval_us": round(self.interval_s * 1_000_000),
            "attributes": attributes or {},
        }
        if value is not None and status == ObservationStatus.OK:
            if isinstance(value, bool):
                payload["value_bool"] = value
            elif isinstance(value, int):
                payload["value_i64"] = value
            elif isinstance(value, float):
                payload["value_f64"] = value
            else:
                payload["value_str"] = str(value)
        return Observation.model_validate(payload)

    def unavailable(
        self,
        context: CollectorContext,
        *,
        node_type: str,
        node_id: str,
        metric_id: str,
        metric_kind: MetricKind,
        unit: str,
        status: ObservationStatus,
        reason: str,
    ) -> Observation:
        return self.observation(
            context,
            node_type=node_type,
            node_id=node_id,
            metric_id=metric_id,
            metric_kind=metric_kind,
            value=None,
            unit=unit,
            status=status,
            quality_flags=[status.value.upper()],
            attributes={"reason": reason},
        )

    @abstractmethod
    async def collect(self, context: CollectorContext) -> list[Observation]:
        raise NotImplementedError

