from __future__ import annotations

import json
import re
import time
from pathlib import Path

from hgnn_collect.collectors.base import BaseCollector, CollectorContext
from hgnn_collect.models import MetricKind, Observation, ObservationStatus
from hgnn_collect.utils import RateTracker, read_int, read_text, run_command


def discover_interfaces(requested: list[str] | None = None) -> list[str]:
    net_paths = [
        path for path in Path("/sys/class/net").glob("*") if path.name != "lo"
    ]
    available = sorted(path.name for path in net_paths)
    if not requested or "auto" in requested:
        physical = sorted(
            path.name for path in net_paths if (path / "device").exists()
        )
        return physical or available
    return [interface for interface in requested if interface in available]


def parse_ethtool_stats(output: str) -> dict[str, int]:
    stats: dict[str, int] = {}
    for line in output.splitlines():
        match = re.match(r"\s*([^:]+):\s*(-?\d+)\s*$", line)
        if match:
            stats[match.group(1).strip().lower()] = int(match.group(2))
    return stats


def aggregate_matching(
    stats: dict[str, int], patterns: tuple[str, ...]
) -> int | None:
    matched = [
        value
        for key, value in stats.items()
        if any(re.search(pattern, key) for pattern in patterns)
    ]
    return sum(matched) if matched else None


def select_pfc_counter(
    stats: dict[str, int], direction: str
) -> tuple[int, list[str]] | None:
    """Select one aggregate PFC counter, or sum per-priority counters.

    Drivers commonly expose both ``mac_tx_pfc_pkt_num`` and eight
    per-priority counters. Summing every regex match would double count.
    """

    matches = {
        key: value
        for key, value in stats.items()
        if "pfc" in key
        and (
            re.search(rf"(?:^|[_-]){direction}(?:[_-]|$)", key)
            or key.startswith(f"{direction}pfc")
        )
    }
    if not matches:
        return None
    per_priority = re.compile(
        r"(?:pri(?:ority)?|prio)[_-]?\d+|pfc[_-]?\d+(?:[_-]|$)"
    )
    aggregate_keys = [
        key for key in matches if not per_priority.search(key)
    ]
    if aggregate_keys:
        preferred = sorted(
            aggregate_keys,
            key=lambda key: (
                0
                if key == f"mac_{direction}_pfc_pkt_num"
                else 1
                if "total" in key or "aggregate" in key
                else 2,
                key,
            ),
        )[0]
        return matches[preferred], [preferred]
    keys = sorted(matches)
    return sum(matches[key] for key in keys), keys


class NetworkFastCollector(BaseCollector):
    COUNTERS = (
        "rx_bytes",
        "tx_bytes",
        "rx_packets",
        "tx_packets",
        "rx_dropped",
        "tx_dropped",
        "rx_errors",
        "tx_errors",
    )

    def __init__(
        self, interval_s: float, interfaces: list[str] | None = None, critical: bool = True
    ):
        super().__init__("network_fast", interval_s, critical)
        self.interfaces = discover_interfaces(interfaces)
        self._rates = RateTracker()

    async def collect(self, context: CollectorContext) -> list[Observation]:
        now_utc_ns = time.time_ns()
        now_mono_ns = time.monotonic_ns()
        observations: list[Observation] = []
        for interface in self.interfaces:
            node_id = f"{context.host_id}/nic/{interface}"
            stats_dir = Path("/sys/class/net") / interface / "statistics"
            values: dict[str, int] = {}
            for counter in self.COUNTERS:
                value = read_int(stats_dir / counter)
                if value is None:
                    continue
                values[counter] = value
                observations.append(
                    self.observation(
                        context,
                        node_type="nic",
                        node_id=node_id,
                        metric_id=f"nic.{counter}_total",
                        metric_kind=MetricKind.COUNTER,
                        value=value,
                        unit="byte" if counter.endswith("_bytes") else "count",
                        ts_utc_ns=now_utc_ns,
                        ts_mono_ns=now_mono_ns,
                        attributes={"interface": interface, "raw_counter": True},
                    )
                )
                rate, flag = self._rates.rate(
                    f"{interface}:{counter}", value, now_mono_ns
                )
                if rate is None:
                    if flag:
                        observations[-1].quality_flags.append(flag)
                    continue
                metric_map = {
                    "tx_bytes": ("nic.tx_gbps", rate * 8 / 1_000_000_000, "Gb/s"),
                    "rx_bytes": ("nic.rx_gbps", rate * 8 / 1_000_000_000, "Gb/s"),
                    "rx_dropped": (
                        "nic.rx_buffer_drop_rate_s",
                        rate,
                        "1/s",
                    ),
                    "tx_dropped": ("nic.tx_drop_rate_s", rate, "1/s"),
                }
                if counter in metric_map:
                    metric_id, derived, unit = metric_map[counter]
                    observations.append(
                        self.observation(
                            context,
                            node_type="nic",
                            node_id=node_id,
                            metric_id=metric_id,
                            metric_kind=MetricKind.GAUGE,
                            value=float(derived),
                            unit=unit,
                            ts_utc_ns=now_utc_ns,
                            ts_mono_ns=now_mono_ns,
                            attributes={"interface": interface},
                        )
                    )
        return observations


class NetworkSlowCollector(BaseCollector):
    def __init__(
        self,
        interval_s: float,
        interfaces: list[str] | None = None,
        critical: bool = False,
        timeout_s: float = 3.0,
    ):
        super().__init__("network_slow", interval_s, critical)
        self.interfaces = discover_interfaces(interfaces)
        self.timeout_s = timeout_s
        self._rates = RateTracker()

    async def _collect_ethtool(
        self,
        context: CollectorContext,
        interface: str,
        now_utc_ns: int,
        now_mono_ns: int,
    ) -> list[Observation]:
        result = await run_command(
            ["ethtool", "-S", interface], timeout_s=self.timeout_s
        )
        node_id = f"{context.host_id}/nic/{interface}"
        if result.returncode != 0:
            return [
                self.unavailable(
                    context,
                    node_type="nic",
                    node_id=node_id,
                    metric_id="nic.ethtool_stats_state",
                    metric_kind=MetricKind.CATEGORICAL,
                    unit="state",
                    status=ObservationStatus.SOURCE_ERROR,
                    reason=result.stderr.strip()[:300],
                )
            ]
        stats = parse_ethtool_stats(result.stdout)
        categories = {
            "ecn_cnp": (r"cnp", r"ecn"),
            "roce_retrans": (r"retrans", r"retry"),
            "fec_error": (r"fec.*err", r"corrected.*codeword", r"uncorrectable"),
        }
        observations: list[Observation] = []
        selected_counters: dict[str, tuple[int, list[str]] | None] = {
            "pfc_tx": select_pfc_counter(stats, "tx"),
            "pfc_rx": select_pfc_counter(stats, "rx"),
        }
        selected_counters.update(
            {
                name: (
                    (total, [f"regex:{'|'.join(patterns)}"])
                    if (
                        total := aggregate_matching(stats, patterns)
                    )
                    is not None
                    else None
                )
                for name, patterns in categories.items()
            }
        )
        for name, selected in selected_counters.items():
            if selected is None:
                continue
            total, counter_keys = selected
            if total is None:
                continue
            observations.append(
                self.observation(
                    context,
                    node_type="nic",
                    node_id=node_id,
                    metric_id=f"nic.{name}_total",
                    metric_kind=MetricKind.COUNTER,
                    value=total,
                    unit="count",
                    source_latency_us=result.duration_us,
                    ts_utc_ns=now_utc_ns,
                    ts_mono_ns=now_mono_ns,
                    attributes={
                        "interface": interface,
                        "raw_counter": True,
                        "counter_keys": counter_keys,
                    },
                )
            )
            rate, flag = self._rates.rate(
                f"ethtool:{interface}:{name}", total, now_mono_ns
            )
            if rate is None:
                if flag:
                    observations[-1].quality_flags.append(flag)
                continue
            metric_map = {
                "pfc_tx": "nic.pfc_tx_rate_s",
                "pfc_rx": "nic.pfc_rx_rate_s",
                "ecn_cnp": "nic.ecn_cnp_rate_s",
            }
            if name in metric_map:
                observations.append(
                    self.observation(
                        context,
                        node_type="nic",
                        node_id=node_id,
                        metric_id=metric_map[name],
                        metric_kind=MetricKind.GAUGE,
                        value=float(rate),
                        unit="1/s",
                        source_latency_us=result.duration_us,
                        ts_utc_ns=now_utc_ns,
                        ts_mono_ns=now_mono_ns,
                    )
                )
        return observations

    async def _collect_qdisc(
        self, context: CollectorContext, now_utc_ns: int, now_mono_ns: int
    ) -> list[Observation]:
        result = await run_command(
            ["tc", "-s", "-j", "qdisc", "show"], timeout_s=self.timeout_s
        )
        if result.returncode != 0:
            return []
        try:
            rows = json.loads(result.stdout)
        except json.JSONDecodeError:
            return []
        observations: list[Observation] = []
        for row in rows:
            interface = row.get("dev")
            if not interface:
                continue
            stats = row.get("stats") or row.get("stats2") or {}
            drops = row.get("drops")
            if drops is None:
                drops = stats.get("drops")
            if drops is None and isinstance(stats.get("basic"), dict):
                drops = stats["basic"].get("drops")
            if drops is None:
                continue
            node_id = f"{context.host_id}/nic/{interface}"
            observations.append(
                self.observation(
                    context,
                    node_type="nic",
                    node_id=node_id,
                    metric_id="nic.qdisc_drops_total",
                    metric_kind=MetricKind.COUNTER,
                    value=int(drops),
                    unit="count",
                    source_latency_us=result.duration_us,
                    ts_utc_ns=now_utc_ns,
                    ts_mono_ns=now_mono_ns,
                    attributes={"kind": row.get("kind"), "handle": row.get("handle")},
                )
            )
            rate, flag = self._rates.rate(
                f"qdisc:{interface}:{row.get('handle')}:{row.get('parent')}",
                int(drops),
                now_mono_ns,
            )
            if rate is not None:
                observations.append(
                    self.observation(
                        context,
                        node_type="nic",
                        node_id=node_id,
                        metric_id="nic.qdisc_drop_rate_s",
                        metric_kind=MetricKind.GAUGE,
                        value=float(rate),
                        unit="1/s",
                        source_latency_us=result.duration_us,
                        ts_utc_ns=now_utc_ns,
                        ts_mono_ns=now_mono_ns,
                    )
                )
            elif flag:
                observations[-1].quality_flags.append(flag)
        return observations

    async def collect(self, context: CollectorContext) -> list[Observation]:
        now_utc_ns = time.time_ns()
        now_mono_ns = time.monotonic_ns()
        observations: list[Observation] = []
        for interface in self.interfaces:
            base = Path("/sys/class/net") / interface
            node_id = f"{context.host_id}/nic/{interface}"
            state = read_text(base / "operstate", "unknown")
            observations.append(
                self.observation(
                    context,
                    node_type="nic",
                    node_id=node_id,
                    metric_id="nic.link_state",
                    metric_kind=MetricKind.CATEGORICAL,
                    value=state,
                    unit="state",
                    ts_utc_ns=now_utc_ns,
                    ts_mono_ns=now_mono_ns,
                    attributes={
                        "interface": interface,
                        "carrier": read_int(base / "carrier"),
                        "speed_mbps": read_int(base / "speed"),
                        "mtu": read_int(base / "mtu"),
                    },
                )
            )
            observations.extend(
                await self._collect_ethtool(
                    context, interface, now_utc_ns, now_mono_ns
                )
            )
        observations.extend(
            await self._collect_qdisc(context, now_utc_ns, now_mono_ns)
        )
        return observations

