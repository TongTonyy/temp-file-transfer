from __future__ import annotations

import ctypes
import time
from pathlib import Path
from typing import Any

from hgnn_collect.collectors.base import BaseCollector, CollectorContext
from hgnn_collect.models import MetricKind, Observation, ObservationStatus


class _DcmiAicoreInfo(ctypes.Structure):
    _fields_ = [
        ("freq", ctypes.c_uint),
        ("cur_freq", ctypes.c_uint),
    ]


class DcmiApi:
    """Minimal read-only wrapper for the public DCMI AI Core frequency API."""

    def __init__(self, library_path: str | Path = "libdcmi.so"):
        self.library_path = str(library_path)
        self.error: str | None = None
        self.card_ids: list[int] = []
        self._library: ctypes.CDLL | None = None
        try:
            library = ctypes.CDLL(self.library_path)
            library.dcmi_init.argtypes = []
            library.dcmi_init.restype = ctypes.c_int
            library.dcmi_get_card_list.argtypes = [
                ctypes.POINTER(ctypes.c_int),
                ctypes.POINTER(ctypes.c_int),
                ctypes.c_int,
            ]
            library.dcmi_get_card_list.restype = ctypes.c_int
            library.dcmi_get_device_aicore_info.argtypes = [
                ctypes.c_int,
                ctypes.c_int,
                ctypes.POINTER(_DcmiAicoreInfo),
            ]
            library.dcmi_get_device_aicore_info.restype = ctypes.c_int
            init_rc = int(library.dcmi_init())
            if init_rc != 0:
                raise RuntimeError(f"dcmi_init returned {init_rc}")
            card_num = ctypes.c_int()
            card_list = (ctypes.c_int * 64)()
            list_rc = int(
                library.dcmi_get_card_list(
                    ctypes.byref(card_num),
                    card_list,
                    len(card_list),
                )
            )
            if list_rc != 0:
                raise RuntimeError(f"dcmi_get_card_list returned {list_rc}")
            if not 0 < card_num.value <= len(card_list):
                raise RuntimeError(
                    f"invalid DCMI card count {card_num.value}"
                )
            self._library = library
            self.card_ids = [
                int(card_list[index]) for index in range(card_num.value)
            ]
        except (AttributeError, OSError, RuntimeError) as error:
            self.error = f"{type(error).__name__}: {error}"

    @property
    def available(self) -> bool:
        return self._library is not None and bool(self.card_ids)

    def aicore_frequency(
        self, card_id: int, device_id: int = 0
    ) -> tuple[int, int, int]:
        if self._library is None:
            raise RuntimeError(self.error or "DCMI is unavailable")
        info = _DcmiAicoreInfo()
        return_code = int(
            self._library.dcmi_get_device_aicore_info(
                int(card_id),
                int(device_id),
                ctypes.byref(info),
            )
        )
        return return_code, int(info.freq), int(info.cur_freq)


_SHARED_API: DcmiApi | None = None


def shared_dcmi_api() -> DcmiApi:
    global _SHARED_API
    if _SHARED_API is None:
        _SHARED_API = DcmiApi()
    return _SHARED_API


def probe_dcmi_aicore(
    library_path: str | Path | None = None,
) -> dict[str, Any]:
    api = DcmiApi(library_path) if library_path else shared_dcmi_api()
    readings: list[dict[str, int]] = []
    errors: list[str] = []
    if api.available:
        for card_id in api.card_ids:
            return_code, nominal_mhz, current_mhz = api.aicore_frequency(
                card_id
            )
            if return_code != 0:
                errors.append(f"card {card_id}: rc={return_code}")
                continue
            readings.append(
                {
                    "card_id": card_id,
                    "nominal_mhz": nominal_mhz,
                    "current_mhz": current_mhz,
                }
            )
    return {
        "available": api.available and not errors and bool(readings),
        "library": api.library_path,
        "card_ids": api.card_ids,
        "readings": readings,
        "errors": errors,
        "initialization_error": api.error,
    }


class DcmiCollector(BaseCollector):
    def __init__(
        self,
        interval_s: float,
        critical: bool = False,
        api: DcmiApi | None = None,
    ):
        super().__init__("dcmi", interval_s, critical)
        self.api = api or shared_dcmi_api()

    async def collect(self, context: CollectorContext) -> list[Observation]:
        if not self.api.available:
            return [
                self.unavailable(
                    context,
                    node_type="npu",
                    node_id=f"{context.host_id}/npu/unknown",
                    metric_id="npu.clock_mhz",
                    metric_kind=MetricKind.GAUGE,
                    unit="MHz",
                    status=ObservationStatus.UNSUPPORTED,
                    reason=self.api.error or "DCMI is unavailable",
                )
            ]
        now_utc_ns = time.time_ns()
        now_mono_ns = time.monotonic_ns()
        observations: list[Observation] = []
        for card_id in self.api.card_ids:
            return_code, nominal_mhz, current_mhz = (
                self.api.aicore_frequency(card_id)
            )
            node_id = f"{context.host_id}/npu/{card_id}"
            if return_code != 0:
                observations.append(
                    self.unavailable(
                        context,
                        node_type="npu",
                        node_id=node_id,
                        metric_id="npu.clock_mhz",
                        metric_kind=MetricKind.GAUGE,
                        unit="MHz",
                        status=ObservationStatus.SOURCE_ERROR,
                        reason=(
                            "dcmi_get_device_aicore_info returned "
                            f"{return_code}"
                        ),
                    )
                )
                continue
            observations.append(
                self.observation(
                    context,
                    node_type="npu",
                    node_id=node_id,
                    metric_id="npu.clock_mhz",
                    metric_kind=MetricKind.GAUGE,
                    value=current_mhz,
                    unit="MHz",
                    ts_utc_ns=now_utc_ns,
                    ts_mono_ns=now_mono_ns,
                    attributes={
                        "card_id": card_id,
                        "device_id": 0,
                        "nominal_mhz": nominal_mhz,
                        "api": "dcmi_get_device_aicore_info",
                    },
                )
            )
        return observations
