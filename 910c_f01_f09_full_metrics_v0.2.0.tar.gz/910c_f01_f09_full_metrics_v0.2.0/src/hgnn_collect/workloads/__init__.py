from hgnn_collect.workloads.hccl import HcclWorkload, parse_hccl_results

__all__ = ["HcclWorkload", "parse_hccl_results"]

