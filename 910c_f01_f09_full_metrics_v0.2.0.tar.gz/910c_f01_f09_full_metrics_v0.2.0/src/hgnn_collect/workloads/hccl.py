from __future__ import annotations

import asyncio
import os
import re
import time
import uuid
from pathlib import Path
from typing import Any, Callable

from hgnn_collect.collectors.base import CollectorContext
from hgnn_collect.config import PilotConfig
from hgnn_collect.models import EventRecord, MetricKind, Observation
from hgnn_collect.utils import run_command, run_command_sync


HCCL_RESULT_PATTERN = re.compile(
    r"^\s*(\d+)\s*\|\s*([0-9.]+)\s*\|\s*([0-9.]+)\s*\|\s*(\S+)\s*$"
)
MPI_TAG_PATTERN = re.compile(r"^\[[^\]]+\]<(?:stdout|stderr)>:")
HCCL_ERROR_PATTERNS = (
    r"local rank_id[^\n]*failed",
    "total err",
    "acl interface return err",
    "hccl interface return err",
    "execute failed",
    "hcclgetrootinfo failed",
    "received invalid data from root process",
)


def parse_hccl_results(output: str) -> list[dict[str, Any]]:
    results: list[dict[str, Any]] = []
    for line in output.splitlines():
        match = HCCL_RESULT_PATTERN.match(MPI_TAG_PATTERN.sub("", line))
        if not match:
            continue
        results.append(
            {
                "data_size_bytes": int(match.group(1)),
                "average_time_us": float(match.group(2)),
                "algorithm_bandwidth_gbs": float(match.group(3)),
                "verification_result": match.group(4).lower(),
            }
        )
    return results


def parse_size_bytes(value: str) -> int:
    match = re.fullmatch(r"\s*(\d+)\s*([KMGT]?)B?\s*", value, re.IGNORECASE)
    if match is None:
        raise ValueError(f"invalid HCCL byte size: {value}")
    factors = {"": 1, "K": 1024, "M": 1024**2, "G": 1024**3, "T": 1024**4}
    return int(match.group(1)) * factors[match.group(2).upper()]


def expected_result_count(minimum: str, maximum: str, factor: int) -> int:
    current = parse_size_bytes(minimum)
    upper = parse_size_bytes(maximum)
    if current > upper:
        return 0
    count = 0
    while current <= upper:
        count += 1
        current *= factor
    return count


def validate_hccl_output(
    stdout: str,
    stderr: str,
    *,
    expected_results: int,
    check_enabled: bool,
) -> tuple[list[dict[str, Any]], list[str]]:
    results = parse_hccl_results(stdout)
    errors: list[str] = []
    combined = f"{stdout}\n{stderr}".lower()
    for pattern in HCCL_ERROR_PATTERNS:
        if re.search(pattern, combined):
            errors.append(f"HCCL error marker found: {pattern}")
    if len(results) != expected_results:
        errors.append(
            f"expected {expected_results} result rows, parsed {len(results)}"
        )
    if check_enabled:
        failed = [
            row["verification_result"]
            for row in results
            if row["verification_result"] != "success"
        ]
        if failed:
            errors.append(f"verification result is not success: {failed}")
    return results, errors


def health_output_ok(output: str) -> bool:
    error_code = ""
    health = ""
    for line in output.splitlines():
        if ":" not in line:
            continue
        key, value = line.split(":", 1)
        if key.strip() == "Error Code":
            error_code = value.strip()
        if key.strip() == "Health Status":
            health = value.strip()
    no_error_codes = {"", "0", "00000000", "NA", "N/A", "NONE"}
    return health.upper() == "OK" and error_code.upper() in no_error_codes


def _health_precheck(device_ids: list[int]) -> tuple[bool, list[dict[str, Any]]]:
    details: list[dict[str, Any]] = []
    healthy = True
    for device_id in device_ids:
        result = run_command_sync(
            [
                "npu-smi",
                "info",
                "-t",
                "health",
                "-i",
                str(device_id),
                "-c",
                "0",
            ],
            timeout_s=5,
        )
        payload = {
            "device_id": device_id,
            "returncode": result.returncode,
            "stdout": result.stdout.strip(),
            "stderr": result.stderr.strip(),
        }
        details.append(payload)
        if result.returncode != 0:
            healthy = False
            continue
        if not health_output_ok(result.stdout):
            healthy = False
    return healthy, details


class HcclWorkload:
    collector_id = "hccl_test"

    def __init__(
        self,
        config: PilotConfig,
        *,
        phase_getter: Callable[[int], str],
    ):
        self.config = config
        self.workload = config.workload
        self.phase_getter = phase_getter
        self.sequence = 0
        self.summary: dict[str, Any] = {
            "enabled": self.workload.enabled,
            "kind": self.workload.kind,
            "invocations": 0,
            "successful_invocations": 0,
            "failed_invocations": 0,
            "parsed_results": 0,
            "verification_failures": 0,
            "safety_stopped": False,
            "max_temperature_c": None,
            "precheck": {},
        }

    def _next_sequence(self) -> int:
        sequence = self.sequence
        self.sequence += 1
        return sequence

    def _event(
        self,
        context: CollectorContext,
        event_type: str,
        *,
        severity: str = "info",
        payload: dict[str, Any] | None = None,
    ) -> EventRecord:
        now_mono_ns = time.monotonic_ns()
        return EventRecord(
            schema_version=context.schema_version,
            event_id=str(uuid.uuid4()),
            run_id=context.run_id,
            collector_id=self.collector_id,
            seq=self._next_sequence(),
            ts_utc_ns=time.time_ns(),
            ts_mono_ns=now_mono_ns,
            clock_quality=context.clock_quality,
            host_id=context.host_id,
            event_type=event_type,
            phase=self.phase_getter(now_mono_ns),
            severity=severity,
            entity_ids=[
                f"{context.host_id}/npu/{device_id}"
                for device_id in self.workload.npu_ids
            ],
            correlation_id=f"hccl-{self.summary['invocations']}",
            payload=payload or {},
        )

    def _observation(
        self,
        context: CollectorContext,
        metric_id: str,
        value: float | int,
        unit: str,
        kind: MetricKind,
        attributes: dict[str, Any],
    ) -> Observation:
        now_mono_ns = time.monotonic_ns()
        payload: dict[str, Any] = {
            "schema_version": context.schema_version,
            "run_id": context.run_id,
            "collector_id": self.collector_id,
            "seq": self._next_sequence(),
            "ts_utc_ns": time.time_ns(),
            "ts_mono_ns": now_mono_ns,
            "clock_quality": context.clock_quality,
            "host_id": context.host_id,
            "node_type": "global_task",
            "node_id": f"{context.host_id}/global_task/{context.run_id}",
            "metric_id": metric_id,
            "metric_kind": kind,
            "unit": unit,
            "observed": True,
            "status": "ok",
            "quality_flags": [],
            "source_latency_us": 0,
            "scheduled_lag_us": 0,
            "attributes": attributes,
        }
        if isinstance(value, int):
            payload["value_i64"] = value
        else:
            payload["value_f64"] = float(value)
        return Observation.model_validate(payload)

    def _runtime_env(self) -> dict[str, str]:
        environment = os.environ.copy()
        environment["HCCL_TEST_USE_DEVS"] = ",".join(
            str(device_id) for device_id in self.workload.npu_ids
        )
        toolkit = os.environ.get(
            "ASCEND_HOME_PATH", "/home/jialei/Ascend/ascend-toolkit/latest"
        )
        library = str(Path(toolkit) / "lib64")
        current = environment.get("LD_LIBRARY_PATH", "")
        paths = [library] + ([current] if current else [])
        environment["LD_LIBRARY_PATH"] = ":".join(paths)
        environment["HCCL_OP_RETRY_ENABLE"] = "L0:0, L1:0, L2:0"
        environment["HCCL_EXEC_TIMEOUT"] = str(
            min(120, max(30, round(self.workload.command_timeout_s)))
        )
        environment.pop("HCCL_TEST_PROFILING", None)
        environment.pop("HCCL_TEST_PROFILING_PATH", None)
        return environment

    async def _runtime_safety_check(self) -> tuple[bool, list[dict[str, Any]]]:
        queries = [
            (device_id, query_type)
            for device_id in self.workload.npu_ids
            for query_type in ("temp", "health")
        ]
        results = await asyncio.gather(
            *(
                run_command(
                    [
                        "npu-smi",
                        "info",
                        "-t",
                        query_type,
                        "-i",
                        str(device_id),
                        "-c",
                        "0",
                    ],
                    timeout_s=5,
                )
                for device_id, query_type in queries
            )
        )
        safe = True
        details: list[dict[str, Any]] = []
        for (device_id, query_type), result in zip(queries, results):
            detail: dict[str, Any] = {
                "device_id": device_id,
                "query_type": query_type,
                "returncode": result.returncode,
            }
            if result.returncode != 0:
                detail["error"] = (result.stderr or result.stdout).strip()[-500:]
                safe = False
            elif query_type == "health":
                detail["healthy"] = health_output_ok(result.stdout)
                safe = safe and detail["healthy"]
            else:
                match = re.search(
                    r"NPU Temperature\s*\(C\)\s*:\s*(-?\d+(?:\.\d+)?)",
                    result.stdout,
                )
                if match is None:
                    detail["error"] = "temperature output could not be parsed"
                    safe = False
                else:
                    temperature = float(match.group(1))
                    detail["temperature_c"] = temperature
                    current_max = self.summary["max_temperature_c"]
                    self.summary["max_temperature_c"] = (
                        temperature
                        if current_max is None
                        else max(float(current_max), temperature)
                    )
                    if temperature >= self.workload.max_temperature_c:
                        detail["threshold_exceeded"] = True
                        safe = False
            details.append(detail)
        return safe, details

    def command(self) -> list[str]:
        return [
            "mpirun",
            "--tag-output",
            "--bind-to",
            "none",
            "--mca",
            "btl",
            "^openib",
            "-x",
            "HCCL_TEST_USE_DEVS",
            "-x",
            "LD_LIBRARY_PATH",
            "-x",
            "HCCL_OP_RETRY_ENABLE",
            "-x",
            "HCCL_EXEC_TIMEOUT",
            "-n",
            str(len(self.workload.npu_ids)),
            str(self.workload.binary),
            "-b",
            self.workload.min_bytes,
            "-e",
            self.workload.max_bytes,
            "-f",
            str(self.workload.step_factor),
            "-d",
            "fp32",
            "-o",
            "sum",
            "-p",
            str(len(self.workload.npu_ids)),
            "-n",
            str(self.workload.iterations),
            "-w",
            str(self.workload.warmup_iterations),
            "-c",
            "1" if self.workload.check else "0",
            "-z",
            "0",
        ]

    async def run(
        self,
        context: CollectorContext,
        queue: asyncio.Queue[Observation | EventRecord | None],
        *,
        end_mono_ns: int,
    ) -> dict[str, Any]:
        if not self.workload.enabled:
            return self.summary
        if not self.workload.binary.is_file():
            self.summary["precheck"] = {
                "ok": False,
                "reason": f"binary missing: {self.workload.binary}",
            }
            await queue.put(
                self._event(
                    context,
                    "WORKLOAD_SKIPPED",
                    severity="warning",
                    payload=self.summary["precheck"],
                )
            )
            return self.summary
        healthy, health_details = _health_precheck(self.workload.npu_ids)
        self.summary["precheck"] = {
            "ok": healthy,
            "health_details": health_details,
        }
        if not healthy:
            await queue.put(
                self._event(
                    context,
                    "WORKLOAD_PRECHECK_FAILED",
                    severity="error",
                    payload=self.summary["precheck"],
                )
            )
            return self.summary

        await queue.put(
            self._event(
                context,
                "WORKLOAD_STARTED",
                payload={"command": self.command(), "device_ids": self.workload.npu_ids},
            )
        )
        last_invocation_s: float | None = None
        expected_rows = expected_result_count(
            self.workload.min_bytes,
            self.workload.max_bytes,
            self.workload.step_factor,
        )
        while True:
            remaining_s = (end_mono_ns - time.monotonic_ns()) / 1_000_000_000
            launch_window_s = (
                max(15.0, last_invocation_s * 1.5)
                if last_invocation_s is not None
                else 20.0
            )
            if remaining_s < launch_window_s:
                break
            safe, safety_details = await self._runtime_safety_check()
            if not safe:
                self.summary["safety_stopped"] = True
                self.summary["safety_details"] = safety_details
                await queue.put(
                    self._event(
                        context,
                        "WORKLOAD_SAFETY_STOP",
                        severity="error",
                        payload={
                            "max_temperature_c": self.workload.max_temperature_c,
                            "details": safety_details,
                        },
                    )
                )
                break
            invocation = self.summary["invocations"]
            self.summary["invocations"] += 1
            await queue.put(
                self._event(
                    context,
                    "HCCL_INVOCATION_STARTED",
                    payload={"invocation": invocation},
                )
            )
            result = await run_command(
                self.command(),
                timeout_s=min(self.workload.command_timeout_s, remaining_s),
                env=self._runtime_env(),
                start_new_session=True,
            )
            last_invocation_s = result.duration_us / 1_000_000
            parsed, output_errors = validate_hccl_output(
                result.stdout,
                result.stderr,
                expected_results=expected_rows,
                check_enabled=self.workload.check,
            )
            if result.returncode != 0 or output_errors:
                self.summary["failed_invocations"] += 1
                if any("verification" in error for error in output_errors):
                    self.summary["verification_failures"] += 1
                await queue.put(
                    self._event(
                        context,
                        "HCCL_INVOCATION_FAILED",
                        severity="error",
                        payload={
                            "invocation": invocation,
                            "returncode": result.returncode,
                            "timed_out": result.timed_out,
                            "validation_errors": output_errors,
                            "stderr": result.stderr[-2000:],
                            "stdout_tail": result.stdout[-2000:],
                        },
                    )
                )
                break
            self.summary["successful_invocations"] += 1
            self.summary["parsed_results"] += len(parsed)
            for row in parsed:
                attributes = {
                    "collective_type": "all_reduce",
                    "invocation": invocation,
                    "device_ids": self.workload.npu_ids,
                    "observation_kind": "group_inferred",
                    "verification_result": row["verification_result"],
                }
                await queue.put(
                    self._observation(
                        context,
                        "global_task.step_time_ms",
                        row["average_time_us"] / 1000,
                        "ms",
                        MetricKind.DURATION,
                        attributes,
                    )
                )
                await queue.put(
                    self._observation(
                        context,
                        "global_task.collective_bytes",
                        row["data_size_bytes"],
                        "byte",
                        MetricKind.GAUGE,
                        attributes,
                    )
                )
                await queue.put(
                    self._observation(
                        context,
                        "global_task.collective_bandwidth_gbs",
                        row["algorithm_bandwidth_gbs"],
                        "GB/s",
                        MetricKind.GAUGE,
                        attributes,
                    )
                )
                await queue.put(
                    self._observation(
                        context,
                        "global_task.active_rank_count",
                        len(self.workload.npu_ids),
                        "count",
                        MetricKind.GAUGE,
                        attributes,
                    )
                )
                await queue.put(
                    self._event(
                        context,
                        "HCCL_COLLECTIVE_RESULT",
                        payload={**row, **attributes},
                    )
                )
            await queue.put(
                self._event(
                    context,
                    "HCCL_INVOCATION_FINISHED",
                    payload={
                        "invocation": invocation,
                        "duration_us": result.duration_us,
                        "result_count": len(parsed),
                    },
                )
            )
            if self.workload.cooldown_s:
                await asyncio.sleep(self.workload.cooldown_s)
        await queue.put(
            self._event(context, "WORKLOAD_FINISHED", payload=self.summary.copy())
        )
        return self.summary

