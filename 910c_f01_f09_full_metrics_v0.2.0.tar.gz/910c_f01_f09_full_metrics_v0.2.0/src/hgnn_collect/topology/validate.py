from __future__ import annotations

import json
from pathlib import Path
from typing import Any

import numpy as np
import pyarrow.parquet as pq


EXPECTED_NODE_TYPES = {
    "npu",
    "hbm",
    "cpu_numa",
    "sys_mem_numa",
    "storage_swap",
    "pcie_switch",
    "nic",
    "bmc_env",
    "global_task",
}


def validate_topology_and_priors(run_dir: Path) -> dict[str, Any]:
    errors: list[str] = []
    topology = json.loads(
        (run_dir / "topology" / "topology.json").read_text(encoding="utf-8")
    )
    nodes = topology["nodes"]
    edges = topology["edges"]
    node_ids = [node["node_id"] for node in nodes]
    node_by_id = {node["node_id"]: node for node in nodes}
    node_types = {node["node_type"] for node in nodes}
    if len(node_ids) != len(set(node_ids)):
        errors.append("duplicate node_id in topology")
    missing_types = EXPECTED_NODE_TYPES - node_types
    if missing_types:
        errors.append(f"missing node types: {sorted(missing_types)}")

    edge_ids: set[str] = set()
    for edge in edges:
        if edge["edge_id"] in edge_ids:
            errors.append(f"duplicate edge_id: {edge['edge_id']}")
        edge_ids.add(edge["edge_id"])
        source = node_by_id.get(edge["source_id"])
        target = node_by_id.get(edge["target_id"])
        if source is None:
            errors.append(f"missing edge source: {edge['source_id']}")
        elif source["node_type"] != edge["source_type"]:
            errors.append(f"source type mismatch: {edge['edge_id']}")
        if target is None:
            errors.append(f"missing edge target: {edge['target_id']}")
        elif target["node_type"] != edge["target_type"]:
            errors.append(f"target type mismatch: {edge['edge_id']}")

    node_index = json.loads(
        (run_dir / "priors" / "node_index.json").read_text(encoding="utf-8")
    )
    for node_type, index in node_index.items():
        expected = {
            node["node_id"]
            for node in nodes
            if node["node_type"] == node_type
        }
        if set(index) != expected:
            errors.append(f"node index mismatch for {node_type}")
        if sorted(index.values()) != list(range(len(index))):
            errors.append(f"node index not contiguous for {node_type}")

    prior_manifest = json.loads(
        (run_dir / "priors" / "prior_manifest.json").read_text(encoding="utf-8")
    )
    relation_summary: dict[str, Any] = {}
    for relation, item in prior_manifest["relations"].items():
        path = run_dir / "priors" / item["path"]
        if not path.is_file():
            errors.append(f"missing prior cache: {item['path']}")
            continue
        with np.load(path, allow_pickle=False) as matrix:
            row = matrix["row"]
            column = matrix["col"]
            data = matrix["data"]
            shape = matrix["shape"].tolist()
        expected_shape = [
            len(node_index.get(item["source_type"], {})),
            len(node_index.get(item["target_type"], {})),
        ]
        if shape != expected_shape:
            errors.append(f"prior shape mismatch for {relation}")
        if not (len(row) == len(column) == len(data) == item["edge_count"]):
            errors.append(f"prior edge count mismatch for {relation}")
        if len(row) and (row.min() < 0 or row.max() >= shape[0]):
            errors.append(f"prior source index out of range for {relation}")
        if len(column) and (column.min() < 0 or column.max() >= shape[1]):
            errors.append(f"prior target index out of range for {relation}")
        relation_summary[relation] = {
            "shape": shape,
            "edge_count": len(row),
        }

    allowed_path = run_dir / "priors" / "allowed_edges.parquet"
    if not allowed_path.is_file():
        errors.append("missing allowed_edges.parquet")
        allowed_edges = 0
    else:
        allowed_rows = pq.read_table(allowed_path).to_pylist()
        allowed_edges = len(allowed_rows)
        for edge in allowed_rows:
            if edge["source_id"] not in node_by_id:
                errors.append(f"allowed edge missing source: {edge['edge_id']}")
            if edge["target_id"] not in node_by_id:
                errors.append(f"allowed edge missing target: {edge['edge_id']}")

    return {
        "passed": not errors,
        "errors": sorted(set(errors)),
        "topology_id": topology["topology_id"],
        "node_count": len(nodes),
        "edge_count": len(edges),
        "node_types": sorted(node_types),
        "allowed_edge_count": allowed_edges,
        "relations": relation_summary,
    }

