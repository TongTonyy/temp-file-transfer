from __future__ import annotations

import json
import re
from pathlib import Path
from typing import Any

from hgnn_collect.collectors.network import (
    discover_interfaces,
    parse_ethtool_stats,
    select_pfc_counter,
)
from hgnn_collect.collectors.npu_smi import parse_npu_summary
from hgnn_collect.config import PilotConfig
from hgnn_collect.models import EdgeRecord, NodeRecord
from hgnn_collect.storage.parquet import write_pylist
from hgnn_collect.utils import (
    atomic_write_json,
    canonical_hash,
    read_int,
    read_text,
    run_command_sync,
    sha256_text,
)


PCI_BDF = re.compile(r"^[0-9a-fA-F]{4}:[0-9a-fA-F]{2}:[0-9a-fA-F]{2}\.[0-7]$")


def _hardware_id(*parts: str) -> str:
    return f"sha256:{sha256_text('|'.join(parts))[:20]}"


def _edge(
    source_type: str,
    relation: str,
    target_type: str,
    source_id: str,
    target_id: str,
    topology: str,
    evidence: str,
    confidence: float,
    **attributes: Any,
) -> EdgeRecord:
    canonical = f"{source_type}|{relation}|{target_type}|{source_id}|{target_id}"
    return EdgeRecord(
        edge_id=f"edge:{sha256_text(canonical)[:20]}",
        source_type=source_type,
        relation=relation,
        target_type=target_type,
        source_id=source_id,
        target_id=target_id,
        topology=topology,
        evidence=evidence,
        confidence=confidence,
        attributes=attributes,
    )


def _pci_attributes(path: Path) -> dict[str, Any]:
    return {
        "bdf": path.name,
        "vendor_id": read_text(path / "vendor"),
        "device_id": read_text(path / "device"),
        "subsystem_vendor_id": read_text(path / "subsystem_vendor"),
        "subsystem_device_id": read_text(path / "subsystem_device"),
        "class": read_text(path / "class"),
        "numa_node": read_int(path / "numa_node"),
        "current_link_speed": read_text(path / "current_link_speed"),
        "current_link_width": read_text(path / "current_link_width"),
        "max_link_speed": read_text(path / "max_link_speed"),
        "max_link_width": read_text(path / "max_link_width"),
        "aer_sysfs_capable": any(
            (path / name).is_file()
            for name in (
                "aer_dev_correctable",
                "aer_dev_nonfatal",
                "aer_dev_fatal",
            )
        ),
    }


def _parent_bridges(endpoint_bdf: str, bridge_bdfs: set[str]) -> list[str]:
    endpoint = Path("/sys/bus/pci/devices") / endpoint_bdf
    try:
        components = endpoint.resolve().parts
    except OSError:
        return []
    parents = [
        component
        for component in components
        if PCI_BDF.fullmatch(component) and component in bridge_bdfs
    ]
    return parents


def _qdisc_drop_capable_interfaces(timeout_s: float) -> set[str]:
    result = run_command_sync(
        ["tc", "-s", "-j", "qdisc", "show"],
        timeout_s=timeout_s,
    )
    if result.returncode != 0:
        return set()
    try:
        rows = json.loads(result.stdout)
    except json.JSONDecodeError:
        return set()
    capable: set[str] = set()
    for row in rows:
        stats = row.get("stats") or row.get("stats2") or {}
        drops = row.get("drops")
        if drops is None:
            drops = stats.get("drops")
        if drops is None and isinstance(stats.get("basic"), dict):
            drops = stats["basic"].get("drops")
        if row.get("dev") and drops is not None:
            capable.add(str(row["dev"]))
    return capable


def _pfc_capable_interfaces(
    interfaces: list[str], timeout_s: float
) -> dict[str, set[str]]:
    capable = {"tx": set(), "rx": set()}
    for interface in interfaces:
        result = run_command_sync(
            ["ethtool", "-S", interface],
            timeout_s=timeout_s,
        )
        if result.returncode != 0:
            continue
        stats = parse_ethtool_stats(result.stdout)
        for direction in capable:
            if select_pfc_counter(stats, direction) is not None:
                capable[direction].add(interface)
    return capable


def discover_topology(config: PilotConfig, run_id: str) -> dict[str, Any]:
    host_id = config.resolved_host_id
    nodes: dict[str, NodeRecord] = {}
    edges: dict[str, EdgeRecord] = {}

    def add_node(node: NodeRecord) -> None:
        nodes[node.node_id] = node

    def add_edge(edge: EdgeRecord) -> None:
        edges[edge.edge_id] = edge

    numa_nodes = sorted(Path("/sys/devices/system/node").glob("node[0-9]*"))
    for numa in numa_nodes:
        numa_id = numa.name.removeprefix("node")
        cpu_id = f"{host_id}/cpu_numa/{numa_id}"
        memory_id = f"{host_id}/sys_mem_numa/{numa_id}"
        add_node(
            NodeRecord(
                node_id=cpu_id,
                node_type="cpu_numa",
                host_id=host_id,
                hardware_instance_id=_hardware_id(host_id, "cpu_numa", numa_id),
                attributes={
                    "numa_id": int(numa_id),
                    "cpulist": read_text(numa / "cpulist"),
                    "cpumap": read_text(numa / "cpumap"),
                },
            )
        )
        add_node(
            NodeRecord(
                node_id=memory_id,
                node_type="sys_mem_numa",
                host_id=host_id,
                hardware_instance_id=_hardware_id(host_id, "sys_mem_numa", numa_id),
                attributes={"numa_id": int(numa_id), "granularity": "numa_node"},
            )
        )
        add_edge(
            _edge(
                "cpu_numa",
                "owns",
                "sys_mem_numa",
                cpu_id,
                memory_id,
                "static",
                "sysfs_numa",
                1.0,
            )
        )

    for node_type in ("cpu_numa", "sys_mem_numa"):
        node_id = f"{host_id}/{node_type}/host_aggregate"
        add_node(
            NodeRecord(
                node_id=node_id,
                node_type=node_type,
                host_id=host_id,
                hardware_instance_id=_hardware_id(host_id, node_type, "host_aggregate"),
                attributes={"virtual": True, "granularity": "host_aggregate"},
            )
        )

    pci_devices = {
        path.name: path for path in Path("/sys/bus/pci/devices").glob("*")
    }
    bridge_bdfs: set[str] = set()
    for bdf, path in pci_devices.items():
        if read_text(path / "class").lower().startswith("0x0604"):
            bridge_bdfs.add(bdf)
            attributes = _pci_attributes(path)
            node_id = f"{host_id}/pcie_switch/{bdf}"
            add_node(
                NodeRecord(
                    node_id=node_id,
                    node_type="pcie_switch",
                    host_id=host_id,
                    hardware_instance_id=_hardware_id(
                        host_id,
                        "pcie_switch",
                        bdf,
                        attributes["vendor_id"],
                        attributes["device_id"],
                    ),
                    attributes=attributes,
                )
            )
            numa_id = attributes.get("numa_node")
            cpu_id = (
                f"{host_id}/cpu_numa/{numa_id}"
                if isinstance(numa_id, int) and numa_id >= 0
                else f"{host_id}/cpu_numa/host_aggregate"
            )
            add_edge(
                _edge(
                    "cpu_numa",
                    "mounts_to",
                    "pcie_switch",
                    cpu_id,
                    node_id,
                    "static",
                    "sysfs_pci_numa",
                    0.9,
                )
            )

    summary_result = run_command_sync(["npu-smi", "info"], timeout_s=8)
    npu_summaries = (
        parse_npu_summary(summary_result.stdout)
        if summary_result.returncode == 0
        else []
    )
    for summary in npu_summaries:
        npu_id = f"{host_id}/npu/{summary.device_id}"
        hbm_id = f"{host_id}/hbm/{summary.device_id}"
        add_node(
            NodeRecord(
                node_id=npu_id,
                node_type="npu",
                host_id=host_id,
                hardware_instance_id=_hardware_id(
                    host_id, "npu", str(summary.device_id), summary.bus_id
                ),
                attributes={
                    "device_id": summary.device_id,
                    "chip_id": summary.chip_id,
                    "product": summary.name,
                    "pci_bdf": summary.bus_id.lower(),
                    "numa_node": read_int(
                        Path("/sys/bus/pci/devices")
                        / summary.bus_id.lower()
                        / "numa_node"
                    ),
                },
            )
        )
        add_node(
            NodeRecord(
                node_id=hbm_id,
                node_type="hbm",
                host_id=host_id,
                hardware_instance_id=_hardware_id(
                    host_id, "hbm", str(summary.device_id), summary.bus_id
                ),
                attributes={
                    "device_id": summary.device_id,
                    "capacity_bytes": summary.hbm_total_mb * 1024 * 1024,
                    "granularity": "device_aggregate",
                },
            )
        )
        add_edge(
            _edge(
                "npu",
                "on_chip_connects",
                "hbm",
                npu_id,
                hbm_id,
                "static",
                "npu_smi_device_mapping",
                1.0,
            )
        )
        parents = _parent_bridges(summary.bus_id.lower(), bridge_bdfs)
        if parents:
            bridge_id = f"{host_id}/pcie_switch/{parents[-1]}"
            add_edge(
                _edge(
                    "pcie_switch",
                    "routes_to",
                    "npu",
                    bridge_id,
                    npu_id,
                    "static",
                    "sysfs_pci_parent",
                    1.0,
                    pci_path=parents,
                )
            )

    interfaces = discover_interfaces(["auto"])
    qdisc_capable_interfaces = _qdisc_drop_capable_interfaces(
        config.command_timeout_s
    )
    pfc_capable_interfaces = _pfc_capable_interfaces(
        interfaces,
        config.command_timeout_s,
    )
    for interface in interfaces:
        netdev = Path("/sys/class/net") / interface
        try:
            device_path = (netdev / "device").resolve()
            bdf = device_path.name if PCI_BDF.fullmatch(device_path.name) else ""
        except OSError:
            bdf = ""
        attributes = {
            "interface": interface,
            "pci_bdf": bdf,
            "mac_hash": _hardware_id(read_text(netdev / "address")),
            "operstate": read_text(netdev / "operstate"),
            "mtu": read_int(netdev / "mtu"),
            "speed_mbps": read_int(netdev / "speed"),
            "numa_node": read_int(device_path / "numa_node") if bdf else None,
            "qdisc_drop_stats_capable": interface
            in qdisc_capable_interfaces,
            "pfc_tx_stats_capable": interface
            in pfc_capable_interfaces["tx"],
            "pfc_rx_stats_capable": interface
            in pfc_capable_interfaces["rx"],
        }
        nic_id = f"{host_id}/nic/{interface}"
        add_node(
            NodeRecord(
                node_id=nic_id,
                node_type="nic",
                host_id=host_id,
                hardware_instance_id=_hardware_id(host_id, "nic", interface, bdf),
                attributes=attributes,
            )
        )
        if bdf:
            parents = _parent_bridges(bdf, bridge_bdfs)
            if parents:
                add_edge(
                    _edge(
                        "pcie_switch",
                        "routes_to",
                        "nic",
                        f"{host_id}/pcie_switch/{parents[-1]}",
                        nic_id,
                        "static",
                        "sysfs_pci_parent",
                        1.0,
                        pci_path=parents,
                    )
                )

    for block in sorted(Path("/sys/block").glob("*")):
        if block.name.startswith(("loop", "ram")):
            continue
        try:
            device = (block / "device").resolve()
        except OSError:
            device = block
        numa_node = read_int(device / "numa_node")
        storage_id = f"{host_id}/storage_swap/{block.name}"
        add_node(
            NodeRecord(
                node_id=storage_id,
                node_type="storage_swap",
                host_id=host_id,
                hardware_instance_id=_hardware_id(
                    host_id, "storage_swap", block.name, str(device)
                ),
                attributes={
                    "block_device": block.name,
                    "numa_node": numa_node,
                    "size_sectors": read_int(block / "size"),
                    "rotational": read_int(block / "queue/rotational"),
                },
            )
        )
        cpu_id = (
            f"{host_id}/cpu_numa/{numa_node}"
            if isinstance(numa_node, int) and numa_node >= 0
            else f"{host_id}/cpu_numa/host_aggregate"
        )
        add_edge(
            _edge(
                "cpu_numa",
                "accesses",
                "storage_swap",
                cpu_id,
                storage_id,
                "static",
                "sysfs_block_numa",
                0.8 if numa_node is not None and numa_node >= 0 else 0.5,
            )
        )

    swap_id = f"{host_id}/storage_swap/host_swap"
    if swap_id not in nodes:
        add_node(
            NodeRecord(
                node_id=swap_id,
                node_type="storage_swap",
                host_id=host_id,
                hardware_instance_id=_hardware_id(host_id, "storage_swap", "host_swap"),
                attributes={"virtual": True, "granularity": "host_swap"},
            )
        )

    bmc_id = f"{host_id}/bmc_env/0"
    add_node(
        NodeRecord(
            node_id=bmc_id,
            node_type="bmc_env",
            host_id=host_id,
            hardware_instance_id=_hardware_id(host_id, "bmc_env", "0"),
            attributes={
                "capability": "unsupported_or_permission_denied",
                "virtual_placeholder": False,
            },
        )
    )
    for node in list(nodes.values()):
        if node.node_type in {"npu", "nic"}:
            add_edge(
                _edge(
                    "bmc_env",
                    "monitors",
                    node.node_type,
                    bmc_id,
                    node.node_id,
                    "static_allowed",
                    "chassis_membership_zone_unknown",
                    0.25,
                )
            )

    task_id = f"{host_id}/global_task/{run_id}"
    add_node(
        NodeRecord(
            node_id=task_id,
            node_type="global_task",
            host_id=host_id,
            hardware_instance_id=_hardware_id(host_id, "global_task", run_id),
            attributes={"run_id": run_id, "workload_kind": config.workload.kind},
        )
    )
    if config.workload.enabled:
        selected_npus = set(config.workload.npu_ids)
        for summary in npu_summaries:
            if summary.device_id not in selected_npus:
                continue
            add_edge(
                _edge(
                    "global_task",
                    "executes_on",
                    "npu",
                    task_id,
                    f"{host_id}/npu/{summary.device_id}",
                    "dynamic_membership",
                    "workload_config",
                    1.0,
                    device_id=summary.device_id,
                )
            )

    node_payload = [
        node.model_dump(mode="json")
        for node in sorted(nodes.values(), key=lambda item: item.node_id)
    ]
    edge_payload = [
        edge.model_dump(mode="json")
        for edge in sorted(edges.values(), key=lambda item: item.edge_id)
    ]
    topology_core = {
        "schema_version": config.schema_version,
        "host_id": host_id,
        "nodes": node_payload,
        "edges": edge_payload,
    }
    topology_id = f"topo-sha256-{canonical_hash(topology_core)[:12]}"
    return {
        "topology_id": topology_id,
        "schema_version": config.schema_version,
        "dataset_version": config.dataset_version,
        "host_id": host_id,
        "nodes": node_payload,
        "edges": edge_payload,
    }


def persist_topology(
    config: PilotConfig, topology: dict[str, Any], output_dir: Path
) -> dict[str, Any]:
    output_dir.mkdir(parents=True, exist_ok=True)
    atomic_write_json(output_dir / "topology.json", topology)
    write_pylist(
        output_dir / "nodes.parquet",
        [
            {
                **{key: value for key, value in node.items() if key != "attributes"},
                "attributes_json": json.dumps(
                    node.get("attributes", {}),
                    ensure_ascii=False,
                    sort_keys=True,
                ),
            }
            for node in topology["nodes"]
        ],
        compression=config.storage.parquet_compression,
        compression_level=config.storage.parquet_compression_level,
    )
    write_pylist(
        output_dir / "edges.parquet",
        [
            {
                **{key: value for key, value in edge.items() if key != "attributes"},
                "attributes_json": json.dumps(
                    edge.get("attributes", {}),
                    ensure_ascii=False,
                    sort_keys=True,
                ),
            }
            for edge in topology["edges"]
        ],
        compression=config.storage.parquet_compression,
        compression_level=config.storage.parquet_compression_level,
    )
    return topology


def write_topology(
    config: PilotConfig, run_id: str, output_dir: Path
) -> dict[str, Any]:
    topology = discover_topology(config, run_id)
    return persist_topology(config, topology, output_dir)

