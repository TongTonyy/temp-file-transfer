from __future__ import annotations

import json
from collections import defaultdict
from pathlib import Path
from typing import Any

import numpy as np

from hgnn_collect.config import PilotConfig
from hgnn_collect.storage.parquet import write_pylist
from hgnn_collect.utils import atomic_write_json, canonical_hash, sha256_file, sha256_text


def _relation_key(edge: dict[str, Any]) -> str:
    return (
        f"{edge['source_type']}__{edge['relation']}__{edge['target_type']}"
    )


def build_priors(
    config: PilotConfig,
    topology: dict[str, Any],
    output_dir: Path,
) -> dict[str, Any]:
    output_dir.mkdir(parents=True, exist_ok=True)
    nodes_by_type: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for node in topology["nodes"]:
        nodes_by_type[node["node_type"]].append(node)
    for node_type in nodes_by_type:
        nodes_by_type[node_type].sort(key=lambda item: item["node_id"])

    node_index = {
        node_type: {
            node["node_id"]: index for index, node in enumerate(nodes)
        }
        for node_type, nodes in sorted(nodes_by_type.items())
    }
    atomic_write_json(output_dir / "node_index.json", node_index)

    allowed_edges: list[dict[str, Any]] = []
    for edge in topology["edges"]:
        allowed_edges.append(
            {
                "edge_id": edge["edge_id"],
                "source_type": edge["source_type"],
                "relation": edge["relation"],
                "target_type": edge["target_type"],
                "source_id": edge["source_id"],
                "target_id": edge["target_id"],
                "prior_kind": edge["topology"],
                "evidence": edge["evidence"],
                "confidence": edge["confidence"],
                "active_observation": edge["topology"] == "static",
            }
        )

    selected_ids = {
        f"{config.resolved_host_id}/npu/{device_id}"
        for device_id in (
            config.workload.npu_ids if config.workload.enabled else []
        )
    }
    selected_ids.intersection_update(node_index.get("npu", {}))
    for source_id in sorted(selected_ids):
        for target_id in sorted(selected_ids):
            if source_id == target_id:
                continue
            canonical = f"npu|logical_sync_with|npu|{source_id}|{target_id}"
            allowed_edges.append(
                {
                    "edge_id": f"edge:{sha256_text(canonical)[:20]}",
                    "source_type": "npu",
                    "relation": "logical_sync_with",
                    "target_type": "npu",
                    "source_id": source_id,
                    "target_id": target_id,
                    "prior_kind": "communicator_allowed",
                    "evidence": "workload_device_set_group_inferred",
                    "confidence": 0.5,
                    "active_observation": False,
                }
            )

    write_pylist(
        output_dir / "allowed_edges.parquet",
        allowed_edges,
        compression=config.storage.parquet_compression,
        compression_level=config.storage.parquet_compression_level,
    )

    grouped: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for edge in allowed_edges:
        grouped[_relation_key(edge)].append(edge)

    relation_manifest: dict[str, Any] = {}
    for relation, edges in sorted(grouped.items()):
        source_type = edges[0]["source_type"]
        target_type = edges[0]["target_type"]
        rows: list[int] = []
        columns: list[int] = []
        data: list[float] = []
        edge_ids: list[str] = []
        for edge in edges:
            source = node_index.get(source_type, {}).get(edge["source_id"])
            target = node_index.get(target_type, {}).get(edge["target_id"])
            if source is None or target is None:
                continue
            rows.append(source)
            columns.append(target)
            data.append(float(edge["confidence"]))
            edge_ids.append(edge["edge_id"])
        path = output_dir / f"{relation}.npz"
        np.savez_compressed(
            path,
            row=np.asarray(rows, dtype=np.int64),
            col=np.asarray(columns, dtype=np.int64),
            data=np.asarray(data, dtype=np.float32),
            shape=np.asarray(
                [
                    len(node_index.get(source_type, {})),
                    len(node_index.get(target_type, {})),
                ],
                dtype=np.int64,
            ),
            edge_id=np.asarray(edge_ids, dtype="U64"),
        )
        relation_manifest[relation] = {
            "source_type": source_type,
            "target_type": target_type,
            "edge_count": len(rows),
            "shape": [
                len(node_index.get(source_type, {})),
                len(node_index.get(target_type, {})),
            ],
            "path": path.name,
            "sha256": sha256_file(path),
        }

    manifest = {
        "schema_version": config.schema_version,
        "dataset_version": config.dataset_version,
        "topology_id": topology["topology_id"],
        "node_index_sha256": canonical_hash(node_index),
        "allowed_edge_count": len(allowed_edges),
        "relations": relation_manifest,
    }
    atomic_write_json(output_dir / "prior_manifest.json", manifest)
    return manifest


def load_and_build_priors(
    config: PilotConfig, topology_path: Path, output_dir: Path
) -> dict[str, Any]:
    topology = json.loads(topology_path.read_text(encoding="utf-8"))
    return build_priors(config, topology, output_dir)

