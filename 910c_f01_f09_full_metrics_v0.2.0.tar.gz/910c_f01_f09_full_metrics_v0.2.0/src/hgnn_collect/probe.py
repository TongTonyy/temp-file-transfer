from __future__ import annotations

import importlib.metadata
import json
import os
import platform
import sys
from pathlib import Path
from typing import Any

from hgnn_collect.collectors.dcmi import probe_dcmi_aicore
from hgnn_collect.config import PilotConfig
from hgnn_collect.models import CapabilityEntry
from hgnn_collect.support import build_readiness_report
from hgnn_collect.utils import (
    atomic_write_json,
    command_exists,
    detect_clock_quality,
    qdisc_snapshot,
    read_int,
    read_text,
    run_command_sync,
    sha256_text,
)


def _command_capability(
    name: str,
    argv: list[str],
    *,
    source: str,
    timeout_s: float = 5,
    success_detail: str = "",
) -> tuple[CapabilityEntry, dict[str, Any]]:
    result = run_command_sync(argv, timeout_s=timeout_s)
    output = {
        "argv": argv,
        "returncode": result.returncode,
        "duration_us": result.duration_us,
        "stdout_sha256": sha256_text(result.stdout),
        "stderr": result.stderr.strip()[:1000],
    }
    if result.returncode == 0:
        return (
            CapabilityEntry(
                name=name,
                status="available",
                source=source,
                detail=success_detail,
                evidence={"duration_us": result.duration_us},
            ),
            output,
        )
    status = "unsupported" if result.returncode in {127, 255} else "unstable"
    return (
        CapabilityEntry(
            name=name,
            status=status,
            source=source,
            detail=(result.stderr or result.stdout).strip()[:500],
            evidence={"returncode": result.returncode},
        ),
        output,
    )


def _package_versions() -> dict[str, str]:
    names = [
        "numpy",
        "pyarrow",
        "pydantic",
        "psutil",
        "PyYAML",
        "pytest",
        "torch",
        "torch-npu",
    ]
    versions: dict[str, str] = {}
    for name in names:
        try:
            versions[name] = importlib.metadata.version(name)
        except importlib.metadata.PackageNotFoundError:
            versions[name] = "not-installed"
    return versions


def _torch_snapshot() -> dict[str, Any]:
    script = (
        "import json, torch, torch_npu;"
        "print(json.dumps({"
        "'available': True,"
        "'torch_version': torch.__version__,"
        "'has_npu_namespace': hasattr(torch, 'npu'),"
        "'npu_available': bool(torch.npu.is_available()),"
        "'npu_count': int(torch.npu.device_count()),"
        "'torch_npu_version': getattr(torch_npu, '__version__', 'unknown')"
        "}))"
    )
    failures: list[str] = []
    for _ in range(2):
        result = run_command_sync([sys.executable, "-c", script], timeout_s=30)
        if result.returncode == 0:
            try:
                return json.loads(result.stdout.strip().splitlines()[-1])
            except (IndexError, json.JSONDecodeError) as error:
                failures.append(f"invalid JSON: {error}")
        else:
            failures.append((result.stderr or result.stdout).strip()[-1000:])
    return {"available": False, "error": " | ".join(failures)}


def _conda_explicit() -> dict[str, Any]:
    conda = os.environ.get("CONDA_EXE", "conda")
    result = run_command_sync(
        [conda, "list", "--explicit", "--prefix", sys.prefix], timeout_s=20
    )
    return {
        "prefix": sys.prefix,
        "environment_name": os.environ.get("CONDA_DEFAULT_ENV"),
        "returncode": result.returncode,
        "packages": [
            line
            for line in result.stdout.splitlines()
            if line and not line.startswith("#")
        ],
        "stderr": result.stderr.strip()[:1000],
    }


def probe_capabilities(config: PilotConfig) -> dict[str, Any]:
    entries: list[CapabilityEntry] = []
    command_evidence: dict[str, Any] = {}

    dcmi_evidence = probe_dcmi_aicore(
        config.site.vendor_api.dcmi_library
    )
    entries.append(
        CapabilityEntry(
            name="npu_clock",
            status=(
                "available"
                if dcmi_evidence["available"]
                else "unsupported"
            ),
            source="libdcmi.so",
            detail=(
                f"cards={dcmi_evidence['card_ids']}"
                if dcmi_evidence["available"]
                else str(
                    dcmi_evidence["initialization_error"]
                    or dcmi_evidence["errors"]
                )
            ),
            evidence={
                "card_count": len(dcmi_evidence["card_ids"]),
                "reading_count": len(dcmi_evidence["readings"]),
            },
        )
    )
    command_evidence["npu_clock"] = dcmi_evidence

    command_specs = [
        ("npu_summary", ["npu-smi", "info"], "npu-smi", 8),
        (
            "npu_usages",
            ["npu-smi", "info", "-t", "usages", "-i", "0", "-c", "0"],
            "npu-smi",
            5,
        ),
        (
            "npu_memory",
            ["npu-smi", "info", "-t", "memory", "-i", "0", "-c", "0"],
            "npu-smi",
            5,
        ),
        (
            "npu_health",
            ["npu-smi", "info", "-t", "health", "-i", "0", "-c", "0"],
            "npu-smi",
            5,
        ),
        (
            "npu_ecc",
            ["npu-smi", "info", "-t", "ecc", "-i", "0", "-c", "0"],
            "npu-smi",
            5,
        ),
        ("tc_read", ["tc", "-s", "-j", "qdisc", "show"], "iproute2", 5),
        ("rdma_link", ["rdma", "-j", "link", "show"], "rdma-core", 5),
        ("msprof", ["msprof", "--help"], "CANN", 8),
    ]
    for name, argv, source, timeout in command_specs:
        entry, evidence = _command_capability(
            name, argv, source=source, timeout_s=timeout
        )
        entries.append(entry)
        command_evidence[name] = evidence

    proc_files = {
        "procfs": Path("/proc/stat").is_file() and Path("/proc/vmstat").is_file(),
        "psi": Path("/proc/pressure/cpu").is_file(),
        "net_sysfs": Path("/sys/class/net").is_dir(),
        "pcie_sysfs": Path("/sys/bus/pci/devices").is_dir(),
        "numa_sysfs": Path("/sys/devices/system/node").is_dir(),
        "ptp": any(Path("/dev").glob("ptp*")),
        "bmc": os.access("/dev/ipmi0", os.R_OK) if Path("/dev/ipmi0").exists() else False,
    }
    for name, available in proc_files.items():
        entries.append(
            CapabilityEntry(
                name=name,
                status="available" if available else "unsupported",
                source="filesystem",
                detail="readable" if available else "not present or not readable",
            )
        )

    interfaces = sorted(
        path.name for path in Path("/sys/class/net").glob("*") if path.name != "lo"
    )
    ethtool_available = command_exists("ethtool") and bool(interfaces)
    entries.append(
        CapabilityEntry(
            name="ethtool_stats",
            status="available" if ethtool_available else "unsupported",
            source="ethtool",
            detail=f"interfaces={interfaces}",
        )
    )

    perf_paranoid = read_int(Path("/proc/sys/kernel/perf_event_paranoid"))
    perf_available = command_exists("perf") and (
        perf_paranoid is None or perf_paranoid <= 2
    )
    entries.append(
        CapabilityEntry(
            name="perf",
            status="available" if perf_available else "permission_denied",
            source="perf_event",
            detail=f"perf_event_paranoid={perf_paranoid}",
        )
    )

    torch_snapshot = _torch_snapshot()
    entries.append(
        CapabilityEntry(
            name="torch_npu",
            status="available" if torch_snapshot.get("available") else "unsupported",
            source="cmh-torch",
            detail=json.dumps(torch_snapshot, ensure_ascii=False),
        )
    )

    hccl_source = config.workload.source_dir
    entries.append(
        CapabilityEntry(
            name="hccl_test_source",
            status="available" if hccl_source.joinpath("Makefile").is_file() else "unsupported",
            source=str(hccl_source),
            detail="vendor source tree",
        )
    )
    entries.append(
        CapabilityEntry(
            name="hccl_test_binary",
            status="available" if config.workload.binary.is_file() else "unsupported",
            source=str(config.workload.binary),
            detail="build required" if not config.workload.binary.is_file() else "executable present",
        )
    )

    npu_mapping = run_command_sync(["npu-smi", "info", "-m"], timeout_s=8)
    npu_topology = run_command_sync(["npu-smi", "info", "-l"], timeout_s=8)
    os_release = {}
    for line in read_text(Path("/etc/os-release")).splitlines():
        if "=" in line:
            key, value = line.split("=", 1)
            os_release[key] = value.strip('"')

    capabilities = {
        "schema_version": config.schema_version,
        "dataset_version": config.dataset_version,
        "host_id": config.resolved_host_id,
        "collected_at_utc_ns": __import__("time").time_ns(),
        "clock_quality": detect_clock_quality().value,
        "platform": {
            "system": platform.system(),
            "release": platform.release(),
            "machine": platform.machine(),
            "python": sys.version,
            "python_executable": sys.executable,
            "os_release": os_release,
        },
        "environment": {
            "conda": _conda_explicit(),
            "packages": _package_versions(),
            "torch": torch_snapshot,
            "selected_environment_variables": {
                key: os.environ.get(key)
                for key in (
                    "CONDA_PREFIX",
                    "CONDA_DEFAULT_ENV",
                    "ASCEND_HOME_PATH",
                    "ASCEND_TOOLKIT_HOME",
                    "LD_LIBRARY_PATH",
                )
            },
        },
        "interfaces": interfaces,
        "qdisc_snapshot": qdisc_snapshot(),
        "entries": [entry.model_dump(mode="json") for entry in entries],
        "command_evidence": command_evidence,
        "static_command_outputs": {
            "npu_mapping": {
                "returncode": npu_mapping.returncode,
                "stdout": npu_mapping.stdout,
                "stderr": npu_mapping.stderr,
            },
            "npu_topology": {
                "returncode": npu_topology.returncode,
                "stdout": npu_topology.stdout,
                "stderr": npu_topology.stderr,
            },
        },
        "deployment_readiness": build_readiness_report(config),
    }
    capabilities["capability_status"] = {
        entry.name: entry.status for entry in entries
    }
    return capabilities


def write_capabilities(config: PilotConfig, output_path: Path) -> dict[str, Any]:
    capabilities = probe_capabilities(config)
    atomic_write_json(output_path, capabilities)
    explicit_packages = capabilities["environment"]["conda"].get("packages", [])
    explicit_path = output_path.parent / "cmh-torch-explicit.txt"
    temporary = explicit_path.with_suffix(explicit_path.suffix + ".tmp")
    temporary.write_text(
        "# Generated by hgnn-collect probe\n@EXPLICIT\n"
        + "\n".join(explicit_packages)
        + "\n",
        encoding="utf-8",
    )
    temporary.replace(explicit_path)
    return capabilities

