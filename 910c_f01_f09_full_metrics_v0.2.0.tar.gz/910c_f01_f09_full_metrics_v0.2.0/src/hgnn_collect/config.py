from __future__ import annotations

import hashlib
import json
import socket
from pathlib import Path
from typing import Any

import yaml
from pydantic import BaseModel, ConfigDict, Field, model_validator


PROJECT_ROOT = Path(__file__).resolve().parents[2]
DEFAULT_CONFIG_PATH = PROJECT_ROOT / "configs" / "pilot_910b_passive.yaml"
DEFAULT_NODE_SCHEMA = PROJECT_ROOT / "schemas" / "node_features.yaml"
DEFAULT_EDGE_SCHEMA = PROJECT_ROOT / "schemas" / "edge_features.yaml"
DEFAULT_METRIC_SUPPORT = PROJECT_ROOT / "schemas" / "metric_support.yaml"


class ClockConfig(BaseModel):
    required: str = "ntp"
    max_offset_us: int = 10_000


class CollectorConfig(BaseModel):
    model_config = ConfigDict(extra="allow")

    enabled: bool = True
    interval_s: float = Field(gt=0)
    critical: bool = False
    interfaces: list[str] = Field(default_factory=list)


class WorkloadConfig(BaseModel):
    enabled: bool = False
    kind: str = "hccl_test"
    binary: Path
    source_dir: Path
    npu_ids: list[int] = Field(default_factory=list)
    min_bytes: str = "8M"
    max_bytes: str = "64M"
    step_factor: int = Field(default=2, gt=1)
    iterations: int = Field(default=20, gt=0)
    warmup_iterations: int = Field(default=5, ge=0)
    check: bool = True
    command_timeout_s: float = Field(default=120, gt=0)
    cooldown_s: float = Field(default=1.0, ge=0)
    max_temperature_c: float = Field(default=80.0, gt=0)
    profile_once: bool = False


class QualityConfig(BaseModel):
    required_coverage: float = Field(default=0.95, ge=0, le=1)
    baseline_required_coverage: float = Field(default=0.98, ge=0, le=1)
    safety_metric_coverage: float = Field(default=0.995, ge=0, le=1)
    fast_schedule_lag_p95_ms: float = Field(default=75, ge=0)
    slow_schedule_lag_p95_ms: float = Field(default=500, ge=0)
    fail_on_qdisc_change: bool = True
    fail_on_worker_exit: bool = True
    allow_unsupported: bool = True


class StorageConfig(BaseModel):
    raw_compression: str = "zstd"
    parquet_compression: str = "zstd"
    parquet_compression_level: int = 3
    fsync_parts: bool = True


class BmcSiteConfig(BaseModel):
    enabled: bool = False
    protocol: str = "redfish"
    endpoint: str | None = None
    username_env: str = "HGNN_BMC_USERNAME"
    password_env: str = "HGNN_BMC_PASSWORD"
    ca_bundle: Path | None = None
    sensor_map_path: Path | None = None
    local_ipmi_helper: Path | None = None


class SwitchTelemetryConfig(BaseModel):
    enabled: bool = False
    endpoint: str | None = None
    username_env: str = "HGNN_SWITCH_USERNAME"
    password_env: str = "HGNN_SWITCH_PASSWORD"
    token_env: str = "HGNN_SWITCH_TOKEN"
    ca_bundle: Path | None = None
    port_map_path: Path | None = None


class PtpSiteConfig(BaseModel):
    enabled: bool = False
    domain: int | None = Field(default=None, ge=0, le=127)
    grandmaster_identity: str | None = None
    status_path: Path | None = None
    phc_device: Path | None = None


class PrivilegedHelperConfig(BaseModel):
    perf_socket: Path | None = None
    ras_socket: Path | None = None
    ethtool_eeprom_helper: Path | None = None
    pcie_config_helper: Path | None = None
    journal_helper: Path | None = None


class TrainingTelemetryConfig(BaseModel):
    enabled: bool = False
    event_socket: Path | None = None
    rank_map_path: Path | None = None
    launch_command_ref: str | None = None


class ProfilerSiteConfig(BaseModel):
    enabled: bool = False
    output_root: Path | None = None
    full_window: bool = False
    max_overhead_pct: float = Field(default=5.0, ge=0)


class VendorApiConfig(BaseModel):
    dcmi_library: Path | None = None
    metric_plugin: Path | None = None
    capability_statement_ref: str | None = None


class SiteConfig(BaseModel):
    bmc: BmcSiteConfig = Field(default_factory=BmcSiteConfig)
    switch_telemetry: SwitchTelemetryConfig = Field(
        default_factory=SwitchTelemetryConfig
    )
    ptp: PtpSiteConfig = Field(default_factory=PtpSiteConfig)
    privileged_helpers: PrivilegedHelperConfig = Field(
        default_factory=PrivilegedHelperConfig
    )
    training: TrainingTelemetryConfig = Field(
        default_factory=TrainingTelemetryConfig
    )
    profiler: ProfilerSiteConfig = Field(default_factory=ProfilerSiteConfig)
    vendor_api: VendorApiConfig = Field(default_factory=VendorApiConfig)


class CompatibilityConfig(BaseModel):
    current_platform: str = "ascend910b"
    target_platform: str = "ascend910c"
    metric_support_path: Path = DEFAULT_METRIC_SUPPORT
    allow_current_platform_skips: bool = True
    require_target_reprobe: bool = True


class BatchRuntimeConfig(BaseModel):
    enabled: bool = False
    batch_id: str = "legacy"
    batch_version: str = "0.0.0"
    risk_level: str = "R0"
    state: str = "legacy"
    platform_family: str = "a910x"
    denominator: int = Field(default=83, gt=0)
    planned_cumulative_max: int = Field(default=83, ge=0)
    metric_selection: str = "all"
    selected_metric_ids: list[str] = Field(default_factory=list)
    previous_batch_id: str | None = None
    previous_metric_ids: list[str] = Field(default_factory=list)
    manifest_path: Path | None = None
    injection_profile: str = "none"

    @model_validator(mode="after")
    def validate_selection(self) -> "BatchRuntimeConfig":
        if self.metric_selection not in {"all", "allowlist"}:
            raise ValueError("batch.metric_selection must be all or allowlist")
        if len(self.selected_metric_ids) != len(set(self.selected_metric_ids)):
            raise ValueError("batch.selected_metric_ids contains duplicates")
        if len(self.previous_metric_ids) != len(set(self.previous_metric_ids)):
            raise ValueError("batch.previous_metric_ids contains duplicates")
        if self.planned_cumulative_max > self.denominator:
            raise ValueError("batch planned count exceeds denominator")
        if (
            self.metric_selection == "allowlist"
            and len(self.selected_metric_ids) != self.planned_cumulative_max
        ):
            raise ValueError(
                "allowlist size must equal batch planned_cumulative_max"
            )
        if not set(self.previous_metric_ids).issubset(self.selected_metric_ids):
            raise ValueError("batch previous metrics must be selected")
        return self

    def selects(self, metric_id: str) -> bool:
        return self.metric_selection == "all" or metric_id in set(
            self.selected_metric_ids
        )


class PilotConfig(BaseModel):
    model_config = ConfigDict(extra="forbid")

    schema_version: str
    dataset_version: str
    campaign_id: str
    mode: str = "passive"
    planned_fault_code: str = "F04"
    data_root: Path
    duration_s: int = Field(gt=0)
    phase_boundaries_s: list[int]
    rotation_s: int = Field(default=30, gt=0)
    queue_maxsize: int = Field(default=20_000, gt=0)
    command_timeout_s: float = Field(default=3.0, gt=0)
    clock: ClockConfig
    collectors: dict[str, CollectorConfig]
    workload: WorkloadConfig
    quality: QualityConfig
    storage: StorageConfig
    site: SiteConfig = Field(default_factory=SiteConfig)
    compatibility: CompatibilityConfig = Field(
        default_factory=CompatibilityConfig
    )
    batch: BatchRuntimeConfig = Field(default_factory=BatchRuntimeConfig)
    host_id: str | None = None
    node_schema_path: Path = DEFAULT_NODE_SCHEMA
    edge_schema_path: Path = DEFAULT_EDGE_SCHEMA

    @model_validator(mode="after")
    def validate_passive_mode(self) -> "PilotConfig":
        if self.mode != "passive":
            raise ValueError("this implementation only permits passive mode")
        if len(self.phase_boundaries_s) != 4:
            raise ValueError("phase_boundaries_s must contain [start, t0_end, t1_end, end]")
        if self.phase_boundaries_s[0] != 0:
            raise ValueError("phase boundaries must start at zero")
        if self.phase_boundaries_s[-1] != self.duration_s:
            raise ValueError("last phase boundary must equal duration_s")
        if self.phase_boundaries_s != sorted(self.phase_boundaries_s):
            raise ValueError("phase boundaries must be ordered")
        return self

    @property
    def resolved_host_id(self) -> str:
        return self.host_id or socket.gethostname().split(".")[0]

    def for_duration(self, duration_s: int | None) -> "PilotConfig":
        if duration_s is None or duration_s == self.duration_s:
            return self
        data = self.model_dump()
        data["duration_s"] = duration_s
        data["phase_boundaries_s"] = [
            0,
            max(1, round(duration_s * 0.2)),
            max(2, round(duration_s * 0.8)),
            duration_s,
        ]
        return PilotConfig.model_validate(data)

    def canonical_json(self) -> str:
        return json.dumps(
            self.model_dump(mode="json"),
            ensure_ascii=False,
            sort_keys=True,
            separators=(",", ":"),
        )

    def sha256(self) -> str:
        return hashlib.sha256(self.canonical_json().encode("utf-8")).hexdigest()


def load_config(path: Path | str = DEFAULT_CONFIG_PATH) -> PilotConfig:
    config_path = Path(path).expanduser().resolve()
    with config_path.open("r", encoding="utf-8") as handle:
        raw: dict[str, Any] = yaml.safe_load(handle)
    config = PilotConfig.model_validate(raw)

    def resolve_path(value: Path) -> Path:
        expanded = value.expanduser()
        return (
            expanded.resolve()
            if expanded.is_absolute()
            else (config_path.parent / expanded).resolve()
        )

    def resolve_optional(value: Path | None) -> Path | None:
        return resolve_path(value) if value is not None else None

    config.data_root = resolve_path(config.data_root)
    config.node_schema_path = resolve_path(config.node_schema_path)
    config.edge_schema_path = resolve_path(config.edge_schema_path)
    config.compatibility.metric_support_path = resolve_path(
        config.compatibility.metric_support_path
    )
    config.site.bmc.ca_bundle = resolve_optional(config.site.bmc.ca_bundle)
    config.site.bmc.sensor_map_path = resolve_optional(
        config.site.bmc.sensor_map_path
    )
    config.site.bmc.local_ipmi_helper = resolve_optional(
        config.site.bmc.local_ipmi_helper
    )
    config.site.switch_telemetry.ca_bundle = resolve_optional(
        config.site.switch_telemetry.ca_bundle
    )
    config.site.switch_telemetry.port_map_path = resolve_optional(
        config.site.switch_telemetry.port_map_path
    )
    config.site.ptp.status_path = resolve_optional(config.site.ptp.status_path)
    config.site.ptp.phc_device = resolve_optional(config.site.ptp.phc_device)
    for field_name in PrivilegedHelperConfig.model_fields:
        value = getattr(config.site.privileged_helpers, field_name)
        setattr(
            config.site.privileged_helpers,
            field_name,
            resolve_optional(value),
        )
    config.site.training.event_socket = resolve_optional(
        config.site.training.event_socket
    )
    config.site.training.rank_map_path = resolve_optional(
        config.site.training.rank_map_path
    )
    config.site.profiler.output_root = resolve_optional(
        config.site.profiler.output_root
    )
    config.site.vendor_api.dcmi_library = resolve_optional(
        config.site.vendor_api.dcmi_library
    )
    config.site.vendor_api.metric_plugin = resolve_optional(
        config.site.vendor_api.metric_plugin
    )
    config.batch.manifest_path = resolve_optional(config.batch.manifest_path)
    return config

