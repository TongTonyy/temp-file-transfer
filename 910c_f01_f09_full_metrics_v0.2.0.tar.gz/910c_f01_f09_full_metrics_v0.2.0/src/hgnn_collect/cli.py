from __future__ import annotations

import argparse
import asyncio
import json
import sys
import time
import traceback
from pathlib import Path

from hgnn_collect.batches import (
    apply_batch_manifest,
    batch_plan_payload,
    load_batch_manifest,
    load_batch_roadmap,
)
from hgnn_collect.config import DEFAULT_CONFIG_PATH, PilotConfig, load_config
from hgnn_collect.orchestrator import collect_passive
from hgnn_collect.probe import write_capabilities
from hgnn_collect.processing import align_run, evaluate_quality
from hgnn_collect.promotion import promote_batch_run
from hgnn_collect.storage import verify_checksums
from hgnn_collect.support import write_readiness_report
from hgnn_collect.topology import build_priors, write_topology
from hgnn_collect.utils import atomic_write_json


def _load_from_args(args: argparse.Namespace) -> PilotConfig:
    config = load_config(args.config)
    if getattr(args, "duration", None):
        config = config.for_duration(args.duration)
    if getattr(args, "data_root", None):
        config.data_root = Path(args.data_root).expanduser().resolve()
    if getattr(args, "no_workload", False):
        config.workload.enabled = False
    return config


def _load_run_config(fallback: PilotConfig, run_dir: Path) -> PilotConfig:
    manifest_path = run_dir / "manifest.json"
    if not manifest_path.is_file():
        return fallback
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    embedded = manifest.get("config")
    if not embedded:
        return fallback
    config = PilotConfig.model_validate(embedded)
    run_node_schema = run_dir / "schemas" / "node_features.yaml"
    run_edge_schema = run_dir / "schemas" / "edge_features.yaml"
    run_metric_support = run_dir / "schemas" / "metric_support.yaml"
    if run_node_schema.is_file():
        config.node_schema_path = run_node_schema
    if run_edge_schema.is_file():
        config.edge_schema_path = run_edge_schema
    if run_metric_support.is_file():
        config.compatibility.metric_support_path = run_metric_support
    return config


def command_probe(args: argparse.Namespace) -> int:
    config = _load_from_args(args)
    output = Path(args.output).expanduser().resolve()
    payload = write_capabilities(config, output)
    print(
        json.dumps(
            {
                "output": str(output),
                "host_id": payload["host_id"],
                "capability_status": payload["capability_status"],
            },
            ensure_ascii=False,
            indent=2,
        )
    )
    return 0


def command_readiness(args: argparse.Namespace) -> int:
    config = _load_from_args(args)
    output = Path(args.output).expanduser().resolve()
    report = write_readiness_report(config, output)
    print(
        json.dumps(
            {
                "output": str(output),
                "current_platform": report["current_platform"],
                "target_platform": report["target_platform"],
                "schema_metric_count": report["schema_metric_count"],
                "current_skipped_metrics": len(report["current_skipped_metrics"]),
                "target_attention_metrics": len(report["target_attention_metrics"]),
                "target_uncertified_metrics": len(
                    report["target_uncertified_metrics"]
                ),
                "target_certification_ready": report[
                    "target_certification_ready"
                ],
                "site_ready": report["site"]["ready_for_enabled_sources"],
                "unconfigured_placeholders": sum(
                    not item["configured"]
                    for item in report["site"]["placeholders"]
                ),
                "blocking_placeholders": report["site"]["blocking_placeholders"],
            },
            ensure_ascii=False,
            indent=2,
        )
    )
    return 0


def command_topology(args: argparse.Namespace) -> int:
    config = _load_from_args(args)
    output = Path(args.output).expanduser().resolve()
    topology = write_topology(config, args.run_id, output)
    priors = build_priors(config, topology, output.parent / "priors")
    print(
        json.dumps(
            {
                "topology_id": topology["topology_id"],
                "nodes": len(topology["nodes"]),
                "edges": len(topology["edges"]),
                "prior_relations": len(priors["relations"]),
                "output": str(output),
            },
            ensure_ascii=False,
            indent=2,
        )
    )
    return 0


def _execute_collection(
    config: PilotConfig, run_id: str | None, *, allow_postprocess_failure: bool = False
) -> tuple[int, dict[str, object]]:
    artifacts = asyncio.run(collect_passive(config, run_id))
    manager = artifacts.manager
    try:
        alignment = align_run(config, manager.staging_dir)
        quality = evaluate_quality(config, manager.staging_dir)
        atomic_write_json(manager.staging_dir / "pipeline_report.json", alignment)
        status = "committed" if quality["passed"] else "quarantined"
        final_dir = manager.commit(
            qdisc_after=artifacts.qdisc_after,
            collector_summary=artifacts.collector_summary,
            workload_summary=artifacts.workload_summary,
            quality_summary={
                "status": quality["status"],
                "failures": quality["failures"],
                "warnings": quality["warnings"],
                "limitation_count": len(quality["limitations"]),
                "batch_validation": quality.get("batch_validation"),
            },
            status=status,
        )
        checksum_validation = verify_checksums(final_dir)
    except Exception as error:
        reason = f"post-processing failed: {type(error).__name__}: {error}"
        if not allow_postprocess_failure:
            manager.abort(reason)
            raise
        manager.update(
            status="raw_complete_postprocess_failed",
            postprocess_error=reason,
            qdisc_after=artifacts.qdisc_after,
            collector_summary=artifacts.collector_summary,
            workload_summary=artifacts.workload_summary,
            completed_at_utc_ns=time.time_ns(),
        )
        manager.manifest["files"] = manager.compute_checksums()
        atomic_write_json(manager.manifest_path, manager.manifest)
        checksum_validation = verify_checksums(manager.staging_dir)
        payload = {
            "run_id": manager.run_id,
            "status": "raw_complete_postprocess_failed",
            "run_dir": str(manager.staging_dir),
            "postprocess_error": reason,
            "raw_record_counts": manager.manifest.get("raw_record_counts", {}),
            "checksums": checksum_validation,
            "collector_records": {
                key: value["records"]
                for key, value in artifacts.collector_summary.items()
            },
            "workload": artifacts.workload_summary,
        }
        return 0, payload
    payload: dict[str, object] = {
        "run_id": manager.run_id,
        "status": status,
        "run_dir": str(final_dir),
        "quality_status": quality["status"],
        "failures": quality["failures"],
        "warnings": quality["warnings"],
        "limitations": len(quality["limitations"]),
        "batch_validation": quality.get("batch_validation"),
        "checksums": checksum_validation,
        "collector_records": {
            key: value["records"]
            for key, value in artifacts.collector_summary.items()
        },
        "workload": artifacts.workload_summary,
    }
    return (0 if quality["passed"] else 2), payload


def command_collect(args: argparse.Namespace) -> int:
    config = _load_from_args(args)
    exit_code, payload = _execute_collection(
        config,
        args.run_id,
        allow_postprocess_failure=args.allow_postprocess_failure,
    )
    print(json.dumps(payload, ensure_ascii=False, indent=2))
    return exit_code


def command_batch_plan(args: argparse.Namespace) -> int:
    if args.roadmap:
        manifests = load_batch_roadmap(args.roadmap)
        payload: object = [batch_plan_payload(item) for item in manifests]
    else:
        payload = batch_plan_payload(load_batch_manifest(args.batch_config))
    print(json.dumps(payload, ensure_ascii=False, indent=2))
    return 0


def command_batch_run(args: argparse.Namespace) -> int:
    manifest = load_batch_manifest(args.batch_config)
    if manifest.state != "enabled":
        raise ValueError(
            f"{manifest.batch_id} is {manifest.state}; only enabled batches can run"
        )
    config = apply_batch_manifest(manifest)
    if args.duration:
        config = config.for_duration(args.duration)
    if args.data_root:
        config.data_root = Path(args.data_root).expanduser().resolve()
    exit_code, payload = _execute_collection(config, args.run_id)
    print(json.dumps(payload, ensure_ascii=False, indent=2))
    return exit_code


def command_batch_validate(args: argparse.Namespace) -> int:
    run_dir = Path(args.run_dir).expanduser().resolve()
    fallback = _load_from_args(args)
    config = _load_run_config(fallback, run_dir)
    report = evaluate_quality(
        config,
        run_dir,
        write_report=not (run_dir / "checksums.sha256").is_file(),
    )
    checksums = verify_checksums(run_dir)
    payload = {
        "run_id": report["run_id"],
        "status": report["status"],
        "passed": report["passed"],
        "failures": report["failures"],
        "warnings": report["warnings"],
        "batch_validation": report["batch_validation"],
        "checksums": checksums,
    }
    print(json.dumps(payload, ensure_ascii=False, indent=2))
    return 0 if report["passed"] and checksums["passed"] else 2


def command_batch_promote(args: argparse.Namespace) -> int:
    promotion = promote_batch_run(
        args.batch_config,
        args.run_dir,
        args.output_dir,
        smoke_run_dirs=args.smoke_run_dir,
        require_acceptance_evidence=True,
    )
    print(json.dumps(promotion, ensure_ascii=False, indent=2))
    return 0


def command_align(args: argparse.Namespace) -> int:
    config = _load_from_args(args)
    run_dir = Path(args.run_dir).expanduser().resolve()
    config = _load_run_config(config, run_dir)
    summary = align_run(config, run_dir)
    print(json.dumps(summary, ensure_ascii=False, indent=2))
    return 0


def command_validate(args: argparse.Namespace) -> int:
    config = _load_from_args(args)
    run_dir = Path(args.run_dir).expanduser().resolve()
    config = _load_run_config(config, run_dir)
    checksum_path = run_dir / "checksums.sha256"
    report = evaluate_quality(
        config, run_dir, write_report=not checksum_path.is_file()
    )
    checksum_validation = verify_checksums(run_dir)
    report["checksums"] = checksum_validation
    print(json.dumps(report, ensure_ascii=False, indent=2))
    return 0 if report["passed"] and checksum_validation["passed"] else 2


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="hgnn-collect",
        description="Ascend 910B/910C passive HGNN telemetry pipeline",
    )
    parser.add_argument(
        "--config",
        type=Path,
        default=DEFAULT_CONFIG_PATH,
        help="pilot YAML configuration",
    )
    subparsers = parser.add_subparsers(dest="command", required=True)

    probe = subparsers.add_parser("probe", help="write a read-only capability snapshot")
    probe.add_argument("--output", required=True)
    probe.set_defaults(function=command_probe)

    readiness = subparsers.add_parser(
        "readiness",
        help="report blank site settings and 910B/910C metric compatibility",
    )
    readiness.add_argument("--output", required=True)
    readiness.set_defaults(function=command_readiness)

    batch = subparsers.add_parser(
        "batch", help="plan, run, validate and promote cumulative metric batches"
    )
    batch_commands = batch.add_subparsers(dest="batch_command", required=True)

    batch_plan = batch_commands.add_parser(
        "plan", help="validate and print one batch or the complete roadmap"
    )
    plan_source = batch_plan.add_mutually_exclusive_group(required=True)
    plan_source.add_argument("--batch-config", type=Path)
    plan_source.add_argument("--roadmap", type=Path)
    batch_plan.set_defaults(function=command_batch_plan)

    batch_run = batch_commands.add_parser(
        "run", help="run an enabled batch through collection and quality gates"
    )
    batch_run.add_argument("--batch-config", type=Path, required=True)
    batch_run.add_argument("--duration", type=int)
    batch_run.add_argument("--run-id")
    batch_run.add_argument("--data-root")
    batch_run.set_defaults(function=command_batch_run)

    batch_validate = batch_commands.add_parser(
        "validate", help="read-only validation of a sealed batch run"
    )
    batch_validate.add_argument("--run-dir", required=True)
    batch_validate.set_defaults(function=command_batch_validate)

    batch_promote = batch_commands.add_parser(
        "promote", help="publish an n-83 release alias from a passing run"
    )
    batch_promote.add_argument("--batch-config", type=Path, required=True)
    batch_promote.add_argument("--run-dir", required=True)
    batch_promote.add_argument(
        "--smoke-run-dir",
        action="append",
        required=True,
        help="passing >=30-second run; provide this option three times",
    )
    batch_promote.add_argument(
        "--output-dir",
        type=Path,
        default=Path("releases") / "batches",
    )
    batch_promote.set_defaults(function=command_batch_promote)

    topology = subparsers.add_parser(
        "topology", help="discover entities and build sparse priors"
    )
    topology.add_argument("--run-id", default="topology-probe")
    topology.add_argument("--output", required=True)
    topology.set_defaults(function=command_topology)

    collect = subparsers.add_parser(
        "collect", help="run passive collection, alignment and validation"
    )
    collect.add_argument("--duration", type=int)
    collect.add_argument("--run-id")
    collect.add_argument("--data-root")
    collect.add_argument("--no-workload", action="store_true")
    collect.add_argument(
        "--allow-postprocess-failure",
        action="store_true",
        help="preserve raw A/B observations and return success if alignment fails",
    )
    collect.set_defaults(function=command_collect)

    align = subparsers.add_parser("align", help="rebuild L1/L2 from an existing run")
    align.add_argument("--run-dir", required=True)
    align.set_defaults(function=command_align)

    validate = subparsers.add_parser("validate", help="validate an existing run")
    validate.add_argument("--run-dir", required=True)
    validate.set_defaults(function=command_validate)
    return parser


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    try:
        return int(args.function(args))
    except KeyboardInterrupt:
        print("collection interrupted by user", file=sys.stderr)
        return 130
    except Exception as error:
        print(f"{type(error).__name__}: {error}", file=sys.stderr)
        print(traceback.format_exc(limit=20), file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())

