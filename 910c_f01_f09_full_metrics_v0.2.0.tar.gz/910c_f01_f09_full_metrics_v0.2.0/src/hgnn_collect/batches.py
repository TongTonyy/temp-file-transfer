from __future__ import annotations

import json
import re
from pathlib import Path
from typing import Any, Literal

import yaml
from pydantic import BaseModel, ConfigDict, Field, model_validator

from hgnn_collect.config import BatchRuntimeConfig, PilotConfig, load_config
from hgnn_collect.processing.schema import SchemaRegistry
from hgnn_collect.utils import sha256_file


BATCH_ID_PATTERN = re.compile(r"^B\d{2}$")
SEMVER_PATTERN = re.compile(r"^\d+\.\d+\.\d+$")
RISK_LEVELS = {"R0", "R1", "R2", "R3"}


class BatchManifest(BaseModel):
    model_config = ConfigDict(extra="forbid")

    manifest_version: str = "1.0.0"
    batch_id: str
    batch_version: str
    state: Literal["enabled", "planned", "retired"] = "planned"
    risk_level: str
    platform_family: str = "a910x"
    denominator: int = Field(default=83, gt=0)
    planned_cumulative_max: int = Field(ge=0)
    previous_batch_id: str | None = None
    previous_promotion: Path | None = None
    base_config: Path
    metric_ids: list[str] = Field(default_factory=list)
    added_metric_ids: list[str] = Field(default_factory=list)
    enabled_collectors: list[str] = Field(default_factory=list)
    workload_enabled: bool = False
    injection_profile: str = "none"
    description: str = ""
    manifest_path: Path | None = None

    @model_validator(mode="after")
    def validate_contract(self) -> "BatchManifest":
        if not BATCH_ID_PATTERN.fullmatch(self.batch_id):
            raise ValueError("batch_id must match BNN, for example B01")
        if not SEMVER_PATTERN.fullmatch(self.batch_version):
            raise ValueError("batch_version must be semantic X.Y.Z")
        if self.risk_level not in RISK_LEVELS:
            raise ValueError(f"risk_level must be one of {sorted(RISK_LEVELS)}")
        if len(self.metric_ids) != len(set(self.metric_ids)):
            raise ValueError("metric_ids contains duplicates")
        if len(self.added_metric_ids) != len(set(self.added_metric_ids)):
            raise ValueError("added_metric_ids contains duplicates")
        if self.planned_cumulative_max > self.denominator:
            raise ValueError("planned_cumulative_max exceeds denominator")
        if self.batch_id == "B00" and self.previous_batch_id is not None:
            raise ValueError("B00 cannot declare previous_batch_id")
        if self.injection_profile != "none" and self.risk_level == "R0":
            raise ValueError("R0 collection batches cannot enable injection")
        return self

    @property
    def pending_script_name(self) -> str:
        return release_script_name(self, None)


def release_script_name(
    manifest: BatchManifest,
    validated_count: int | None,
    platform_name: str | None = None,
) -> str:
    if validated_count is not None and not 0 <= validated_count <= len(
        manifest.metric_ids
    ):
        raise ValueError("validated_count is outside this batch allowlist")
    count = "pending" if validated_count is None else f"{validated_count:02d}"
    platform = platform_name or manifest.platform_family
    return (
        f"collect_{manifest.batch_id.lower()}_{count}-{manifest.denominator}_"
        f"{platform}_passive_v{manifest.batch_version}.sh"
    )


def load_batch_manifest(path: Path | str) -> BatchManifest:
    manifest_path = Path(path).expanduser().resolve()
    payload: dict[str, Any] = yaml.safe_load(
        manifest_path.read_text(encoding="utf-8")
    )
    manifest = BatchManifest.model_validate(payload)
    manifest.manifest_path = manifest_path
    if not manifest.base_config.is_absolute():
        manifest.base_config = (manifest_path.parent / manifest.base_config).resolve()
    else:
        manifest.base_config = manifest.base_config.expanduser().resolve()
    if manifest.previous_promotion is not None:
        if not manifest.previous_promotion.is_absolute():
            manifest.previous_promotion = (
                manifest_path.parent / manifest.previous_promotion
            ).resolve()
        else:
            manifest.previous_promotion = (
                manifest.previous_promotion.expanduser().resolve()
            )
    if manifest.previous_batch_id:
        previous_path = (
            manifest_path.parent / f"{manifest.previous_batch_id.lower()}.yaml"
        )
        previous = load_batch_manifest(previous_path)
        if not manifest.metric_ids:
            manifest.metric_ids = [
                *previous.metric_ids,
                *manifest.added_metric_ids,
            ]
    elif not manifest.metric_ids:
        manifest.metric_ids = list(manifest.added_metric_ids)
    if len(manifest.metric_ids) != len(set(manifest.metric_ids)):
        raise ValueError(f"{manifest.batch_id}: cumulative metrics contain duplicates")
    if len(manifest.metric_ids) != manifest.planned_cumulative_max:
        raise ValueError(
            f"{manifest.batch_id}: cumulative metric count "
            f"{len(manifest.metric_ids)} != planned "
            f"{manifest.planned_cumulative_max}"
        )
    if not set(manifest.added_metric_ids).issubset(manifest.metric_ids):
        raise ValueError("added metrics must be in the cumulative allowlist")

    config = load_config(manifest.base_config)
    registry = SchemaRegistry(config.node_schema_path)
    schema_metrics = set(registry.by_metric)
    if len(schema_metrics) != manifest.denominator:
        raise ValueError(
            f"batch denominator {manifest.denominator} != schema metrics "
            f"{len(schema_metrics)}"
        )
    unknown = sorted(set(manifest.metric_ids) - schema_metrics)
    if unknown:
        raise ValueError(f"batch contains unknown metrics: {unknown}")
    unknown_collectors = sorted(
        set(manifest.enabled_collectors) - set(config.collectors)
    )
    if unknown_collectors:
        raise ValueError(
            f"batch contains unknown collectors: {unknown_collectors}"
        )
    return manifest


def _previous_validated_metric_ids(manifest: BatchManifest) -> list[str]:
    if manifest.previous_batch_id is None or manifest.manifest_path is None:
        return []
    previous_path = (
        manifest.manifest_path.parent
        / f"{manifest.previous_batch_id.lower()}.yaml"
    )
    previous = load_batch_manifest(previous_path)
    if manifest.previous_promotion is None:
        return previous.metric_ids
    if not manifest.previous_promotion.is_file():
        raise FileNotFoundError(
            f"previous promotion is missing: {manifest.previous_promotion}"
        )
    promotion = json.loads(
        manifest.previous_promotion.read_text(encoding="utf-8")
    )
    if promotion.get("batch_id") != manifest.previous_batch_id:
        raise ValueError("previous promotion batch_id does not match")
    if promotion.get("batch_version") != previous.batch_version:
        raise ValueError("previous promotion batch_version does not match")
    if int(promotion.get("denominator", -1)) != manifest.denominator:
        raise ValueError("previous promotion denominator does not match")
    validated = list(promotion.get("validated_metric_ids", []))
    if len(validated) != len(set(validated)):
        raise ValueError("previous promotion validated metrics contain duplicates")
    if len(validated) != int(promotion.get("validated_metric_count", -1)):
        raise ValueError("previous promotion validated count does not match")
    outside_allowlist = sorted(set(validated) - set(previous.metric_ids))
    if outside_allowlist:
        raise ValueError(
            "previous promotion contains metrics outside its allowlist: "
            f"{outside_allowlist}"
        )
    return validated


def load_batch_roadmap(directory: Path | str) -> list[BatchManifest]:
    root = Path(directory).expanduser().resolve()
    manifests = [
        load_batch_manifest(path)
        for path in sorted(root.glob("b[0-9][0-9].yaml"))
    ]
    if not manifests:
        raise ValueError(f"no batch manifests found in {root}")
    validate_batch_chain(manifests)
    return manifests


def validate_batch_chain(manifests: list[BatchManifest]) -> None:
    ids = [manifest.batch_id for manifest in manifests]
    if len(ids) != len(set(ids)):
        raise ValueError("batch roadmap contains duplicate batch IDs")
    by_id = {manifest.batch_id: manifest for manifest in manifests}
    for index, manifest in enumerate(manifests):
        expected_id = f"B{index:02d}"
        if manifest.batch_id != expected_id:
            raise ValueError(
                f"batch roadmap expected {expected_id}, got {manifest.batch_id}"
            )
        if index == 0:
            continue
        previous = manifests[index - 1]
        if manifest.previous_batch_id != previous.batch_id:
            raise ValueError(
                f"{manifest.batch_id} must inherit {previous.batch_id}"
            )
        missing = sorted(set(previous.metric_ids) - set(manifest.metric_ids))
        if missing:
            raise ValueError(
                f"{manifest.batch_id} drops prior metrics: {missing}"
            )
        if manifest.planned_cumulative_max < previous.planned_cumulative_max:
            raise ValueError(f"{manifest.batch_id} decreases planned count")
    unresolved = [
        manifest.previous_batch_id
        for manifest in manifests
        if manifest.previous_batch_id and manifest.previous_batch_id not in by_id
    ]
    if unresolved:
        raise ValueError(f"unknown previous batches: {sorted(set(unresolved))}")


def apply_batch_manifest(manifest: BatchManifest) -> PilotConfig:
    config = load_config(manifest.base_config)
    previous_metric_ids = _previous_validated_metric_ids(manifest)
    for collector_name, collector_config in config.collectors.items():
        collector_config.enabled = collector_name in manifest.enabled_collectors
    config.workload.enabled = manifest.workload_enabled
    config.campaign_id = f"{config.campaign_id}-{manifest.batch_id.lower()}"
    config.batch = BatchRuntimeConfig(
        enabled=True,
        batch_id=manifest.batch_id,
        batch_version=manifest.batch_version,
        risk_level=manifest.risk_level,
        state=manifest.state,
        platform_family=manifest.platform_family,
        denominator=manifest.denominator,
        planned_cumulative_max=manifest.planned_cumulative_max,
        metric_selection="allowlist",
        selected_metric_ids=manifest.metric_ids,
        previous_batch_id=manifest.previous_batch_id,
        previous_metric_ids=previous_metric_ids,
        manifest_path=manifest.manifest_path,
        injection_profile=manifest.injection_profile,
    )
    return config


def batch_plan_payload(manifest: BatchManifest) -> dict[str, Any]:
    return {
        "batch_id": manifest.batch_id,
        "batch_version": manifest.batch_version,
        "state": manifest.state,
        "risk_level": manifest.risk_level,
        "denominator": manifest.denominator,
        "planned_cumulative_max": manifest.planned_cumulative_max,
        "metric_ids": manifest.metric_ids,
        "added_metric_ids": manifest.added_metric_ids,
        "previous_promotion": (
            str(manifest.previous_promotion)
            if manifest.previous_promotion is not None
            else None
        ),
        "enabled_collectors": manifest.enabled_collectors,
        "workload_enabled": manifest.workload_enabled,
        "injection_profile": manifest.injection_profile,
        "pending_script_name": manifest.pending_script_name,
        "manifest_path": str(manifest.manifest_path),
        "manifest_sha256": (
            sha256_file(manifest.manifest_path)
            if manifest.manifest_path is not None
            else None
        ),
        "base_config": str(manifest.base_config),
    }


def batch_plan_json(manifest: BatchManifest) -> str:
    return json.dumps(
        batch_plan_payload(manifest),
        ensure_ascii=False,
        indent=2,
        sort_keys=True,
    )
