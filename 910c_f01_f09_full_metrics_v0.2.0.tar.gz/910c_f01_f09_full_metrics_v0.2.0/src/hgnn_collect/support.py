from __future__ import annotations

import os
from collections import Counter
from pathlib import Path
from typing import Any, Mapping

from hgnn_collect.config import PilotConfig
from hgnn_collect.metric_policy import (
    load_metric_support_policy,
    resolve_metric_policy,
)
from hgnn_collect.processing.schema import SchemaRegistry
from hgnn_collect.utils import atomic_write_json


PLACEHOLDER_DESCRIPTIONS = {
    "site.bmc.endpoint": "BMC Redfish 地址",
    "site.bmc.ca_bundle": "BMC CA 证书路径",
    "site.bmc.sensor_map_path": "BMC 传感器到实体的映射",
    "site.bmc.local_ipmi_helper": "root-owned 只读 IPMI helper",
    "site.switch_telemetry.endpoint": "交换机只读遥测地址",
    "site.switch_telemetry.ca_bundle": "交换机 CA 证书路径",
    "site.switch_telemetry.port_map_path": "NIC/RDMA 到交换机端口映射",
    "site.ptp.domain": "PTP domain",
    "site.ptp.grandmaster_identity": "PTP Grandmaster identity",
    "site.ptp.status_path": "ptp4l/pmc 状态导出路径",
    "site.ptp.phc_device": "目标机 PHC 设备，例如 /dev/ptp0",
    "site.privileged_helpers.perf_socket": "perf/uncore 只读 exporter socket",
    "site.privileged_helpers.ras_socket": "EDAC/RAS 事件 exporter socket",
    "site.privileged_helpers.ethtool_eeprom_helper": "光模块 EEPROM 只读 helper",
    "site.privileged_helpers.pcie_config_helper": "PCIe 配置空间只读 helper",
    "site.privileged_helpers.journal_helper": "过滤后的 kernel journal helper",
    "site.training.event_socket": "训练 rank/step/loss/heartbeat 事件 socket",
    "site.training.rank_map_path": "rank 到 host/NPU 映射文件",
    "site.training.launch_command_ref": "训练启动命令或作业模板引用",
    "site.profiler.output_root": "msprof 专用输出目录",
    "site.vendor_api.dcmi_library": "目标机 libdcmi.so 路径",
    "site.vendor_api.metric_plugin": "厂商扩展指标插件路径",
    "site.vendor_api.capability_statement_ref": "厂商能力说明或工单引用",
}
PATH_PLACEHOLDERS = {
    path
    for path in PLACEHOLDER_DESCRIPTIONS
    if path.endswith(("_path", "_root", "_socket", "_helper"))
    or path.endswith((".ca_bundle", ".phc_device", ".dcmi_library", ".metric_plugin"))
}


def _nested_value(payload: Mapping[str, Any], dotted_path: str) -> Any:
    value: Any = payload
    for part in dotted_path.split("."):
        if not isinstance(value, Mapping):
            return None
        value = value.get(part)
    return value


def _site_placeholder_report(config: PilotConfig) -> dict[str, Any]:
    site_payload = {"site": config.site.model_dump(mode="json")}
    placeholders: list[dict[str, Any]] = []
    for path, description in PLACEHOLDER_DESCRIPTIONS.items():
        value = _nested_value(site_payload, path)
        section = ".".join(path.split(".")[:2])
        required_now = False
        if section == "site.bmc" and config.site.bmc.enabled:
            required_now = path == "site.bmc.sensor_map_path"
            if config.site.bmc.protocol == "redfish":
                required_now = required_now or path in {
                    "site.bmc.endpoint",
                    "site.bmc.ca_bundle",
                }
            if config.site.bmc.protocol == "ipmi_local":
                required_now = required_now or path == "site.bmc.local_ipmi_helper"
        elif section == "site.switch_telemetry":
            required_now = config.site.switch_telemetry.enabled
        elif section == "site.ptp":
            required_now = config.site.ptp.enabled
        elif section == "site.training":
            required_now = config.site.training.enabled
        elif section == "site.profiler":
            required_now = config.site.profiler.enabled
        configured = value not in {None, ""}
        item: dict[str, Any] = {
            "path": path,
            "description": description,
            "configured": configured,
            "required_now": required_now,
        }
        if configured and path in PATH_PLACEHOLDERS:
            item["exists"] = Path(str(value)).expanduser().exists()
        placeholders.append(item)

    credential_environment = []
    for purpose, variable in (
        ("BMC username", config.site.bmc.username_env),
        ("BMC password", config.site.bmc.password_env),
        ("switch username", config.site.switch_telemetry.username_env),
        ("switch password", config.site.switch_telemetry.password_env),
        ("switch token", config.site.switch_telemetry.token_env),
    ):
        credential_environment.append(
            {
                "purpose": purpose,
                "environment_variable": variable,
                "present": bool(variable and os.environ.get(variable)),
            }
        )

    blockers = [
        item["path"]
        for item in placeholders
        if item["required_now"] and not item["configured"]
    ]
    if config.site.bmc.enabled and config.site.bmc.protocol == "redfish":
        blockers.extend(
            item["environment_variable"]
            for item in credential_environment[:2]
            if not item["present"]
        )
    if config.site.switch_telemetry.enabled:
        switch_credentials = credential_environment[2:]
        if not any(item["present"] for item in switch_credentials):
            blockers.append(
                "one of HGNN_SWITCH_TOKEN or HGNN_SWITCH_USERNAME/PASSWORD"
            )
    return {
        "ready_for_enabled_sources": not blockers,
        "blocking_placeholders": sorted(set(blockers)),
        "placeholders": placeholders,
        "credential_environment": credential_environment,
    }


def load_metric_support(config: PilotConfig) -> dict[str, Any]:
    path = config.compatibility.metric_support_path
    payload = load_metric_support_policy(path)
    registry = SchemaRegistry(config.node_schema_path)
    unknown = sorted(set(payload["metrics"]) - set(registry.by_metric))
    if unknown:
        raise ValueError(f"metric support policy contains unknown metrics: {unknown}")
    return payload


def build_readiness_report(config: PilotConfig) -> dict[str, Any]:
    policy = load_metric_support(config)
    registry = SchemaRegistry(config.node_schema_path)
    current = config.compatibility.current_platform
    target = config.compatibility.target_platform
    metric_entries: list[dict[str, Any]] = []
    for metric_id, spec in sorted(registry.by_metric.items()):
        override = policy["metrics"].get(metric_id, {})
        current_policy = resolve_metric_policy(policy, metric_id, current)
        target_policy = resolve_metric_policy(policy, metric_id, target)
        metric_entries.append(
            {
                "metric_id": metric_id,
                "node_type": spec.node_type,
                "required_capability": spec.required_capability,
                "current": current_policy,
                "target": target_policy,
                "solution": override.get("solution"),
            }
        )

    current_actions = Counter(item["current"]["action"] for item in metric_entries)
    target_actions = Counter(item["target"]["action"] for item in metric_entries)
    current_skips = [
        item
        for item in metric_entries
        if item["current"]["action"] == "skip_current"
    ]
    target_attention = [
        item
        for item in metric_entries
        if item["target"]["action"] != "probe_then_collect"
    ]
    target_redesign = [
        item
        for item in target_attention
        if item["target"]["action"] == "redesign_or_vendor_api"
    ]
    target_uncertified = [
        item for item in metric_entries if item["target"]["status"] != "available"
    ]
    site_report = _site_placeholder_report(config)
    return {
        "policy_version": policy.get("policy_version"),
        "schema_metric_count": len(metric_entries),
        "current_platform": current,
        "target_platform": target,
        "allow_current_platform_skips": (
            config.compatibility.allow_current_platform_skips
        ),
        "require_target_reprobe": config.compatibility.require_target_reprobe,
        "current_action_counts": dict(sorted(current_actions.items())),
        "target_action_counts": dict(sorted(target_actions.items())),
        "current_skipped_metrics": current_skips,
        "target_attention_metrics": target_attention,
        "target_redesign_or_vendor_api_metrics": target_redesign,
        "target_uncertified_metrics": target_uncertified,
        "target_certification_ready": (
            not target_uncertified and site_report["ready_for_enabled_sources"]
        ),
        "site": site_report,
    }


def write_readiness_report(config: PilotConfig, output_path: Path) -> dict[str, Any]:
    report = build_readiness_report(config)
    atomic_write_json(output_path, report)
    return report
