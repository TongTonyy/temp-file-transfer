from __future__ import annotations

import argparse
import json
import os
import re
import subprocess
import time
from dataclasses import asdict, dataclass
from typing import Any


APPROVAL_TOKEN = "I_ACKNOWLEDGE_ISOLATED_NETNS_ONLY"
SAFE_NAME = re.compile(r"^[A-Za-z0-9_.-]+$")


@dataclass(frozen=True)
class NetnsInjectionPlan:
    namespace: str
    interface: str
    mode: str = "delay"
    duration_s: float = 5.0
    delay_us: int = 100
    jitter_us: int = 20
    loss_pct: float = 0.01

    def validate(self) -> None:
        if not self.namespace.startswith("hgnn-f04-"):
            raise ValueError("namespace must start with hgnn-f04-")
        if not SAFE_NAME.fullmatch(self.namespace) or not SAFE_NAME.fullmatch(
            self.interface
        ):
            raise ValueError("namespace/interface contains unsafe characters")
        if self.mode not in {"delay", "loss"}:
            raise ValueError("mode must be delay or loss")
        if not 0 < self.duration_s <= 5:
            raise ValueError("duration must be in (0, 5] seconds")
        if not 0 < self.delay_us <= 1_000:
            raise ValueError("delay_us must be in (0, 1000]")
        if not 0 <= self.jitter_us <= 500:
            raise ValueError("jitter_us must be in [0, 500]")
        if self.jitter_us > self.delay_us:
            raise ValueError("jitter_us cannot exceed delay_us")
        if not 0 < self.loss_pct <= 0.01:
            raise ValueError("loss_pct must be in (0, 0.01]")

    def apply_command(self) -> list[str]:
        self.validate()
        netem = (
            ["delay", f"{self.delay_us}us", f"{self.jitter_us}us"]
            if self.mode == "delay"
            else ["loss", f"{self.loss_pct:.6g}%"]
        )
        return [
            "ip",
            "netns",
            "exec",
            self.namespace,
            "tc",
            "qdisc",
            "replace",
            "dev",
            self.interface,
            "root",
            "netem",
            *netem,
        ]

    def cleanup_command(self) -> list[str]:
        self.validate()
        return [
            "ip",
            "netns",
            "exec",
            self.namespace,
            "tc",
            "qdisc",
            "del",
            "dev",
            self.interface,
            "root",
        ]


def plan_payload(plan: NetnsInjectionPlan) -> dict[str, Any]:
    plan.validate()
    return {
        "injection_id": "I01",
        "fault_code": "F04",
        "scope": "isolated_network_namespace_only",
        "dry_run_default": True,
        "plan": asdict(plan),
        "apply_command": plan.apply_command(),
        "cleanup_command": plan.cleanup_command(),
    }


def _run(argv: list[str], *, check: bool = True) -> subprocess.CompletedProcess[str]:
    return subprocess.run(
        argv,
        check=check,
        capture_output=True,
        text=True,
        timeout=10,
    )


def _preflight(plan: NetnsInjectionPlan) -> None:
    namespaces = _run(["ip", "netns", "list"]).stdout.splitlines()
    if not any(line.split()[0] == plan.namespace for line in namespaces if line):
        raise RuntimeError(f"network namespace not found: {plan.namespace}")
    _run(
        [
            "ip",
            "netns",
            "exec",
            plan.namespace,
            "ip",
            "link",
            "show",
            "dev",
            plan.interface,
        ]
    )
    qdisc = _run(
        [
            "ip",
            "netns",
            "exec",
            plan.namespace,
            "tc",
            "-j",
            "qdisc",
            "show",
            "dev",
            plan.interface,
        ]
    )
    entries = json.loads(qdisc.stdout or "[]")
    disallowed = [
        entry.get("kind")
        for entry in entries
        if entry.get("kind") not in {None, "noqueue"}
    ]
    if disallowed:
        raise RuntimeError(
            f"refusing to replace existing qdisc kinds: {sorted(set(disallowed))}"
        )


def _cleanup(plan: NetnsInjectionPlan) -> None:
    _run(plan.cleanup_command(), check=False)


def _start_external_watchdog(plan: NetnsInjectionPlan) -> int:
    pid = os.fork()
    if pid == 0:
        try:
            os.setsid()
            time.sleep(plan.duration_s + 1)
            _cleanup(plan)
        finally:
            os._exit(0)
    return pid


def execute(plan: NetnsInjectionPlan) -> dict[str, Any]:
    plan.validate()
    if os.geteuid() != 0:
        raise PermissionError("execution requires root; dry-run does not")
    if os.environ.get("HGNN_INJECTION_APPROVAL") != APPROVAL_TOKEN:
        raise PermissionError(
            "HGNN_INJECTION_APPROVAL does not contain the isolated-netns token"
        )
    _preflight(plan)
    watchdog_pid = _start_external_watchdog(plan)
    started_ns = time.time_ns()
    try:
        _run(plan.apply_command())
        time.sleep(plan.duration_s)
    finally:
        _cleanup(plan)
        try:
            os.waitpid(watchdog_pid, 0)
        except ChildProcessError:
            pass
    return {
        **plan_payload(plan),
        "executed": True,
        "started_at_utc_ns": started_ns,
        "completed_at_utc_ns": time.time_ns(),
        "rollback_attempted": True,
    }


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="F04 I01 isolated-network-namespace netem test"
    )
    parser.add_argument("--namespace", required=True)
    parser.add_argument("--interface", required=True)
    parser.add_argument("--mode", choices=("delay", "loss"), default="delay")
    parser.add_argument("--duration", type=float, default=5.0)
    parser.add_argument("--delay-us", type=int, default=100)
    parser.add_argument("--jitter-us", type=int, default=20)
    parser.add_argument("--loss-pct", type=float, default=0.01)
    parser.add_argument(
        "--execute",
        action="store_true",
        help="execute after root/token/preflight checks; default is dry-run",
    )
    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    plan = NetnsInjectionPlan(
        namespace=args.namespace,
        interface=args.interface,
        mode=args.mode,
        duration_s=args.duration,
        delay_us=args.delay_us,
        jitter_us=args.jitter_us,
        loss_pct=args.loss_pct,
    )
    payload = execute(plan) if args.execute else plan_payload(plan)
    print(json.dumps(payload, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
