from __future__ import annotations

try:
    from enum import StrEnum
except ImportError:  # Python 3.9/3.10 compatibility on Ascend hosts.
    from enum import Enum

    class StrEnum(str, Enum):
        def __str__(self) -> str:
            return str(self.value)
from typing import Any

from pydantic import BaseModel, ConfigDict, Field, model_validator


class MetricKind(StrEnum):
    GAUGE = "gauge"
    COUNTER = "counter"
    EVENT = "event"
    DURATION = "duration"
    HISTOGRAM = "histogram"
    CATEGORICAL = "categorical"
    BITSET = "bitset"


class ObservationStatus(StrEnum):
    OK = "ok"
    MISSING = "missing"
    UNSUPPORTED = "unsupported"
    SOURCE_ERROR = "source_error"
    INVALID = "invalid"
    STALE = "stale"


class ClockQuality(StrEnum):
    PTP_LOCKED = "ptp_locked"
    NTP_SYNCED = "ntp_synced"
    HOLDOVER = "holdover"
    UNSYNCED = "unsynced"
    UNKNOWN = "unknown"


class Observation(BaseModel):
    model_config = ConfigDict(extra="forbid", validate_assignment=True)

    record_type: str = "observation"
    schema_version: str
    run_id: str
    collector_id: str
    seq: int = Field(ge=0)
    ts_utc_ns: int = Field(ge=0)
    ts_mono_ns: int = Field(ge=0)
    clock_quality: ClockQuality = ClockQuality.UNKNOWN
    host_id: str
    node_type: str
    node_id: str
    metric_id: str
    metric_kind: MetricKind
    value_f64: float | None = None
    value_i64: int | None = None
    value_str: str | None = None
    value_bool: bool | None = None
    unit: str = ""
    observed: bool = True
    status: ObservationStatus = ObservationStatus.OK
    quality_flags: list[str] = Field(default_factory=list)
    source_latency_us: int = Field(default=0, ge=0)
    scheduled_lag_us: int = Field(default=0, ge=0)
    sample_interval_us: int | None = Field(default=None, ge=0)
    source_ts_ns: int | None = Field(default=None, ge=0)
    raw_ref: str | None = None
    attributes: dict[str, Any] = Field(default_factory=dict)

    @model_validator(mode="after")
    def check_value(self) -> "Observation":
        values = (
            self.value_f64,
            self.value_i64,
            self.value_str,
            self.value_bool,
        )
        populated = sum(value is not None for value in values)
        if self.observed and self.status == ObservationStatus.OK and populated != 1:
            raise ValueError("an observed OK record must contain exactly one value")
        if not self.observed and populated:
            raise ValueError("an unobserved record cannot contain a value")
        return self

    @property
    def value(self) -> float | int | str | bool | None:
        for candidate in (
            self.value_f64,
            self.value_i64,
            self.value_str,
            self.value_bool,
        ):
            if candidate is not None:
                return candidate
        return None


class EventRecord(BaseModel):
    model_config = ConfigDict(extra="forbid")

    record_type: str = "event"
    schema_version: str
    event_id: str
    run_id: str
    collector_id: str
    seq: int = Field(ge=0)
    ts_utc_ns: int = Field(ge=0)
    ts_mono_ns: int = Field(ge=0)
    clock_quality: ClockQuality = ClockQuality.UNKNOWN
    host_id: str
    event_type: str
    phase: str
    severity: str = "info"
    entity_ids: list[str] = Field(default_factory=list)
    correlation_id: str | None = None
    payload: dict[str, Any] = Field(default_factory=dict)


class CapabilityEntry(BaseModel):
    model_config = ConfigDict(extra="forbid")

    name: str
    status: str
    source: str
    detail: str = ""
    evidence: dict[str, Any] = Field(default_factory=dict)


class NodeRecord(BaseModel):
    model_config = ConfigDict(extra="allow")

    node_id: str
    node_type: str
    host_id: str
    hardware_instance_id: str
    attributes: dict[str, Any] = Field(default_factory=dict)


class EdgeRecord(BaseModel):
    model_config = ConfigDict(extra="allow")

    edge_id: str
    source_type: str
    relation: str
    target_type: str
    source_id: str
    target_id: str
    topology: str
    evidence: str
    confidence: float = Field(ge=0, le=1)
    attributes: dict[str, Any] = Field(default_factory=dict)

