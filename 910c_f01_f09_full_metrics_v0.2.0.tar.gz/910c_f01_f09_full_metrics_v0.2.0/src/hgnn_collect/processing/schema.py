from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any

import yaml


@dataclass(frozen=True)
class FeatureSpec:
    node_type: str
    metric_id: str
    kind: str
    unit: str
    raw_hz: float
    aggregates: tuple[str, ...]
    required_capability: str
    normalize: bool
    applies_to: str
    applicability_attribute: str | None
    zero_evidence_metric: str | None


class SchemaRegistry:
    def __init__(self, path: Path):
        payload: dict[str, Any] = yaml.safe_load(path.read_text(encoding="utf-8"))
        self.schema_version = str(payload["schema_version"])
        self.by_node_type: dict[str, list[FeatureSpec]] = {}
        self.by_metric: dict[str, FeatureSpec] = {}
        for node_type, node_payload in payload["node_types"].items():
            features: list[FeatureSpec] = []
            for item in node_payload.get("features", []):
                spec = FeatureSpec(
                    node_type=node_type,
                    metric_id=item["id"],
                    kind=item["kind"],
                    unit=str(item.get("unit", "")),
                    raw_hz=float(item.get("raw_hz", 0)),
                    aggregates=tuple(item.get("aggregates", ["last"])),
                    required_capability=item.get("required_capability", ""),
                    normalize=bool(item.get("normalize", False)),
                    applies_to=str(item.get("applies_to", "physical")),
                    applicability_attribute=item.get(
                        "applicability_attribute"
                    ),
                    zero_evidence_metric=item.get("zero_evidence_metric"),
                )
                if spec.applies_to not in {"physical", "virtual", "all"}:
                    raise ValueError(
                        f"{spec.metric_id}: applies_to must be physical, virtual or all"
                    )
                features.append(spec)
                self.by_metric[spec.metric_id] = spec
            self.by_node_type[node_type] = features

    def features(self, node_type: str) -> list[FeatureSpec]:
        return self.by_node_type.get(node_type, [])

    def metric(self, metric_id: str) -> FeatureSpec | None:
        return self.by_metric.get(metric_id)

