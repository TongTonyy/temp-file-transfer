from __future__ import annotations

import json
import math
from pathlib import Path
from typing import Any

import numpy as np
import pyarrow.parquet as pq

from hgnn_collect.config import PilotConfig
from hgnn_collect.metric_policy import (
    load_metric_support_policy,
    resolve_metric_policy,
)
from hgnn_collect.processing.schema import SchemaRegistry
from hgnn_collect.topology.validate import validate_topology_and_priors
from hgnn_collect.utils import atomic_write_json, canonical_hash


DYNAMIC_QDISC_KEYS = {
    "bytes",
    "packets",
    "drops",
    "overlimits",
    "requeues",
    "backlog",
    "qlen",
    "stats",
    "stats2",
    "xstats",
}


def _strip_dynamic_qdisc(value: Any) -> Any:
    if isinstance(value, dict):
        if "dev" in value and "kind" in value:
            configuration_keys = {
                "dev",
                "kind",
                "handle",
                "parent",
                "root",
                "ingress_block",
                "egress_block",
                "options",
            }
            return {
                key: _strip_dynamic_qdisc(item)
                for key, item in value.items()
                if key in configuration_keys
            }
        return {
            key: _strip_dynamic_qdisc(item)
            for key, item in value.items()
            if key not in DYNAMIC_QDISC_KEYS
        }
    if isinstance(value, list):
        cleaned = [_strip_dynamic_qdisc(item) for item in value]
        return sorted(cleaned, key=lambda item: json.dumps(item, sort_keys=True))
    return value


def _percentile(values: list[float], percentile: float) -> float | None:
    if not values:
        return None
    return float(np.percentile(np.asarray(values, dtype=np.float64), percentile))


def _topology_nodes_by_type(run_dir: Path) -> dict[str, list[dict[str, Any]]]:
    payload = json.loads(
        (run_dir / "topology" / "topology.json").read_text(encoding="utf-8")
    )
    result: dict[str, list[dict[str, Any]]] = {}
    for node in payload["nodes"]:
        result.setdefault(node["node_type"], []).append(node)
    return result


def _applicable_node_ids(
    nodes: list[dict[str, Any]],
    applies_to: str,
    applicability_attribute: str | None,
) -> list[str]:
    selected: list[str] = []
    for node in nodes:
        virtual = bool(node.get("attributes", {}).get("virtual"))
        if applies_to == "physical" and virtual:
            continue
        if applies_to == "virtual" and not virtual:
            continue
        if applicability_attribute and not bool(
            node.get("attributes", {}).get(applicability_attribute)
        ):
            continue
        selected.append(node["node_id"])
    return sorted(selected)


def _check_aligned_nodes(
    config: PilotConfig,
    run_dir: Path,
    capabilities: dict[str, str],
    duration: int,
) -> tuple[list[dict[str, Any]], list[str], list[str], dict[str, Any]]:
    registry = SchemaRegistry(config.node_schema_path)
    support_policy = load_metric_support_policy(
        config.compatibility.metric_support_path
    )
    topology_nodes = _topology_nodes_by_type(run_dir)
    batch_selected = set(config.batch.selected_metric_ids)
    previous_validated = set(config.batch.previous_metric_ids)
    validated_metric_ids: set[str] = set()
    checks: list[dict[str, Any]] = []
    failures: list[str] = []
    limitations: list[str] = []
    for node_type, specs in registry.by_node_type.items():
        path = run_dir / "aligned" / "nodes" / f"{node_type}.parquet"
        if not path.is_file():
            failures.append(f"missing aligned node file: {node_type}")
            continue
        table = pq.read_table(path)
        rows = table.to_pylist()
        node_ids = sorted({row["node_id"] for row in rows})
        expected_rows = len(node_ids) * duration
        unique_pairs = {(row["node_id"], row["t_idx"]) for row in rows}
        exact_axis = (
            table.num_rows == expected_rows
            and len(unique_pairs) == expected_rows
            and all(
                {row["t_idx"] for row in rows if row["node_id"] == node_id}
                == set(range(duration))
                for node_id in node_ids
            )
        )
        checks.append(
            {
                "check": "time_axis",
                "node_type": node_type,
                "passed": exact_axis,
                "rows": table.num_rows,
                "expected_rows": expected_rows,
                "nodes": len(node_ids),
            }
        )
        if not exact_axis:
            failures.append(f"{node_type}: aligned time axis is not exact")

        columns = set(table.column_names)
        for spec in specs:
            selected_in_batch = (
                not config.batch.enabled or spec.metric_id in batch_selected
            )
            previously_validated = spec.metric_id in previous_validated
            compatibility = resolve_metric_policy(
                support_policy,
                spec.metric_id,
                config.compatibility.current_platform,
            )
            intentionally_skipped = (
                config.compatibility.allow_current_platform_skips
                and compatibility["action"] == "skip_current"
            )
            target_support_uncertified = (
                config.compatibility.require_target_reprobe
                and config.compatibility.current_platform
                == config.compatibility.target_platform
                and compatibility["status"] != "available"
            )
            if target_support_uncertified and selected_in_batch:
                message = (
                    f"{spec.metric_id}: target support is not certified "
                    f"({compatibility['status']})"
                )
                if previously_validated:
                    failures.append(message)
                else:
                    limitations.append(message)
            observed_column = f"{spec.metric_id}__observed"
            if observed_column not in columns:
                if selected_in_batch:
                    message = (
                        f"{node_type}: missing mask column {observed_column}"
                    )
                    if previously_validated:
                        failures.append(message)
                    else:
                        limitations.append(message)
                continue
            capable = capabilities.get(spec.required_capability) == "available"
            observed_by_node: dict[str, list[bool]] = {}
            for row in rows:
                observed_by_node.setdefault(row["node_id"], []).append(
                    bool(row.get(observed_column))
                )
            active_nodes = {
                node_id: values
                for node_id, values in observed_by_node.items()
                if any(values)
            }
            expected_node_ids = _applicable_node_ids(
                topology_nodes.get(node_type, []),
                spec.applies_to,
                spec.applicability_attribute,
            )
            validation_column = observed_column
            validation_raw_hz = spec.raw_hz
            validation_source = spec.metric_id
            if spec.raw_hz == 0 and spec.zero_evidence_metric:
                evidence_spec = registry.metric(spec.zero_evidence_metric)
                evidence_column = f"{spec.zero_evidence_metric}__observed"
                if evidence_spec is not None and evidence_column in columns:
                    validation_column = evidence_column
                    validation_raw_hz = evidence_spec.raw_hz
                    validation_source = spec.zero_evidence_metric
            validation_by_node: dict[str, list[bool]] = {}
            for row in rows:
                validation_by_node.setdefault(row["node_id"], []).append(
                    bool(row.get(validation_column))
                )
            if config.batch.enabled:
                coverage_by_node = {
                    node_id: (
                        sum(validation_by_node.get(node_id, []))
                        / len(validation_by_node.get(node_id, []))
                        if validation_by_node.get(node_id)
                        else 0.0
                    )
                    for node_id in expected_node_ids
                }
            else:
                coverage_by_node = {
                    node_id: sum(values) / len(values)
                    for node_id, values in validation_by_node.items()
                    if any(values)
                }
            coverage = min(coverage_by_node.values(), default=0.0)
            threshold = (
                config.quality.required_coverage
                if validation_raw_hz >= 1
                else min(
                    1.0,
                    max(
                        1 / max(1, duration),
                        validation_raw_hz,
                    ),
                )
            )
            if validation_raw_hz >= 1:
                warmup_adjusted = max(0.0, (duration - 1) / duration)
                threshold = min(threshold, warmup_adjusted)
            missing_instances = [
                node_id
                for node_id, node_coverage in coverage_by_node.items()
                if node_coverage < threshold
            ]
            metric_validated = (
                selected_in_batch
                and bool(expected_node_ids)
                and bool(coverage_by_node)
                and not missing_instances
                and not intentionally_skipped
                and not target_support_uncertified
            )
            if metric_validated:
                validated_metric_ids.add(spec.metric_id)

            if not selected_in_batch:
                limitation = "not selected in this batch"
            elif metric_validated:
                limitation = ""
            elif intentionally_skipped:
                limitation = (
                    f"intentionally skipped on "
                    f"{config.compatibility.current_platform} "
                    f"({compatibility['status']})"
                )
                limitations.append(f"{spec.metric_id}: {limitation}")
            elif not expected_node_ids:
                limitation = f"no applicable {spec.applies_to} instances"
                message = f"{spec.metric_id}: {limitation}"
                if previously_validated:
                    failures.append(message)
                else:
                    limitations.append(message)
            elif missing_instances:
                limitation = (
                    f"{len(missing_instances)}/{len(expected_node_ids)} "
                    f"applicable instances below coverage {threshold:.3f}"
                )
                if config.batch.enabled:
                    message = f"{spec.metric_id}: {limitation}"
                    if previously_validated:
                        failures.append(message)
                    else:
                        limitations.append(message)
                elif capable and spec.raw_hz >= 1:
                    failures.append(
                        f"{spec.metric_id}: coverage {coverage:.3f} "
                        f"< {threshold:.3f}"
                    )
                else:
                    limitations.append(
                        f"{spec.metric_id}: unsupported or unobserved on this host"
                    )
            else:
                limitation = "not validated"

            if not active_nodes and selected_in_batch and not config.batch.enabled:
                if intentionally_skipped:
                    limitations.append(
                        f"{spec.metric_id}: intentionally skipped on "
                        f"{config.compatibility.current_platform} "
                        f"({compatibility['status']})"
                    )
                elif capable and spec.raw_hz >= 1:
                    failures.append(
                        f"{spec.metric_id}: capability available but no observations"
                    )
                else:
                    limitations.append(
                        f"{spec.metric_id}: unsupported or unobserved on this host"
                    )
            checks.append(
                {
                    "check": "metric_coverage",
                    "node_type": node_type,
                    "metric_id": spec.metric_id,
                    "required_capability": spec.required_capability,
                    "compatibility_status": compatibility["status"],
                    "compatibility_action": compatibility["action"],
                    "intentionally_skipped": intentionally_skipped,
                    "target_support_uncertified": target_support_uncertified,
                    "selected_in_batch": selected_in_batch,
                    "validated": metric_validated,
                    "validation_source": validation_source,
                    "applies_to": spec.applies_to,
                    "applicability_attribute": spec.applicability_attribute,
                    "capability_status": capabilities.get(
                        spec.required_capability, "unknown"
                    ),
                    "active_nodes": len(active_nodes),
                    "expected_instances": len(expected_node_ids),
                    "missing_instance_ids": missing_instances,
                    "coverage_threshold": threshold,
                    "coverage_min": coverage,
                    "status_detail": limitation,
                }
            )
    regressed_metric_ids = sorted(previous_validated - validated_metric_ids)
    if regressed_metric_ids:
        failures.append(
            f"previously validated metrics regressed: {regressed_metric_ids}"
        )
    batch_validation = {
        "enabled": config.batch.enabled,
        "batch_id": config.batch.batch_id,
        "denominator": config.batch.denominator,
        "planned_cumulative_max": config.batch.planned_cumulative_max,
        "selected_metric_ids": sorted(batch_selected),
        "validated_metric_ids": sorted(validated_metric_ids),
        "validated_metric_count": len(validated_metric_ids),
        "newly_validated_metric_ids": sorted(
            validated_metric_ids - previous_validated
        ),
        "regressed_metric_ids": regressed_metric_ids,
    }
    return checks, failures, limitations, batch_validation


def _check_aligned_edges(
    run_dir: Path, duration: int
) -> tuple[list[dict[str, Any]], list[str]]:
    topology = json.loads(
        (run_dir / "topology" / "topology.json").read_text(encoding="utf-8")
    )
    node_ids = {node["node_id"] for node in topology["nodes"]}
    expected = (
        "npu__logical_sync_with__npu",
        "nic__logical_comm_with__nic",
        "global_task__executes_on__npu",
    )
    checks: list[dict[str, Any]] = []
    failures: list[str] = []
    for edge_type in expected:
        path = run_dir / "aligned" / "edges" / f"{edge_type}.parquet"
        if not path.is_file():
            failures.append(f"missing aligned edge file: {edge_type}")
            continue
        table = pq.read_table(path)
        invalid_references = 0
        invalid_time = 0
        invalid_type = 0
        for row in table.to_pylist():
            invalid_references += int(
                row["src_node_id"] not in node_ids
                or row["dst_node_id"] not in node_ids
            )
            invalid_time += int(not 0 <= row["t_idx"] < duration)
            invalid_type += int(row["edge_type"] != edge_type)
        passed = not (invalid_references or invalid_time or invalid_type)
        checks.append(
            {
                "check": "aligned_edge_integrity",
                "edge_type": edge_type,
                "passed": passed,
                "rows": table.num_rows,
                "invalid_references": invalid_references,
                "invalid_time": invalid_time,
                "invalid_type": invalid_type,
            }
        )
        if not passed:
            failures.append(f"aligned edge integrity failed: {edge_type}")
    return checks, failures


def _detect_npu_alerts(run_dir: Path) -> list[dict[str, Any]]:
    path = run_dir / "aligned" / "nodes" / "npu.parquet"
    if not path.is_file():
        return []
    columns = ["node_id", "npu.error_code", "npu.error_code__observed"]
    table = pq.read_table(path, columns=columns)
    by_node: dict[str, set[str]] = {}
    no_error_codes = {"", "0", "00000000", "NA", "N/A", "NONE"}
    for row in table.to_pylist():
        if not row["npu.error_code__observed"]:
            continue
        code = str(row["npu.error_code"] or "").upper()
        if code in no_error_codes:
            continue
        by_node.setdefault(row["node_id"], set()).add(code)
    return [
        {"node_id": node_id, "error_codes": sorted(codes)}
        for node_id, codes in sorted(by_node.items())
    ]


def evaluate_quality(
    config: PilotConfig, run_dir: Path, *, write_report: bool = True
) -> dict[str, Any]:
    manifest = json.loads((run_dir / "manifest.json").read_text(encoding="utf-8"))
    capabilities_payload = json.loads(
        (run_dir / "capabilities.json").read_text(encoding="utf-8")
    )
    capability_status = capabilities_payload.get("capability_status", {})
    failures: list[str] = []
    limitations: list[str] = []
    warnings: list[str] = []
    checks: list[dict[str, Any]] = []

    topology_quality = validate_topology_and_priors(run_dir)
    checks.append(
        {
            "check": "topology_and_priors",
            "passed": topology_quality["passed"],
            "node_count": topology_quality["node_count"],
            "edge_count": topology_quality["edge_count"],
            "allowed_edge_count": topology_quality["allowed_edge_count"],
        }
    )
    failures.extend(topology_quality["errors"])

    node_checks, node_failures, node_limitations, batch_validation = (
        _check_aligned_nodes(
            config,
            run_dir,
            capability_status,
            int(manifest["duration_s"]),
        )
    )
    checks.extend(node_checks)
    failures.extend(node_failures)
    limitations.extend(node_limitations)
    edge_checks, edge_failures = _check_aligned_edges(
        run_dir, int(manifest["duration_s"])
    )
    checks.extend(edge_checks)
    failures.extend(edge_failures)
    npu_alerts = _detect_npu_alerts(run_dir)
    selected_nodes = {
        f"{config.resolved_host_id}/npu/{device_id}"
        for device_id in config.workload.npu_ids
    }
    if npu_alerts:
        warnings.append(
            "pre-existing NPU alerts observed: "
            + ", ".join(
                f"{item['node_id']}={item['error_codes']}" for item in npu_alerts
            )
        )
    selected_alerts = [
        item for item in npu_alerts if item["node_id"] in selected_nodes
    ]
    if config.workload.enabled and selected_alerts:
        failures.append("workload used an NPU with a non-zero error code")

    before = _strip_dynamic_qdisc(manifest.get("qdisc_before"))
    after = _strip_dynamic_qdisc(manifest.get("qdisc_after"))
    qdisc_unchanged = canonical_hash(before) == canonical_hash(after)
    checks.append(
        {
            "check": "qdisc_configuration_unchanged",
            "passed": qdisc_unchanged,
            "before_hash": canonical_hash(before),
            "after_hash": canonical_hash(after),
        }
    )
    if config.quality.fail_on_qdisc_change and not qdisc_unchanged:
        failures.append("qdisc configuration changed during passive run")

    collector_quality: dict[str, Any] = {}
    for collector_id, summary in manifest.get("collector_summary", {}).items():
        lags = [float(value) / 1000 for value in summary.get("schedule_lag_us", [])]
        durations = [
            float(value) / 1000
            for value in summary.get("collection_duration_us", [])
        ]
        lag_p95 = _percentile(lags, 95)
        duration_p95 = _percentile(durations, 95)
        interval_s = float(summary.get("interval_s", 1))
        threshold = (
            config.quality.fast_schedule_lag_p95_ms
            if interval_s < 1
            else config.quality.slow_schedule_lag_p95_ms
        )
        collector_quality[collector_id] = {
            "attempts": summary.get("attempts", 0),
            "successful_samples": summary.get("successful_samples", 0),
            "records": summary.get("records", 0),
            "errors": summary.get("errors", 0),
            "skipped_deadlines": summary.get("skipped_deadlines", 0),
            "schedule_lag_p50_ms": _percentile(lags, 50),
            "schedule_lag_p95_ms": lag_p95,
            "schedule_lag_max_ms": max(lags) if lags else None,
            "collection_duration_p95_ms": duration_p95,
            "threshold_ms": threshold,
        }
        if summary.get("attempts", 0) == 0:
            failures.append(f"collector {collector_id} made no attempts")
        if summary.get("critical") and summary.get("errors", 0):
            failures.append(
                f"critical collector {collector_id} had {summary['errors']} errors"
            )
        if lag_p95 is not None and lag_p95 > threshold:
            warnings.append(
                f"collector {collector_id} schedule lag p95 {lag_p95:.2f}ms "
                f"exceeds {threshold:.2f}ms"
            )

    temporary_files = [
        str(path.relative_to(run_dir))
        for path in run_dir.rglob("*.tmp")
        if path.is_file()
    ]
    if temporary_files:
        failures.append(f"temporary files remain: {temporary_files}")

    labels = json.loads((run_dir / "labels.json").read_text(encoding="utf-8"))
    passive_label_valid = (
        labels.get("injection_mode") == "passive"
        and labels.get("fault_type") == [0.0] * 9
        and labels.get("severity_level") == 0
    )
    checks.append(
        {
            "check": "passive_label",
            "passed": passive_label_valid,
        }
    )
    if not passive_label_valid:
        failures.append("passive run label is not all-zero/no-fault")

    workload = manifest.get("workload_summary", {})
    if config.workload.enabled:
        if not workload.get("precheck", {}).get("ok"):
            limitations.append("HCCL workload precheck failed or binary unavailable")
        if workload.get("verification_failures", 0):
            failures.append("HCCL workload reported verification failures")
        if workload.get("successful_invocations", 0) == 0:
            limitations.append("no successful HCCL workload invocation")
        if workload.get("safety_stopped"):
            warnings.append("HCCL workload stopped by the runtime safety gate")

    unsupported = sorted(
        name for name, status in capability_status.items() if status != "available"
    )
    limitations.extend(f"capability {name}: {capability_status[name]}" for name in unsupported)

    status = "failed" if failures else "passed_with_limitations" if limitations else "passed"
    report = {
        "schema_version": config.schema_version,
        "run_id": manifest["run_id"],
        "status": status,
        "passed": not failures,
        "failures": sorted(set(failures)),
        "warnings": sorted(set(warnings)),
        "limitations": sorted(set(limitations)),
        "checks": checks,
        "topology": topology_quality,
        "npu_alerts": npu_alerts,
        "collectors": collector_quality,
        "capability_status": capability_status,
        "batch_validation": batch_validation,
        "temporary_files": temporary_files,
    }
    if write_report:
        atomic_write_json(run_dir / "quality_report.json", report)
    return report

