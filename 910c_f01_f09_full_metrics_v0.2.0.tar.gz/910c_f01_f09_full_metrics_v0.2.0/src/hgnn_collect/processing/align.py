from __future__ import annotations

import json
import math
from collections import defaultdict
from pathlib import Path
from statistics import fmean, pstdev
from typing import Any

import numpy as np
import pyarrow as pa
import pyarrow.parquet as pq

from hgnn_collect.config import PilotConfig
from hgnn_collect.models import MetricKind, Observation, ObservationStatus
from hgnn_collect.processing.schema import FeatureSpec, SchemaRegistry
from hgnn_collect.storage.parquet import write_pylist
from hgnn_collect.storage.raw import iter_run_events, iter_run_observations
from hgnn_collect.utils import atomic_write_json


QUALITY_BITS = {
    "MISSING": 1 << 0,
    "STALE": 1 << 1,
    "OUT_OF_RANGE": 1 << 2,
    "COUNTER_RESET": 1 << 3,
    "CLOCK_DEGRADED": 1 << 4,
    "SOURCE_ERROR": 1 << 5,
    "UNSUPPORTED": 1 << 6,
    "SCHEDULE_LATE": 1 << 7,
    "WARMUP_COUNTER": 1 << 8,
    "INVALID": 1 << 9,
}


def quality_mask(flags: list[str], status: str) -> int:
    result = 0
    for flag in flags:
        result |= QUALITY_BITS.get(flag, 0)
    result |= QUALITY_BITS.get(status.upper(), 0)
    return result


def _percentile(values: list[float], percentile: float) -> float:
    return float(np.percentile(np.asarray(values, dtype=np.float64), percentile))


def _aggregate_numeric(values: list[float], aggregates: tuple[str, ...]) -> dict[str, float]:
    if not values:
        return {}
    result: dict[str, float] = {}
    for aggregate in aggregates:
        if aggregate == "mean":
            result[aggregate] = float(fmean(values))
        elif aggregate == "max":
            result[aggregate] = float(max(values))
        elif aggregate == "min":
            result[aggregate] = float(min(values))
        elif aggregate == "std":
            result[aggregate] = float(pstdev(values)) if len(values) > 1 else 0.0
        elif aggregate == "p95":
            result[aggregate] = _percentile(values, 95)
        elif aggregate == "p50":
            result[aggregate] = _percentile(values, 50)
        elif aggregate == "last":
            result[aggregate] = float(values[-1])
        elif aggregate == "count":
            result[aggregate] = float(len(values))
    return result


def _base_aggregate(spec: FeatureSpec, aggregated: dict[str, Any]) -> Any:
    for preferred in ("mean", "last", "rate", "count", "min", "max", "p50"):
        if preferred in aggregated:
            return aggregated[preferred]
    return next(iter(aggregated.values()), None)


def _node_arrow_schema(specs: list[FeatureSpec]) -> pa.Schema:
    fields = [
        pa.field("dataset_version", pa.string(), nullable=False),
        pa.field("schema_version", pa.string(), nullable=False),
        pa.field("campaign_id", pa.string(), nullable=False),
        pa.field("run_id", pa.string(), nullable=False),
        pa.field("topology_id", pa.string(), nullable=False),
        pa.field("t_idx", pa.int32(), nullable=False),
        pa.field("ts_bucket_start_utc_ns", pa.int64(), nullable=False),
        pa.field("node_id", pa.string(), nullable=False),
    ]
    for spec in specs:
        if spec.kind == "categorical":
            value_type: pa.DataType = pa.string()
        elif spec.kind == "bitset":
            value_type = pa.int64()
        else:
            value_type = pa.float64()
        fields.append(pa.field(spec.metric_id, value_type))
        if spec.kind == "counter":
            fields.extend(
                [
                    pa.field(f"{spec.metric_id}__delta", pa.float64()),
                    pa.field(f"{spec.metric_id}__rate", pa.float64()),
                ]
            )
        elif spec.kind in {"categorical", "bitset"}:
            fields.append(pa.field(f"{spec.metric_id}__changes", pa.int64()))
        else:
            fields.extend(
                pa.field(f"{spec.metric_id}__{aggregate}", pa.float64())
                for aggregate in spec.aggregates
            )
        fields.extend(
            [
                pa.field(f"{spec.metric_id}__observed", pa.bool_(), nullable=False),
                pa.field(f"{spec.metric_id}__quality", pa.uint16(), nullable=False),
            ]
        )
    return pa.schema(fields)


def _load_topology_nodes(run_dir: Path) -> dict[str, list[str]]:
    topology = json.loads(
        (run_dir / "topology" / "topology.json").read_text(encoding="utf-8")
    )
    result: dict[str, list[str]] = defaultdict(list)
    for node in topology["nodes"]:
        result[node["node_type"]].append(node["node_id"])
    return {key: sorted(set(values)) for key, values in result.items()}


def _bucket_index(record: dict[str, Any], start_mono_ns: int, duration_s: int) -> int | None:
    index = (int(record["ts_mono_ns"]) - start_mono_ns) // 1_000_000_000
    return int(index) if 0 <= index < duration_s else None


def _edge_arrow_schema(edge_type: str) -> pa.Schema:
    fields = [
        pa.field("dataset_version", pa.string(), nullable=False),
        pa.field("schema_version", pa.string(), nullable=False),
        pa.field("campaign_id", pa.string(), nullable=False),
        pa.field("run_id", pa.string(), nullable=False),
        pa.field("t_idx", pa.int32(), nullable=False),
        pa.field("edge_type", pa.string(), nullable=False),
        pa.field("src_node_id", pa.string(), nullable=False),
        pa.field("dst_node_id", pa.string(), nullable=False),
        pa.field("edge_active", pa.bool_(), nullable=False),
        pa.field("observation_kind", pa.string(), nullable=False),
        pa.field("edge_attr_observed", pa.bool_(), nullable=False),
        pa.field("mask", pa.uint16(), nullable=False),
    ]
    attributes: dict[str, list[tuple[str, pa.DataType]]] = {
        "npu__logical_sync_with__npu": [
            ("edge.collective_duration_ms", pa.float64()),
            ("edge.collective_bytes", pa.float64()),
            ("edge.collective_bandwidth_gbs", pa.float64()),
            ("edge.wait_ratio", pa.float64()),
            ("edge.collective_type", pa.string()),
        ],
        "nic__logical_comm_with__nic": [
            ("edge.rtt_ms", pa.float64()),
            ("edge.jitter_ms", pa.float64()),
            ("edge.roce_retrans_rate", pa.float64()),
            ("edge.pfc_rate_s", pa.float64()),
            ("edge.ecn_rate_s", pa.float64()),
            ("edge.ber", pa.float64()),
            ("edge.tx_bytes", pa.float64()),
            ("edge.rx_bytes", pa.float64()),
        ],
        "global_task__executes_on__npu": [
            ("edge.rank_active", pa.bool_()),
            ("edge.compute_duration_ms", pa.float64()),
        ],
    }
    fields.extend(
        pa.field(name, data_type) for name, data_type in attributes[edge_type]
    )
    return pa.schema(fields)


def align_nodes(config: PilotConfig, run_dir: Path) -> dict[str, Any]:
    manifest = json.loads((run_dir / "manifest.json").read_text(encoding="utf-8"))
    start_mono_ns = int(manifest["run_start_mono_ns"])
    start_utc_ns = int(manifest["run_start_utc_ns"])
    duration_s = int(manifest["duration_s"])
    registry = SchemaRegistry(config.node_schema_path)
    topology_nodes = _load_topology_nodes(run_dir)

    buckets: dict[
        tuple[str, str, str, int], list[tuple[int, Any, int]]
    ] = defaultdict(list)
    counter_series: dict[
        tuple[str, str, str], list[tuple[int, int, int, list[str], str]]
    ] = defaultdict(list)
    raw_records = 0
    out_of_window = 0
    invalid_records = 0
    for payload in iter_run_observations(run_dir):
        raw_records += 1
        try:
            observation = Observation.model_validate(payload)
        except Exception:
            invalid_records += 1
            continue
        index = _bucket_index(payload, start_mono_ns, duration_s)
        if index is None:
            out_of_window += 1
            continue
        spec = registry.metric(observation.metric_id)
        if spec is None:
            continue
        if not observation.observed or observation.status != ObservationStatus.OK:
            continue
        value = observation.value
        if value is None:
            continue
        mask = quality_mask(
            observation.quality_flags, observation.status.value
        )
        if observation.metric_kind == MetricKind.COUNTER and isinstance(value, int):
            counter_series[
                (observation.node_type, observation.node_id, observation.metric_id)
            ].append(
                (
                    observation.ts_mono_ns,
                    index,
                    value,
                    observation.quality_flags,
                    observation.status.value,
                )
            )
        else:
            buckets[
                (
                    observation.node_type,
                    observation.node_id,
                    observation.metric_id,
                    index,
                )
            ].append((observation.ts_mono_ns, value, mask))

    counter_derived: dict[
        tuple[str, str, str, int], dict[str, list[float]]
    ] = defaultdict(lambda: defaultdict(list))
    counter_quality: dict[tuple[str, str, str, int], int] = defaultdict(int)
    for key, samples in counter_series.items():
        samples.sort()
        previous: tuple[int, int] | None = None
        for ts_mono_ns, index, value, flags, status in samples:
            bucket_key = (*key, index)
            counter_derived[bucket_key]["last"].append(float(value))
            counter_quality[bucket_key] |= quality_mask(flags, status)
            if previous is not None:
                previous_ts, previous_value = previous
                elapsed = (ts_mono_ns - previous_ts) / 1_000_000_000
                if elapsed > 0 and value >= previous_value:
                    delta = float(value - previous_value)
                    counter_derived[bucket_key]["delta"].append(delta)
                    counter_derived[bucket_key]["rate"].append(delta / elapsed)
                elif value < previous_value:
                    counter_quality[bucket_key] |= QUALITY_BITS["COUNTER_RESET"]
            previous = (ts_mono_ns, value)

    output_dir = run_dir / "aligned" / "nodes"
    output_dir.mkdir(parents=True, exist_ok=True)
    file_summary: dict[str, Any] = {}
    for node_type, specs in registry.by_node_type.items():
        node_ids = topology_nodes.get(node_type, [])
        rows: list[dict[str, Any]] = []
        for node_id in node_ids:
            for index in range(duration_s):
                row: dict[str, Any] = {
                    "dataset_version": config.dataset_version,
                    "schema_version": config.schema_version,
                    "campaign_id": config.campaign_id,
                    "run_id": manifest["run_id"],
                    "topology_id": manifest["topology_id"],
                    "t_idx": index,
                    "ts_bucket_start_utc_ns": start_utc_ns
                    + index * 1_000_000_000,
                    "node_id": node_id,
                }
                for spec in specs:
                    key = (node_type, node_id, spec.metric_id, index)
                    values = sorted(buckets.get(key, []), key=lambda item: item[0])
                    masks = [item[2] for item in values]
                    if spec.kind == "counter":
                        derived = counter_derived.get(key, {})
                        aggregated: dict[str, Any] = {
                            "last": derived.get("last", [None])[-1]
                            if derived.get("last")
                            else None,
                            "delta": sum(derived.get("delta", []))
                            if derived.get("delta")
                            else None,
                            "rate": fmean(derived.get("rate", []))
                            if derived.get("rate")
                            else None,
                        }
                        observed = aggregated["last"] is not None
                        metric_quality = counter_quality.get(key, 0)
                        row[spec.metric_id] = aggregated["last"]
                        for aggregate in ("delta", "rate"):
                            row[f"{spec.metric_id}__{aggregate}"] = aggregated[aggregate]
                    elif spec.kind in {"categorical", "bitset"}:
                        raw_values = [item[1] for item in values]
                        observed = bool(raw_values)
                        if raw_values:
                            if spec.kind == "bitset" and all(
                                isinstance(value, int) for value in raw_values
                            ):
                                combined = 0
                                for value in raw_values:
                                    combined |= value
                                row[spec.metric_id] = combined
                            else:
                                row[spec.metric_id] = raw_values[-1]
                            row[f"{spec.metric_id}__changes"] = sum(
                                left != right
                                for left, right in zip(
                                    raw_values, raw_values[1:], strict=False
                                )
                            )
                        else:
                            row[spec.metric_id] = None
                            row[f"{spec.metric_id}__changes"] = 0
                        metric_quality = 0
                        for mask in masks:
                            metric_quality |= mask
                    else:
                        numeric = [
                            float(item[1])
                            for item in values
                            if isinstance(item[1], (int, float))
                            and math.isfinite(float(item[1]))
                        ]
                        aggregated = _aggregate_numeric(numeric, spec.aggregates)
                        observed = bool(numeric)
                        row[spec.metric_id] = _base_aggregate(spec, aggregated)
                        for aggregate in spec.aggregates:
                            row[f"{spec.metric_id}__{aggregate}"] = aggregated.get(
                                aggregate
                            )
                        metric_quality = 0
                        for mask in masks:
                            metric_quality |= mask
                    row[f"{spec.metric_id}__observed"] = observed
                    row[f"{spec.metric_id}__quality"] = metric_quality
                rows.append(row)
        path = output_dir / f"{node_type}.parquet"
        table = write_pylist(
            path,
            rows,
            schema=_node_arrow_schema(specs),
            compression=config.storage.parquet_compression,
            compression_level=config.storage.parquet_compression_level,
        )
        file_summary[node_type] = {
            "rows": table.num_rows,
            "columns": table.num_columns,
            "nodes": len(node_ids),
            "path": str(path.relative_to(run_dir)),
        }

    return {
        "raw_observation_records": raw_records,
        "invalid_observation_records": invalid_records,
        "out_of_window_records": out_of_window,
        "node_files": file_summary,
    }


def align_events_and_edges(config: PilotConfig, run_dir: Path) -> dict[str, Any]:
    manifest = json.loads((run_dir / "manifest.json").read_text(encoding="utf-8"))
    start_mono_ns = int(manifest["run_start_mono_ns"])
    duration_s = int(manifest["duration_s"])
    event_rows: list[dict[str, Any]] = []
    hccl_by_bucket: dict[int, list[dict[str, Any]]] = defaultdict(list)
    workload_start: int | None = None
    workload_finish: int | None = None
    for payload in iter_run_events(run_dir):
        index = _bucket_index(payload, start_mono_ns, duration_s)
        event_rows.append(
            {
                **{
                    key: value
                    for key, value in payload.items()
                    if key not in {"payload", "entity_ids"}
                },
                "t_idx": index,
                "entity_ids_json": json.dumps(
                    payload.get("entity_ids", []), ensure_ascii=False
                ),
                "payload_json": json.dumps(
                    payload.get("payload", {}),
                    ensure_ascii=False,
                    sort_keys=True,
                ),
            }
        )
        if payload.get("event_type") == "HCCL_COLLECTIVE_RESULT" and index is not None:
            hccl_by_bucket[index].append(payload)
        elif payload.get("event_type") == "WORKLOAD_STARTED" and index is not None:
            workload_start = index
        elif payload.get("event_type") == "WORKLOAD_FINISHED" and index is not None:
            workload_finish = index

    events_path = run_dir / "events.parquet"
    write_pylist(
        events_path,
        event_rows,
        compression=config.storage.parquet_compression,
        compression_level=config.storage.parquet_compression_level,
    )

    selected = [
        f"{config.resolved_host_id}/npu/{device_id}"
        for device_id in (
            config.workload.npu_ids if config.workload.enabled else []
        )
    ]
    sync_rows: list[dict[str, Any]] = []
    for index, events in sorted(hccl_by_bucket.items()):
        durations = [
            float(event["payload"]["average_time_us"]) / 1000 for event in events
        ]
        sizes = [int(event["payload"]["data_size_bytes"]) for event in events]
        bandwidth = [
            float(event["payload"]["algorithm_bandwidth_gbs"]) for event in events
        ]
        for source_id in selected:
            for target_id in selected:
                if source_id == target_id:
                    continue
                sync_rows.append(
                    {
                        "dataset_version": config.dataset_version,
                        "schema_version": config.schema_version,
                        "campaign_id": config.campaign_id,
                        "run_id": manifest["run_id"],
                        "t_idx": index,
                        "edge_type": "npu__logical_sync_with__npu",
                        "src_node_id": source_id,
                        "dst_node_id": target_id,
                        "edge_active": True,
                        "observation_kind": "group_inferred",
                        "edge.collective_duration_ms": fmean(durations),
                        "edge.collective_bytes": max(sizes),
                        "edge.collective_bandwidth_gbs": fmean(bandwidth),
                        "edge.wait_ratio": None,
                        "edge.collective_type": "all_reduce",
                        "edge_attr_observed": True,
                        "mask": 0,
                    }
                )
    executes_rows: list[dict[str, Any]] = []
    if workload_start is not None:
        finish = (
            workload_finish
            if workload_finish is not None
            else duration_s - 1
        )
        task_id = f"{config.resolved_host_id}/global_task/{manifest['run_id']}"
        for index in range(workload_start, finish + 1):
            for npu_id in selected:
                executes_rows.append(
                    {
                        "dataset_version": config.dataset_version,
                        "schema_version": config.schema_version,
                        "campaign_id": config.campaign_id,
                        "run_id": manifest["run_id"],
                        "t_idx": index,
                        "edge_type": "global_task__executes_on__npu",
                        "src_node_id": task_id,
                        "dst_node_id": npu_id,
                        "edge_active": True,
                        "observation_kind": "workload_device_map",
                        "edge_attr_observed": True,
                        "mask": 0,
                        "edge.rank_active": True,
                        "edge.compute_duration_ms": None,
                    }
                )

    edge_dir = run_dir / "aligned" / "edges"
    edge_payloads = {
        "npu__logical_sync_with__npu": sync_rows,
        "nic__logical_comm_with__nic": [],
        "global_task__executes_on__npu": executes_rows,
    }
    edge_files: dict[str, dict[str, Any]] = {}
    for edge_type, rows in edge_payloads.items():
        edge_path = edge_dir / f"{edge_type}.parquet"
        table = write_pylist(
            edge_path,
            rows,
            schema=_edge_arrow_schema(edge_type),
            compression=config.storage.parquet_compression,
            compression_level=config.storage.parquet_compression_level,
        )
        edge_files[edge_type] = {
            "rows": table.num_rows,
            "path": str(edge_path.relative_to(run_dir)),
        }

    return {
        "event_records": len(event_rows),
        "hccl_event_buckets": len(hccl_by_bucket),
        "dynamic_edge_records": len(sync_rows) + len(executes_rows),
        "events_path": str(events_path.relative_to(run_dir)),
        "edge_files": edge_files,
    }


def normalize_nodes(config: PilotConfig, run_dir: Path) -> dict[str, Any]:
    registry = SchemaRegistry(config.node_schema_path)
    baseline_end = config.phase_boundaries_s[1]
    input_dir = run_dir / "aligned" / "nodes"
    output_dir = run_dir / "normalized" / "nodes"
    baseline_rows: list[dict[str, Any]] = []
    summary: dict[str, Any] = {}
    for node_type, specs in registry.by_node_type.items():
        source = input_dir / f"{node_type}.parquet"
        if not source.is_file():
            continue
        rows = pq.read_table(source).to_pylist()
        by_node: dict[str, list[dict[str, Any]]] = defaultdict(list)
        for row in rows:
            by_node[row["node_id"]].append(row)
        normalized_rows: list[dict[str, Any]] = []
        for node_id, node_rows in by_node.items():
            node_rows.sort(key=lambda item: item["t_idx"])
            stats: dict[str, tuple[float, float]] = {}
            for spec in specs:
                if not spec.normalize:
                    continue
                values = [
                    float(row[spec.metric_id])
                    for row in node_rows
                    if row["t_idx"] < baseline_end
                    and row.get(f"{spec.metric_id}__observed")
                    and isinstance(row.get(spec.metric_id), (int, float))
                    and math.isfinite(float(row[spec.metric_id]))
                ]
                if not values:
                    continue
                mean = float(fmean(values))
                std = float(pstdev(values)) if len(values) > 1 else 0.0
                sigma_floor = max(1e-6, abs(mean) * 1e-6)
                denominator = max(std, sigma_floor)
                stats[spec.metric_id] = (mean, denominator)
                baseline_rows.append(
                    {
                        "node_type": node_type,
                        "node_id": node_id,
                        "metric_id": spec.metric_id,
                        "base_mean": mean,
                        "base_std": std,
                        "sigma_floor": sigma_floor,
                        "base_valid_count": len(values),
                    }
                )
            for row in node_rows:
                normalized = row.copy()
                for metric_id, (mean, denominator) in stats.items():
                    value = row.get(metric_id)
                    if row.get(f"{metric_id}__observed") and isinstance(
                        value, (int, float)
                    ):
                        normalized[metric_id] = (float(value) - mean) / denominator
                    else:
                        normalized[metric_id] = None
                normalized_rows.append(normalized)
        target = output_dir / f"{node_type}.parquet"
        table = write_pylist(
            target,
            normalized_rows,
            schema=pq.read_schema(source),
            compression=config.storage.parquet_compression,
            compression_level=config.storage.parquet_compression_level,
        )
        summary[node_type] = {
            "rows": table.num_rows,
            "path": str(target.relative_to(run_dir)),
        }
    write_pylist(
        run_dir / "normalized" / "baseline_stats.parquet",
        baseline_rows,
        schema=pa.schema(
            [
                pa.field("node_type", pa.string(), nullable=False),
                pa.field("node_id", pa.string(), nullable=False),
                pa.field("metric_id", pa.string(), nullable=False),
                pa.field("base_mean", pa.float64(), nullable=False),
                pa.field("base_std", pa.float64(), nullable=False),
                pa.field("sigma_floor", pa.float64(), nullable=False),
                pa.field("base_valid_count", pa.int64(), nullable=False),
            ]
        ),
        compression=config.storage.parquet_compression,
        compression_level=config.storage.parquet_compression_level,
    )
    return {"node_files": summary, "baseline_stat_records": len(baseline_rows)}


def align_run(config: PilotConfig, run_dir: Path) -> dict[str, Any]:
    summary = {
        "nodes": align_nodes(config, run_dir),
        "events_edges": align_events_and_edges(config, run_dir),
        "normalization": normalize_nodes(config, run_dir),
    }
    atomic_write_json(run_dir / "alignment_report.json", summary)
    return summary

