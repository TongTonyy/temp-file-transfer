from __future__ import annotations

import asyncio
import time
import uuid
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from hgnn_collect.collectors import (
    BaseCollector,
    CollectorContext,
    DcmiApi,
    DcmiCollector,
    NetworkFastCollector,
    NetworkSlowCollector,
    NpuDetailCollector,
    NpuSummaryCollector,
    ProcfsCollector,
    SystemCollector,
)
from hgnn_collect.config import PilotConfig
from hgnn_collect.models import ClockQuality, EventRecord, Observation
from hgnn_collect.probe import probe_capabilities
from hgnn_collect.storage.raw import RotatingRawWriter
from hgnn_collect.storage.run import RunManager
from hgnn_collect.topology.discover import discover_topology, persist_topology
from hgnn_collect.topology.priors import build_priors
from hgnn_collect.utils import atomic_write_json, detect_clock_quality, qdisc_snapshot
from hgnn_collect.workloads import HcclWorkload


@dataclass
class CollectionArtifacts:
    manager: RunManager
    capabilities: dict[str, Any]
    topology: dict[str, Any]
    collector_summary: dict[str, Any]
    workload_summary: dict[str, Any]
    event_markers: list[dict[str, Any]]
    qdisc_after: dict[str, Any]


def _build_collectors(config: PilotConfig) -> list[BaseCollector]:
    collectors: list[BaseCollector] = []
    for name, collector_config in config.collectors.items():
        if not collector_config.enabled:
            continue
        if name == "procfs":
            collectors.append(
                ProcfsCollector(
                    interval_s=collector_config.interval_s,
                    critical=collector_config.critical,
                )
            )
        elif name == "network_fast":
            collectors.append(
                NetworkFastCollector(
                    interval_s=collector_config.interval_s,
                    interfaces=collector_config.interfaces,
                    critical=collector_config.critical,
                )
            )
        elif name == "network_slow":
            collectors.append(
                NetworkSlowCollector(
                    interval_s=collector_config.interval_s,
                    interfaces=collector_config.interfaces,
                    critical=collector_config.critical,
                    timeout_s=config.command_timeout_s,
                )
            )
        elif name == "npu_summary":
            collectors.append(
                NpuSummaryCollector(
                    interval_s=collector_config.interval_s,
                    critical=collector_config.critical,
                    timeout_s=max(config.command_timeout_s, 3),
                )
            )
        elif name == "npu_detail":
            collectors.append(
                NpuDetailCollector(
                    interval_s=collector_config.interval_s,
                    critical=collector_config.critical,
                    timeout_s=max(config.command_timeout_s, 3),
                    devices_per_cycle=int(
                        getattr(collector_config, "devices_per_cycle", 1)
                    ),
                )
            )
        elif name == "dcmi":
            collectors.append(
                DcmiCollector(
                    interval_s=collector_config.interval_s,
                    critical=collector_config.critical,
                    api=(
                        DcmiApi(config.site.vendor_api.dcmi_library)
                        if config.site.vendor_api.dcmi_library
                        else None
                    ),
                )
            )
        elif name == "system":
            collectors.append(
                SystemCollector(
                    interval_s=collector_config.interval_s,
                    critical=collector_config.critical,
                )
            )
        else:
            raise ValueError(f"unknown collector configured: {name}")
    return collectors


class PassiveOrchestrator:
    def __init__(self, config: PilotConfig, run_id: str | None = None):
        self.config = config
        self.manager = RunManager(config, run_id)
        self.clock_quality = detect_clock_quality()
        self.queue: asyncio.Queue[Observation | EventRecord | None] = asyncio.Queue(
            maxsize=config.queue_maxsize
        )
        self.start_mono_ns = 0
        self.start_utc_ns = 0
        self.end_mono_ns = 0
        self.event_sequence = 0
        self.event_markers: list[dict[str, Any]] = []
        self.collector_summary: dict[str, Any] = {}
        self.batch_filtered_records = 0
        self.selected_metric_ids = set(config.batch.selected_metric_ids)

    def metric_selected(self, metric_id: str) -> bool:
        return (
            not self.config.batch.enabled
            or self.config.batch.metric_selection == "all"
            or metric_id in self.selected_metric_ids
        )

    def phase_for(self, mono_ns: int) -> str:
        elapsed_s = (mono_ns - self.start_mono_ns) / 1_000_000_000
        _, t0_end, t1_end, _ = self.config.phase_boundaries_s
        if elapsed_s < t0_end:
            return "T0_BASELINE"
        if elapsed_s < t1_end:
            return "T1_NOOP"
        if elapsed_s < self.config.duration_s:
            return "T2_RECOVERY"
        return "POSTCHECK"

    def context(self, scheduled_mono_ns: int | None = None) -> CollectorContext:
        mono_ns = scheduled_mono_ns or time.monotonic_ns()
        return CollectorContext(
            schema_version=self.config.schema_version,
            run_id=self.manager.run_id,
            host_id=self.config.resolved_host_id,
            phase=self.phase_for(mono_ns),
            clock_quality=self.clock_quality,
            scheduled_mono_ns=mono_ns,
        )

    def event(
        self,
        event_type: str,
        *,
        severity: str = "info",
        payload: dict[str, Any] | None = None,
        entity_ids: list[str] | None = None,
        correlation_id: str | None = None,
        mono_ns: int | None = None,
        utc_ns: int | None = None,
    ) -> EventRecord:
        timestamp_mono = mono_ns or time.monotonic_ns()
        event = EventRecord(
            schema_version=self.config.schema_version,
            event_id=str(uuid.uuid4()),
            run_id=self.manager.run_id,
            collector_id="orchestrator",
            seq=self.event_sequence,
            ts_utc_ns=utc_ns or time.time_ns(),
            ts_mono_ns=timestamp_mono,
            clock_quality=self.clock_quality,
            host_id=self.config.resolved_host_id,
            event_type=event_type,
            phase=self.phase_for(timestamp_mono),
            severity=severity,
            entity_ids=entity_ids or [],
            correlation_id=correlation_id,
            payload=payload or {},
        )
        self.event_sequence += 1
        return event

    async def _writer_loop(self, writer: RotatingRawWriter) -> None:
        while True:
            item = await self.queue.get()
            try:
                if item is None:
                    return
                if isinstance(item, Observation):
                    if self.metric_selected(item.metric_id):
                        writer.write_observation(item)
                    else:
                        self.batch_filtered_records += 1
                elif isinstance(item, EventRecord):
                    writer.write_event(item)
            finally:
                self.queue.task_done()

    async def _run_collector(self, collector: BaseCollector) -> None:
        interval_ns = round(collector.interval_s * 1_000_000_000)
        scheduled = self.start_mono_ns
        stats = {
            "interval_s": collector.interval_s,
            "critical": collector.critical,
            "attempts": 0,
            "successful_samples": 0,
            "source_records": 0,
            "records": 0,
            "filtered_records": 0,
            "errors": 0,
            "skipped_deadlines": 0,
            "schedule_lag_us": [],
            "collection_duration_us": [],
        }
        consecutive_errors = 0
        while scheduled < self.end_mono_ns:
            sleep_s = (scheduled - time.monotonic_ns()) / 1_000_000_000
            if sleep_s > 0:
                await asyncio.sleep(sleep_s)
            actual_start = time.monotonic_ns()
            lag_us = max(0, (actual_start - scheduled) // 1_000)
            stats["attempts"] += 1
            stats["schedule_lag_us"].append(lag_us)
            try:
                observations = await collector.collect(self.context(scheduled))
                completed = time.monotonic_ns()
                duration_us = max(0, (completed - actual_start) // 1_000)
                stats["collection_duration_us"].append(duration_us)
                stats["successful_samples"] += 1
                stats["source_records"] += len(observations)
                selected_observations = [
                    observation
                    for observation in observations
                    if self.metric_selected(observation.metric_id)
                ]
                stats["records"] += len(selected_observations)
                stats["filtered_records"] += (
                    len(observations) - len(selected_observations)
                )
                consecutive_errors = 0
                for observation in selected_observations:
                    observation.scheduled_lag_us = lag_us
                    if observation.source_latency_us == 0:
                        observation.source_latency_us = duration_us
                    await self.queue.put(observation)
            except Exception as error:  # A failed source must not silently end a run.
                stats["errors"] += 1
                consecutive_errors += 1
                await self.queue.put(
                    self.event(
                        "COLLECTOR_ERROR",
                        severity="error" if collector.critical else "warning",
                        payload={
                            "collector_id": collector.collector_id,
                            "error_type": type(error).__name__,
                            "error": str(error),
                            "consecutive_errors": consecutive_errors,
                        },
                    )
                )
            scheduled += interval_ns
            now = time.monotonic_ns()
            if now > scheduled + interval_ns:
                missed = (now - scheduled) // interval_ns
                stats["skipped_deadlines"] += int(missed)
                scheduled += missed * interval_ns
        self.collector_summary[collector.collector_id] = stats
        await self.queue.put(
            self.event(
                "COLLECTOR_FINISHED",
                payload={
                    "collector_id": collector.collector_id,
                    "attempts": stats["attempts"],
                    "errors": stats["errors"],
                },
            )
        )

    async def _phase_markers(self) -> None:
        marker_specs = [
            (0, "RUN_START"),
            (0, "T0_BASELINE_STARTED"),
            (self.config.phase_boundaries_s[1], "T1_NOOP_STARTED"),
            (self.config.phase_boundaries_s[2], "T2_RECOVERY_STARTED"),
            (self.config.phase_boundaries_s[3], "RUN_WINDOW_FINISHED"),
        ]
        for offset_s, event_type in marker_specs:
            target = self.start_mono_ns + offset_s * 1_000_000_000
            delay = (target - time.monotonic_ns()) / 1_000_000_000
            if delay > 0:
                await asyncio.sleep(delay)
            marker = self.event(event_type, mono_ns=target)
            self.event_markers.append(
                {
                    "event_type": marker.event_type,
                    "ts_utc_ns": marker.ts_utc_ns,
                    "ts_mono_ns": marker.ts_mono_ns,
                    "phase": marker.phase,
                }
            )
            await self.queue.put(marker)

    async def run(self) -> CollectionArtifacts:
        capabilities = probe_capabilities(self.config)
        topology = discover_topology(self.config, self.manager.run_id)
        qdisc_before = qdisc_snapshot()
        self.manager.create(
            run_start_utc_ns=0,
            run_start_mono_ns=0,
            qdisc_before=qdisc_before,
        )
        atomic_write_json(
            self.manager.staging_dir / "capabilities.json", capabilities
        )
        persist_topology(
            self.config, topology, self.manager.staging_dir / "topology"
        )
        build_priors(
            self.config, topology, self.manager.staging_dir / "priors"
        )
        collectors = _build_collectors(self.config)

        self.start_utc_ns = time.time_ns()
        self.start_mono_ns = time.monotonic_ns()
        self.end_mono_ns = (
            self.start_mono_ns + self.config.duration_s * 1_000_000_000
        )
        self.manager.update(
            run_start_utc_ns=self.start_utc_ns,
            run_start_mono_ns=self.start_mono_ns,
            topology_id=topology["topology_id"],
            status="collecting",
        )

        writer = RotatingRawWriter(
            self.manager.staging_dir,
            run_start_mono_ns=self.start_mono_ns,
            rotation_s=self.config.rotation_s,
            compression=self.config.storage.raw_compression,
            fsync_parts=self.config.storage.fsync_parts,
        )
        writer_task = asyncio.create_task(self._writer_loop(writer))
        collector_tasks = [
            asyncio.create_task(self._run_collector(collector))
            for collector in collectors
        ]
        marker_task = asyncio.create_task(self._phase_markers())
        workload = HcclWorkload(self.config, phase_getter=self.phase_for)
        workload_task = asyncio.create_task(
            workload.run(
                self.context(self.start_mono_ns),
                self.queue,
                end_mono_ns=self.end_mono_ns,
            )
        )

        try:
            await asyncio.gather(*collector_tasks)
            await marker_task
            workload_summary = await workload_task
            await self.queue.join()
            await self.queue.put(None)
            await writer_task
            writer.close()
        except BaseException as error:
            for task in [*collector_tasks, marker_task, workload_task]:
                task.cancel()
            await asyncio.gather(
                *collector_tasks,
                marker_task,
                workload_task,
                return_exceptions=True,
            )
            writer.close()
            self.manager.abort(f"{type(error).__name__}: {error}")
            raise

        qdisc_after = qdisc_snapshot()
        self.manager.add_event_markers_to_labels(self.event_markers)
        self.manager.update(
            status="raw_complete",
            collector_summary=self.collector_summary,
            workload_summary=workload_summary,
            raw_record_counts=writer.record_counts,
            batch_filtered_records=self.batch_filtered_records
            + sum(
                int(summary.get("filtered_records", 0))
                for summary in self.collector_summary.values()
            ),
            qdisc_after=qdisc_after,
        )
        return CollectionArtifacts(
            manager=self.manager,
            capabilities=capabilities,
            topology=topology,
            collector_summary=self.collector_summary,
            workload_summary=workload_summary,
            event_markers=self.event_markers,
            qdisc_after=qdisc_after,
        )


async def collect_passive(
    config: PilotConfig, run_id: str | None = None
) -> CollectionArtifacts:
    return await PassiveOrchestrator(config, run_id).run()

