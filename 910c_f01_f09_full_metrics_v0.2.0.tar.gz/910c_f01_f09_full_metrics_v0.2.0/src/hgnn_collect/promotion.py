from __future__ import annotations

import json
import os
import time
from pathlib import Path
from typing import Any, Sequence

from hgnn_collect.batches import (
    BatchManifest,
    load_batch_manifest,
    release_script_name,
)
from hgnn_collect.config import load_config
from hgnn_collect.processing.schema import SchemaRegistry
from hgnn_collect.storage.run import verify_checksums
from hgnn_collect.utils import atomic_write_json, sha256_file


def _load_json(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))


def _release_platform_name(run_manifest: dict[str, Any]) -> str:
    configured = str(
        run_manifest.get("config", {})
        .get("compatibility", {})
        .get("current_platform", "")
    )
    if configured.startswith("ascend"):
        configured = f"a{configured.removeprefix('ascend')}"
    if not configured or any(
        character not in "abcdefghijklmnopqrstuvwxyz0123456789_-"
        for character in configured
    ):
        raise ValueError(f"invalid run platform for release name: {configured!r}")
    return configured


def _validate_smoke_evidence(
    run_dirs: Sequence[Path | str],
    batch: BatchManifest,
    required_metrics: set[str],
    host_id: str,
) -> list[dict[str, Any]]:
    evidence: list[dict[str, Any]] = []
    resolved = [Path(path).expanduser().resolve() for path in run_dirs]
    if len(resolved) < 3 or len(set(resolved)) != len(resolved):
        raise ValueError("promotion requires three distinct 30-second smoke runs")
    for run_dir in resolved:
        manifest_path = run_dir / "manifest.json"
        quality_path = run_dir / "quality_report.json"
        if not manifest_path.is_file() or not quality_path.is_file():
            raise FileNotFoundError(f"smoke evidence is incomplete: {run_dir}")
        checksums = verify_checksums(run_dir)
        manifest = _load_json(manifest_path)
        quality = _load_json(quality_path)
        validated = set(
            quality.get("batch_validation", {}).get(
                "validated_metric_ids", []
            )
        )
        if (
            manifest.get("status") != "committed"
            or not quality.get("passed")
            or manifest.get("batch", {}).get("batch_id") != batch.batch_id
            or manifest.get("host_id") != host_id
            or int(manifest.get("duration_s", 0)) < 30
            or not checksums["passed"]
            or not required_metrics.issubset(validated)
        ):
            raise ValueError(f"smoke evidence did not pass promotion gates: {run_dir}")
        evidence.append(
            {
                "run_id": manifest["run_id"],
                "run_dir": str(run_dir),
                "duration_s": int(manifest["duration_s"]),
                "validated_metric_count": len(validated),
                "manifest_sha256": sha256_file(manifest_path),
                "quality_report_sha256": sha256_file(quality_path),
            }
        )
    return evidence


def promote_batch_run(
    batch_manifest_path: Path | str,
    run_dir: Path | str,
    output_dir: Path | str,
    *,
    smoke_run_dirs: Sequence[Path | str] = (),
    require_acceptance_evidence: bool = False,
) -> dict[str, Any]:
    batch = load_batch_manifest(batch_manifest_path)
    sealed_run = Path(run_dir).expanduser().resolve()
    destination = Path(output_dir).expanduser().resolve()
    if sealed_run.name.endswith(".staging"):
        raise ValueError("staging runs cannot be promoted")
    run_manifest_path = sealed_run / "manifest.json"
    quality_path = sealed_run / "quality_report.json"
    if not run_manifest_path.is_file() or not quality_path.is_file():
        raise FileNotFoundError("run manifest or quality report is missing")

    checksum_result = verify_checksums(sealed_run)
    if not checksum_result["passed"]:
        raise ValueError(f"run checksum verification failed: {checksum_result}")
    run_manifest = _load_json(run_manifest_path)
    quality = _load_json(quality_path)
    run_batch = run_manifest.get("batch", {})
    if run_batch.get("batch_id") != batch.batch_id:
        raise ValueError(
            f"run batch {run_batch.get('batch_id')} does not match {batch.batch_id}"
        )
    if run_manifest.get("status") != "committed":
        raise ValueError(
            f"only committed runs can be promoted, got {run_manifest.get('status')}"
        )
    if not quality.get("passed"):
        raise ValueError("quality report did not pass")
    validation = quality.get("batch_validation", {})
    validated = validation.get("validated_metric_ids", [])
    regressed = validation.get("regressed_metric_ids", [])
    if regressed:
        raise ValueError(f"previous metrics regressed: {regressed}")
    run_selected = set(run_batch.get("selected_metric_ids", []))
    if run_selected != set(batch.metric_ids):
        raise ValueError(
            "sealed run allowlist does not match the batch manifest"
        )
    extra = sorted(set(validated) - set(batch.metric_ids))
    if extra:
        raise ValueError(f"validated metrics outside batch allowlist: {extra}")
    previous = set(run_batch.get("previous_metric_ids", []))
    missing_previous = sorted(previous - set(validated))
    if missing_previous:
        raise ValueError(f"previous metrics regressed: {missing_previous}")
    if batch.batch_id != "B00" and len(validated) <= len(previous):
        raise ValueError("promotion would not increase the validated metric count")
    sealed_batch_manifest = sealed_run / "batch" / "batch_manifest.yaml"
    if not sealed_batch_manifest.is_file():
        raise FileNotFoundError("sealed batch manifest is missing")
    if sha256_file(sealed_batch_manifest) != sha256_file(batch.manifest_path):
        raise ValueError("sealed batch manifest does not match current manifest")
    acceptance_evidence: list[dict[str, Any]] = []
    if require_acceptance_evidence:
        if int(run_manifest.get("duration_s", 0)) < 300:
            raise ValueError("promotion requires a final run of at least 300 seconds")
        acceptance_evidence = _validate_smoke_evidence(
            smoke_run_dirs,
            batch,
            set(validated),
            str(run_manifest.get("host_id", "")),
        )

    validated_count = len(validated)
    unvalidated_batch = sorted(set(batch.metric_ids) - set(validated))
    registry = SchemaRegistry(load_config(batch.base_config).node_schema_path)
    unvalidated = sorted(set(registry.by_metric) - set(validated))
    release_platform = _release_platform_name(run_manifest)
    script_name = release_script_name(
        batch,
        validated_count,
        platform_name=release_platform,
    )
    project_root = Path(__file__).resolve().parents[2]
    runner = project_root / "scripts" / "batches" / "run_batch.sh"
    batch_relative = batch.manifest_path.relative_to(project_root)
    script = (
        "#!/usr/bin/env bash\n"
        "set -euo pipefail\n"
        f'PROJECT_ROOT="${{HGNN_PROJECT_ROOT:-{project_root}}}"\n'
        f'exec "$PROJECT_ROOT/scripts/batches/{runner.name}" '
        f'--batch-config "$PROJECT_ROOT/{batch_relative}" "$@"\n'
    )
    destination.mkdir(parents=True, exist_ok=True)
    script_path = destination / script_name
    if script_path.exists() and script_path.read_text(encoding="utf-8") != script:
        raise FileExistsError(f"release script already exists with other content: {script_path}")
    temporary = script_path.with_suffix(script_path.suffix + ".tmp")
    temporary.write_text(script, encoding="utf-8")
    os.chmod(temporary, 0o555)
    temporary.replace(script_path)

    promotion = {
        "promotion_version": "1.0.0",
        "batch_id": batch.batch_id,
        "batch_version": batch.batch_version,
        "validated_metric_count": validated_count,
        "denominator": batch.denominator,
        "target_platform": release_platform,
        "validated_metric_ids": sorted(validated),
        "unvalidated_metric_ids": unvalidated,
        "unvalidated_batch_metric_ids": unvalidated_batch,
        "run_id": run_manifest["run_id"],
        "run_dir": str(sealed_run),
        "run_manifest_sha256": sha256_file(run_manifest_path),
        "quality_report_sha256": sha256_file(quality_path),
        "batch_manifest_sha256": sha256_file(batch.manifest_path),
        "checksums": checksum_result,
        "acceptance_evidence": {
            "required": require_acceptance_evidence,
            "smoke_runs": acceptance_evidence,
            "final_duration_s": int(run_manifest.get("duration_s", 0)),
        },
        "release_script": str(script_path),
        "promoted_at_utc_ns": time.time_ns(),
    }
    promotion_path = destination / (
        f"promotion_{batch.batch_id.lower()}_{validated_count:02d}-"
        f"{batch.denominator}_v{batch.batch_version}.json"
    )
    atomic_write_json(promotion_path, promotion)
    promotion["promotion_path"] = str(promotion_path)
    return promotion
