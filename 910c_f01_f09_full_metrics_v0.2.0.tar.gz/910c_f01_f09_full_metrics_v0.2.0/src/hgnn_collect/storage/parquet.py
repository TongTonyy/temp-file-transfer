from __future__ import annotations

import csv
import json
import os
from contextlib import suppress
from pathlib import Path
from typing import Any, Iterable

import pyarrow as pa
import pyarrow.parquet as pq


def atomic_write_table(
    path: Path,
    table: pa.Table,
    *,
    compression: str = "zstd",
    compression_level: int | None = 3,
) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")

    def write_and_validate(
        *,
        candidate_compression: str | None,
        candidate_level: int | None,
    ) -> None:
        pq.write_table(
            table,
            temporary,
            compression=candidate_compression,
            compression_level=candidate_level,
            use_dictionary=False,
            write_statistics=False,
            data_page_version="1.0",
            row_group_size=512,
        )
        # Catch corrupt page/level encodings immediately while the original table
        # is still in memory, then retry with a simpler encoding below.
        pq.read_table(temporary)

    try:
        write_and_validate(
            candidate_compression=compression,
            candidate_level=compression_level,
        )
    except Exception:
        with suppress(FileNotFoundError):
            temporary.unlink()
        write_and_validate(candidate_compression=None, candidate_level=None)
    descriptor = os.open(temporary, os.O_RDONLY)
    try:
        os.fsync(descriptor)
    finally:
        os.close(descriptor)
    temporary.replace(path)


def write_pylist(
    path: Path,
    rows: Iterable[dict[str, Any]],
    *,
    schema: pa.Schema | None = None,
    compression: str = "zstd",
    compression_level: int | None = 3,
) -> pa.Table:
    materialized = list(rows)
    if schema is not None:
        table = pa.Table.from_pylist(materialized, schema=schema)
    elif materialized:
        table = pa.Table.from_pylist(materialized)
    else:
        table = pa.table({})

    def write_csv_sidecar() -> None:
        if not materialized:
            return
        csv_path = path.with_suffix(".csv")
        temporary = csv_path.with_suffix(csv_path.suffix + ".tmp")
        fields = list(materialized[0].keys())
        with temporary.open("w", encoding="utf-8-sig", newline="") as handle:
            writer = csv.DictWriter(handle, fieldnames=fields, extrasaction="ignore")
            writer.writeheader()
            writer.writerows(materialized)
            handle.flush()
            os.fsync(handle.fileno())
        temporary.replace(csv_path)

    parquet_error: Exception | None = None
    try:
        atomic_write_table(
            path,
            table,
            compression=compression,
            compression_level=compression_level,
        )
    except Exception as error:
        parquet_error = error
        with suppress(FileNotFoundError):
            path.with_suffix(path.suffix + ".tmp").unlink()
        error_path = path.with_suffix(path.suffix + ".error.json")
        error_path.write_text(
            json.dumps(
                {
                    "path": str(path),
                    "error": f"{type(error).__name__}: {error}",
                    "fallback": "csv_sidecar",
                },
                ensure_ascii=False,
                indent=2,
            ),
            encoding="utf-8",
        )
    write_csv_sidecar()
    if materialized:
        # Surface the issue to later quality checks without blocking raw/CSV data.
        if parquet_error is not None:
            return table
    return table

