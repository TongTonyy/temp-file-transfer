from __future__ import annotations

import json
import os
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from hgnn_collect.config import PilotConfig
from hgnn_collect.utils import atomic_write_json, sha256_file

UTC = timezone.utc


def generate_run_id(config: PilotConfig) -> str:
    timestamp = datetime.now(UTC).strftime("%Y%m%dT%H%M%SZ")
    return f"{timestamp}-passive-{config.planned_fault_code.lower()}-{config.resolved_host_id}"


class RunManager:
    def __init__(self, config: PilotConfig, run_id: str | None = None):
        self.config = config
        self.run_id = run_id or generate_run_id(config)
        self.runs_root = (
            config.data_root
            / "versions"
            / config.dataset_version
            / "campaigns"
            / config.campaign_id
            / "runs"
        )
        self.staging_dir = self.runs_root / f"{self.run_id}.staging"
        self.final_dir = self.runs_root / self.run_id
        self.manifest_path = self.staging_dir / "manifest.json"
        self.manifest: dict[str, Any] = {}

    def create(
        self,
        *,
        run_start_utc_ns: int,
        run_start_mono_ns: int,
        qdisc_before: dict[str, Any],
    ) -> Path:
        self.runs_root.mkdir(parents=True, exist_ok=True)
        if self.staging_dir.exists() or self.final_dir.exists():
            raise FileExistsError(f"run directory already exists: {self.run_id}")
        self.staging_dir.mkdir(parents=True)
        (self.staging_dir / "schemas").mkdir()
        schema_paths = sorted(
            path
            for path in self.config.node_schema_path.parent.glob("*")
            if path.suffix in {".json", ".yaml", ".yml"}
        )
        for schema in schema_paths:
            target = self.staging_dir / "schemas" / schema.name
            target.write_bytes(schema.read_bytes())
        atomic_write_json(
            self.staging_dir / "config.resolved.json",
            self.config.model_dump(mode="json"),
        )
        workload_build_manifest = (
            self.config.workload.binary.parent / "build_manifest.json"
        )
        if workload_build_manifest.is_file():
            workload_dir = self.staging_dir / "workload"
            workload_dir.mkdir()
            (workload_dir / "build_manifest.json").write_bytes(
                workload_build_manifest.read_bytes()
            )
        if (
            self.config.batch.enabled
            and self.config.batch.manifest_path is not None
            and self.config.batch.manifest_path.is_file()
        ):
            batch_dir = self.staging_dir / "batch"
            batch_dir.mkdir()
            (batch_dir / "batch_manifest.yaml").write_bytes(
                self.config.batch.manifest_path.read_bytes()
            )

        self.manifest = {
            "schema_version": self.config.schema_version,
            "dataset_version": self.config.dataset_version,
            "campaign_id": self.config.campaign_id,
            "run_id": self.run_id,
            "status": "collecting",
            "mode": self.config.mode,
            "planned_fault_code": self.config.planned_fault_code,
            "host_id": self.config.resolved_host_id,
            "run_start_utc_ns": run_start_utc_ns,
            "run_start_mono_ns": run_start_mono_ns,
            "duration_s": self.config.duration_s,
            "phase_boundaries_s": self.config.phase_boundaries_s,
            "config_sha256": self.config.sha256(),
            "config": self.config.model_dump(mode="json"),
            "batch": self.config.batch.model_dump(mode="json"),
            "qdisc_before": qdisc_before,
            "qdisc_after": None,
            "collector_summary": {},
            "workload_summary": {},
            "quality_summary": {},
            "files": [],
            "deviations": [],
            "created_at_utc_ns": time.time_ns(),
        }
        atomic_write_json(self.manifest_path, self.manifest)
        self.write_labels()
        return self.staging_dir

    def write_labels(self) -> None:
        first, second, third, end = self.config.phase_boundaries_s
        phase = [
            0 if first <= index < second else 1 if index < third else 2
            for index in range(end)
        ]
        labels = {
            "run_id": self.run_id,
            "injection_mode": "passive",
            "planned_fault_code": self.config.planned_fault_code,
            "fault_type": [0.0] * 9,
            "severity_level": 0,
            "intensity_norm": 0.0,
            "intensity_raw": {},
            "target_node_ids": [],
            "root_cause_node_ids": [],
            "phase": phase,
            "event_markers": [],
            "propagation_edges": [],
            "dag_supervision_level": "none",
            "quality_flags": [],
        }
        atomic_write_json(self.staging_dir / "labels.json", labels)

    def update(self, **values: Any) -> None:
        self.manifest.update(values)
        atomic_write_json(self.manifest_path, self.manifest)

    def add_event_markers_to_labels(self, markers: list[dict[str, Any]]) -> None:
        path = self.staging_dir / "labels.json"
        labels = json.loads(path.read_text(encoding="utf-8"))
        labels["event_markers"] = markers
        atomic_write_json(path, labels)

    def compute_checksums(self) -> list[dict[str, Any]]:
        files: list[dict[str, Any]] = []
        excluded = {"manifest.json", "checksums.sha256"}
        for path in sorted(self.staging_dir.rglob("*")):
            if not path.is_file() or path.name in excluded or path.name.endswith(".tmp"):
                continue
            files.append(
                {
                    "path": str(path.relative_to(self.staging_dir)),
                    "bytes": path.stat().st_size,
                    "sha256": sha256_file(path),
                }
            )
        checksum_path = self.staging_dir / "checksums.sha256"
        temporary = checksum_path.with_suffix(".sha256.tmp")
        with temporary.open("w", encoding="utf-8") as handle:
            for item in files:
                handle.write(f"{item['sha256']}  {item['path']}\n")
            handle.flush()
            os.fsync(handle.fileno())
        temporary.replace(checksum_path)
        return files

    def commit(
        self,
        *,
        qdisc_after: dict[str, Any],
        collector_summary: dict[str, Any],
        workload_summary: dict[str, Any],
        quality_summary: dict[str, Any],
        status: str,
    ) -> Path:
        self.manifest.update(
            {
                "status": status,
                "qdisc_after": qdisc_after,
                "collector_summary": collector_summary,
                "workload_summary": workload_summary,
                "quality_summary": quality_summary,
                "completed_at_utc_ns": time.time_ns(),
            }
        )
        self.manifest["files"] = self.compute_checksums()
        atomic_write_json(self.manifest_path, self.manifest)
        self.staging_dir.replace(self.final_dir)
        return self.final_dir

    def abort(self, reason: str) -> Path:
        self.manifest.update(
            {
                "status": "aborted",
                "abort_reason": reason,
                "completed_at_utc_ns": time.time_ns(),
            }
        )
        atomic_write_json(self.manifest_path, self.manifest)
        return self.staging_dir


def verify_checksums(run_dir: Path) -> dict[str, Any]:
    checksum_path = run_dir / "checksums.sha256"
    if not checksum_path.is_file():
        return {
            "passed": False,
            "checked": 0,
            "errors": ["checksums.sha256 is missing"],
        }
    errors: list[str] = []
    checked = 0
    for line in checksum_path.read_text(encoding="utf-8").splitlines():
        if not line.strip():
            continue
        try:
            expected, relative = line.split("  ", 1)
        except ValueError:
            errors.append(f"malformed checksum line: {line}")
            continue
        path = run_dir / relative
        if not path.is_file():
            errors.append(f"missing file: {relative}")
            continue
        actual = sha256_file(path)
        checked += 1
        if actual != expected:
            errors.append(f"checksum mismatch: {relative}")
    return {"passed": not errors, "checked": checked, "errors": errors}

