from __future__ import annotations

import json
import os
from dataclasses import dataclass
from pathlib import Path
from typing import Iterator

import pyarrow as pa

from hgnn_collect.models import EventRecord, Observation


@dataclass
class _Part:
    temporary_path: Path
    final_path: Path
    raw_stream: pa.NativeFile
    compressed_stream: pa.NativeFile
    records: int = 0

    def write(self, payload: dict) -> None:
        encoded = (
            json.dumps(
                payload,
                ensure_ascii=False,
                sort_keys=True,
                separators=(",", ":"),
            )
            + "\n"
        ).encode("utf-8")
        self.compressed_stream.write(encoded)
        self.records += 1

    def close(self, fsync: bool) -> None:
        if self.compressed_stream.closed:
            return
        self.compressed_stream.close()
        if not self.raw_stream.closed:
            self.raw_stream.close()
        if fsync:
            descriptor = os.open(self.temporary_path, os.O_RDONLY)
            try:
                os.fsync(descriptor)
            finally:
                os.close(descriptor)
        self.temporary_path.replace(self.final_path)


class RotatingRawWriter:
    def __init__(
        self,
        run_dir: Path,
        *,
        run_start_mono_ns: int,
        rotation_s: int,
        compression: str = "zstd",
        fsync_parts: bool = True,
    ):
        self.run_dir = run_dir
        self.run_start_mono_ns = run_start_mono_ns
        self.rotation_ns = rotation_s * 1_000_000_000
        self.compression = compression
        self.fsync_parts = fsync_parts
        self._parts: dict[tuple[str, int], _Part] = {}
        self.record_counts: dict[str, int] = {}

    def _part_index(self, ts_mono_ns: int) -> int:
        return max(0, (ts_mono_ns - self.run_start_mono_ns) // self.rotation_ns)

    def _open_part(self, stream_key: str, part_index: int) -> _Part:
        if stream_key == "events":
            directory = self.run_dir / "raw" / "events"
        else:
            directory = (
                self.run_dir
                / "raw"
                / "observations"
                / f"collector={stream_key}"
            )
        directory.mkdir(parents=True, exist_ok=True)
        suffix = "zst" if self.compression == "zstd" else self.compression
        final_path = directory / f"part-{part_index:05d}.jsonl.{suffix}"
        temporary_path = final_path.with_suffix(final_path.suffix + ".tmp")
        raw_stream = pa.OSFile(str(temporary_path), "wb")
        compressed_stream = pa.CompressedOutputStream(raw_stream, self.compression)
        return _Part(
            temporary_path=temporary_path,
            final_path=final_path,
            raw_stream=raw_stream,
            compressed_stream=compressed_stream,
        )

    def _part_for(self, stream_key: str, part_index: int) -> _Part:
        key = (stream_key, part_index)
        if key not in self._parts:
            stale = [
                old_key
                for old_key in self._parts
                if old_key[0] == stream_key and old_key[1] != part_index
            ]
            for old_key in stale:
                self._parts.pop(old_key).close(self.fsync_parts)
            self._parts[key] = self._open_part(stream_key, part_index)
        return self._parts[key]

    def write_observation(self, observation: Observation) -> None:
        part_index = self._part_index(observation.ts_mono_ns)
        part = self._part_for(observation.collector_id, part_index)
        part.write(observation.model_dump(mode="json"))
        self.record_counts[observation.collector_id] = (
            self.record_counts.get(observation.collector_id, 0) + 1
        )

    def write_event(self, event: EventRecord) -> None:
        part_index = self._part_index(event.ts_mono_ns)
        part = self._part_for("events", part_index)
        part.write(event.model_dump(mode="json"))
        self.record_counts["events"] = self.record_counts.get("events", 0) + 1

    def close(self) -> None:
        for part in list(self._parts.values()):
            part.close(self.fsync_parts)
        self._parts.clear()

    def __enter__(self) -> "RotatingRawWriter":
        return self

    def __exit__(self, exc_type, exc, traceback) -> None:
        self.close()


def _compression_from_path(path: Path) -> str:
    if path.suffix == ".zst":
        return "zstd"
    if path.suffix == ".gz":
        return "gzip"
    return "uncompressed"


def iter_jsonl(path: Path) -> Iterator[dict]:
    raw_stream = pa.OSFile(str(path), "rb")
    compression = _compression_from_path(path)
    stream: pa.NativeFile
    if compression == "uncompressed":
        stream = raw_stream
    else:
        stream = pa.CompressedInputStream(raw_stream, compression)
    buffer = b""
    try:
        while True:
            chunk = stream.read(1024 * 1024)
            if not chunk:
                break
            buffer += chunk
            lines = buffer.split(b"\n")
            buffer = lines.pop()
            for line in lines:
                if line:
                    yield json.loads(line)
        if buffer:
            yield json.loads(buffer)
    finally:
        stream.close()
        if not raw_stream.closed:
            raw_stream.close()


def iter_run_observations(run_dir: Path) -> Iterator[dict]:
    pattern = "raw/observations/collector=*/part-*.jsonl.*"
    for path in sorted(run_dir.glob(pattern)):
        yield from iter_jsonl(path)


def iter_run_events(run_dir: Path) -> Iterator[dict]:
    for path in sorted((run_dir / "raw" / "events").glob("part-*.jsonl.*")):
        yield from iter_jsonl(path)

