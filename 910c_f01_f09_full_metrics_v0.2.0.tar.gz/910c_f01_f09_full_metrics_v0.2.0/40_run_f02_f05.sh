#!/usr/bin/env bash
set -Eeuo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
exec "$ROOT/_run_batch.sh" "${FAULTS:-F02,F05}" "${INTENSITIES:-10,20,40}" "${REPEATS:-1}"
