#!/usr/bin/env bash
set -Eeuo pipefail
umask 077
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
OUTPUT_ROOT="${HGNN_OUTPUT_ROOT:-$(cd "$ROOT/.." && pwd)/910c_f01_f09_outputs}"
RETURN_ROOT="${HGNN_RETURN_ROOT:-$(cd "$ROOT/.." && pwd)/return_bundles}"
[[ -d "$OUTPUT_ROOT" ]] || { echo "输出目录不存在: $OUTPUT_ROOT" >&2; exit 2; }
mkdir -p "$RETURN_ROOT"
stamp="$(date -u +%Y%m%dT%H%M%SZ)"
bundle_dir="$RETURN_ROOT/910c_f01_f09_results_$stamp"
mkdir -p "$bundle_dir"
cp -a "$OUTPUT_ROOT" "$bundle_dir/outputs"
(
  cd "$bundle_dir"
  find outputs -type f -print0 | sort -z | xargs -0 sha256sum > SHA256SUMS
)
python3 - "$bundle_dir" <<'PY'
import json, platform, sys, time
from pathlib import Path
root = Path(sys.argv[1])
(root / "return_manifest.json").write_text(json.dumps({
    "format_version": "0.2.0", "created_at_utc_ns": time.time_ns(),
    "hostname": platform.node(), "output_dir": "outputs",
    "checksums": "SHA256SUMS",
}, indent=2) + "\n", encoding="utf-8")
PY
tar -C "$RETURN_ROOT" -czf "$bundle_dir.tar.gz" "$(basename "$bundle_dir")"
sha256sum "$bundle_dir.tar.gz" > "$bundle_dir.tar.gz.sha256"
echo "RETURN_BUNDLE=$bundle_dir.tar.gz"
