#!/usr/bin/env bash
set -Eeuo pipefail
umask 077
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
OUTPUT_ROOT="${HGNN_OUTPUT_ROOT:-$(cd "$ROOT/.." && pwd)/910c_f01_f09_outputs}"
DATA_ROOT="${HGNN_DATA_ROOT:-$OUTPUT_ROOT/hgnn_data}"
REPEATS="${REPEATS:-10}"
mkdir -p "$OUTPUT_ROOT" "$DATA_ROOT"
export PYTHONPATH="$ROOT/src${PYTHONPATH:+:$PYTHONPATH}"
for ((i=1; i<=REPEATS; i++)); do
  run_id="$(date -u +%Y%m%dT%H%M%SZ)-noop-control-$(printf '%02d' "$i")"
  python3 -m hgnn_collect --config "$ROOT/config/collector.yaml" collect \
    --duration 300 --run-id "$run_id" --data-root "$DATA_ROOT" \
    --no-workload --allow-postprocess-failure
done
