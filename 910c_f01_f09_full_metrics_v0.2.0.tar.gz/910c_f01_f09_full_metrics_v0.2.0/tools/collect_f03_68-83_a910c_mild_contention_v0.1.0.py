#!/usr/bin/env python3
"""Ascend 910C F03 单卡轻量资源挤占、采集、对齐与导出试点。

默认只输出计划，不执行注入。真正执行必须同时提供 ``run --execute`` 和
环境变量 ``HGNN_F03_APPROVAL=I_ACKNOWLEDGE_SINGLE_NPU_BOUNDED_CONTENTION``。

脚本只在指定 NPU 上启动短时、低占空比 GEMM 噪声进程，不修改风扇、频率、
网络、驱动或持久系统配置。噪声进程退出即完成主要回滚。
"""

from __future__ import annotations

import argparse
import contextlib
import csv
import json
import math
import os
import re
import shutil
import signal
import statistics
import subprocess
import sys
import tarfile
import threading
import time
import traceback
import uuid
from dataclasses import asdict, dataclass, replace
from datetime import datetime, timezone
from html import escape
from pathlib import Path
from typing import Any, Iterable, Iterator, Sequence


SCRIPT_VERSION = "0.1.12"
FAULT_CODE = "F03"
APPROVAL_TOKEN = "I_ACKNOWLEDGE_SINGLE_NPU_BOUNDED_CONTENTION"
ROOT_APPROVAL_TOKEN = "I_ACKNOWLEDGE_HARDENED_ROOT_EXECUTION"
MAX_PILOT_INTENSITY_PCT = 80.0
MAX_TENSOR_DIM = 2048
MAX_STAGE_DURATION_S = 120
MAX_TOTAL_DURATION_S = 900
MAX_HBM_USAGE_PCT = 50.0
MAX_HBM_TEMPERATURE_C = 85.0
MIN_OUTPUT_FREE_BYTES = 2 * 1024**3
VISIBILITY_ENV_VARS = (
    "ASCEND_RT_VISIBLE_DEVICES",
    "ASCEND_VISIBLE_DEVICES",
    "NPU_VISIBLE_DEVICES",
    "CUDA_VISIBLE_DEVICES",
)
UTC = timezone.utc
DEFAULT_CONFIG = (
    Path(__file__).resolve().parents[1]
    / "configs"
    / "pilot_910c_f03_mild_contention.yaml"
)
DEFAULT_OUTPUT_ROOT = Path("/datadisk1/hgnn_fault_evolution_data/f03_pilot_outputs")

TRAINING_FIELDS = [
    "ts_start_utc_ns",
    "ts_end_utc_ns",
    "ts_start_mono_ns",
    "ts_end_mono_ns",
    "stage_id",
    "requested_intensity_pct",
    "step_id",
    "rank_id",
    "device_id",
    "samples",
    "step_time_ms",
    "throughput_sps",
    "loss_value",
    "heartbeat_seq",
    "hbm_alloc_retries",
    "hbm_oom_count",
    "profiler_active",
]

INJECTOR_FIELDS = [
    "ts_utc_ns",
    "ts_mono_ns",
    "stage_id",
    "device_id",
    "requested_intensity_pct",
    "measured_duty_pct",
    "window_elapsed_ms",
    "active_ms",
    "op_count",
    "tensor_dim",
]

SAFETY_FIELDS = [
    "ts_utc_ns",
    "ts_utc_iso",
    "ts_mono_ns",
    "elapsed_s",
    "stage_id",
    "requested_intensity_pct",
    "device_id",
    "npu_temperature_c",
    "npu_power_w",
    "npu_utilization_pct",
    "hbm_used_bytes",
    "hbm_total_bytes",
    "hbm_utilization_pct",
    "hbm_temperature_c",
    "npu_health_state",
    "npu_process_count",
    "unexpected_npu_pids",
    "missing_expected_npu_pids",
    "output_free_bytes",
    "target_alive",
    "injector_alive",
    "heartbeat_age_s",
    "sample_status",
    "sample_error",
]


@dataclass(frozen=True)
class StageSpec:
    stage_id: str
    label: str
    requested_intensity_pct: float
    duration_s: int
    inject: bool
    profile: bool


@dataclass(frozen=True)
class PilotPlan:
    device_id: int
    torch_device_id: int | None
    stages: tuple[StageSpec, ...]
    sample_interval_s: float
    detail_interval_s: float
    tensor_dim: int
    max_temperature_c: float
    heartbeat_timeout_s: float
    profiler_enabled: bool
    hgnn_collector_enabled: bool

    @property
    def duration_s(self) -> int:
        return sum(stage.duration_s for stage in self.stages)

    def validate(self) -> None:
        if self.device_id < 0:
            raise ValueError("device_id must be non-negative")
        if self.torch_device_id is not None and self.torch_device_id < 0:
            raise ValueError("torch_device_id must be non-negative")
        if not self.stages:
            raise ValueError("at least one stage is required")
        if self.duration_s > MAX_TOTAL_DURATION_S:
            raise ValueError(
                f"total duration {self.duration_s}s exceeds {MAX_TOTAL_DURATION_S}s"
            )
        if not 0.2 <= self.sample_interval_s <= 10:
            raise ValueError("sample_interval_s must be in [0.2, 10]")
        if self.detail_interval_s < self.sample_interval_s:
            raise ValueError("detail_interval_s cannot be shorter than sample interval")
        if not 256 <= self.tensor_dim <= MAX_TENSOR_DIM:
            raise ValueError(f"tensor_dim must be in [256, {MAX_TENSOR_DIM}]")
        if not 40 <= self.max_temperature_c <= 75:
            raise ValueError("max_temperature_c must be in [40, 75]")
        if self.heartbeat_timeout_s < 2:
            raise ValueError("heartbeat_timeout_s must be >= 2")
        for stage in self.stages:
            if not 1 <= stage.duration_s <= MAX_STAGE_DURATION_S:
                raise ValueError(
                    f"{stage.stage_id} duration must be in [1, {MAX_STAGE_DURATION_S}]"
                )
            if not 0 <= stage.requested_intensity_pct <= MAX_PILOT_INTENSITY_PCT:
                raise ValueError(
                    f"{stage.stage_id} intensity exceeds safe pilot bound "
                    f"{MAX_PILOT_INTENSITY_PCT}%"
                )
            if stage.inject and stage.requested_intensity_pct <= 0:
                raise ValueError(f"{stage.stage_id} inject stage requires positive intensity")
            if not stage.inject and stage.requested_intensity_pct != 0:
                raise ValueError(
                    f"{stage.stage_id} non-injection stage must have zero intensity"
                )


@dataclass
class CommandResult:
    argv: list[str]
    returncode: int
    stdout: str
    stderr: str
    duration_s: float
    error: str | None = None


@dataclass
class NpuSummary:
    device_id: int
    card_id: int
    chip_id: int
    health: str
    power_w: float
    temperature_c: float
    utilization_pct: float
    hbm_used_mb: int
    hbm_total_mb: int
    product: str
    bus_id: str


def utc_iso(timestamp_ns: int) -> str:
    value = datetime.fromtimestamp(timestamp_ns / 1_000_000_000, UTC)
    return value.isoformat(timespec="milliseconds").replace("+00:00", "Z")


def numeric(value: Any) -> float | None:
    if value is None or isinstance(value, bool):
        return None
    try:
        converted = float(str(value).strip().rstrip("%"))
    except (TypeError, ValueError):
        return None
    return converted if math.isfinite(converted) else None


def percentile(values: Sequence[float], q: float) -> float | None:
    finite = sorted(value for value in values if math.isfinite(value))
    if not finite:
        return None
    if len(finite) == 1:
        return finite[0]
    position = (len(finite) - 1) * q
    lower = int(math.floor(position))
    upper = int(math.ceil(position))
    if lower == upper:
        return finite[lower]
    weight = position - lower
    return finite[lower] * (1 - weight) + finite[upper] * weight


def atomic_write_json(path: Path, payload: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    with temporary.open("w", encoding="utf-8") as handle:
        json.dump(payload, handle, ensure_ascii=False, indent=2, sort_keys=True)
        handle.write("\n")
        handle.flush()
        os.fsync(handle.fileno())
    temporary.replace(path)


def append_jsonl(path: Path, payload: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    line = json.dumps(payload, ensure_ascii=False, sort_keys=True) + "\n"
    with path.open("a", encoding="utf-8") as handle:
        handle.write(line)
        handle.flush()


def read_json(path: Path, default: Any = None) -> Any:
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return default


def run_command(
    argv: Sequence[str],
    *,
    timeout_s: float = 10,
    env: dict[str, str] | None = None,
) -> CommandResult:
    started = time.monotonic()
    try:
        result = subprocess.run(
            list(argv),
            capture_output=True,
            text=True,
            timeout=timeout_s,
            env=env,
            check=False,
        )
        return CommandResult(
            argv=list(argv),
            returncode=result.returncode,
            stdout=result.stdout,
            stderr=result.stderr,
            duration_s=time.monotonic() - started,
        )
    except (OSError, subprocess.TimeoutExpired) as error:
        stdout = error.stdout if isinstance(error, subprocess.TimeoutExpired) else ""
        stderr = error.stderr if isinstance(error, subprocess.TimeoutExpired) else ""
        return CommandResult(
            argv=list(argv),
            returncode=124 if isinstance(error, subprocess.TimeoutExpired) else 127,
            stdout=stdout or "",
            stderr=stderr or "",
            duration_s=time.monotonic() - started,
            error=f"{type(error).__name__}: {error}",
        )


def parse_key_value_output(output: str) -> dict[str, str]:
    values: dict[str, str] = {}
    for line in output.splitlines():
        if ":" not in line:
            continue
        key, value = line.split(":", 1)
        values[key.strip()] = value.strip()
    return values


def parse_npu_summary(output: str) -> list[NpuSummary]:
    rows = [line for line in output.splitlines() if line.lstrip().startswith("|")]
    summaries: list[NpuSummary] = []
    pending: dict[str, Any] | None = None
    card_power: dict[int, float] = {}
    for line in rows:
        cells = [cell.strip() for cell in line.split("|")[1:-1]]
        if len(cells) != 3:
            continue
        first = cells[0].split(maxsplit=1)
        if (
            len(first) == 2
            and first[0].isdigit()
            and first[1] not in {"NPU", "Chip"}
            and not first[1].isdigit()
            and re.search(r"\d", cells[2])
        ):
            match = re.match(
                r"^\s*([0-9.]+|-)\s+(-?[0-9.]+)\s+(\d+)\s*/\s*(\d+)\s*$",
                cells[2],
            )
            if match:
                card_id = int(first[0])
                power = (
                    float(match.group(1))
                    if match.group(1) != "-"
                    else card_power.get(card_id)
                )
                if power is not None:
                    card_power[card_id] = power
                pending = {
                    "card_id": card_id,
                    "product": first[1],
                    "health": cells[1],
                    "power_w": power,
                    "temperature_c": float(match.group(2)),
                }
            continue
        if pending is None:
            continue
        second = re.match(
            r"^\s*([0-9.]+)\s+(\d+)\s*/\s*(\d+)\s+(\d+)\s*/\s*(\d+)\s*$",
            cells[2],
        )
        chip_parts = cells[0].split()
        if second and chip_parts and chip_parts[0].isdigit():
            chip_id = int(chip_parts[0])
            device_id = (
                int(chip_parts[1])
                if len(chip_parts) > 1 and chip_parts[1].isdigit()
                else int(pending["card_id"])
            )
            summaries.append(
                NpuSummary(
                    device_id=device_id,
                    card_id=int(pending["card_id"]),
                    chip_id=chip_id,
                    health=str(pending["health"]),
                    power_w=float(pending["power_w"] or 0.0),
                    temperature_c=float(pending["temperature_c"]),
                    utilization_pct=float(second.group(1)),
                    hbm_used_mb=int(second.group(4)),
                    hbm_total_mb=int(second.group(5)),
                    product=str(pending["product"]),
                    bus_id=cells[1],
                )
            )
            pending = None
    return summaries


def query_npu_summary(device_id: int) -> tuple[NpuSummary | None, str | None]:
    result = run_command(["npu-smi", "info"], timeout_s=8)
    if result.returncode != 0:
        detail = result.error or result.stderr.strip() or result.stdout.strip()
        return None, f"npu-smi info failed: {detail[:500]}"
    for summary in parse_npu_summary(result.stdout):
        if summary.device_id == device_id:
            return summary, None
    return None, f"device {device_id} not found in npu-smi summary"


def query_npu_processes(
    device_id: int,
) -> tuple[list[dict[str, Any]] | None, str | None]:
    result = run_command(["npu-smi", "info"], timeout_s=8)
    if result.returncode != 0:
        detail = result.error or result.stderr.strip() or result.stdout.strip()
        return None, f"npu-smi process table failed: {detail[:500]}"
    summaries = parse_npu_summary(result.stdout)
    target = next(
        (summary for summary in summaries if summary.device_id == device_id),
        None,
    )
    if target is None:
        return None, f"unable to map physical device {device_id} to NPU/chip"
    in_process_table = False
    processes: list[dict[str, Any]] = []
    saw_device_evidence = False
    no_process_pattern = re.compile(
        rf"No running processes found in NPU\s+{target.card_id}\b",
        re.IGNORECASE,
    )
    for line in result.stdout.splitlines():
        if "Process id" in line and "Process name" in line:
            in_process_table = True
            continue
        if not in_process_table:
            continue
        if no_process_pattern.search(line):
            saw_device_evidence = True
            continue
        if not line.lstrip().startswith("|"):
            continue
        cells = [cell.strip() for cell in line.split("|")[1:-1]]
        if len(cells) < 4:
            continue
        device_chip = cells[0].split()
        if not device_chip or not device_chip[0].isdigit():
            continue
        if int(device_chip[0]) != target.card_id:
            continue
        if not cells[1].isdigit():
            continue
        saw_device_evidence = True
        row_chip_id = (
            int(device_chip[1])
            if len(device_chip) > 1 and device_chip[1].isdigit()
            else None
        )
        row_summary = next(
            (
                summary
                for summary in summaries
                if summary.card_id == target.card_id
                and (row_chip_id is None or summary.chip_id == row_chip_id)
            ),
            None,
        )
        processes.append(
            {
                "device_id": row_summary.device_id if row_summary else None,
                "selected_device_id": device_id,
                "card_id": target.card_id,
                "chip_id": row_chip_id,
                "on_selected_chip": row_chip_id in {None, target.chip_id},
                "pid": int(cells[1]),
                "process_name": cells[2],
                "process_memory_mb": numeric(cells[3]),
            }
        )
    if not saw_device_evidence:
        return None, f"unable to prove process scope for NPU {device_id}"
    return processes, None


def query_hbm_temperature(
    summary: NpuSummary,
) -> tuple[float | None, str | None]:
    result = run_command(
        [
            "npu-smi",
            "info",
            "-t",
            "memory",
            "-i",
            str(summary.card_id),
            "-c",
            str(summary.chip_id),
        ],
        timeout_s=6,
    )
    if result.returncode != 0:
        detail = result.error or result.stderr.strip() or result.stdout.strip()
        return None, f"npu-smi memory failed: {detail[:500]}"
    values = parse_key_value_output(result.stdout)
    for key in (
        "HBM Temperature(C)",
        "HBM Temperature",
        "HBM Temp(C)",
    ):
        temperature = numeric(values.get(key))
        if temperature is not None:
            return temperature, None
    return None, "HBM temperature field not found"


def query_phyid_remap(
    physical_id: int,
) -> tuple[dict[str, int] | None, str | None]:
    result = run_command(
        [
            "npu-smi",
            "info",
            "-t",
            "phyid-remap",
            "-p",
            str(physical_id),
        ],
        timeout_s=8,
    )
    if result.returncode != 0:
        detail = result.error or result.stderr.strip() or result.stdout.strip()
        return None, f"npu-smi phyid-remap failed: {detail[:500]}"
    values = parse_key_value_output(result.stdout)
    aliases = {
        "physical_id": ("Chip Physical ID", "Physical ID"),
        "logic_id": ("Chip Logic ID", "Logic ID"),
        "card_id": ("NPU ID", "Device ID"),
        "chip_id": ("Chip ID",),
    }
    parsed: dict[str, int] = {}
    for output_key, candidates in aliases.items():
        value: float | None = None
        for candidate in candidates:
            value = numeric(values.get(candidate))
            if value is not None:
                break
        if value is None or not float(value).is_integer():
            return None, f"phyid-remap field missing or invalid: {candidates[0]}"
        parsed[output_key] = int(value)
    if parsed["physical_id"] != physical_id:
        return None, (
            f"phyid-remap returned physical {parsed['physical_id']} "
            f"for requested {physical_id}"
        )
    return parsed, None


def parse_intensities(text: str) -> tuple[float, ...]:
    values: list[float] = []
    for item in text.split(","):
        item = item.strip()
        if not item:
            continue
        value = float(item)
        if value <= 0:
            raise ValueError("injection intensities must be positive; baseline is automatic")
        if value > MAX_PILOT_INTENSITY_PCT:
            raise ValueError(
                f"intensity {value} exceeds pilot maximum {MAX_PILOT_INTENSITY_PCT}"
            )
        values.append(value)
    if not values:
        raise ValueError("at least one positive intensity is required")
    if values != sorted(set(values)):
        raise ValueError("intensities must be unique and strictly increasing")
    return tuple(values)


def build_plan(args: argparse.Namespace) -> PilotPlan:
    intensities = parse_intensities(args.intensities)
    stages: list[StageSpec] = [
        StageSpec("WARMUP", "目标负载预热", 0.0, args.warmup_duration, False, False),
        StageSpec(
            "T0_BASELINE",
            "无注入基线",
            0.0,
            args.stage_duration,
            False,
            args.enable_profiler,
        ),
    ]
    for index, intensity in enumerate(intensities, start=1):
        suffix = f"{intensity:g}".replace(".", "p")
        stages.append(
            StageSpec(
                f"F03_I{index}_{suffix}PCT",
                f"F03 资源挤占 {intensity:g}%",
                intensity,
                args.stage_duration,
                True,
                args.enable_profiler,
            )
        )
    stages.append(
        StageSpec(
            "T2_RECOVERY",
            "停止注入后的恢复窗口",
            0.0,
            args.recovery_duration,
            False,
            False,
        )
    )
    plan = PilotPlan(
        device_id=args.device_id,
        torch_device_id=getattr(args, "torch_device_id", None),
        stages=tuple(stages),
        sample_interval_s=args.sample_interval,
        detail_interval_s=args.detail_interval,
        tensor_dim=args.tensor_dim,
        max_temperature_c=args.max_temperature_c,
        heartbeat_timeout_s=args.heartbeat_timeout,
        profiler_enabled=args.enable_profiler,
        hgnn_collector_enabled=not args.skip_hgnn_collector,
    )
    plan.validate()
    return plan


def plan_payload(plan: PilotPlan) -> dict[str, Any]:
    plan.validate()
    offsets: list[dict[str, Any]] = []
    cursor = 0
    for stage in plan.stages:
        offsets.append(
            {
                **asdict(stage),
                "start_offset_s": cursor,
                "end_offset_s": cursor + stage.duration_s,
            }
        )
        cursor += stage.duration_s
    return {
        "script_version": SCRIPT_VERSION,
        "fault_code": FAULT_CODE,
        "scope": "single_selected_npu_process_only",
        "dry_run_default": True,
        "persistent_system_changes": False,
        "maximum_intensity_pct": MAX_PILOT_INTENSITY_PCT,
        "device_id": plan.device_id,
        "torch_device_id": plan.torch_device_id,
        "duration_s": plan.duration_s,
        "stages": offsets,
        "sample_interval_s": plan.sample_interval_s,
        "detail_interval_s": plan.detail_interval_s,
        "tensor_dim": plan.tensor_dim,
        "max_temperature_c": plan.max_temperature_c,
        "heartbeat_timeout_s": plan.heartbeat_timeout_s,
        "profiler_enabled": plan.profiler_enabled,
        "hgnn_collector_enabled": plan.hgnn_collector_enabled,
        "expected_response": {
            "must_change": ["injection.measured_duty_pct"],
            "expected_increase": [
                "global_task.step_time_ms",
                "npu.utilization_pct (unless baseline is saturated)",
                "npu.power_w",
                "npu.temperature_c (with thermal lag)",
            ],
            "expected_decrease": ["global_task.throughput_sps"],
            "diagnostic_not_forced_monotonic": [
                "npu.aicore_stall_ratio",
                "hbm.read_gbps",
                "hbm.write_gbps",
                "global_task.loss_value",
            ],
        },
    }


def write_csv(path: Path, rows: Iterable[dict[str, Any]], fields: Sequence[str]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(fields), extrasaction="ignore")
        writer.writeheader()
        for row in rows:
            writer.writerow(row)


def read_csv(path: Path) -> list[dict[str, str]]:
    if not path.is_file():
        return []
    with path.open("r", encoding="utf-8-sig", newline="") as handle:
        return list(csv.DictReader(handle))


def append_csv_row(
    handle: Any,
    writer: csv.DictWriter[str],
    row: dict[str, Any],
) -> None:
    writer.writerow(row)
    handle.flush()


def profiler_capability() -> dict[str, Any]:
    result: dict[str, Any] = {
        "torch_available": False,
        "torch_npu_available": False,
        "profiler_available": False,
        "resource_conflict_ratio_available": False,
        "details": [],
    }
    try:
        import torch  # type: ignore

        result["torch_available"] = True
        result["torch_version"] = getattr(torch, "__version__", "unknown")
        result["npu_available"] = bool(
            hasattr(torch, "npu") and torch.npu.is_available()
        )
        result["npu_device_count"] = (
            int(torch.npu.device_count()) if result["npu_available"] else 0
        )
    except Exception as error:
        result["details"].append(f"torch import failed: {type(error).__name__}: {error}")
        return result
    try:
        import torch_npu  # type: ignore

        result["torch_npu_available"] = True
        result["torch_npu_version"] = getattr(torch_npu, "__version__", "unknown")
        profiler = getattr(torch_npu, "profiler", None)
        if profiler is None:
            import torch_npu.profiler as profiler  # type: ignore

        required = ("profile", "schedule", "tensorboard_trace_handler")
        result["profiler_available"] = all(hasattr(profiler, name) for name in required)
        metrics = getattr(profiler, "AiCMetrics", None)
        if metrics is not None:
            names = [name for name in dir(metrics) if not name.startswith("_")]
            result["aic_metric_names"] = names
            result["resource_conflict_ratio_available"] = any(
                name.lower() == "resourceconflictratio" for name in names
            )
        else:
            result["details"].append("torch_npu.profiler.AiCMetrics is missing")
    except Exception as error:
        result["details"].append(
            f"torch_npu profiler import failed: {type(error).__name__}: {error}"
        )
    return result


def preflight(
    plan: PilotPlan,
    *,
    output_root: Path,
    config_path: Path,
    allow_busy_device: bool,
    require_reporting_dependencies: bool,
) -> dict[str, Any]:
    plan.validate()
    checks: list[dict[str, Any]] = []

    def add(name: str, passed: bool, detail: Any, *, blocking: bool = True) -> None:
        checks.append(
            {
                "check": name,
                "passed": bool(passed),
                "blocking": blocking,
                "detail": detail,
            }
        )

    npu_smi = shutil.which("npu-smi")
    add("npu_smi_binary", npu_smi is not None, npu_smi or "not found")
    summary, summary_error = query_npu_summary(plan.device_id) if npu_smi else (None, "")
    add(
        "selected_npu_visible",
        summary is not None,
        asdict(summary) if summary else summary_error,
    )
    if summary is not None:
        health_ok = summary.health.strip().upper() in {"OK", "NORMAL", "HEALTHY"}
        add("selected_npu_health", health_ok, summary.health)
        add(
            "start_temperature",
            summary.temperature_c < plan.max_temperature_c - 3,
            {
                "current_c": summary.temperature_c,
                "execution_limit_c": plan.max_temperature_c,
                "required_headroom_c": 3,
            },
        )
        used_pct = (
            100 * summary.hbm_used_mb / summary.hbm_total_mb
            if summary.hbm_total_mb
            else 100.0
        )
        idle_ok = summary.utilization_pct <= 10 and used_pct <= 20
        add(
            "reserved_or_idle_npu",
            idle_ok or allow_busy_device,
            {
                "utilization_pct": summary.utilization_pct,
                "hbm_used_pct": used_pct,
                "allow_busy_device": allow_busy_device,
                "note": (
                    "默认要求使用空闲/已预留单卡，避免影响其他任务；"
                    "--allow-busy-device 只应用于已获批准的目标训练任务"
                ),
            },
        )
        processes, process_error = query_npu_processes(plan.device_id)
        add(
            "selected_npu_has_no_processes",
            (processes == []) or allow_busy_device,
            {
                "processes": processes,
                "error": process_error,
                "allow_busy_device": allow_busy_device,
                "note": "无法证明进程为空时默认拒绝执行",
            },
        )
        hbm_temperature, hbm_temperature_error = query_hbm_temperature(summary)
        add(
            "hbm_start_temperature",
            hbm_temperature is not None
            and hbm_temperature < MAX_HBM_TEMPERATURE_C - 5,
            {
                "current_c": hbm_temperature,
                "execution_limit_c": MAX_HBM_TEMPERATURE_C,
                "required_headroom_c": 5,
                "error": hbm_temperature_error,
            },
        )

    try:
        output_root.mkdir(parents=True, exist_ok=True)
        usage = shutil.disk_usage(output_root)
        free_gib = usage.free / (1024**3)
        add("output_disk_free", free_gib >= 2, {"free_gib": round(free_gib, 3)})
    except OSError as error:
        add("output_directory", False, f"{type(error).__name__}: {error}")

    add("pilot_config", config_path.is_file(), str(config_path))
    project_root = Path(__file__).resolve().parents[1]
    collector_import = run_command(
        [
            sys.executable,
            "-c",
            (
                "import sys;"
                f"sys.path.insert(0,{str(project_root / 'src')!r});"
                "import hgnn_collect;print(hgnn_collect.__file__)"
            ),
        ],
        timeout_s=10,
    )
    add(
        "hgnn_collector_import",
        (not plan.hgnn_collector_enabled) or collector_import.returncode == 0,
        {
            "enabled": plan.hgnn_collector_enabled,
            "stdout": collector_import.stdout.strip(),
            "stderr": collector_import.stderr.strip(),
        },
    )

    capability = profiler_capability()
    add(
        "torch_npu",
        capability["torch_npu_available"] and capability.get("npu_available", False),
        capability,
    )
    inventory_result = run_command(["npu-smi", "info"], timeout_s=8)
    physical_ids = (
        sorted(
            item.device_id
            for item in parse_npu_summary(inventory_result.stdout)
        )
        if inventory_result.returncode == 0
        else []
    )
    visibility = {
        name: os.environ.get(name)
        for name in VISIBILITY_ENV_VARS
        if os.environ.get(name) not in {None, ""}
    }
    torch_device_count = int(capability.get("npu_device_count", 0))
    device_mapping, remap_error = query_phyid_remap(plan.device_id)
    identity_ok = (
        not visibility
        and device_mapping is not None
        and torch_device_count == len(physical_ids)
        and plan.device_id in physical_ids
        and 0 <= int(device_mapping["logic_id"]) < torch_device_count
        and (
            summary is not None
            and int(device_mapping["card_id"]) == summary.card_id
            and int(device_mapping["chip_id"]) == summary.chip_id
        )
        and (
            plan.torch_device_id is None
            or plan.torch_device_id == int(device_mapping["logic_id"])
        )
    )
    add(
        "physical_to_torch_device_identity",
        identity_ok,
        {
            "visibility_environment": visibility,
            "npu_smi_physical_ids": physical_ids,
            "torch_npu_device_count": torch_device_count,
            "selected_physical_id": plan.device_id,
            "phyid_remap": device_mapping,
            "phyid_remap_error": remap_error,
            "requested_torch_device_id": plan.torch_device_id,
            "note": (
                "使用npu-smi phyid-remap返回的Chip Logic ID作为torch逻辑索引；"
                "同时禁止可见设备环境变量造成二次重编号"
            ),
        },
    )
    if plan.profiler_enabled:
        add("torch_npu_profiler", capability["profiler_available"], capability)
        add(
            "resource_conflict_ratio",
            capability["resource_conflict_ratio_available"],
            capability,
        )

    dependencies: dict[str, bool] = {}
    for module_name in (
        "openpyxl",
        "matplotlib",
        "pyarrow",
        "yaml",
        "pydantic",
        "psutil",
    ):
        try:
            __import__(module_name)
            dependencies[module_name] = True
        except Exception:
            dependencies[module_name] = False
    add(
        "reporting_dependencies",
        (not require_reporting_dependencies)
        or (dependencies["openpyxl"] and dependencies["matplotlib"]),
        dependencies,
        blocking=require_reporting_dependencies,
    )
    if plan.hgnn_collector_enabled:
        add(
            "collector_dependencies",
            dependencies["pyarrow"]
            and dependencies["yaml"]
            and dependencies["pydantic"]
            and dependencies["psutil"],
            dependencies,
        )

    blocking_failures = [
        item["check"] for item in checks if item["blocking"] and not item["passed"]
    ]
    return {
        "passed": not blocking_failures,
        "blocking_failures": blocking_failures,
        "checks": checks,
        "plan": plan_payload(plan),
        "device_mapping": device_mapping,
        "generated_at_utc_ns": time.time_ns(),
    }


def _ratio(value: Any) -> float | None:
    converted = numeric(value)
    if converted is None or converted < 0:
        return None
    if converted <= 1:
        return converted
    if converted <= 100:
        return converted / 100
    return None


def _field(row: dict[str, Any], *candidates: str) -> Any:
    normalized = {
        re.sub(r"[^a-z0-9]", "", key.lower()): value for key, value in row.items()
    }
    for candidate in candidates:
        key = re.sub(r"[^a-z0-9]", "", candidate.lower())
        if key in normalized:
            return normalized[key]
    return None


def parse_resource_conflict_file(path: Path) -> dict[str, Any]:
    """解析 ResourceConflictRatio 相关 CSV 并生成可审计的 wait/stall 聚合。

    ``npu.aicore_stall_ratio`` 使用 cube wait 与 vector wait 按各自 total cycles
    加权。若当前 torch_npu 只在 kernel/op summary 中导出 ``*_cflt_ratio``，
    则使用每行最大冲突比例作为诊断代理，仍不把冲突分量直接相加。
    """

    rows = read_csv(path)
    numerator = 0.0
    denominator = 0.0
    conflict_numerator = 0.0
    conflict_denominator = 0.0
    fallback_wait: list[float] = []
    fallback_conflict: list[float] = []
    components: dict[str, list[float]] = {
        "aic_cube_wait_ratio": [],
        "aiv_vec_wait_ratio": [],
        "aiv_vec_total_cflt_ratio": [],
        "aiv_vec_bankgroup_cflt_ratio": [],
        "aiv_vec_bank_cflt_ratio": [],
        "aiv_vec_resc_cflt_ratio": [],
        "aiv_vec_mte_cflt_ratio": [],
    }
    valid_rows = 0
    for row in rows:
        aic_cycles = numeric(_field(row, "aic_total_cycles")) or 0.0
        aiv_cycles = numeric(_field(row, "aiv_total_cycles")) or 0.0
        aic_wait = _ratio(_field(row, "aic_cube_wait_ratio"))
        aiv_wait = _ratio(_field(row, "aiv_vec_wait_ratio"))
        if aic_wait is not None:
            components["aic_cube_wait_ratio"].append(aic_wait)
            fallback_wait.append(aic_wait)
            if aic_cycles > 0:
                numerator += aic_wait * aic_cycles
                denominator += aic_cycles
        if aiv_wait is not None:
            components["aiv_vec_wait_ratio"].append(aiv_wait)
            fallback_wait.append(aiv_wait)
            if aiv_cycles > 0:
                numerator += aiv_wait * aiv_cycles
                denominator += aiv_cycles
        row_conflict_values: list[float] = []
        for key in (
            "aiv_vec_total_cflt_ratio",
            "aiv_vec_bankgroup_cflt_ratio",
            "aiv_vec_bank_cflt_ratio",
            "aiv_vec_resc_cflt_ratio",
            "aiv_vec_mte_cflt_ratio",
        ):
            value = _ratio(_field(row, key))
            if value is not None:
                components[key].append(value)
                row_conflict_values.append(value)
        if row_conflict_values:
            conflict_ratio = max(row_conflict_values)
            fallback_conflict.append(conflict_ratio)
            if aiv_cycles > 0:
                conflict_numerator += conflict_ratio * aiv_cycles
                conflict_denominator += aiv_cycles
        if aic_wait is not None or aiv_wait is not None:
            valid_rows += 1
        elif row_conflict_values:
            valid_rows += 1
    stall = (
        numerator / denominator
        if denominator > 0
        else statistics.fmean(fallback_wait)
        if fallback_wait
        else conflict_numerator / conflict_denominator
        if conflict_denominator > 0
        else statistics.fmean(fallback_conflict)
        if fallback_conflict
        else None
    )
    component_summary = {
        key: statistics.fmean(values) if values else None
        for key, values in components.items()
    }
    return {
        "source_path": str(path),
        "source_rows": len(rows),
        "valid_wait_rows": valid_rows,
        "npu.aicore_stall_ratio": stall,
        "formula": (
            "sum(aic_cube_wait_ratio*aic_total_cycles + "
            "aiv_vec_wait_ratio*aiv_total_cycles) / sum(cycles); "
            "fallback=max(aiv_vec_*_cflt_ratio) weighted by aiv_total_cycles"
        ),
        "formula_version": "resource_conflict_wait_or_cflt_proxy_v2",
        "components": component_summary,
    }


def parse_step_trace_file(path: Path) -> dict[str, Any]:
    rows = read_csv(path)
    step_times: list[float] = []
    overlap_ratios: list[float] = []
    for row in rows:
        stage_us = numeric(_field(row, "Stage"))
        communication_us = numeric(_field(row, "Communication"))
        overlapped_us = numeric(_field(row, "Overlapped"))
        if stage_us is not None:
            step_times.append(stage_us / 1000)
        if (
            communication_us is not None
            and communication_us > 0
            and overlapped_us is not None
        ):
            overlap_ratios.append(100 * overlapped_us / communication_us)
    return {
        "source_path": str(path),
        "source_rows": len(rows),
        "global_task.step_time_ms": (
            statistics.fmean(step_times) if step_times else None
        ),
        "global_task.step_time_p95_ms": percentile(step_times, 0.95),
        "global_task.comm_compute_overlap_pct": (
            statistics.fmean(overlap_ratios) if overlap_ratios else None
        ),
        "overlap_formula": "Overlapped / Communication * 100",
    }


def parse_hbm_profile_file(path: Path) -> dict[str, Any]:
    rows = read_csv(path)
    selected = next(
        (
            row
            for row in rows
            if str(_field(row, "Metric", "Task") or "").strip().lower() == "average"
        ),
        rows[0] if rows else None,
    )
    if selected is None:
        return {"source_path": str(path), "source_rows": 0}
    read_mbps = numeric(_field(selected, "Read(MB/s)", "Read MB/s"))
    write_mbps = numeric(_field(selected, "Write(MB/s)", "Write MB/s"))
    return {
        "source_path": str(path),
        "source_rows": len(rows),
        "hbm.read_gbps": read_mbps / 1024 if read_mbps is not None else None,
        "hbm.write_gbps": write_mbps / 1024 if write_mbps is not None else None,
        "conversion": "profiler MB/s / 1024",
    }


def detect_stage_from_path(path: Path, stage_ids: Sequence[str]) -> str | None:
    lowered = str(path).lower()
    for stage_id in sorted(stage_ids, key=len, reverse=True):
        if stage_id.lower() in lowered:
            return stage_id
    return None


def profiler_files(root: Path) -> dict[str, list[Path]]:
    result: dict[str, list[Path]] = {
        "resource_conflict": [],
        "step_trace": [],
        "hbm": [],
    }
    if not root.is_dir():
        return result
    for path in root.rglob("*.csv"):
        name = path.name.lower()
        if "resourceconflictratio" in name or (
            "resource" in name and "conflict" in name
        ):
            result["resource_conflict"].append(path)
        elif name == "kernel_details.csv" or name.startswith("op_summary"):
            header = path.read_text(
                encoding="utf-8-sig",
                errors="replace",
            ).splitlines()[:1]
            normalized = header[0].lower() if header else ""
            if "aic_total_cycles" in normalized and "aiv_vec_" in normalized:
                result["resource_conflict"].append(path)
        elif name == "step_trace_time.csv" or "step_trace" in name:
            result["step_trace"].append(path)
        elif name.startswith("hbm") and "memory" not in name:
            result["hbm"].append(path)
    return {key: sorted(set(paths)) for key, paths in result.items()}


def parse_profiler_tree(
    root: Path, stage_ids: Sequence[str]
) -> tuple[list[dict[str, Any]], dict[str, Any]]:
    files = profiler_files(root)
    records: list[dict[str, Any]] = []
    errors: list[dict[str, str]] = []
    parsers = {
        "resource_conflict": parse_resource_conflict_file,
        "step_trace": parse_step_trace_file,
        "hbm": parse_hbm_profile_file,
    }
    for source_type, paths in files.items():
        for path in paths:
            try:
                payload = parsers[source_type](path)
                payload["source_type"] = source_type
                payload["stage_id"] = detect_stage_from_path(path, stage_ids)
                records.append(payload)
            except Exception as error:
                errors.append(
                    {
                        "path": str(path),
                        "error": f"{type(error).__name__}: {error}",
                    }
                )
    return records, {
        "root": str(root),
        "files": {
            source_type: [str(path) for path in paths]
            for source_type, paths in files.items()
        },
        "errors": errors,
    }


def _enum_member(enum_type: Any, name: str) -> Any | None:
    target = name.lower().replace("_", "")
    for candidate in dir(enum_type):
        if candidate.lower().replace("_", "") == target:
            return getattr(enum_type, candidate)
    return None


def _create_stage_profiler(
    output_root: Path,
    stage_id: str,
    event_path: Path,
) -> tuple[Any | None, int]:
    """创建短窗口 torch_npu profiler；失败时仅记录事件，不中断主采集。"""

    try:
        import torch_npu  # type: ignore

        profiler = getattr(torch_npu, "profiler", None)
        if profiler is None:
            import torch_npu.profiler as profiler  # type: ignore

        activities_enum = getattr(profiler, "ProfilerActivity")
        activities = [
            getattr(activities_enum, "CPU"),
            getattr(activities_enum, "NPU"),
        ]
        stage_dir = output_root / stage_id
        stage_dir.mkdir(parents=True, exist_ok=True)

        experimental = None
        experimental_type = getattr(
            profiler,
            "ExperimentalConfig",
            None,
        ) or getattr(profiler, "_ExperimentalConfig", None)
        metrics_type = getattr(profiler, "AiCMetrics", None)
        level_type = getattr(profiler, "ProfilerLevel", None)
        export_type = getattr(profiler, "ExportType", None)
        resource_metric = (
            _enum_member(metrics_type, "ResourceConflictRatio")
            if metrics_type is not None
            else None
        )
        level1 = (
            _enum_member(level_type, "Level1") if level_type is not None else None
        )
        level0 = (
            _enum_member(level_type, "Level0") if level_type is not None else None
        )
        text_export = (
            _enum_member(export_type, "Text") if export_type is not None else None
        )
        if experimental_type is not None and resource_metric is not None:
            export_candidates = (
                [[text_export], text_export, None]
                if text_export is not None
                else [None]
            )
            candidates: list[dict[str, Any]] = [
                dict(
                    export_type=export,
                    profiler_level=level,
                    aic_metrics=resource_metric,
                    l2_cache=False,
                    data_simplification=False,
                )
                for export in export_candidates
                for level in (level1, level0, None)
            ]
            for kwargs in candidates:
                clean = {key: value for key, value in kwargs.items() if value is not None}
                try:
                    experimental = experimental_type(**clean)
                    break
                except TypeError:
                    continue
        if experimental is None:
            raise RuntimeError(
                "ResourceConflictRatio ExperimentalConfig cannot be constructed"
            )

        handler = profiler.tensorboard_trace_handler(str(stage_dir))
        schedule = profiler.schedule(wait=0, warmup=1, active=5, repeat=1)
        kwargs = {
            "activities": activities,
            "schedule": schedule,
            "on_trace_ready": handler,
            "record_shapes": False,
            "profile_memory": False,
            "with_stack": False,
            "experimental_config": experimental,
        }
        session = profiler.profile(**kwargs)
        session.__enter__()
        append_jsonl(
            event_path,
            {
                "event_type": "PROFILER_STARTED",
                "ts_utc_ns": time.time_ns(),
                "ts_mono_ns": time.monotonic_ns(),
                "stage_id": stage_id,
                "output": str(stage_dir),
                "aic_metrics": "ResourceConflictRatio",
                "active_steps": 5,
            },
        )
        return session, 6
    except Exception as error:
        append_jsonl(
            event_path,
            {
                "event_type": "PROFILER_START_FAILED",
                "ts_utc_ns": time.time_ns(),
                "ts_mono_ns": time.monotonic_ns(),
                "stage_id": stage_id,
                "error": f"{type(error).__name__}: {error}",
                "traceback": traceback.format_exc(limit=8),
            },
        )
        return None, 0


def _close_profiler(session: Any | None, stage_id: str, event_path: Path) -> None:
    if session is None:
        return
    try:
        session.__exit__(None, None, None)
        append_jsonl(
            event_path,
            {
                "event_type": "PROFILER_STOPPED",
                "ts_utc_ns": time.time_ns(),
                "ts_mono_ns": time.monotonic_ns(),
                "stage_id": stage_id,
            },
        )
    except Exception as error:
        append_jsonl(
            event_path,
            {
                "event_type": "PROFILER_STOP_FAILED",
                "ts_utc_ns": time.time_ns(),
                "ts_mono_ns": time.monotonic_ns(),
                "stage_id": stage_id,
                "error": f"{type(error).__name__}: {error}",
            },
        )


def _torch_npu_memory_counters(torch: Any, device_id: int) -> tuple[int | None, int | None]:
    try:
        stats = torch.npu.memory_stats(device_id)
    except Exception:
        return None, None

    def counter(*names: str) -> int | None:
        for name in names:
            value = stats.get(name)
            if isinstance(value, (int, float)):
                return int(value)
        return None

    return (
        counter("num_alloc_retries", "num_alloc_retries.all.current"),
        counter("num_ooms", "num_ooms.all.current"),
    )


def require_internal_child_approval() -> None:
    if (
        os.geteuid() == 0
        and os.environ.get("HGNN_F03_ROOT_APPROVAL") != ROOT_APPROVAL_TOKEN
    ):
        raise PermissionError("root child requires hardened root approval token")
    if os.environ.get("HGNN_F03_APPROVAL") != APPROVAL_TOKEN:
        raise PermissionError("internal child command requires parent approval token")


def child_npu_safety_gate(
    *,
    physical_device_id: int,
    torch_device_id: int,
    max_temperature_c: float,
    output_path: Path,
    allowed_existing_pids: set[int],
) -> None:
    visibility = {
        name: os.environ.get(name)
        for name in VISIBILITY_ENV_VARS
        if os.environ.get(name) not in {None, ""}
    }
    if visibility:
        raise RuntimeError(f"device visibility remapping is not allowed: {visibility}")
    summary, summary_error = query_npu_summary(physical_device_id)
    if summary is None:
        raise RuntimeError(f"selected physical NPU unavailable: {summary_error}")
    mapping, mapping_error = query_phyid_remap(physical_device_id)
    if mapping is None or mapping["logic_id"] != torch_device_id:
        raise RuntimeError(
            f"physical-to-torch mapping mismatch: {mapping}; {mapping_error}"
        )
    if mapping["card_id"] != summary.card_id or mapping["chip_id"] != summary.chip_id:
        raise RuntimeError("phyid-remap disagrees with npu-smi summary topology")
    if summary.health.strip().upper() not in {"OK", "NORMAL", "HEALTHY"}:
        raise RuntimeError(f"NPU health is not safe: {summary.health}")
    if summary.temperature_c >= max_temperature_c - 1:
        raise RuntimeError(
            f"NPU temperature {summary.temperature_c}C lacks child start headroom"
        )
    if summary.hbm_total_mb:
        hbm_usage_pct = 100 * summary.hbm_used_mb / summary.hbm_total_mb
        if hbm_usage_pct >= MAX_HBM_USAGE_PCT:
            raise RuntimeError(f"HBM usage is already {hbm_usage_pct:.2f}%")
    hbm_temperature, hbm_error = query_hbm_temperature(summary)
    if hbm_temperature is None or hbm_temperature >= MAX_HBM_TEMPERATURE_C - 3:
        raise RuntimeError(
            f"HBM temperature is not safe: {hbm_temperature}; {hbm_error}"
        )
    processes, process_error = query_npu_processes(physical_device_id)
    if processes is None:
        raise RuntimeError(f"cannot prove NPU process scope: {process_error}")
    observed_pids = {int(process["pid"]) for process in processes}
    if observed_pids != allowed_existing_pids:
        raise RuntimeError(
            f"NPU process set changed: observed={sorted(observed_pids)}, "
            f"allowed={sorted(allowed_existing_pids)}"
        )
    output_path.parent.mkdir(parents=True, exist_ok=True)
    if shutil.disk_usage(output_path.parent).free < MIN_OUTPUT_FREE_BYTES:
        raise RuntimeError("output filesystem is below the 2 GiB safety floor")
    import torch  # type: ignore
    import torch_npu  # noqa: F401  # type: ignore

    if not torch.npu.is_available() or torch_device_id >= torch.npu.device_count():
        raise RuntimeError("validated torch NPU logic ID is unavailable")


def workload_child(args: argparse.Namespace) -> int:
    require_internal_child_approval()
    if args.device_id < 0 or args.physical_device_id < 0:
        raise ValueError("device IDs must be non-negative")
    if not 40 <= args.max_temperature_c <= 75:
        raise ValueError("child max_temperature_c must be in [40, 75]")
    if not 256 <= args.hidden_dim <= 2048:
        raise ValueError("hidden_dim must be in [256, 2048]")
    if not 1 <= args.batch_size <= 64:
        raise ValueError("batch_size must be in [1, 64]")
    if not 0 <= args.think_time_ms <= 1000:
        raise ValueError("think_time_ms must be in [0, 1000]")
    if not 1 <= args.max_runtime_s <= MAX_TOTAL_DURATION_S + 120:
        raise ValueError("max_runtime_s exceeds bounded workload lifetime")
    control_path = Path(args.control_file)
    stop_path = Path(args.stop_file)
    output_path = Path(args.output)
    profiler_root = Path(args.profiler_root)
    event_path = Path(args.event_file)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    profiler_root.mkdir(parents=True, exist_ok=True)
    child_npu_safety_gate(
        physical_device_id=args.physical_device_id,
        torch_device_id=args.device_id,
        max_temperature_c=args.max_temperature_c,
        output_path=output_path,
        allowed_existing_pids=set(),
    )

    append_jsonl(
        event_path,
        {
            "event_type": "TARGET_PROCESS_STARTING",
            "ts_utc_ns": time.time_ns(),
            "ts_mono_ns": time.monotonic_ns(),
            "pid": os.getpid(),
            "device_id": args.physical_device_id,
            "torch_device_id": args.device_id,
        },
    )
    try:
        import torch  # type: ignore
        import torch_npu  # noqa: F401  # type: ignore

        torch.npu.set_device(args.device_id)
        torch.manual_seed(args.seed)
        dtype = torch.float16
        x = torch.randn(
            (args.batch_size, args.hidden_dim),
            device=f"npu:{args.device_id}",
            dtype=dtype,
        )
        weight = torch.randn(
            (args.hidden_dim, args.hidden_dim),
            device=f"npu:{args.device_id}",
            dtype=dtype,
            requires_grad=True,
        )
        for _ in range(3):
            weight.grad = None
            loss = (x @ weight).float().square().mean()
            loss.backward()
            torch.npu.synchronize()
    except Exception as error:
        append_jsonl(
            event_path,
            {
                "event_type": "TARGET_INITIALIZATION_FAILED",
                "ts_utc_ns": time.time_ns(),
                "ts_mono_ns": time.monotonic_ns(),
                "error": f"{type(error).__name__}: {error}",
                "traceback": traceback.format_exc(limit=12),
            },
        )
        return 2

    session: Any | None = None
    session_stage = ""
    session_steps_left = 0
    step_id = 0
    heartbeat_seq = 0
    last_stage = ""
    deadline = time.monotonic() + args.max_runtime_s
    try:
        with output_path.open("w", encoding="utf-8-sig", newline="") as handle:
            writer = csv.DictWriter(handle, fieldnames=TRAINING_FIELDS)
            writer.writeheader()
            handle.flush()
            while not stop_path.exists() and time.monotonic() < deadline:
                control = read_json(control_path, {}) or {}
                stage_id = str(control.get("stage_id", "UNASSIGNED"))
                intensity = float(control.get("requested_intensity_pct", 0.0))
                profile_requested = bool(control.get("profile", False))
                if stage_id != last_stage:
                    _close_profiler(session, session_stage, event_path)
                    session = None
                    session_steps_left = 0
                    session_stage = stage_id
                    if profile_requested:
                        session, session_steps_left = _create_stage_profiler(
                            profiler_root, stage_id, event_path
                        )
                    append_jsonl(
                        event_path,
                        {
                            "event_type": "TARGET_STAGE_CHANGED",
                            "ts_utc_ns": time.time_ns(),
                            "ts_mono_ns": time.monotonic_ns(),
                            "stage_id": stage_id,
                            "requested_intensity_pct": intensity,
                        },
                    )
                    last_stage = stage_id

                start_utc = time.time_ns()
                start_mono = time.monotonic_ns()
                weight.grad = None
                loss = (x @ weight).float().square().mean()
                loss.backward()
                torch.npu.synchronize()
                if args.think_time_ms > 0:
                    time.sleep(args.think_time_ms / 1000)
                end_mono = time.monotonic_ns()
                end_utc = time.time_ns()
                step_ms = (end_mono - start_mono) / 1_000_000
                loss_value = float(loss.detach().cpu().item())
                alloc_retries, oom_count = _torch_npu_memory_counters(
                    torch, args.device_id
                )
                heartbeat_seq += 1
                row = {
                    "ts_start_utc_ns": start_utc,
                    "ts_end_utc_ns": end_utc,
                    "ts_start_mono_ns": start_mono,
                    "ts_end_mono_ns": end_mono,
                    "stage_id": stage_id,
                    "requested_intensity_pct": intensity,
                    "step_id": step_id,
                    "rank_id": 0,
                    "device_id": args.physical_device_id,
                    "samples": args.batch_size,
                    "step_time_ms": step_ms,
                    "throughput_sps": (
                        args.batch_size * 1000 / step_ms if step_ms > 0 else None
                    ),
                    "loss_value": loss_value,
                    "heartbeat_seq": heartbeat_seq,
                    "hbm_alloc_retries": alloc_retries,
                    "hbm_oom_count": oom_count,
                    "profiler_active": session is not None,
                }
                append_csv_row(handle, writer, row)
                atomic_write_json(
                    output_path.parent / "heartbeat.json",
                    {
                        "ts_utc_ns": end_utc,
                        "ts_mono_ns": end_mono,
                        "heartbeat_seq": heartbeat_seq,
                        "step_id": step_id,
                        "stage_id": stage_id,
                    },
                )
                if not math.isfinite(loss_value):
                    raise RuntimeError("non-finite loss observed")
                if session is not None:
                    try:
                        session.step()
                        session_steps_left -= 1
                    except Exception as error:
                        append_jsonl(
                            event_path,
                            {
                                "event_type": "PROFILER_STEP_FAILED",
                                "ts_utc_ns": time.time_ns(),
                                "stage_id": stage_id,
                                "error": f"{type(error).__name__}: {error}",
                            },
                        )
                        _close_profiler(session, session_stage, event_path)
                        session = None
                        session_steps_left = 0
                    if session is not None and session_steps_left <= 0:
                        _close_profiler(session, session_stage, event_path)
                        session = None
                step_id += 1
    except KeyboardInterrupt:
        pass
    except Exception as error:
        append_jsonl(
            event_path,
            {
                "event_type": "TARGET_PROCESS_FAILED",
                "ts_utc_ns": time.time_ns(),
                "ts_mono_ns": time.monotonic_ns(),
                "stage_id": last_stage,
                "error": f"{type(error).__name__}: {error}",
                "traceback": traceback.format_exc(limit=12),
            },
        )
        return 3
    finally:
        _close_profiler(session, session_stage, event_path)
    append_jsonl(
        event_path,
        {
            "event_type": "TARGET_PROCESS_STOPPED",
            "ts_utc_ns": time.time_ns(),
            "ts_mono_ns": time.monotonic_ns(),
            "pid": os.getpid(),
            "steps": step_id,
        },
    )
    return 0


def injector_child(args: argparse.Namespace) -> int:
    require_internal_child_approval()
    if args.device_id < 0 or args.physical_device_id < 0:
        raise ValueError("device IDs must be non-negative")
    if not 40 <= args.max_temperature_c <= 75:
        raise ValueError("child max_temperature_c must be in [40, 75]")
    if args.expected_target_pid <= 0:
        raise ValueError("expected_target_pid must be positive")
    if not 0 < args.intensity <= MAX_PILOT_INTENSITY_PCT:
        raise ValueError("injector intensity exceeds safe pilot bound")
    if not 256 <= args.tensor_dim <= MAX_TENSOR_DIM:
        raise ValueError("injector tensor_dim exceeds safe pilot bound")
    if not 50 <= args.cycle_ms <= 2000:
        raise ValueError("injection cycle must be in [50, 2000] ms")
    if not 1 <= args.max_runtime_s <= MAX_STAGE_DURATION_S + 30:
        raise ValueError("injector max_runtime_s exceeds bounded stage lifetime")
    stop_path = Path(args.stop_file)
    output_path = Path(args.output)
    event_path = Path(args.event_file)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    child_npu_safety_gate(
        physical_device_id=args.physical_device_id,
        torch_device_id=args.device_id,
        max_temperature_c=args.max_temperature_c,
        output_path=output_path,
        allowed_existing_pids={args.expected_target_pid},
    )
    stopped = False

    def request_stop(_signum: int, _frame: Any) -> None:
        nonlocal stopped
        stopped = True

    signal.signal(signal.SIGTERM, request_stop)
    signal.signal(signal.SIGINT, request_stop)
    append_jsonl(
        event_path,
        {
            "event_type": "INJECTION_PROCESS_STARTING",
            "ts_utc_ns": time.time_ns(),
            "ts_mono_ns": time.monotonic_ns(),
            "pid": os.getpid(),
            "stage_id": args.stage_id,
            "requested_intensity_pct": args.intensity,
            "device_id": args.physical_device_id,
            "torch_device_id": args.device_id,
        },
    )
    try:
        import torch  # type: ignore
        import torch_npu  # noqa: F401  # type: ignore

        torch.npu.set_device(args.device_id)
        torch.manual_seed(args.seed)
        a = torch.randn(
            (args.tensor_dim, args.tensor_dim),
            device=f"npu:{args.device_id}",
            dtype=torch.float16,
        )
        b = torch.randn(
            (args.tensor_dim, args.tensor_dim),
            device=f"npu:{args.device_id}",
            dtype=torch.float16,
        )
        with torch.no_grad():
            _ = a @ b
            torch.npu.synchronize()
    except Exception as error:
        append_jsonl(
            event_path,
            {
                "event_type": "INJECTION_INITIALIZATION_FAILED",
                "ts_utc_ns": time.time_ns(),
                "ts_mono_ns": time.monotonic_ns(),
                "stage_id": args.stage_id,
                "error": f"{type(error).__name__}: {error}",
                "traceback": traceback.format_exc(limit=12),
            },
        )
        return 2

    cycle_s = args.cycle_ms / 1000
    target_active_s = cycle_s * args.intensity / 100
    report_started = time.monotonic()
    report_active = 0.0
    report_ops = 0
    deadline = time.monotonic() + args.max_runtime_s
    try:
        with output_path.open("w", encoding="utf-8-sig", newline="") as handle:
            writer = csv.DictWriter(handle, fieldnames=INJECTOR_FIELDS)
            writer.writeheader()
            handle.flush()
            while (
                not stopped
                and not stop_path.exists()
                and time.monotonic() < deadline
            ):
                cycle_started = time.monotonic()
                active = 0.0
                operations = 0
                with torch.no_grad():
                    while (
                        not stopped
                        and not stop_path.exists()
                        and active < target_active_s
                    ):
                        op_started = time.monotonic()
                        _ = a @ b
                        torch.npu.synchronize()
                        active += time.monotonic() - op_started
                        operations += 1
                report_active += active
                report_ops += operations
                cycle_elapsed = time.monotonic() - cycle_started
                remaining = cycle_s - cycle_elapsed
                if remaining > 0:
                    time.sleep(remaining)
                report_elapsed = time.monotonic() - report_started
                if report_elapsed >= 1:
                    append_csv_row(
                        handle,
                        writer,
                        {
                            "ts_utc_ns": time.time_ns(),
                            "ts_mono_ns": time.monotonic_ns(),
                            "stage_id": args.stage_id,
                            "device_id": args.physical_device_id,
                            "requested_intensity_pct": args.intensity,
                            "measured_duty_pct": min(
                                100.0, 100 * report_active / report_elapsed
                            ),
                            "window_elapsed_ms": report_elapsed * 1000,
                            "active_ms": report_active * 1000,
                            "op_count": report_ops,
                            "tensor_dim": args.tensor_dim,
                        },
                    )
                    report_started = time.monotonic()
                    report_active = 0.0
                    report_ops = 0
    except Exception as error:
        append_jsonl(
            event_path,
            {
                "event_type": "INJECTION_PROCESS_FAILED",
                "ts_utc_ns": time.time_ns(),
                "ts_mono_ns": time.monotonic_ns(),
                "stage_id": args.stage_id,
                "error": f"{type(error).__name__}: {error}",
                "traceback": traceback.format_exc(limit=12),
            },
        )
        return 3
    append_jsonl(
        event_path,
        {
            "event_type": "INJECTION_PROCESS_STOPPED",
            "ts_utc_ns": time.time_ns(),
            "ts_mono_ns": time.monotonic_ns(),
            "stage_id": args.stage_id,
            "pid": os.getpid(),
        },
    )
    return 0


def stop_process(
    process: subprocess.Popen[Any] | None,
    *,
    grace_s: float = 10,
) -> dict[str, Any]:
    if process is None:
        return {"pid": None, "already_stopped": True}
    if process.poll() is not None:
        return {
            "pid": process.pid,
            "already_stopped": True,
            "returncode": process.returncode,
        }
    result: dict[str, Any] = {"pid": process.pid, "already_stopped": False}
    try:
        os.killpg(process.pid, signal.SIGTERM)
    except (OSError, ProcessLookupError):
        with contextlib.suppress(OSError):
            process.terminate()
    try:
        result["returncode"] = process.wait(timeout=grace_s)
        result["forced"] = False
        return result
    except subprocess.TimeoutExpired:
        try:
            os.killpg(process.pid, signal.SIGKILL)
        except (OSError, ProcessLookupError):
            with contextlib.suppress(OSError):
                process.kill()
        result["returncode"] = process.wait(timeout=5)
        result["forced"] = True
        return result


def _child_command(
    subcommand: str,
    arguments: Sequence[str],
) -> list[str]:
    return [sys.executable, str(Path(__file__).resolve()), subcommand, *arguments]


def _spawn_logged(
    argv: Sequence[str],
    stdout_path: Path,
    stderr_path: Path,
    *,
    env: dict[str, str] | None = None,
) -> tuple[subprocess.Popen[Any], tuple[Any, Any]]:
    stdout_path.parent.mkdir(parents=True, exist_ok=True)
    stdout_handle = stdout_path.open("w", encoding="utf-8")
    stderr_handle = stderr_path.open("w", encoding="utf-8")
    try:
        process = subprocess.Popen(
            list(argv),
            stdout=stdout_handle,
            stderr=stderr_handle,
            env=env,
            start_new_session=True,
            text=True,
        )
    except BaseException:
        stdout_handle.close()
        stderr_handle.close()
        raise
    return process, (stdout_handle, stderr_handle)


def _close_handles(handles: Iterable[Any]) -> None:
    for handle in handles:
        with contextlib.suppress(Exception):
            handle.close()


def _hgnn_run_dir(
    config_path: Path,
    data_root: Path,
    run_id: str,
) -> Path | None:
    project_root = Path(__file__).resolve().parents[1]
    sys.path.insert(0, str(project_root / "src"))
    try:
        from hgnn_collect.config import load_config
        from hgnn_collect.storage.run import RunManager

        config = load_config(config_path)
        config.data_root = data_root.resolve()
        manager = RunManager(config, run_id)
        if manager.final_dir.is_dir():
            return manager.final_dir
        if manager.staging_dir.is_dir():
            return manager.staging_dir
    except Exception:
        return None
    finally:
        with contextlib.suppress(ValueError):
            sys.path.remove(str(project_root / "src"))
    return None


class PilotRuntime:
    def __init__(self, args: argparse.Namespace, plan: PilotPlan):
        self.args = args
        self.plan = plan
        timestamp = datetime.now(UTC).strftime("%Y%m%dT%H%M%SZ")
        host = os.uname().nodename.split(".")[0]
        intensities = "-".join(
            f"{stage.requested_intensity_pct:g}"
            for stage in plan.stages
            if stage.inject
        )
        self.run_id = (
            args.run_id
            or f"{timestamp}-f03-{intensities}pct-{host}-npu{plan.device_id}"
        )
        self.run_dir = args.output_root.expanduser().resolve() / self.run_id
        self.control_path = self.run_dir / "control.json"
        self.target_stop_path = self.run_dir / "control" / "target.stop"
        self.training_path = self.run_dir / "raw" / "training_steps.csv"
        self.heartbeat_path = self.training_path.parent / "heartbeat.json"
        self.profiler_root = self.run_dir / "raw" / "profiler"
        self.event_path = self.run_dir / "raw" / "events.jsonl"
        self.safety_path = self.run_dir / "raw" / "safety_timeseries.csv"
        self.injector_dir = self.run_dir / "raw" / "injector"
        self.target_process: subprocess.Popen[Any] | None = None
        self.collector_process: subprocess.Popen[Any] | None = None
        self.injector_process: subprocess.Popen[Any] | None = None
        self.process_handles: list[Any] = []
        self.stage_timeline: list[dict[str, Any]] = []
        self.abort_reason: str | None = None
        self.started_utc_ns = 0
        self.started_mono_ns = 0
        self.consecutive_sample_errors = 0
        self.last_hbm_temperature_c: float | None = None
        self.last_hbm_temperature_error: str | None = None
        self.last_hbm_temperature_query_mono_ns = 0
        self.received_signal: int | None = None

    def _event(self, event_type: str, **payload: Any) -> None:
        append_jsonl(
            self.event_path,
            {
                "event_type": event_type,
                "ts_utc_ns": time.time_ns(),
                "ts_mono_ns": time.monotonic_ns(),
                "run_id": self.run_id,
                **payload,
            },
        )

    def _signal_handler(self, signum: int, _frame: Any) -> None:
        self.received_signal = signum
        self.abort_reason = f"received signal {signum}"

    def _prepare(self) -> None:
        self.run_dir.mkdir(parents=True, exist_ok=False)
        (self.run_dir / "control").mkdir()
        (self.run_dir / "raw").mkdir()
        self.injector_dir.mkdir(parents=True)
        self.profiler_root.mkdir(parents=True)
        atomic_write_json(self.run_dir / "plan.json", plan_payload(self.plan))
        atomic_write_json(
            self.run_dir / "manifest.json",
            {
                "script_version": SCRIPT_VERSION,
                "run_id": self.run_id,
                "fault_code": FAULT_CODE,
                "status": "initializing",
                "device_id": self.plan.device_id,
                "plan": plan_payload(self.plan),
                "created_at_utc_ns": time.time_ns(),
                "output_dir": str(self.run_dir),
                "hgnn_run_dir": None,
            },
        )

    def _update_manifest(self, **values: Any) -> None:
        path = self.run_dir / "manifest.json"
        payload = read_json(path, {}) or {}
        payload.update(values)
        atomic_write_json(path, payload)

    def _write_control(self, stage: StageSpec) -> dict[str, Any]:
        now_utc = time.time_ns()
        now_mono = time.monotonic_ns()
        payload = {
            "run_id": self.run_id,
            "stage_id": stage.stage_id,
            "label": stage.label,
            "requested_intensity_pct": stage.requested_intensity_pct,
            "profile": stage.profile,
            "stage_start_utc_ns": now_utc,
            "stage_start_mono_ns": now_mono,
            "stage_end_mono_ns": now_mono + stage.duration_s * 1_000_000_000,
        }
        atomic_write_json(self.control_path, payload)
        return payload

    def _start_target(self) -> None:
        if self.plan.torch_device_id is None:
            raise RuntimeError("torch device mapping was not validated")
        initial = self.plan.stages[0]
        self._write_control(initial)
        command = _child_command(
            "_workload",
            [
                "--control-file",
                str(self.control_path),
                "--stop-file",
                str(self.target_stop_path),
                "--output",
                str(self.training_path),
                "--profiler-root",
                str(self.profiler_root),
                "--event-file",
                str(self.event_path),
                "--device-id",
                str(self.plan.torch_device_id),
                "--physical-device-id",
                str(self.plan.device_id),
                "--max-temperature-c",
                str(self.plan.max_temperature_c),
                "--hidden-dim",
                str(self.args.target_hidden_dim),
                "--batch-size",
                str(self.args.target_batch_size),
                "--think-time-ms",
                str(self.args.target_think_time_ms),
                "--seed",
                str(self.args.seed),
                "--max-runtime-s",
                str(self.plan.duration_s + 120),
            ],
        )
        process, handles = _spawn_logged(
            command,
            self.run_dir / "logs" / "target.stdout.log",
            self.run_dir / "logs" / "target.stderr.log",
        )
        self.target_process = process
        self.process_handles.extend(handles)
        self._event("TARGET_LAUNCHED", pid=process.pid, command=command)

    def _wait_target_ready(self) -> None:
        deadline = time.monotonic() + self.args.target_start_timeout
        while time.monotonic() < deadline:
            if self.target_process is None or self.target_process.poll() is not None:
                code = self.target_process.returncode if self.target_process else None
                raise RuntimeError(f"target process exited before readiness: {code}")
            heartbeat = read_json(self.heartbeat_path, {}) or {}
            if heartbeat.get("heartbeat_seq"):
                self._event("TARGET_READY", heartbeat=heartbeat)
                return
            time.sleep(0.5)
        raise TimeoutError("target workload did not emit heartbeat before timeout")

    def _start_hgnn_collector(self) -> None:
        if not self.plan.hgnn_collector_enabled:
            return
        project_root = Path(__file__).resolve().parents[1]
        collector_duration = self.plan.duration_s + 5
        command = [
            sys.executable,
            "-m",
            "hgnn_collect",
            "--config",
            str(self.args.config),
            "collect",
            "--duration",
            str(collector_duration),
            "--run-id",
            self.run_id,
            "--data-root",
            str(self.args.hgnn_data_root),
            "--no-workload",
            "--allow-postprocess-failure",
        ]
        env = os.environ.copy()
        env["PYTHONPATH"] = (
            str(project_root / "src")
            + (os.pathsep + env["PYTHONPATH"] if env.get("PYTHONPATH") else "")
        )
        process, handles = _spawn_logged(
            command,
            self.run_dir / "logs" / "hgnn_collect.stdout.log",
            self.run_dir / "logs" / "hgnn_collect.stderr.log",
            env=env,
        )
        self.collector_process = process
        self.process_handles.extend(handles)
        self._event("HGNN_COLLECTOR_LAUNCHED", pid=process.pid, command=command)
        time.sleep(2)
        if process.poll() is not None and process.returncode not in {0, 2}:
            raise RuntimeError(
                f"hgnn collector exited during startup: {process.returncode}"
            )

    def _start_injector(self, stage: StageSpec) -> Path:
        if not stage.inject:
            raise ValueError("cannot start injector for non-injection stage")
        if self.plan.torch_device_id is None:
            raise RuntimeError("torch device mapping was not validated")
        stop_path = self.run_dir / "control" / f"{stage.stage_id}.stop"
        output_path = self.injector_dir / f"{stage.stage_id}.csv"
        with contextlib.suppress(FileNotFoundError):
            stop_path.unlink()
        command = _child_command(
            "_injector",
            [
                "--stop-file",
                str(stop_path),
                "--output",
                str(output_path),
                "--event-file",
                str(self.event_path),
                "--stage-id",
                stage.stage_id,
                "--device-id",
                str(self.plan.torch_device_id),
                "--physical-device-id",
                str(self.plan.device_id),
                "--max-temperature-c",
                str(self.plan.max_temperature_c),
                "--expected-target-pid",
                str(self.target_process.pid if self.target_process else -1),
                "--intensity",
                str(stage.requested_intensity_pct),
                "--tensor-dim",
                str(self.plan.tensor_dim),
                "--cycle-ms",
                str(self.args.injection_cycle_ms),
                "--seed",
                str(self.args.seed + len(self.stage_timeline) + 1),
                "--max-runtime-s",
                str(stage.duration_s + 15),
            ],
        )
        process, handles = _spawn_logged(
            command,
            self.run_dir / "logs" / f"{stage.stage_id}.injector.stdout.log",
            self.run_dir / "logs" / f"{stage.stage_id}.injector.stderr.log",
        )
        self.injector_process = process
        self.process_handles.extend(handles)
        self._event(
            "INJECTION_LAUNCHED",
            stage_id=stage.stage_id,
            requested_intensity_pct=stage.requested_intensity_pct,
            pid=process.pid,
            command=command,
        )
        return stop_path

    def _stop_injector(self, stop_path: Path | None) -> dict[str, Any]:
        if stop_path is not None:
            stop_path.touch(exist_ok=True)
        result = stop_process(self.injector_process, grace_s=8)
        self._event("INJECTION_ROLLBACK_COMPLETED", result=result)
        self.injector_process = None
        return result

    def _heartbeat_age(self) -> float | None:
        heartbeat = read_json(self.heartbeat_path, {}) or {}
        timestamp = heartbeat.get("ts_mono_ns")
        if not isinstance(timestamp, int):
            return None
        return max(0.0, (time.monotonic_ns() - timestamp) / 1_000_000_000)

    def _safety_sample(self, stage: StageSpec) -> dict[str, Any]:
        now_utc = time.time_ns()
        now_mono = time.monotonic_ns()
        summary, error = query_npu_summary(self.plan.device_id)
        heartbeat_age = self._heartbeat_age()
        target_alive = (
            self.target_process is not None and self.target_process.poll() is None
        )
        injector_alive = (
            self.injector_process is not None
            and self.injector_process.poll() is None
        )
        processes, process_error = query_npu_processes(self.plan.device_id)
        allowed_pids = {
            process.pid
            for process in (self.target_process, self.injector_process)
            if process is not None and process.poll() is None
        }
        unexpected_processes = [
            process
            for process in (processes or [])
            if int(process["pid"]) not in allowed_pids
        ]
        observed_pids = {int(process["pid"]) for process in (processes or [])}
        missing_expected_pids = sorted(allowed_pids - observed_pids)
        if summary is not None and (
            self.last_hbm_temperature_query_mono_ns == 0
            or now_mono - self.last_hbm_temperature_query_mono_ns
            >= int(self.plan.detail_interval_s * 1_000_000_000)
        ):
            (
                self.last_hbm_temperature_c,
                self.last_hbm_temperature_error,
            ) = query_hbm_temperature(summary)
            self.last_hbm_temperature_query_mono_ns = now_mono
        try:
            output_free_bytes = shutil.disk_usage(self.run_dir).free
        except OSError:
            output_free_bytes = 0
        if summary is None:
            self.consecutive_sample_errors += 1
        else:
            self.consecutive_sample_errors = 0
        row = {
            "ts_utc_ns": now_utc,
            "ts_utc_iso": utc_iso(now_utc),
            "ts_mono_ns": now_mono,
            "elapsed_s": (
                (now_mono - self.started_mono_ns) / 1_000_000_000
                if self.started_mono_ns
                else 0
            ),
            "stage_id": stage.stage_id,
            "requested_intensity_pct": stage.requested_intensity_pct,
            "device_id": self.plan.device_id,
            "npu_temperature_c": summary.temperature_c if summary else None,
            "npu_power_w": summary.power_w if summary else None,
            "npu_utilization_pct": summary.utilization_pct if summary else None,
            "hbm_used_bytes": summary.hbm_used_mb * 1024 * 1024 if summary else None,
            "hbm_total_bytes": summary.hbm_total_mb * 1024 * 1024 if summary else None,
            "hbm_utilization_pct": (
                100 * summary.hbm_used_mb / summary.hbm_total_mb
                if summary and summary.hbm_total_mb
                else None
            ),
            "hbm_temperature_c": self.last_hbm_temperature_c,
            "npu_health_state": summary.health if summary else None,
            "npu_process_count": len(processes) if processes is not None else None,
            "unexpected_npu_pids": ",".join(
                str(process["pid"]) for process in unexpected_processes
            ),
            "missing_expected_npu_pids": ",".join(
                str(pid) for pid in missing_expected_pids
            ),
            "output_free_bytes": output_free_bytes,
            "target_alive": target_alive,
            "injector_alive": injector_alive,
            "heartbeat_age_s": heartbeat_age,
            "sample_status": "ok" if summary else "source_error",
            "sample_error": "; ".join(
                item
                for item in (
                    error,
                    process_error,
                    self.last_hbm_temperature_error,
                )
                if item
            ),
        }
        if not target_alive:
            raise RuntimeError("target workload exited unexpectedly")
        if stage.inject and not injector_alive:
            code = self.injector_process.returncode if self.injector_process else None
            raise RuntimeError(f"injector exited unexpectedly: {code}")
        if self.consecutive_sample_errors >= 3:
            raise RuntimeError("three consecutive npu-smi safety sample failures")
        if process_error is not None:
            raise RuntimeError(
                f"cannot prove selected NPU process exclusivity: {process_error}"
            )
        if unexpected_processes:
            raise RuntimeError(
                "foreign process appeared on selected NPU: "
                + ",".join(str(process["pid"]) for process in unexpected_processes)
            )
        if self.last_hbm_temperature_error is not None:
            raise RuntimeError(
                "HBM temperature safety source unavailable: "
                f"{self.last_hbm_temperature_error}"
            )
        if (
            self.last_hbm_temperature_c is not None
            and self.last_hbm_temperature_c >= MAX_HBM_TEMPERATURE_C
        ):
            raise RuntimeError(
                f"HBM temperature {self.last_hbm_temperature_c}C reached "
                f"{MAX_HBM_TEMPERATURE_C}C safety limit"
            )
        if output_free_bytes < MIN_OUTPUT_FREE_BYTES:
            raise RuntimeError(
                f"output filesystem free space {output_free_bytes} bytes is below "
                f"{MIN_OUTPUT_FREE_BYTES} byte safety floor"
            )
        if summary is not None:
            if summary.temperature_c >= self.plan.max_temperature_c:
                raise RuntimeError(
                    f"NPU temperature {summary.temperature_c}C reached "
                    f"{self.plan.max_temperature_c}C safety limit"
                )
            if summary.health.strip().upper() not in {"OK", "NORMAL", "HEALTHY"}:
                raise RuntimeError(f"NPU health changed to {summary.health!r}")
            if summary.hbm_total_mb:
                hbm_usage_pct = 100 * summary.hbm_used_mb / summary.hbm_total_mb
                if hbm_usage_pct >= MAX_HBM_USAGE_PCT:
                    raise RuntimeError(
                        f"NPU HBM usage {hbm_usage_pct:.2f}% reached "
                        f"{MAX_HBM_USAGE_PCT:.1f}% safety limit"
                    )
        if heartbeat_age is None:
            raise RuntimeError("target heartbeat is missing or invalid")
        if heartbeat_age > self.plan.heartbeat_timeout_s:
            raise RuntimeError(
                f"target heartbeat age {heartbeat_age:.3f}s exceeded "
                f"{self.plan.heartbeat_timeout_s}s"
            )
        return row

    def _run_stages(self) -> None:
        self.started_utc_ns = time.time_ns()
        self.started_mono_ns = time.monotonic_ns()
        self._update_manifest(
            status="running",
            started_at_utc_ns=self.started_utc_ns,
            started_at_mono_ns=self.started_mono_ns,
        )
        self._event("PILOT_STARTED", plan=plan_payload(self.plan))
        with self.safety_path.open("w", encoding="utf-8-sig", newline="") as handle:
            writer = csv.DictWriter(handle, fieldnames=SAFETY_FIELDS)
            writer.writeheader()
            handle.flush()
            for stage in self.plan.stages:
                if self.abort_reason:
                    raise RuntimeError(self.abort_reason)
                control = self._write_control(stage)
                timeline = {
                    **asdict(stage),
                    "start_utc_ns": control["stage_start_utc_ns"],
                    "start_mono_ns": control["stage_start_mono_ns"],
                    "planned_end_mono_ns": control["stage_end_mono_ns"],
                }
                self.stage_timeline.append(timeline)
                self._event(
                    "STAGE_STARTED",
                    stage_id=stage.stage_id,
                    requested_intensity_pct=stage.requested_intensity_pct,
                    duration_s=stage.duration_s,
                )
                injector_stop: Path | None = None
                if stage.inject:
                    injector_stop = self._start_injector(stage)
                    time.sleep(1)
                    if (
                        self.injector_process is None
                        or self.injector_process.poll() is not None
                    ):
                        code = (
                            self.injector_process.returncode
                            if self.injector_process
                            else None
                        )
                        raise RuntimeError(f"injector failed during startup: {code}")
                target_end = control["stage_end_mono_ns"]
                next_sample = time.monotonic_ns()
                try:
                    while time.monotonic_ns() < target_end:
                        if self.abort_reason:
                            raise RuntimeError(self.abort_reason)
                        now = time.monotonic_ns()
                        if now >= next_sample:
                            append_csv_row(
                                handle, writer, self._safety_sample(stage)
                            )
                            next_sample += round(
                                self.plan.sample_interval_s * 1_000_000_000
                            )
                            if now > next_sample + 1_000_000_000:
                                next_sample = now
                        sleep_s = min(
                            0.2,
                            max(0.0, (next_sample - time.monotonic_ns()) / 1e9),
                            max(0.0, (target_end - time.monotonic_ns()) / 1e9),
                        )
                        if sleep_s > 0:
                            time.sleep(sleep_s)
                finally:
                    if stage.inject:
                        self._stop_injector(injector_stop)
                timeline["actual_end_utc_ns"] = time.time_ns()
                timeline["actual_end_mono_ns"] = time.monotonic_ns()
                self._event(
                    "STAGE_COMPLETED",
                    stage_id=stage.stage_id,
                    requested_intensity_pct=stage.requested_intensity_pct,
                )

    def _wait_collector(self) -> int | None:
        if self.collector_process is None:
            return None
        try:
            return self.collector_process.wait(timeout=45)
        except subprocess.TimeoutExpired:
            result = stop_process(self.collector_process, grace_s=10)
            self._event("HGNN_COLLECTOR_FORCED_STOP", result=result)
            return int(result.get("returncode", -1))

    def cleanup(self, *, abort_collector: bool) -> dict[str, Any]:
        self.target_stop_path.touch(exist_ok=True)
        injector = self._stop_injector(None)
        target = stop_process(self.target_process, grace_s=15)
        collector: dict[str, Any] | None = None
        if abort_collector:
            collector = stop_process(self.collector_process, grace_s=15)
        _close_handles(self.process_handles)
        return {"injector": injector, "target": target, "collector": collector}

    def run(self) -> dict[str, Any]:
        self._prepare()
        old_handlers = {
            signum: signal.getsignal(signum)
            for signum in (signal.SIGINT, signal.SIGTERM, signal.SIGHUP)
        }
        for signum in old_handlers:
            signal.signal(signum, self._signal_handler)
        success = False
        cleanup_result: dict[str, Any] = {}
        collector_returncode: int | None = None
        try:
            self._start_target()
            self._wait_target_ready()
            self._start_hgnn_collector()
            self._run_stages()
            self.target_stop_path.touch()
            target_result = stop_process(self.target_process, grace_s=20)
            self._event("TARGET_ROLLBACK_COMPLETED", result=target_result)
            collector_returncode = self._wait_collector()
            if collector_returncode not in {None, 0, 2}:
                raise RuntimeError(
                    f"hgnn collector failed with return code {collector_returncode}"
                )
            success = True
        except BaseException as error:
            self.abort_reason = self.abort_reason or f"{type(error).__name__}: {error}"
            self._event(
                "PILOT_ABORTED",
                reason=self.abort_reason,
                traceback=traceback.format_exc(limit=16),
            )
        finally:
            cleanup_result = self.cleanup(abort_collector=not success)
            for signum, handler in old_handlers.items():
                signal.signal(signum, handler)

        hgnn_dir = _hgnn_run_dir(
            self.args.config, self.args.hgnn_data_root, self.run_id
        )
        atomic_write_json(self.run_dir / "stage_timeline.json", self.stage_timeline)
        final_status = "raw_complete" if success else "aborted"
        self._update_manifest(
            status=final_status,
            completed_at_utc_ns=time.time_ns(),
            abort_reason=self.abort_reason,
            collector_returncode=collector_returncode,
            cleanup=cleanup_result,
            stage_timeline=self.stage_timeline,
            hgnn_run_dir=str(hgnn_dir) if hgnn_dir else None,
        )
        if not success:
            bundle = create_bundle(
                self.run_dir,
                extra_paths=[hgnn_dir] if hgnn_dir is not None else (),
            )
            return {
                "passed": False,
                "status": final_status,
                "run_dir": str(self.run_dir),
                "abort_reason": self.abort_reason,
                "cleanup": cleanup_result,
                "bundle": str(bundle),
            }
        analysis = analyze_run(self.run_dir, hgnn_run_dir=hgnn_dir)
        self._update_manifest(status="complete", analysis=analysis)
        bundle = create_bundle(
            self.run_dir,
            extra_paths=[hgnn_dir] if hgnn_dir is not None else (),
        )
        return {
            "passed": bool(analysis.get("passed")),
            "status": "complete",
            "run_dir": str(self.run_dir),
            "hgnn_run_dir": str(hgnn_dir) if hgnn_dir else None,
            "analysis": analysis,
            "bundle": str(bundle),
        }


def stage_for_timestamp(
    timestamp_ns: int, timeline: Sequence[dict[str, Any]]
) -> dict[str, Any] | None:
    for stage in timeline:
        start = int(stage.get("start_utc_ns", 0))
        end = int(stage.get("actual_end_utc_ns", 0))
        if start <= timestamp_ns < end:
            return stage
    return None


def _group_rows_by_second(
    rows: Sequence[dict[str, str]],
    timestamp_field: str,
) -> dict[int, list[dict[str, str]]]:
    grouped: dict[int, list[dict[str, str]]] = {}
    for row in rows:
        timestamp = numeric(row.get(timestamp_field))
        if timestamp is None:
            continue
        grouped.setdefault(int(timestamp) // 1_000_000_000, []).append(row)
    return grouped


def _mean_field(rows: Sequence[dict[str, Any]], field: str) -> float | None:
    values = [numeric(row.get(field)) for row in rows]
    finite = [value for value in values if value is not None]
    return statistics.fmean(finite) if finite else None


def _last_field(rows: Sequence[dict[str, Any]], field: str) -> float | None:
    for row in reversed(rows):
        value = numeric(row.get(field))
        if value is not None:
            return value
    return None


def combined_timeseries(
    run_dir: Path,
    timeline: Sequence[dict[str, Any]],
    profiler_records: Sequence[dict[str, Any]],
) -> list[dict[str, Any]]:
    safety = read_csv(run_dir / "raw" / "safety_timeseries.csv")
    training = read_csv(run_dir / "raw" / "training_steps.csv")
    injectors: list[dict[str, str]] = []
    for path in sorted((run_dir / "raw" / "injector").glob("*.csv")):
        injectors.extend(read_csv(path))
    training_by_second = _group_rows_by_second(training, "ts_end_utc_ns")
    injector_by_second = _group_rows_by_second(injectors, "ts_utc_ns")
    profiles_by_stage: dict[str, list[dict[str, Any]]] = {}
    for record in profiler_records:
        stage_id = record.get("stage_id")
        if isinstance(stage_id, str):
            profiles_by_stage.setdefault(stage_id, []).append(record)

    result: list[dict[str, Any]] = []
    previous_alloc: float | None = None
    previous_oom: float | None = None
    for safety_row in safety:
        timestamp = int(float(safety_row["ts_utc_ns"]))
        second = timestamp // 1_000_000_000
        stage_id = safety_row["stage_id"]
        train_rows = training_by_second.get(second, [])
        injection_rows = injector_by_second.get(second, [])
        step_times = [
            value
            for value in (numeric(row.get("step_time_ms")) for row in train_rows)
            if value is not None
        ]
        current_alloc = _last_field(train_rows, "hbm_alloc_retries")
        current_oom = _last_field(train_rows, "hbm_oom_count")
        alloc_delta: float | None = None
        if current_alloc is not None or current_oom is not None:
            alloc_delta = 0.0
            if current_alloc is not None and previous_alloc is not None:
                alloc_delta += max(0.0, current_alloc - previous_alloc)
            if current_oom is not None and previous_oom is not None:
                alloc_delta += max(0.0, current_oom - previous_oom)
            previous_alloc = current_alloc if current_alloc is not None else previous_alloc
            previous_oom = current_oom if current_oom is not None else previous_oom

        row: dict[str, Any] = {
            "ts_utc_ns": timestamp,
            "timestamp_utc": safety_row.get("ts_utc_iso") or utc_iso(timestamp),
            "elapsed_s": numeric(safety_row.get("elapsed_s")),
            "stage_id": stage_id,
            "requested_intensity_pct": numeric(
                safety_row.get("requested_intensity_pct")
            ),
            "injection.measured_duty_pct": _mean_field(
                injection_rows, "measured_duty_pct"
            ),
            "npu.temperature_c": numeric(safety_row.get("npu_temperature_c")),
            "npu.power_w": numeric(safety_row.get("npu_power_w")),
            "npu.utilization_pct": numeric(
                safety_row.get("npu_utilization_pct")
            ),
            "hbm.used_bytes": numeric(safety_row.get("hbm_used_bytes")),
            "hbm.utilization_pct": numeric(
                safety_row.get("hbm_utilization_pct")
            ),
            "hbm.temperature_c": numeric(safety_row.get("hbm_temperature_c")),
            "npu.health_state": safety_row.get("npu_health_state"),
            "global_task.step_time_ms": (
                statistics.fmean(step_times) if step_times else None
            ),
            "global_task.step_time_p95_ms": percentile(step_times, 0.95),
            "global_task.throughput_sps": _mean_field(
                train_rows, "throughput_sps"
            ),
            "global_task.loss_value": _mean_field(train_rows, "loss_value"),
            "global_task.step_count": len(train_rows),
            "global_task.heartbeat_timeout_count": (
                1
                if (numeric(safety_row.get("heartbeat_age_s")) or 0)
                > 15
                else 0
            ),
            "hbm.alloc_fail_count": alloc_delta,
            "target_alive": safety_row.get("target_alive"),
            "injector_alive": safety_row.get("injector_alive"),
            "sample_status": safety_row.get("sample_status"),
        }
        for profile in profiles_by_stage.get(stage_id, []):
            for key in (
                "npu.aicore_stall_ratio",
                "global_task.comm_compute_overlap_pct",
                "hbm.read_gbps",
                "hbm.write_gbps",
            ):
                value = numeric(profile.get(key))
                if value is not None:
                    row[key] = value
            components = profile.get("components")
            if isinstance(components, dict):
                for key, value in components.items():
                    converted = numeric(value)
                    if converted is not None:
                        row[f"profiler.{key}"] = converted
        result.append(row)
    return result


RESPONSE_METRICS = [
    "injection.measured_duty_pct",
    "global_task.step_time_ms",
    "global_task.throughput_sps",
    "npu.utilization_pct",
    "npu.power_w",
    "npu.temperature_c",
    "npu.aicore_stall_ratio",
    "hbm.read_gbps",
    "hbm.write_gbps",
    "hbm.utilization_pct",
    "global_task.loss_value",
]


def stage_summary_rows(
    rows: Sequence[dict[str, Any]],
    timeline: Sequence[dict[str, Any]],
) -> list[dict[str, Any]]:
    by_stage: dict[str, list[dict[str, Any]]] = {}
    for row in rows:
        by_stage.setdefault(str(row.get("stage_id")), []).append(row)
    result: list[dict[str, Any]] = []
    for stage in timeline:
        stage_id = str(stage["stage_id"])
        stage_rows = by_stage.get(stage_id, [])
        for metric_id in RESPONSE_METRICS:
            values = [
                value
                for value in (numeric(row.get(metric_id)) for row in stage_rows)
                if value is not None
            ]
            if not values:
                continue
            result.append(
                {
                    "stage_id": stage_id,
                    "label": stage.get("label"),
                    "requested_intensity_pct": stage.get(
                        "requested_intensity_pct"
                    ),
                    "metric_id": metric_id,
                    "count": len(values),
                    "mean": statistics.fmean(values),
                    "std": statistics.pstdev(values) if len(values) > 1 else 0.0,
                    "min": min(values),
                    "p50": percentile(values, 0.50),
                    "p95": percentile(values, 0.95),
                    "max": max(values),
                }
            )
    return result


def response_assessment(
    summaries: Sequence[dict[str, Any]],
) -> dict[str, Any]:
    selected = [
        row
        for row in summaries
        if str(row.get("stage_id")) == "T0_BASELINE"
        or str(row.get("stage_id", "")).startswith("F03_I")
    ]
    by_metric: dict[str, list[tuple[float, float]]] = {}
    for row in selected:
        intensity = numeric(row.get("requested_intensity_pct"))
        mean = numeric(row.get("mean"))
        if intensity is None or mean is None:
            continue
        by_metric.setdefault(str(row["metric_id"]), []).append((intensity, mean))
    result: dict[str, Any] = {}
    for metric_id, points in by_metric.items():
        points = sorted(points)
        xs = [item[0] for item in points]
        ys = [item[1] for item in points]
        slope: float | None = None
        if len(points) >= 2 and len(set(xs)) > 1:
            mean_x = statistics.fmean(xs)
            mean_y = statistics.fmean(ys)
            denominator = sum((value - mean_x) ** 2 for value in xs)
            if denominator > 0:
                slope = sum(
                    (x - mean_x) * (y - mean_y) for x, y in points
                ) / denominator
        result[metric_id] = {
            "points": [
                {"intensity_pct": x, "stage_mean": y} for x, y in points
            ],
            "linear_slope_per_intensity_pct": slope,
            "monotonic_non_decreasing": all(
                right >= left for left, right in zip(ys, ys[1:])
            ),
            "monotonic_non_increasing": all(
                right <= left for left, right in zip(ys, ys[1:])
            ),
            "interpretation": (
                "描述性响应，不作为故障注入成功的硬门槛；"
                "仅 measured_duty_pct 必须随请求强度增加。"
            ),
        }
    duty = result.get("injection.measured_duty_pct", {})
    duty_points = duty.get("points", [])
    duty_present = (
        len(duty_points) >= 1
        and all(point["stage_mean"] > 0 for point in duty_points)
    )
    gradient_passed = (
        len(duty_points) >= 2
        and duty_present
        and bool(duty.get("monotonic_non_decreasing"))
    )
    return {
        "injection_control_verified": duty_present,
        "multi_level_gradient_verified": gradient_passed,
        "metrics": result,
    }


def _load_metric_dictionary(hgnn_run_dir: Path | None) -> dict[str, dict[str, Any]]:
    candidates = []
    if hgnn_run_dir is not None:
        candidates.append(hgnn_run_dir / "schemas" / "node_features.yaml")
    candidates.append(
        Path(__file__).resolve().parents[1] / "schemas" / "node_features.yaml"
    )
    try:
        import yaml  # type: ignore
    except Exception:
        return {}
    for path in candidates:
        if not path.is_file():
            continue
        payload = yaml.safe_load(path.read_text(encoding="utf-8"))
        result: dict[str, dict[str, Any]] = {}
        for node_type, node_payload in payload.get("node_types", {}).items():
            for feature in node_payload.get("features", []):
                result[str(feature["id"])] = {
                    "node_type": node_type,
                    **feature,
                }
        return result
    return {}


def export_hgnn_long_csv(
    hgnn_run_dir: Path | None,
    output: Path,
    timeline: Sequence[dict[str, Any]],
) -> dict[str, Any]:
    if hgnn_run_dir is None:
        write_csv(
            output,
            [],
            [
                "timestamp_utc",
                "ts_utc_ns",
                "stage_id",
                "requested_intensity_pct",
                "node_type",
                "node_id",
                "metric_id",
                "unit",
                "observed",
                "value",
                "quality_mask",
                "source",
            ],
        )
        return {"available": False, "rows": 0, "reason": "hgnn run unavailable"}
    try:
        import pyarrow.parquet as pq  # type: ignore
    except Exception as error:
        return {
            "available": False,
            "rows": 0,
            "reason": f"pyarrow unavailable: {error}",
        }
    node_dir = hgnn_run_dir / "aligned" / "nodes"
    if not node_dir.is_dir():
        return {
            "available": False,
            "rows": 0,
            "reason": f"aligned node directory missing: {node_dir}",
        }
    dictionary = _load_metric_dictionary(hgnn_run_dir)
    fields = [
        "timestamp_utc",
        "ts_utc_ns",
        "stage_id",
        "requested_intensity_pct",
        "node_type",
        "node_id",
        "metric_id",
        "unit",
        "observed",
        "value",
        "quality_mask",
        "source",
    ]
    output.parent.mkdir(parents=True, exist_ok=True)
    count = 0
    files = 0
    errors: list[str] = []
    fallback_files: list[str] = []
    with output.open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        parquet_paths = sorted(node_dir.glob("*.parquet"))
        parquet_stems = {path.stem for path in parquet_paths}
        csv_only_paths = sorted(
            path
            for path in node_dir.glob("*.csv")
            if path.stem not in parquet_stems
        )
        for path in [*parquet_paths, *csv_only_paths]:
            if path.suffix == ".csv":
                rows = read_csv(path)
                column_names = list(rows[0].keys()) if rows else []
                fallback_files.append(path.name)
            else:
                try:
                    table = pq.read_table(path)
                    rows = table.to_pylist()
                    column_names = table.column_names
                except Exception as error:
                    csv_sidecar = path.with_suffix(".csv")
                    if not csv_sidecar.is_file():
                        errors.append(f"{path.name}: {type(error).__name__}: {error}")
                        continue
                    rows = read_csv(csv_sidecar)
                    column_names = list(rows[0].keys()) if rows else []
                    fallback_files.append(csv_sidecar.name)
            node_type = path.stem
            metric_ids = [
                metric_id
                for metric_id, spec in dictionary.items()
                if spec.get("node_type") == node_type
                and metric_id in column_names
            ]
            for row in rows:
                timestamp = int(row["ts_bucket_start_utc_ns"])
                stage = stage_for_timestamp(timestamp, timeline)
                for metric_id in metric_ids:
                    writer.writerow(
                        {
                            "timestamp_utc": utc_iso(timestamp),
                            "ts_utc_ns": timestamp,
                            "stage_id": stage.get("stage_id") if stage else None,
                            "requested_intensity_pct": (
                                stage.get("requested_intensity_pct")
                                if stage
                                else None
                            ),
                            "node_type": node_type,
                            "node_id": row.get("node_id"),
                            "metric_id": metric_id,
                            "unit": dictionary[metric_id].get("unit"),
                            "observed": row.get(f"{metric_id}__observed"),
                            "value": row.get(metric_id),
                            "quality_mask": row.get(f"{metric_id}__quality"),
                            "source": "hgnn_collect",
                        }
                    )
                    count += 1
            files += 1
    if files == 0 and errors:
        return {
            "available": False,
            "rows": count,
            "files": files,
            "output": str(output),
            "reason": "aligned node parquet unreadable; raw hgnn run preserved",
            "errors": errors[:20],
            "fallback_files": fallback_files,
        }
    return {
        "available": True,
        "rows": count,
        "files": files,
        "output": str(output),
        "errors": errors,
        "fallback_files": fallback_files,
    }


def write_workbook(
    output: Path,
    *,
    manifest: dict[str, Any],
    combined: Sequence[dict[str, Any]],
    training: Sequence[dict[str, str]],
    profiler: Sequence[dict[str, Any]],
    summaries: Sequence[dict[str, Any]],
    long_csv: Path,
    events_path: Path,
    dictionary: dict[str, dict[str, Any]],
) -> dict[str, Any]:
    from openpyxl import Workbook  # type: ignore

    workbook = Workbook(write_only=True)

    def add_sheet(name: str, rows: Sequence[dict[str, Any]]) -> None:
        sheet = workbook.create_sheet(name)
        if not rows:
            sheet.append(["status"])
            sheet.append(["no rows"])
            return
        fields = list(rows[0].keys())
        sheet.append(fields)
        for row in rows:
            sheet.append(
                [
                    json.dumps(value, ensure_ascii=False, sort_keys=True)
                    if isinstance(value, (dict, list))
                    else value
                    for value in (row.get(field) for field in fields)
                ]
            )

    metadata = [
        {"field": key, "value": value}
        for key, value in manifest.items()
        if key not in {"plan", "stage_timeline", "analysis"}
    ]
    add_sheet("run_metadata", metadata)
    add_sheet("metric_timeseries_1s", list(combined))
    add_sheet("training_steps", list(training))
    flat_profiler: list[dict[str, Any]] = []
    for record in profiler:
        base = {
            key: value
            for key, value in record.items()
            if not isinstance(value, dict)
        }
        components = record.get("components", {})
        if isinstance(components, dict):
            base.update({f"component.{key}": value for key, value in components.items()})
        flat_profiler.append(base)
    add_sheet("profiler_metrics", flat_profiler)
    add_sheet("stage_summary", list(summaries))
    dictionary_rows = [
        {"metric_id": metric_id, **spec}
        for metric_id, spec in sorted(dictionary.items())
    ]
    add_sheet("metric_dictionary", dictionary_rows)
    event_rows: list[dict[str, Any]] = []
    if events_path.is_file():
        for line in events_path.read_text(encoding="utf-8").splitlines():
            try:
                payload = json.loads(line)
            except json.JSONDecodeError:
                continue
            event_rows.append(payload)
    add_sheet("events", event_rows)

    long_sheet = workbook.create_sheet("all_metrics_long")
    if long_csv.is_file():
        with long_csv.open("r", encoding="utf-8-sig", newline="") as handle:
            for row in csv.reader(handle):
                long_sheet.append(row)
    else:
        long_sheet.append(["status"])
        long_sheet.append(["hgnn long metrics unavailable"])

    output.parent.mkdir(parents=True, exist_ok=True)
    temporary = output.with_suffix(output.suffix + ".tmp")
    workbook.save(temporary)
    temporary.replace(output)
    return {"output": str(output), "sheets": workbook.sheetnames}


def generate_plots(
    output_dir: Path,
    combined: Sequence[dict[str, Any]],
    summaries: Sequence[dict[str, Any]],
) -> list[str]:
    import matplotlib  # type: ignore

    matplotlib.use("Agg")
    import matplotlib.pyplot as plt  # type: ignore

    output_dir.mkdir(parents=True, exist_ok=True)
    rows = sorted(combined, key=lambda row: int(row["ts_utc_ns"]))
    times = [numeric(row.get("elapsed_s")) or 0 for row in rows]
    panels = [
        ("requested_intensity_pct", "Requested intensity (%)"),
        ("injection.measured_duty_pct", "Measured injection duty (%)"),
        ("global_task.step_time_ms", "Step time (ms)"),
        ("global_task.throughput_sps", "Throughput (sample/s)"),
        ("npu.utilization_pct", "NPU utilization (%)"),
        ("npu.power_w", "NPU power (W)"),
        ("npu.temperature_c", "NPU temperature (C)"),
        ("npu.aicore_stall_ratio", "AI Core stall ratio"),
    ]
    figure, axes = plt.subplots(4, 2, figsize=(14, 14), sharex=True)
    for axis, (metric_id, label) in zip(axes.flat, panels):
        values = [numeric(row.get(metric_id)) for row in rows]
        axis.plot(times, values, linewidth=1.2)
        axis.set_ylabel(label)
        axis.grid(True, alpha=0.25)
    axes[-1, 0].set_xlabel("Elapsed time (s)")
    axes[-1, 1].set_xlabel("Elapsed time (s)")
    figure.suptitle("F03 mild NPU contention: aligned time-series response")
    figure.tight_layout()
    time_path = output_dir / "f03_timeseries_response.png"
    figure.savefig(time_path, dpi=160)
    plt.close(figure)

    summary_by_metric: dict[str, list[dict[str, Any]]] = {}
    for row in summaries:
        if row["stage_id"] == "T0_BASELINE" or str(row["stage_id"]).startswith(
            "F03_I"
        ):
            summary_by_metric.setdefault(str(row["metric_id"]), []).append(row)
    response_panels = [
        ("global_task.step_time_ms", "Step time (ms)"),
        ("global_task.throughput_sps", "Throughput (sample/s)"),
        ("npu.utilization_pct", "NPU utilization (%)"),
        ("npu.power_w", "NPU power (W)"),
        ("npu.temperature_c", "NPU temperature (C)"),
        ("npu.aicore_stall_ratio", "AI Core stall ratio"),
    ]
    figure, axes = plt.subplots(3, 2, figsize=(13, 12))
    for axis, (metric_id, label) in zip(axes.flat, response_panels):
        metric_rows = sorted(
            summary_by_metric.get(metric_id, []),
            key=lambda item: float(item["requested_intensity_pct"]),
        )
        xs = [float(row["requested_intensity_pct"]) for row in metric_rows]
        ys = [float(row["mean"]) for row in metric_rows]
        errors = [float(row["std"]) for row in metric_rows]
        if xs:
            axis.errorbar(xs, ys, yerr=errors, marker="o", linewidth=1.2)
        axis.set_xlabel("Requested injection intensity (%)")
        axis.set_ylabel(label)
        axis.grid(True, alpha=0.25)
    figure.suptitle("F03 intensity-response curves (stage mean +/- 1 std)")
    figure.tight_layout()
    response_path = output_dir / "f03_intensity_response.png"
    figure.savefig(response_path, dpi=160)
    plt.close(figure)
    return [str(time_path), str(response_path)]


def _write_svg_panels(
    path: Path,
    *,
    title: str,
    panels: Sequence[tuple[str, Sequence[tuple[float, float]]]],
    x_label: str,
) -> None:
    width = 1200
    panel_height = 190
    margin_x = 80
    top = 70
    height = top + panel_height * len(panels) + 55
    plot_width = width - margin_x - 35
    colors = ("#1f77b4", "#d62728", "#2ca02c", "#9467bd", "#ff7f0e")
    parts = [
        '<?xml version="1.0" encoding="UTF-8"?>',
        (
            f'<svg xmlns="http://www.w3.org/2000/svg" width="{width}" '
            f'height="{height}" viewBox="0 0 {width} {height}">'
        ),
        '<rect width="100%" height="100%" fill="white"/>',
        (
            f'<text x="{width / 2}" y="32" text-anchor="middle" '
            f'font-family="sans-serif" font-size="21">{escape(title)}</text>'
        ),
    ]
    for index, (label, points) in enumerate(panels):
        y0 = top + index * panel_height
        plot_height = panel_height - 55
        numeric_points = [
            (float(x), float(y))
            for x, y in points
            if math.isfinite(float(x)) and math.isfinite(float(y))
        ]
        parts.extend(
            [
                (
                    f'<text x="{margin_x}" y="{y0 - 8}" font-family="sans-serif" '
                    f'font-size="14">{escape(label)}</text>'
                ),
                (
                    f'<line x1="{margin_x}" y1="{y0}" x2="{margin_x}" '
                    f'y2="{y0 + plot_height}" stroke="#555"/>'
                ),
                (
                    f'<line x1="{margin_x}" y1="{y0 + plot_height}" '
                    f'x2="{margin_x + plot_width}" y2="{y0 + plot_height}" '
                    'stroke="#555"/>'
                ),
            ]
        )
        if not numeric_points:
            parts.append(
                (
                    f'<text x="{margin_x + 20}" y="{y0 + 35}" '
                    'font-family="sans-serif" font-size="12" fill="#777">'
                    "no numeric data</text>"
                )
            )
            continue
        xs = [point[0] for point in numeric_points]
        ys = [point[1] for point in numeric_points]
        x_min, x_max = min(xs), max(xs)
        y_min, y_max = min(ys), max(ys)
        if math.isclose(x_min, x_max):
            x_max = x_min + 1.0
        if math.isclose(y_min, y_max):
            padding = max(1.0, abs(y_min) * 0.05)
            y_min -= padding
            y_max += padding
        coordinates = []
        for x_value, y_value in numeric_points:
            x_pixel = margin_x + (x_value - x_min) / (x_max - x_min) * plot_width
            y_pixel = y0 + plot_height - (
                (y_value - y_min) / (y_max - y_min) * plot_height
            )
            coordinates.append(f"{x_pixel:.2f},{y_pixel:.2f}")
        parts.extend(
            [
                (
                    f'<polyline fill="none" stroke="{colors[index % len(colors)]}" '
                    f'stroke-width="1.8" points="{" ".join(coordinates)}"/>'
                ),
                (
                    f'<text x="{margin_x - 7}" y="{y0 + 5}" text-anchor="end" '
                    f'font-family="monospace" font-size="10">{y_max:.4g}</text>'
                ),
                (
                    f'<text x="{margin_x - 7}" y="{y0 + plot_height}" '
                    f'text-anchor="end" font-family="monospace" '
                    f'font-size="10">{y_min:.4g}</text>'
                ),
                (
                    f'<text x="{margin_x}" y="{y0 + plot_height + 17}" '
                    f'font-family="monospace" font-size="10">{x_min:.4g}</text>'
                ),
                (
                    f'<text x="{margin_x + plot_width}" '
                    f'y="{y0 + plot_height + 17}" text-anchor="end" '
                    f'font-family="monospace" font-size="10">{x_max:.4g}</text>'
                ),
            ]
        )
    parts.append(
        (
            f'<text x="{width / 2}" y="{height - 15}" text-anchor="middle" '
            f'font-family="sans-serif" font-size="13">{escape(x_label)}</text>'
        )
    )
    parts.append("</svg>")
    path.write_text("\n".join(parts) + "\n", encoding="utf-8")


def generate_svg_plots(
    output_dir: Path,
    combined: Sequence[dict[str, Any]],
    summaries: Sequence[dict[str, Any]],
) -> list[str]:
    output_dir.mkdir(parents=True, exist_ok=True)
    rows = sorted(combined, key=lambda row: int(row["ts_utc_ns"]))

    def time_points(metric_id: str) -> list[tuple[float, float]]:
        result: list[tuple[float, float]] = []
        for row in rows:
            x_value = numeric(row.get("elapsed_s"))
            y_value = numeric(row.get(metric_id))
            if x_value is not None and y_value is not None:
                result.append((x_value, y_value))
        return result

    time_panels = [
        ("Requested injection intensity (%)", time_points("requested_intensity_pct")),
        ("Training step time (ms)", time_points("global_task.step_time_ms")),
        ("Training throughput (samples/s)", time_points("global_task.throughput_sps")),
        ("NPU power (W)", time_points("npu.power_w")),
        ("NPU temperature (C)", time_points("npu.temperature_c")),
    ]
    time_path = output_dir / "f03_timeseries.svg"
    _write_svg_panels(
        time_path,
        title="F03 aligned time-series",
        panels=time_panels,
        x_label="Elapsed time (s)",
    )

    response_metric_ids = (
        "injection.measured_duty_pct",
        "global_task.step_time_ms",
        "global_task.throughput_sps",
        "npu.power_w",
        "npu.temperature_c",
        "npu.aicore_stall_ratio",
    )
    response_panels: list[tuple[str, list[tuple[float, float]]]] = []
    for metric_id in response_metric_ids:
        points = []
        for row in summaries:
            if row.get("metric_id") != metric_id:
                continue
            x_value = numeric(row.get("requested_intensity_pct"))
            y_value = numeric(row.get("mean"))
            if x_value is not None and y_value is not None:
                points.append((x_value, y_value))
        response_panels.append((metric_id, sorted(points)))
    response_path = output_dir / "f03_intensity_response.svg"
    _write_svg_panels(
        response_path,
        title="F03 intensity-response stage means",
        panels=response_panels,
        x_label="Requested injection intensity (%)",
    )
    return [str(time_path), str(response_path)]


def _write_dynamic_csv(path: Path, rows: Sequence[dict[str, Any]]) -> None:
    fields: list[str] = []
    seen: set[str] = set()
    for row in rows:
        for key in row:
            if key not in seen:
                seen.add(key)
                fields.append(key)
    if not fields:
        fields = ["status"]
        rows = [{"status": "no rows"}]
    write_csv(path, rows, fields)


def analyze_run(
    run_dir: Path,
    *,
    hgnn_run_dir: Path | None = None,
) -> dict[str, Any]:
    run_dir = run_dir.expanduser().resolve()
    manifest_path = run_dir / "manifest.json"
    manifest = read_json(manifest_path, {}) or {}
    timeline = read_json(run_dir / "stage_timeline.json", []) or manifest.get(
        "stage_timeline", []
    )
    if not isinstance(timeline, list) or not timeline:
        raise ValueError("stage timeline is missing")
    if hgnn_run_dir is None:
        configured = manifest.get("hgnn_run_dir")
        if configured:
            candidate = Path(configured)
            if candidate.is_dir():
                hgnn_run_dir = candidate

    stage_ids = [str(stage["stage_id"]) for stage in timeline]
    profiler_records, profiler_inventory = parse_profiler_tree(
        run_dir / "raw" / "profiler", stage_ids
    )
    combined = combined_timeseries(run_dir, timeline, profiler_records)
    summaries = stage_summary_rows(combined, timeline)
    assessment = response_assessment(summaries)

    report_dir = run_dir / "reports"
    report_dir.mkdir(parents=True, exist_ok=True)
    combined_path = report_dir / "metric_timeseries_1s.csv"
    summary_path = report_dir / "stage_summary.csv"
    profiler_path = report_dir / "profiler_metrics.json"
    response_path = report_dir / "response_assessment.json"
    long_path = report_dir / "all_metrics_long.csv"
    _write_dynamic_csv(combined_path, combined)
    _write_dynamic_csv(summary_path, summaries)
    atomic_write_json(profiler_path, profiler_records)
    atomic_write_json(
        report_dir / "profiler_inventory.json", profiler_inventory
    )
    atomic_write_json(response_path, assessment)
    long_result = export_hgnn_long_csv(hgnn_run_dir, long_path, timeline)

    dependency_errors: list[str] = []
    workbook_result: dict[str, Any] | None = None
    plot_paths: list[str] = []
    dictionary = _load_metric_dictionary(hgnn_run_dir)
    try:
        workbook_result = write_workbook(
            report_dir / "f03_complete_metric_timeseries.xlsx",
            manifest=manifest,
            combined=combined,
            training=read_csv(run_dir / "raw" / "training_steps.csv"),
            profiler=profiler_records,
            summaries=summaries,
            long_csv=long_path,
            events_path=run_dir / "raw" / "events.jsonl",
            dictionary=dictionary,
        )
    except Exception as error:
        dependency_errors.append(
            f"xlsx generation failed: {type(error).__name__}: {error}"
        )
    try:
        plot_paths = generate_plots(report_dir, combined, summaries)
    except Exception as error:
        dependency_errors.append(
            f"plot generation failed: {type(error).__name__}: {error}"
        )
        try:
            plot_paths = generate_svg_plots(report_dir, combined, summaries)
        except Exception as fallback_error:
            dependency_errors.append(
                "SVG fallback generation failed: "
                f"{type(fallback_error).__name__}: {fallback_error}"
            )

    stage_counts: dict[str, int] = {}
    for row in combined:
        stage_id = str(row.get("stage_id"))
        stage_counts[stage_id] = stage_counts.get(stage_id, 0) + 1
    missing_stages = [
        stage_id for stage_id in stage_ids if stage_counts.get(stage_id, 0) == 0
    ]
    training_rows = read_csv(run_dir / "raw" / "training_steps.csv")
    training_stage_counts: dict[str, int] = {}
    for row in training_rows:
        stage_id = str(row.get("stage_id"))
        training_stage_counts[stage_id] = training_stage_counts.get(stage_id, 0) + 1
    missing_training_stages = [
        stage_id
        for stage_id in stage_ids
        if training_stage_counts.get(stage_id, 0) == 0
    ]
    checks = {
        "combined_timeseries_nonempty": bool(combined),
        "all_stages_have_safety_samples": not missing_stages,
        "all_stages_have_training_steps": not missing_training_stages,
        "injection_control_verified": assessment["injection_control_verified"],
        "multi_level_gradient_verified": assessment[
            "multi_level_gradient_verified"
        ],
        "table_csv_generated": combined_path.is_file() and combined_path.stat().st_size > 0,
        "xlsx_generated": workbook_result is not None,
        "plots_generated": len(plot_paths) == 2,
        "profiler_resource_conflict_files": len(
            profiler_inventory["files"]["resource_conflict"]
        ),
        "hgnn_long_export": long_result,
    }
    requested_injection_levels = {
        numeric(stage.get("requested_intensity_pct"))
        for stage in timeline
        if bool(stage.get("inject"))
    }
    gradient_required = len(requested_injection_levels) >= 2
    required_passed = all(
        (
            checks["combined_timeseries_nonempty"],
            checks["all_stages_have_safety_samples"],
            checks["all_stages_have_training_steps"],
            checks["injection_control_verified"],
            (not gradient_required) or checks["multi_level_gradient_verified"],
            checks["table_csv_generated"],
            checks["plots_generated"],
        )
    )
    result = {
        "passed": required_passed,
        "run_dir": str(run_dir),
        "hgnn_run_dir": str(hgnn_run_dir) if hgnn_run_dir else None,
        "checks": checks,
        "missing_stages": missing_stages,
        "missing_training_stages": missing_training_stages,
        "dependency_errors": dependency_errors,
        "outputs": {
            "metric_timeseries_csv": str(combined_path),
            "all_metrics_long_csv": str(long_path),
            "stage_summary_csv": str(summary_path),
            "profiler_metrics_json": str(profiler_path),
            "response_assessment_json": str(response_path),
            "xlsx": workbook_result["output"] if workbook_result else None,
            "plots": plot_paths,
        },
    }
    atomic_write_json(report_dir / "analysis_report.json", result)
    return result


def create_bundle(run_dir: Path, *, extra_paths: Sequence[Path] = ()) -> Path:
    bundle = run_dir.with_suffix(".tar.gz")
    temporary = bundle.with_suffix(bundle.suffix + ".tmp")
    with tarfile.open(temporary, "w:gz") as archive:
        archive.add(run_dir, arcname=run_dir.name)
        for extra_path in extra_paths:
            if extra_path.is_dir():
                archive.add(
                    extra_path,
                    arcname=f"{run_dir.name}__{extra_path.name}",
                )
    temporary.replace(bundle)
    return bundle


def simulate_run(args: argparse.Namespace, plan: PilotPlan) -> dict[str, Any]:
    timestamp = datetime.now(UTC).strftime("%Y%m%dT%H%M%SZ")
    run_id = args.run_id or f"{timestamp}-f03-simulation-{uuid.uuid4().hex[:8]}"
    run_dir = args.output_root.expanduser().resolve() / run_id
    (run_dir / "raw" / "injector").mkdir(parents=True)
    (run_dir / "raw" / "profiler").mkdir(parents=True)
    start_utc = time.time_ns()
    start_mono = time.monotonic_ns()
    timeline: list[dict[str, Any]] = []
    safety_rows: list[dict[str, Any]] = []
    training_rows: list[dict[str, Any]] = []
    cursor_s = 0
    step_id = 0
    for stage_index, stage in enumerate(plan.stages):
        stage_start_utc = start_utc + cursor_s * 1_000_000_000
        stage_start_mono = start_mono + cursor_s * 1_000_000_000
        stage_end_utc = stage_start_utc + stage.duration_s * 1_000_000_000
        stage_end_mono = stage_start_mono + stage.duration_s * 1_000_000_000
        timeline.append(
            {
                **asdict(stage),
                "start_utc_ns": stage_start_utc,
                "start_mono_ns": stage_start_mono,
                "planned_end_mono_ns": stage_end_mono,
                "actual_end_utc_ns": stage_end_utc,
                "actual_end_mono_ns": stage_end_mono,
            }
        )
        intensity = stage.requested_intensity_pct
        measured = intensity * (0.94 + stage_index * 0.005) if stage.inject else None
        injector_rows: list[dict[str, Any]] = []
        for second_offset in range(stage.duration_s):
            timestamp_ns = stage_start_utc + second_offset * 1_000_000_000
            elapsed = cursor_s + second_offset
            thermal_lag = min(second_offset / max(1, stage.duration_s / 2), 1)
            temperature = 42 + intensity * 0.08 * thermal_lag
            safety_rows.append(
                {
                    "ts_utc_ns": timestamp_ns,
                    "ts_utc_iso": utc_iso(timestamp_ns),
                    "ts_mono_ns": stage_start_mono
                    + second_offset * 1_000_000_000,
                    "elapsed_s": elapsed,
                    "stage_id": stage.stage_id,
                    "requested_intensity_pct": intensity,
                    "device_id": plan.device_id,
                    "npu_temperature_c": temperature,
                    "npu_power_w": 180 + intensity * 4.2,
                    "npu_utilization_pct": min(99, 35 + intensity * 1.6),
                    "hbm_used_bytes": 4 * 1024**3,
                    "hbm_total_bytes": 64 * 1024**3,
                    "hbm_utilization_pct": 6.25,
                    "npu_health_state": "OK",
                    "target_alive": True,
                    "injector_alive": stage.inject,
                    "heartbeat_age_s": 0.05,
                    "sample_status": "ok",
                    "sample_error": "",
                }
            )
            if stage.inject:
                injector_rows.append(
                    {
                        "ts_utc_ns": timestamp_ns,
                        "ts_mono_ns": stage_start_mono
                        + second_offset * 1_000_000_000,
                        "stage_id": stage.stage_id,
                        "device_id": plan.device_id,
                        "requested_intensity_pct": intensity,
                        "measured_duty_pct": measured,
                        "window_elapsed_ms": 1000,
                        "active_ms": measured * 10,
                        "op_count": max(1, int(intensity)),
                        "tensor_dim": plan.tensor_dim,
                    }
                )
            for local_step in range(5):
                step_ms = 12 * (1 + intensity * 0.018) + local_step * 0.02
                step_start = timestamp_ns + local_step * 180_000_000
                step_end = step_start + int(step_ms * 1_000_000)
                training_rows.append(
                    {
                        "ts_start_utc_ns": step_start,
                        "ts_end_utc_ns": step_end,
                        "ts_start_mono_ns": start_mono
                        + (elapsed * 1_000_000_000)
                        + local_step * 180_000_000,
                        "ts_end_mono_ns": start_mono
                        + (elapsed * 1_000_000_000)
                        + local_step * 180_000_000
                        + int(step_ms * 1_000_000),
                        "stage_id": stage.stage_id,
                        "requested_intensity_pct": intensity,
                        "step_id": step_id,
                        "rank_id": 0,
                        "device_id": plan.device_id,
                        "samples": 32,
                        "step_time_ms": step_ms,
                        "throughput_sps": 32 * 1000 / step_ms,
                        "loss_value": 1.2345,
                        "heartbeat_seq": step_id + 1,
                        "hbm_alloc_retries": 0,
                        "hbm_oom_count": 0,
                        "profiler_active": stage.profile,
                    }
                )
                step_id += 1
        if injector_rows:
            write_csv(
                run_dir / "raw" / "injector" / f"{stage.stage_id}.csv",
                injector_rows,
                INJECTOR_FIELDS,
            )
        if stage.profile:
            profiler_dir = run_dir / "raw" / "profiler" / stage.stage_id
            profiler_dir.mkdir(parents=True, exist_ok=True)
            conflict_fields = [
                "block_id",
                "sub_block_id",
                "aic_total_cycles",
                "aiv_total_cycles",
                "aic_cube_wait_ratio",
                "aiv_vec_total_cflt_ratio",
                "aiv_vec_wait_ratio",
            ]
            conflict_rows = [
                {
                    "block_id": index,
                    "sub_block_id": "vector0",
                    "aic_total_cycles": 10000,
                    "aiv_total_cycles": 10000,
                    "aic_cube_wait_ratio": 0.01 + intensity * 0.001,
                    "aiv_vec_total_cflt_ratio": 0.02 + intensity * 0.0015,
                    "aiv_vec_wait_ratio": 0.015 + intensity * 0.0012,
                }
                for index in range(8)
            ]
            write_csv(
                profiler_dir / "ResourceConflictRatio.csv",
                conflict_rows,
                conflict_fields,
            )
            write_csv(
                profiler_dir / "step_trace_time.csv",
                [
                    {
                        "Device_id": plan.device_id,
                        "Step": index,
                        "Computing": 10000,
                        "Communication(Not Overlapped)": 0,
                        "Overlapped": 0,
                        "Communication": 0,
                        "Free": 0,
                        "Stage": 12000 * (1 + intensity * 0.018),
                    }
                    for index in range(5)
                ],
                [
                    "Device_id",
                    "Step",
                    "Computing",
                    "Communication(Not Overlapped)",
                    "Overlapped",
                    "Communication",
                    "Free",
                    "Stage",
                ],
            )
            write_csv(
                profiler_dir / "hbm.csv",
                [
                    {
                        "Device_id": plan.device_id,
                        "Metric": "Average",
                        "Read(MB/s)": 5000 + intensity * 40,
                        "Write(MB/s)": 3000 + intensity * 25,
                    }
                ],
                ["Device_id", "Metric", "Read(MB/s)", "Write(MB/s)"],
            )
        cursor_s += stage.duration_s

    write_csv(run_dir / "raw" / "safety_timeseries.csv", safety_rows, SAFETY_FIELDS)
    write_csv(run_dir / "raw" / "training_steps.csv", training_rows, TRAINING_FIELDS)
    append_jsonl(
        run_dir / "raw" / "events.jsonl",
        {
            "event_type": "SIMULATION_GENERATED",
            "ts_utc_ns": start_utc,
            "ts_mono_ns": start_mono,
            "run_id": run_id,
        },
    )
    atomic_write_json(run_dir / "stage_timeline.json", timeline)
    atomic_write_json(
        run_dir / "manifest.json",
        {
            "script_version": SCRIPT_VERSION,
            "run_id": run_id,
            "fault_code": FAULT_CODE,
            "status": "raw_complete",
            "simulation": True,
            "device_id": plan.device_id,
            "plan": plan_payload(plan),
            "stage_timeline": timeline,
            "created_at_utc_ns": start_utc,
            "hgnn_run_dir": None,
        },
    )
    analysis = analyze_run(run_dir)
    manifest = read_json(run_dir / "manifest.json", {}) or {}
    manifest.update({"status": "complete", "analysis": analysis})
    atomic_write_json(run_dir / "manifest.json", manifest)
    bundle = create_bundle(run_dir)
    return {
        "passed": analysis["passed"],
        "run_dir": str(run_dir),
        "analysis": analysis,
        "bundle": str(bundle),
    }


def add_plan_arguments(parser: argparse.ArgumentParser) -> None:
    parser.add_argument("--device-id", type=int, default=0)
    parser.add_argument(
        "--intensities",
        default="10,20,30",
        help="逗号分隔的正占空比百分比；0% 基线与恢复窗口会自动加入",
    )
    parser.add_argument("--warmup-duration", type=int, default=15)
    parser.add_argument("--stage-duration", type=int, default=60)
    parser.add_argument("--recovery-duration", type=int, default=60)
    parser.add_argument("--sample-interval", type=float, default=1.0)
    parser.add_argument("--detail-interval", type=float, default=5.0)
    parser.add_argument("--tensor-dim", type=int, default=2048)
    parser.add_argument("--max-temperature-c", type=float, default=72.0)
    parser.add_argument("--heartbeat-timeout", type=float, default=15.0)
    parser.add_argument(
        "--enable-profiler",
        action=argparse.BooleanOptionalAction,
        default=True,
        help="每个基线/注入阶段采集一次短 ResourceConflictRatio profile",
    )
    parser.add_argument(
        "--skip-hgnn-collector",
        action="store_true",
        help="只运行安全采样、训练 telemetry 和 profiler，不启动现有 hgnn-collect",
    )


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description=(
            "Ascend 910C F03 单卡轻量资源挤占：分强度注入、统一采集、"
            "时间对齐、XLSX 与曲线导出"
        )
    )
    parser.add_argument("--version", action="version", version=SCRIPT_VERSION)
    commands = parser.add_subparsers(dest="command", required=True)

    plan = commands.add_parser("plan", help="只打印安全计划，不访问 NPU")
    add_plan_arguments(plan)

    preflight_parser = commands.add_parser(
        "preflight", help="只读检查 NPU、torch_npu、profiler 和导出依赖"
    )
    add_plan_arguments(preflight_parser)
    preflight_parser.add_argument("--output-root", type=Path, default=DEFAULT_OUTPUT_ROOT)
    preflight_parser.add_argument("--config", type=Path, default=DEFAULT_CONFIG)
    preflight_parser.add_argument("--allow-busy-device", action="store_true")
    preflight_parser.add_argument(
        "--allow-missing-report-deps", action="store_true"
    )

    run = commands.add_parser(
        "run", help="默认只打印计划；增加 --execute 才真正执行"
    )
    add_plan_arguments(run)
    run.add_argument("--execute", action="store_true")
    run.add_argument("--output-root", type=Path, default=DEFAULT_OUTPUT_ROOT)
    run.add_argument(
        "--hgnn-data-root",
        type=Path,
        default=Path("/datadisk1/hgnn_fault_evolution_data"),
    )
    run.add_argument("--config", type=Path, default=DEFAULT_CONFIG)
    run.add_argument("--run-id")
    run.add_argument("--allow-busy-device", action="store_true")
    run.add_argument("--allow-missing-report-deps", action="store_true")
    run.add_argument("--target-hidden-dim", type=int, default=1024)
    run.add_argument("--target-batch-size", type=int, default=32)
    run.add_argument("--target-think-time-ms", type=float, default=5.0)
    run.add_argument("--target-start-timeout", type=float, default=60.0)
    run.add_argument("--injection-cycle-ms", type=float, default=200.0)
    run.add_argument("--seed", type=int, default=20260727)

    analyze = commands.add_parser(
        "analyze", help="对已复制回来的试点目录重新生成表格与曲线"
    )
    analyze.add_argument("--run-dir", type=Path, required=True)
    analyze.add_argument("--hgnn-run-dir", type=Path)
    analyze.add_argument("--bundle", action="store_true")

    simulate = commands.add_parser(
        "simulate", help="不访问 NPU，生成模拟原始数据并验证完整导出链"
    )
    add_plan_arguments(simulate)
    simulate.set_defaults(skip_hgnn_collector=True)
    simulate.add_argument(
        "--output-root",
        type=Path,
        default=Path("reports") / "f03_simulation",
    )
    simulate.add_argument("--run-id")

    workload = commands.add_parser("_workload", help=argparse.SUPPRESS)
    workload.add_argument("--control-file", required=True)
    workload.add_argument("--stop-file", required=True)
    workload.add_argument("--output", required=True)
    workload.add_argument("--profiler-root", required=True)
    workload.add_argument("--event-file", required=True)
    workload.add_argument("--device-id", type=int, required=True)
    workload.add_argument("--physical-device-id", type=int, required=True)
    workload.add_argument("--max-temperature-c", type=float, required=True)
    workload.add_argument("--hidden-dim", type=int, required=True)
    workload.add_argument("--batch-size", type=int, required=True)
    workload.add_argument("--think-time-ms", type=float, required=True)
    workload.add_argument("--seed", type=int, required=True)
    workload.add_argument("--max-runtime-s", type=float, required=True)

    injector = commands.add_parser("_injector", help=argparse.SUPPRESS)
    injector.add_argument("--stop-file", required=True)
    injector.add_argument("--output", required=True)
    injector.add_argument("--event-file", required=True)
    injector.add_argument("--stage-id", required=True)
    injector.add_argument("--device-id", type=int, required=True)
    injector.add_argument("--physical-device-id", type=int, required=True)
    injector.add_argument("--max-temperature-c", type=float, required=True)
    injector.add_argument("--expected-target-pid", type=int, required=True)
    injector.add_argument("--intensity", type=float, required=True)
    injector.add_argument("--tensor-dim", type=int, required=True)
    injector.add_argument("--cycle-ms", type=float, required=True)
    injector.add_argument("--seed", type=int, required=True)
    injector.add_argument("--max-runtime-s", type=float, required=True)
    return parser


def command_plan(args: argparse.Namespace) -> int:
    print(json.dumps(plan_payload(build_plan(args)), ensure_ascii=False, indent=2))
    return 0


def command_preflight(args: argparse.Namespace) -> int:
    plan = build_plan(args)
    result = preflight(
        plan,
        output_root=args.output_root,
        config_path=args.config.expanduser().resolve(),
        allow_busy_device=args.allow_busy_device,
        require_reporting_dependencies=not args.allow_missing_report_deps,
    )
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0 if result["passed"] else 2


def command_run(args: argparse.Namespace) -> int:
    plan = build_plan(args)
    if not args.execute:
        payload = plan_payload(plan)
        payload["next_step"] = (
            "先运行 preflight；确认使用已预留单卡后设置 "
            f"HGNN_F03_APPROVAL={APPROVAL_TOKEN} 并增加 --execute"
        )
        print(json.dumps(payload, ensure_ascii=False, indent=2))
        return 0
    if (
        os.geteuid() == 0
        and os.environ.get("HGNN_F03_ROOT_APPROVAL") != ROOT_APPROVAL_TOKEN
    ):
        raise PermissionError(
            "root execution requires HGNN_F03_ROOT_APPROVAL="
            f"{ROOT_APPROVAL_TOKEN}"
        )
    if os.environ.get("HGNN_F03_APPROVAL") != APPROVAL_TOKEN:
        raise PermissionError(
            "execution requires HGNN_F03_APPROVAL="
            f"{APPROVAL_TOKEN}"
        )
    result = preflight(
        plan,
        output_root=args.output_root,
        config_path=args.config.expanduser().resolve(),
        allow_busy_device=args.allow_busy_device,
        require_reporting_dependencies=not args.allow_missing_report_deps,
    )
    if not result["passed"]:
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return 2
    device_mapping = result.get("device_mapping")
    if not isinstance(device_mapping, dict) or not isinstance(
        device_mapping.get("logic_id"), int
    ):
        raise RuntimeError("validated physical-to-torch device mapping is missing")
    plan = replace(plan, torch_device_id=int(device_mapping["logic_id"]))
    runtime = PilotRuntime(args, plan)
    outcome = runtime.run()
    print(json.dumps(outcome, ensure_ascii=False, indent=2))
    return 0 if outcome.get("passed") else 2


def command_analyze(args: argparse.Namespace) -> int:
    result = analyze_run(
        args.run_dir,
        hgnn_run_dir=(
            args.hgnn_run_dir.expanduser().resolve()
            if args.hgnn_run_dir
            else None
        ),
    )
    if args.bundle:
        result["bundle"] = str(create_bundle(args.run_dir.expanduser().resolve()))
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0 if result["passed"] else 2


def command_simulate(args: argparse.Namespace) -> int:
    result = simulate_run(args, build_plan(args))
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0 if result["passed"] else 2


def main(argv: Sequence[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    try:
        if args.command == "plan":
            return command_plan(args)
        if args.command == "preflight":
            return command_preflight(args)
        if args.command == "run":
            return command_run(args)
        if args.command == "analyze":
            return command_analyze(args)
        if args.command == "simulate":
            return command_simulate(args)
        if args.command == "_workload":
            return workload_child(args)
        if args.command == "_injector":
            return injector_child(args)
        parser.error(f"unsupported command: {args.command}")
    except KeyboardInterrupt:
        print("interrupted", file=sys.stderr)
        return 130
    except Exception as error:
        print(f"{type(error).__name__}: {error}", file=sys.stderr)
        return 1
    return 1


if __name__ == "__main__":
    raise SystemExit(main())

