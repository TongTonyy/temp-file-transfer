#!/bin/bash
# Run energy-state calibration on a 910C server.
#
# v3-fix1 (2026-11-12) — fixes found during dry-run review:
#   * GEMM args renamed --m/--n/--k -> --gm/--gn/--gk: torchrun's argparse
#     aborts with "ambiguous option: --m" (rc=2) otherwise.
#   * Iteration counts raised so every workload sustains >= ~30s of load
#     (fixed counts keep the 16 ranks in lockstep; short bursts of <1s get
#     their power deltas diluted by the idle padding in the sampler window).
#   * make_group() now creates ALL subgroups on every rank (collective
#     rendezvous requirement; own-group-only creation risks HCCL hangs).
#
# v3 (2026-11-12) — 按 ENERGY_CALIBRATION_REQUIREMENTS.md 补齐：
#   * compute / memory / vector 全部改为 torchrun 16 rank 同压
#   * GEMM 3 个 shape（含贴近 Qwen3 MLP 的 4096x5120x17408）
#   * memory_copy 64M/128M/256M，vector_norm rows 4096/8192/16384
#   * 通信补 P2P ring 与 group size 2/4/8（g16 由主通信矩阵覆盖）

set -u
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
# shellcheck disable=SC1091
source "$SCRIPT_DIR/common_env.sh"

OUT_ROOT=${OUT_ROOT:-$SCRIPT_DIR/results_energy_calibration}
mkdir -p "$OUT_ROOT"

run_with_sampler() {
  local name=$1
  shift
  local dir="$OUT_ROOT/$name"
  mkdir -p "$dir"
  echo "======================================================================"
  echo "[$(date '+%F %T')] $name"
  echo "command: $*"
  echo "======================================================================"
  SAMPLE_INTERVAL_SEC=${SAMPLE_INTERVAL_SEC:-1} bash "$SCRIPT_DIR/sampler_power_mem.sh" "$dir/power_mem.csv" &
  local sampler_pid=$!
  sleep 5
  ( "$@" ) > "$dir/run.log" 2>&1
  local rc=$?
  sleep 3
  kill "$sampler_pid" 2>/dev/null || true
  wait "$sampler_pid" 2>/dev/null || true
  echo "$rc" > "$dir/exit_code.txt"
  if [ "$rc" != "0" ]; then
    echo "[warn] $name rc=$rc; see $dir/run.log"
  fi
  return 0
}

torchrun_bench() {
  local port=$1
  shift
  torchrun \
    --nproc_per_node "$NPUS_PER_NODE" \
    --nnodes 1 \
    --node_rank 0 \
    --master_addr "$MASTER_ADDR" \
    --master_port "$port" \
    "$SCRIPT_DIR/energy_microbench_910c.py" "$@"
}

cd "$SCRIPT_DIR" || exit 1

echo "[idle] sampling idle power for ${IDLE_SECONDS:-300} seconds (no jobs running!)"
mkdir -p "$OUT_ROOT/idle"
SAMPLE_INTERVAL_SEC=${SAMPLE_INTERVAL_SEC:-1} bash "$SCRIPT_DIR/sampler_power_mem.sh" "$OUT_ROOT/idle/power_mem.csv" &
idle_pid=$!
sleep "${IDLE_SECONDS:-300}"
kill "$idle_pid" 2>/dev/null || true
wait "$idle_pid" 2>/dev/null || true
echo "0" > "$OUT_ROOT/idle/exit_code.txt"

port=${MASTER_PORT:-7920}

# ---------- compute: GEMM 3 shapes × 16 ranks, sustained ----------
# iters sized for ~30-40s load each (fixed counts, lockstep-safe)
run_with_sampler compute_gemm_shapeA torchrun_bench $port \
  --mode compute_gemm --out "$OUT_ROOT/bench_metrics.csv" --iters 40000 --gm 4096 --gn 4096 --gk 4096
port=$((port + 1))
run_with_sampler compute_gemm_shapeB torchrun_bench $port \
  --mode compute_gemm --out "$OUT_ROOT/bench_metrics.csv" --iters 20000 --gm 8192 --gn 4096 --gk 4096
port=$((port + 1))
# 贴近 Qwen3-14B MLP：m=4096 (seq tokens), n=5120 (hidden), k=17408 (ffn)
run_with_sampler compute_gemm_shapeC torchrun_bench $port \
  --mode compute_gemm --out "$OUT_ROOT/bench_metrics.csv" --iters 8000 --gm 4096 --gn 5120 --gk 17408
port=$((port + 1))

# ---------- memory / vector：16 ranks, sustained ----------
run_with_sampler memory_copy_67108864 torchrun_bench $port \
  --mode memory_copy --out "$OUT_ROOT/bench_metrics.csv" --iters 160000 --numel 67108864
port=$((port + 1))
run_with_sampler memory_copy_134217728 torchrun_bench $port \
  --mode memory_copy --out "$OUT_ROOT/bench_metrics.csv" --iters 80000 --numel 134217728
port=$((port + 1))
run_with_sampler memory_copy_268435456 torchrun_bench $port \
  --mode memory_copy --out "$OUT_ROOT/bench_metrics.csv" --iters 40000 --numel 268435456
port=$((port + 1))

run_with_sampler vector_norm_r4096 torchrun_bench $port \
  --mode vector_norm --out "$OUT_ROOT/bench_metrics.csv" --iters 65000 --rows 4096 --cols 5120
port=$((port + 1))
run_with_sampler vector_norm_r8192 torchrun_bench $port \
  --mode vector_norm --out "$OUT_ROOT/bench_metrics.csv" --iters 29000 --rows 8192 --cols 5120
port=$((port + 1))
run_with_sampler vector_norm_r16384 torchrun_bench $port \
  --mode vector_norm --out "$OUT_ROOT/bench_metrics.csv" --iters 15000 --rows 16384 --cols 5120
port=$((port + 1))

# ---------- HCCL 集合通信：3 算子 × 3 消息量 × world=16, sustained ----------
run_with_sampler all_reduce_g16_16777216 torchrun_bench $port \
  --mode all_reduce --out "$OUT_ROOT/bench_metrics.csv" --iters 50000 --numel 16777216
port=$((port + 1))
run_with_sampler all_reduce_g16_67108864 torchrun_bench $port \
  --mode all_reduce --out "$OUT_ROOT/bench_metrics.csv" --iters 23500 --numel 67108864
port=$((port + 1))
run_with_sampler all_reduce_g16_134217728 torchrun_bench $port \
  --mode all_reduce --out "$OUT_ROOT/bench_metrics.csv" --iters 12300 --numel 134217728
port=$((port + 1))
run_with_sampler all_gather_g16_16777216 torchrun_bench $port \
  --mode all_gather --out "$OUT_ROOT/bench_metrics.csv" --iters 10200 --numel 16777216
port=$((port + 1))
run_with_sampler all_gather_g16_67108864 torchrun_bench $port \
  --mode all_gather --out "$OUT_ROOT/bench_metrics.csv" --iters 2700 --numel 67108864
port=$((port + 1))
run_with_sampler all_gather_g16_134217728 torchrun_bench $port \
  --mode all_gather --out "$OUT_ROOT/bench_metrics.csv" --iters 1350 --numel 134217728
port=$((port + 1))
run_with_sampler reduce_scatter_g16_16777216 torchrun_bench $port \
  --mode reduce_scatter --out "$OUT_ROOT/bench_metrics.csv" --iters 8800 --numel 16777216
port=$((port + 1))
run_with_sampler reduce_scatter_g16_67108864 torchrun_bench $port \
  --mode reduce_scatter --out "$OUT_ROOT/bench_metrics.csv" --iters 2350 --numel 67108864
port=$((port + 1))
run_with_sampler reduce_scatter_g16_134217728 torchrun_bench $port \
  --mode reduce_scatter --out "$OUT_ROOT/bench_metrics.csv" --iters 1200 --numel 134217728
port=$((port + 1))

# ---------- 通信组规模扫描：all_reduce 64M × group 2/4/8 ----------
run_with_sampler all_reduce_g2_67108864 torchrun_bench $port \
  --mode all_reduce --out "$OUT_ROOT/bench_metrics.csv" --iters 28300 --numel 67108864 --group-size 2
port=$((port + 1))
run_with_sampler all_reduce_g4_67108864 torchrun_bench $port \
  --mode all_reduce --out "$OUT_ROOT/bench_metrics.csv" --iters 32200 --numel 67108864 --group-size 4
port=$((port + 1))
run_with_sampler all_reduce_g8_67108864 torchrun_bench $port \
  --mode all_reduce --out "$OUT_ROOT/bench_metrics.csv" --iters 27700 --numel 67108864 --group-size 8
port=$((port + 1))

# ---------- P2P ring：流水级间典型激活量 ----------
# seq4096 × hidden5120 × bf16 × micro_batch: b1=20971520 元素, b2=41943040 元素
run_with_sampler p2p_ring_20971520 torchrun_bench $port \
  --mode p2p --out "$OUT_ROOT/bench_metrics.csv" --iters 55300 --numel 20971520
port=$((port + 1))
run_with_sampler p2p_ring_41943040 torchrun_bench $port \
  --mode p2p --out "$OUT_ROOT/bench_metrics.csv" --iters 27900 --numel 41943040
port=$((port + 1))

echo "[done] results in $OUT_ROOT"
