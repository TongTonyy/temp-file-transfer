#!/usr/bin/env python3
import csv
import re
import sys
from pathlib import Path


def parse_step_ms(text):
    vals = []
    for m in re.finditer(r"Elapsed time per iteration \(ms\):\s*([0-9.]+)", text):
        vals.append(float(m.group(1)))
    for m in re.finditer(r"elapsed time per iteration \(ms\):\s*([0-9.]+)", text, re.I):
        vals.append(float(m.group(1)))
    if len(vals) > 5:
        vals = vals[5:]
    return sum(vals) / len(vals) if vals else ""


def parse_mem(text):
    alloc = []
    reserved = []
    for m in re.finditer(r"\[MEMREPORT rank \d+\] max_allocated=([0-9.]+) GiB max_reserved=([0-9.]+) GiB", text):
        alloc.append(float(m.group(1)))
        reserved.append(float(m.group(2)))
    return (max(alloc) if alloc else "", max(reserved) if reserved else "")


def main():
    root = Path(sys.argv[1])
    rows = []
    for d in sorted(root.glob("zero*")):
        if not d.is_dir():
            continue
        text = (d / "train.log").read_text(errors="ignore") if (d / "train.log").exists() else ""
        status = (d / "run_status.txt").read_text(errors="ignore").strip() if (d / "run_status.txt").exists() else ""
        args = (d / "zero_args.txt").read_text(errors="ignore").strip() if (d / "zero_args.txt").exists() else ""
        step = parse_step_ms(text)
        alloc, reserved = parse_mem(text)
        rows.append({
            "zero": d.name.replace("zero", ""),
            "status": status,
            "zero_args": args,
            "step_mean_ms": step,
            "mem_max_alloc_gib": alloc,
            "mem_max_reserved_gib": reserved,
            "oom": int("out of memory" in text.lower()),
        })
    writer = csv.DictWriter(sys.stdout, fieldnames=[
        "zero", "status", "zero_args", "step_mean_ms",
        "mem_max_alloc_gib", "mem_max_reserved_gib", "oom",
    ])
    writer.writeheader()
    writer.writerows(rows)


if __name__ == "__main__":
    main()
