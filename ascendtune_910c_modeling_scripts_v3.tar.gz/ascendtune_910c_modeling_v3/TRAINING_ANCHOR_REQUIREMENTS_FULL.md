# AscendTune 910C 能耗标定训练锚点完整实验需求

本文档给出用于生成 910C 服务器训练脚本的完整候选策略表。目标是为 AscendTune 的吞吐与能耗状态机模型提供充分的真实训练锚点，而不是复用旧模型排序结论。

所有训练锚点用于 Qwen3-14B SFT，要求每个候选实跑 25 个 step，采集 step time、功耗、显存和真实 token 数。

## 1. 全局统一设置

所有候选统一：

```text
服务器: Atlas-800I A3, 16 x Ascend 910C
模型: Qwen3-14B
任务: SFT
并行约束: TP × PP × DP = 16
global_batch: 1024
seq_length: 4096
max_position_embeddings: 40960
train_iters: 25
warmup_steps: 5
timed_steps: 20
precision: bf16
数据: packed alpaca / no-pad SFT，与前轮保持一致
```

计时口径：

```text
step_time_ms = 第 6-25 步平均 step time
nominal_tokens_per_step = 1024 × 4096
throughput_nominal_tokens_s = nominal_tokens_per_step / (step_time_ms / 1000)
```

真实 token 口径：

```text
real_tokens_per_step = real_tokens.csv 第 6-25 步 tokens_nonpad_allranks 均值
throughput_effective_tokens_s = real_tokens_per_step / (step_time_ms / 1000)
```

## 2. 优化器与 ZeRO 设置

主标定统一使用实测最快的 ZeRO-2 风格配置：

```bash
--use-distributed-optimizer --overlap-grad-reduce
```

使用规则：

- 对 `DP > 1` 的候选，统一使用 `--use-distributed-optimizer --overlap-grad-reduce`。
- 对 `DP = 1` 的候选，ZeRO/分布式优化器没有实际 sharding 作用。该类候选不使用 distributed optimizer，并在结果中标记为 `DP=1 boundary`。
- `recompute` 和 `sequence_parallel` 不统一强行覆盖，按候选策略自身设置执行。

注意：

- 本轮 `zero=1/2/3` 探测中，`--use-distributed-optimizer --overlap-grad-reduce` 跑得最快，约 129 s/step，显存约 41.8 GiB。
- 当前命令行未发现显式 `--zero-stage` 参数，因此论文中应称为“distributed optimizer + overlap 配置”，不要直接把它写成严格语义的 ZeRO-2/ZeRO-3，除非后续确认框架内部实现映射。

## 3. 完整训练锚点候选表

下表是最全实验候选集合，不再裁剪为最小集合。

```text
候选名称	TP	PP	DP	micro_batch	global_batch	SP	recompute	优化器/ZeRO配置	类别	说明
W0	8	1	2	4	1024	on	full	--use-distributed-optimizer --overlap-grad-reduce	基线	cfg_09 复现基线；人工/旧搜索强基线
W1	4	1	4	1	1024	on	off	--use-distributed-optimizer --overlap-grad-reduce	高吞吐/高能效	blindtest 中能效最高，且已验证 TP4DP4 权重可用
W2	8	1	2	2	1024	on	off	--use-distributed-optimizer --overlap-grad-reduce	高吞吐	blindtest 实测吞吐最高族；覆盖 TP8/DP2/b2
W6	8	1	2	2	1024	on	off	--use-distributed-optimizer --overlap-grad-reduce	高吞吐/重复性	与 W2 同物理并行形状，用于 run-level 方差与重复性估计
W7	8	1	2	1	1024	on	off	--use-distributed-optimizer --overlap-grad-reduce	小batch问题区域	旧模型严重高估区域，必须保留用于修正模型
W8	8	1	2	1	1024	on	off	--use-distributed-optimizer --overlap-grad-reduce	小batch问题区域/重复性	与 W7 同物理并行形状，用于 run-level 方差与重复性估计
W5	4	2	2	1	1024	off	full	--use-distributed-optimizer --overlap-grad-reduce	低功耗/能效基线	cfg_13 复现基线；功耗较低；覆盖 PP=2
W3a	4	4	1	4	1024	on	off	none	显存边界可行点	实测未 OOM，但 reserved 接近/超过安全阈值；覆盖 PP=4/DP=1
BND-HGNN	2	2	4	1	1024	off	off	--use-distributed-optimizer --overlap-grad-reduce	显存边界可行点	HGNN 当前候选空间中 mem_pred 约 54.87 GiB，接近 55.15 GiB 阈值
```

## 4. 候选覆盖关系

本完整集合覆盖以下区域：

- 高吞吐区域：W1、W2、W6
- 小 micro-batch 问题区域：W7、W8
- 人工/旧搜索基线：W0
- 低功耗/能效基线：W5
- 显存边界可行点：W3a、BND-HGNN
- PP=1：W0、W1、W2、W6、W7、W8
- PP=2：W5、BND-HGNN
- PP=4：W3a
- TP=2：BND-HGNN
- TP=4：W1、W5、W3a
- TP=8：W0、W2、W6、W7、W8
- DP=1：W3a
- DP=2：W0、W2、W6、W7、W8、W5
- DP=4：W1、BND-HGNN

## 5. 权重转换需求

当前已验证可用：

```text
qwen3_mcore-4TP4DP
```

完整实验还需要准备并验证以下权重：

```text
qwen3_mcore-8TP2DP
qwen3_mcore-4TP2DP
qwen3_mcore-4TP1DP
qwen3_mcore-2TP4DP
```

候选与权重目录对应关系：

```text
候选	权重目录	状态
W1	qwen3_mcore-4TP4DP	已验证可用
W0	qwen3_mcore-8TP2DP	需要转换/验证
W2	qwen3_mcore-8TP2DP	需要转换/验证
W6	qwen3_mcore-8TP2DP	需要转换/验证
W7	qwen3_mcore-8TP2DP	需要转换/验证
W8	qwen3_mcore-8TP2DP	需要转换/验证
W5	qwen3_mcore-4TP2DP	需要转换/验证
W3a	qwen3_mcore-4TP1DP	需要转换/验证
BND-HGNN	qwen3_mcore-2TP4DP	需要转换/验证
```

当前启动脚本中的权重目录命名规则：

```text
如果 TP > 1:
  qwen3_mcore-{TP}TP{DP}DP
如果 TP = 1 且 PP > 1:
  qwen3_mcore-{PP}PP{DP}DP
如果 TP = 1 且 PP = 1:
  qwen3_mcore-{DP}DP
```

本完整候选表中所有候选均满足 `TP > 1`，因此按 `TP/DP` 命名，PP 不写入权重目录名。

## 6. 每个候选必须输出的文件

每个候选目录必须包含：

```text
launch.sh
config_note.txt
train.log
run_status.txt
step_times_raw.txt
real_tokens.csv
power_mem.csv
power_mem.csv.raw_snapshot.txt
```

其中：

- `run_status.txt` 必须明确 `PASS` 或 `FAIL`。
- `train.log` 必须包含每步 elapsed time。
- `real_tokens.csv` 必须有 25 行，且 `tokens_nonpad_allranks > 0`。
- `power_mem.csv` 必须覆盖完整训练过程。
- `step_times_raw.txt` 应包含 25 个 step 的原始时间，或由 `train.log` 可稳定解析。

## 7. 有效性判据

单个候选算有效完成，必须满足：

```text
训练正常完成 25 steps
exit code = 0
第 6-25 步 step time 可解析
MEMREPORT 可解析 max_allocated / max_reserved
power_mem.csv 非空，且覆盖训练窗口
real_tokens.csv 行数 = 25
real_tokens.csv 中 tokens_nonpad_allranks > 0
```

若 `real_tokens.csv` 全 0，则该候选仍可用于 nominal throughput 和 nominal tokens/J，但不能用于 effective throughput 和 effective tokens/J。

## 8. 能耗建模所需汇总字段

每个候选最终需要汇总为一行：

```text
candidate_id
tp
pp
dp
micro_batch
global_batch
seq_length
sp
recompute
optimizer_config
steps_total
step_mean_ms
step_std_ms
step_min_ms
step_max_ms
nominal_tokens_per_step
real_tokens_per_step
throughput_nominal_tokens_s
throughput_effective_tokens_s
power_avg_w
power_max_w
energy_nominal_tokens_j
energy_effective_tokens_j
mem_max_alloc_gib
mem_max_reserved_gib
oom
notes
```

## 9. 执行建议

执行前先确认权重目录存在：

```bash
ls -lh /root/MindSpeed-LLM/model_weights/qwen3_mcore-4TP4DP
ls -lh /root/MindSpeed-LLM/model_weights/qwen3_mcore-8TP2DP
ls -lh /root/MindSpeed-LLM/model_weights/qwen3_mcore-4TP2DP
ls -lh /root/MindSpeed-LLM/model_weights/qwen3_mcore-4TP1DP
ls -lh /root/MindSpeed-LLM/model_weights/qwen3_mcore-2TP4DP
```

执行顺序建议：

```text
1. W1：已验证权重，先确认脚本与 token 计数是否正常。
2. W0/W2/W6/W7/W8：共用 TP8DP2 权重，确认转换后连续执行。
3. W5：覆盖 PP=2 / TP4DP2。
4. BND-HGNN：覆盖 TP2PP2DP4 的显存边界点。
5. W3a：最后跑 DP=1/PP4 边界点，避免高显存点影响前序实验。
```

如果某候选 OOM：

- 保留 `train.log`、`power_mem.csv`、`MEMREPORT`。
- 不要修改该候选后重跑覆盖原目录。
- 将结果标为 OOM，用于显存边界模型。

## 10. 论文表述要求

这些锚点用于新版模型标定与验证。看过结果后，它们可以作为 `calibration` 或 `model_revision` 数据，但不能再作为最终 blind validation。

新版模型冻结后，还需要另选一批候选做最终 blind validation，用于报告：

- 吞吐预测 accuracy
- 功耗预测 MAPE
- 能效预测 MAPE
- Pareto front classification accuracy
