#!/bin/bash
# Probe ZeRO-stage executability on the current MindSpeed-LLM stack.
#
# 重要措辞约定（写论文/报告必须遵守）：
#   本探针的 z=2 / z=3 在多数 MindSpeed-LLM 版本上并不是语义完整的
#   ZeRO-2 / ZeRO-3，而是"当前框架可接受的 flag 组合"（fallback 链见
#   zero_args()）。所有下游文档必须表述为 "ZeRO flag-combination probe"，
#   禁止写成 "ZeRO-2/ZeRO-3 实测"（审计 P0-4 教训）。

set -u
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
# shellcheck disable=SC1091
source "$SCRIPT_DIR/common_env.sh"

OUT_ROOT=${OUT_ROOT:-$SCRIPT_DIR/results_zero_probe}
ENTRY=${ENTRY:-posttrain_gpt_lab_v3.py}
PP=${PP:-1}
TP=${TP:-4}
MICRO_BATCH=${MICRO_BATCH:-1}
BASE_PORT=${BASE_PORT:-7800}
mkdir -p "$OUT_ROOT"

cp "$SCRIPT_DIR/posttrain_gpt_lab_v3.py" "$MSLLM_DIR/$ENTRY"

HELP_FILE="$OUT_ROOT/posttrain_help.txt"
(cd "$MSLLM_DIR" && python3 posttrain_gpt.py --help > "$HELP_FILE" 2>&1) || true

has_flag() {
  grep -q -- "$1" "$HELP_FILE"
}

zero_args() {
  # 2026-11-12 fix: `python3 posttrain_gpt.py --help` detection produced EMPTY
  # args for all stages on this stack (help output lacks the flags), so z1-3
  # silently reran the z0 config and all four OOM'd. Use the proven explicit
  # flag combinations measured on 2026-11-07/08:
  #   z1 PASS 129-131s/step, z2 PASS 129s/step, z3 PASS 132s/step (TP4 mb1 gb1024)
  local z=$1
  case "$z" in
    0)
      echo ""
      ;;
    1)
      echo "--use-distributed-optimizer"
      ;;
    2)
      echo "--use-distributed-optimizer --overlap-grad-reduce"
      ;;
    3)
      echo "--use-distributed-optimizer --overlap-grad-reduce --overlap-param-gather"
      ;;
  esac
}

run_one() {
  local z=$1
  local port=$2
  local dir="$OUT_ROOT/zero${z}"
  local dp=$(( NPUS_PER_NODE / (PP * TP) ))
  local ckpt="$CKPT_WEIGHTS_DIR/$(ckpt_name "$TP" "$PP" "$dp")"
  local args_file="$dir/zero_args.txt"
  local status_file="$dir/run_status.txt"
  local extra
  extra="$(zero_args "$z")"

  mkdir -p "$dir"
  echo "$extra" > "$args_file"
  echo "p=$PP t=$TP d=$dp z=$z b=$MICRO_BATCH entry=$ENTRY" > "$dir/config_note.txt"

  cat > "$dir/launch.sh" <<EOF
#!/bin/bash
source "$SCRIPT_DIR/common_env.sh"
cd "$MSLLM_DIR"
export TOK_OUT="$dir/real_tokens.csv"
torchrun \\
  --nproc_per_node "$NPUS_PER_NODE" \\
  --nnodes 1 \\
  --node_rank 0 \\
  --master_addr "$MASTER_ADDR" \\
  --master_port "$port" \\
  "$ENTRY" \\
  \$(base_qwen_args "$PP" "$TP" "$MICRO_BATCH" "$ckpt") \\
  --sequence-parallel \\
  $extra
EOF
  chmod +x "$dir/launch.sh"

  echo "======================================================================"
  echo "[$(date '+%F %T')] probing zero=$z args: $extra"
  echo "======================================================================"
  SAMPLE_INTERVAL_SEC=${SAMPLE_INTERVAL_SEC:-1} bash "$SCRIPT_DIR/sampler_power_mem.sh" "$dir/power_mem.csv" &
  local sampler_pid=$!
  sleep 5
  (cd "$dir" && bash launch.sh > train.log 2>&1)
  local rc=$?
  sleep 3
  kill "$sampler_pid" 2>/dev/null || true
  wait "$sampler_pid" 2>/dev/null || true
  if grep -qi "out of memory\\|NPU out of memory\\|RuntimeError" "$dir/train.log"; then
    echo "FAIL rc=$rc" > "$status_file"
  elif [ "$rc" = "0" ]; then
    echo "PASS rc=0" > "$status_file"
  else
    echo "FAIL rc=$rc" > "$status_file"
  fi
}

for z in 0 1 2 3; do
  run_one "$z" $(( BASE_PORT + z ))
done

python3 "$SCRIPT_DIR/summarize_zero_probe.py" "$OUT_ROOT" > "$OUT_ROOT/zero_probe_summary.csv"
echo "[done] summary: $OUT_ROOT/zero_probe_summary.csv"
