# -*- coding: utf-8 -*-
"""MindSpeed-LLM training wrapper v3.2 (merged fix).

Base: v3.1 loss_func-class hook (PROVEN on this stack, 2026-11-08:
forward_step is a *class method* in sft_trainer, and loss_mask is passed
into loss_func as input_tensor via functools.partial -- the module-level
forward_step hook used in v2/v3.0 never installs and yields all-zero
real_tokens.csv).

Merged from the collaborator's v3.0 review fixes:
  1. TOK_OUT env: real_tokens.csv lands in the per-run result directory.
  2. TP de-dup: loss_mask is a broadcast replica across TP ranks (Megatron
     gathers the sequence before the vocab-parallel loss), so accumulate
     only on tensor-parallel rank 0. If megatron parallel_state cannot be
     imported, all ranks accumulate and the WORLD all_reduced total is
     divided by TP_SIZE_FALLBACK (exported by launch.sh).

Place this file in $MSLLM_DIR and launch it instead of posttrain_gpt.py.
"""
import atexit
import csv
import os
import runpy
import sys

_tok = {"all": 0, "real": 0, "step": 0, "rows": 0}
_state = {"file": None, "writer": None, "loss_hook": False, "train_hook": False, "grab_fail": 0}
_TP = {"rank": None, "size": None, "import_ok": None}


def _rank0():
    return os.environ.get("RANK", "0") == "0"


def _tp_rank_size():
    """Return (tp_rank, tp_world_size); cached. Falls back to (0, 1) with a
    visible log warning if megatron parallel_state is unavailable."""
    if _TP["rank"] is not None:
        return _TP["rank"], _TP["size"]
    rank, size, ok = 0, 1, False
    try:
        try:
            from megatron.core import parallel_state as _mpu
        except Exception:
            from megatron import mpu as _mpu
        rank = _mpu.get_tensor_model_parallel_rank()
        size = _mpu.get_tensor_model_parallel_world_size()
        ok = True
    except Exception:
        rank, size = 0, int(os.environ.get("TP_SIZE_FALLBACK", "1"))
    _TP["rank"], _TP["size"], _TP["import_ok"] = rank, size, ok
    if _rank0():
        print(f"[TOKCOUNT] tp_rank_size: import_ok={ok} "
              f"(this rank: tp_rank={rank}, tp_size={size})", flush=True)
    return rank, size


def _writer():
    if _state["writer"] is None:
        path = os.environ.get("TOK_OUT", "real_tokens.csv")
        _state["file"] = open(path, "w", newline="", encoding="utf-8")
        _state["writer"] = csv.writer(_state["file"])
        _state["writer"].writerow(["iteration", "tokens_numel_allranks", "tokens_nonpad_allranks"])
        if _rank0():
            print(f"[TOKCOUNT] writing real tokens to {os.path.abspath(path)}", flush=True)
    return _state["writer"]


def _install_loss_hook():
    """Hook loss_func on EVERY class that defines it (base + overriding
    subclass). v3.0 hooked a module-level forward_step that does not exist
    in this MindSpeed-LLM version -> forward_hook=False, tokens all zero."""
    candidates = [
        "mindspeed_llm.tasks.posttrain.sft.sft_trainer",
        "mindspeed_llm.tasks.posttrain.ldt_sft.ldt_sft_trainer",
    ]
    for module_name in candidates:
        try:
            module = __import__(module_name, fromlist=["*"])
        except Exception:
            continue
        hooked = []
        for attr_name in dir(module):
            cls = getattr(module, attr_name)
            if not (isinstance(cls, type) and "loss_func" in cls.__dict__):
                continue
            raw = cls.__dict__["loss_func"]
            is_static = isinstance(raw, staticmethod)
            orig = raw.__func__ if is_static else raw

            def wrapped_loss_func(*args, __orig=orig, **kwargs):
                try:
                    tp_rank, _ = _tp_rank_size()
                    if tp_rank == 0:
                        # loss_mask arrives as input_tensor (partial(self.loss_func, loss_mask))
                        input_tensor = args[0] if args else kwargs.get("input_tensor")
                        if input_tensor is not None:
                            lm = input_tensor[..., 1:]
                            _tok["all"] += int(lm.numel())
                            _tok["real"] += int(lm.sum())
                except Exception:
                    _state["grab_fail"] += 1
                return __orig(*args, **kwargs)

            if is_static:
                setattr(cls, "loss_func", staticmethod(wrapped_loss_func))
            else:
                setattr(cls, "loss_func", wrapped_loss_func)
            hooked.append(attr_name)
        if hooked:
            _state["loss_hook"] = True
            if _rank0():
                print(f"[TOKCOUNT] installed loss_func hook on {module_name}: {','.join(hooked)}", flush=True)
            return


def _install_train_step_hook():
    candidates = [
        "mindspeed_llm.training.training",
        "megatron.training.training",
    ]
    for module_name in candidates:
        try:
            module = __import__(module_name, fromlist=["train_step"])
            orig = getattr(module, "train_step")
        except Exception:
            continue

        def wrapped_train_step(*args, __orig=orig, **kwargs):
            _tok["all"] = 0
            _tok["real"] = 0
            ret = __orig(*args, **kwargs)
            try:
                import torch
                import torch.distributed as dist
                _tok["step"] += 1
                t = torch.tensor([_tok["all"], _tok["real"]], dtype=torch.long).npu()
                # WORLD 求和：跨 DP/PP 合并；TP 维度因只在 tp_rank0 累加而无重复
                dist.all_reduce(t, group=dist.group.WORLD)
                if not _TP["import_ok"]:
                    # 兜底：无法识别 TP 组时按 TP_SIZE_FALLBACK 去重
                    t = t // max(int(os.environ.get("TP_SIZE_FALLBACK", "1")), 1)
                if dist.get_rank() == 0:
                    _writer().writerow([_tok["step"], int(t[0]), int(t[1])])
                    _state["file"].flush()
                    _tok["rows"] += 1
            except Exception:
                _state["grab_fail"] += 1
            return ret

        setattr(module, "train_step", wrapped_train_step)
        _state["train_hook"] = True
        if _rank0():
            print(f"[TOKCOUNT] installed train_step hook on {module_name}", flush=True)
        return


def _install_token_counter():
    _install_loss_hook()
    _install_train_step_hook()
    if _rank0():
        print(
            f"[TOKCOUNT] loss_hook={_state['loss_hook']} "
            f"train_hook={_state['train_hook']} metric=loss_mask.sum tp_rank0_only=True",
            flush=True,
        )


@atexit.register
def _report_memory_and_tokens():
    try:
        import torch
        import torch_npu  # noqa: F401
        rank = os.environ.get("RANK", "?")
        alloc = torch.npu.max_memory_allocated() / 1024**3
        reserved = torch.npu.max_memory_reserved() / 1024**3
        print(
            f"[MEMREPORT rank {rank}] max_allocated={alloc:.2f} GiB "
            f"max_reserved={reserved:.2f} GiB capacity=61.28 GiB",
            flush=True,
        )
    except Exception as exc:
        print(f"[MEMREPORT] failed: {exc}", flush=True)
    if _rank0():
        print(
            f"[TOKCOUNT] rows={_tok['rows']} grab_fail={_state['grab_fail']} "
            f"loss_hook={_state['loss_hook']} train_hook={_state['train_hook']}",
            flush=True,
        )
    if _state["file"]:
        _state["file"].close()


_install_token_counter()

_here = os.path.dirname(os.path.abspath(__file__))
sys.argv[0] = os.path.join(_here, "posttrain_gpt.py")
runpy.run_path(sys.argv[0], run_name="__main__")
