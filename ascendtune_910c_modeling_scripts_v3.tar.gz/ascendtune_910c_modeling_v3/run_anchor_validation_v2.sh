#!/bin/bash
# Frozen validation batch for the anchor-calibrated throughput-energy model.

set -u
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
# shellcheck disable=SC1091
source "$SCRIPT_DIR/common_env.sh"

OUT_ROOT=${OUT_ROOT:-$SCRIPT_DIR/results_anchor_validation_v2}
ENTRY=${ENTRY:-posttrain_gpt_lab_v3.py}
BASE_PORT=${BASE_PORT:-8800}
mkdir -p "$OUT_ROOT"

# Deploy the v3 wrapper shipped with this pack into $MSLLM_DIR (fixes broken
# reproduction chain: v2 pack referenced posttrain_gpt_lab_v3.py but did not
# include it).
cp "$SCRIPT_DIR/posttrain_gpt_lab_v3.py" "$MSLLM_DIR/$ENTRY" || {
  echo "[error] failed to copy posttrain_gpt_lab_v3.py into $MSLLM_DIR"; exit 2;
}

if [ ! -f "$MSLLM_DIR/$ENTRY" ]; then
  echo "[error] $MSLLM_DIR/$ENTRY not found."
  exit 2
fi

# Format:
# name|pp|tp|micro_batch|sp|recompute|category
CONFIGS=(
  "V2A_p1t4d4_sp1_b2|1|4|2|on|off|top_unmeasured"
  "V2B_p2t2d4_sp1_b1|2|2|1|on|off|sp_variant_of_BND"
  "V2C_p4t2d2_sp0_b1|4|2|1|off|off|pp4_tp2_high_rank"
  "V2D_p2t4d2_sp1_b2|2|4|2|on|off|pp2_tp4_high_rank"
  "V2E_p1t8d2_sp1_b4|1|8|4|on|off|tp8_b4_extrapolation"
  "V2F_BND_repeat|2|2|1|off|off|top_repeat"
)

write_launch_script() {
  local name=$1 pp=$2 tp=$3 mb=$4 sp=$5 recompute=$6 port=$7
  local dp=$(( NPUS_PER_NODE / (pp * tp) ))
  local dir="$OUT_ROOT/$name"
  local ckpt="$CKPT_WEIGHTS_DIR/$(ckpt_name "$tp" "$pp" "$dp")"
  local extra="--use-distributed-optimizer --overlap-grad-reduce"
  [ "$sp" = "on" ] && extra="$extra --sequence-parallel"
  case "$recompute" in
    full) extra="$extra --recompute-granularity full --recompute-method uniform --recompute-num-layers 1" ;;
    off) : ;;
    *) echo "[error] unknown recompute=$recompute"; exit 3 ;;
  esac

  cat > "$dir/launch.sh" <<EOF
#!/bin/bash
source "$SCRIPT_DIR/common_env.sh"
cd "$MSLLM_DIR"
export TOK_OUT="$dir/real_tokens.csv"
export TP_SIZE_FALLBACK=$tp
torchrun \\
  --nproc_per_node "$NPUS_PER_NODE" \\
  --nnodes 1 \\
  --node_rank 0 \\
  --master_addr "$MASTER_ADDR" \\
  --master_port "$port" \\
  "$ENTRY" \\
  \$(base_qwen_args "$pp" "$tp" "$mb" "$ckpt") \\
  $extra
EOF
  chmod +x "$dir/launch.sh"
}

parse_step_times() {
  local log=$1
  local out=$2
  python3 - "$log" "$out" <<'PY'
import re, sys
log, out = sys.argv[1], sys.argv[2]
txt = open(log, errors="ignore").read()
vals = re.findall(r"elapsed time per iteration \(ms\):\s*([0-9.]+)", txt, flags=re.I)
with open(out, "w") as f:
    for v in vals:
        f.write(v + "\n")
PY
}

run_one() {
  local spec=$1 port=$2
  local name pp tp mb sp recompute category
  IFS='|' read -r name pp tp mb sp recompute category <<< "$spec"
  local dp=$(( NPUS_PER_NODE / (pp * tp) ))
  local dir="$OUT_ROOT/$name"
  local ckpt="$CKPT_WEIGHTS_DIR/$(ckpt_name "$tp" "$pp" "$dp")"
  mkdir -p "$dir"

  # fail fast with a clear status if the converted weights are missing
  # (V2C needs qwen3_mcore-2TP2DP which may not be converted yet)
  if [ ! -d "$ckpt" ]; then
    echo "[warn] $name SKIPPED: checkpoint dir missing: $ckpt"
    echo "FAIL missing_ckpt" > "$dir/run_status.txt"
    echo "1" > "$dir/exit_code.txt"
    return 0
  fi

  cat > "$dir/config_note.txt" <<EOF
name=$name tp=$tp pp=$pp dp=$dp micro_batch=$mb global_batch=$GLOBAL_BATCH seq=$SEQ_LEN iters=$TRAIN_ITERS sp=$sp recompute=$recompute category=$category zero_args=[--use-distributed-optimizer --overlap-grad-reduce] ckpt=$CKPT_WEIGHTS_DIR/$(ckpt_name "$tp" "$pp" "$dp")
EOF

  write_launch_script "$name" "$pp" "$tp" "$mb" "$sp" "$recompute" "$port"

  echo "======================================================================"
  echo "[$(date '+%F %T')] anchor=$name pp=$pp tp=$tp dp=$dp mb=$mb sp=$sp recompute=$recompute"
  echo "======================================================================"

  SAMPLE_INTERVAL_SEC=${SAMPLE_INTERVAL_SEC:-1} bash "$SCRIPT_DIR/sampler_power_mem.sh" "$dir/power_mem.csv" &
  local sampler_pid=$!
  sleep 5
  (cd "$dir" && bash launch.sh > train.log 2>&1)
  local rc=$?
  sleep 3
  kill "$sampler_pid" 2>/dev/null || true
  wait "$sampler_pid" 2>/dev/null || true

  echo "$rc" > "$dir/exit_code.txt"
  parse_step_times "$dir/train.log" "$dir/step_times_raw.txt"

  local token_rows=0
  if [ -f "$dir/real_tokens.csv" ]; then
    token_rows=$(( $(wc -l < "$dir/real_tokens.csv") - 1 ))
  fi

  if [ "$rc" = "0" ] && [ "$token_rows" -eq "$TRAIN_ITERS" ]; then
    echo "PASS rc=0 tok_rows_ok" > "$dir/run_status.txt"
  else
    echo "FAIL rc=$rc token_rows=$token_rows" > "$dir/run_status.txt"
  fi
  cat "$dir/run_status.txt"
}

main() {
  local idx=0
  for spec in "${CONFIGS[@]}"; do
    run_one "$spec" $(( BASE_PORT + idx ))
    idx=$((idx + 1))
  done
  echo "[done] results in $OUT_ROOT"
}

main "$@"
