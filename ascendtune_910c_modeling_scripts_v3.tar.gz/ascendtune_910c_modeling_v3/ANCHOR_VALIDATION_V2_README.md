# Anchor Validation v2

本批次用于验证已经冻结的锚点校准吞吐-能效模型，不再用于修改候选列表。

## 运行命令

```bash
cd /root/hgnn_910c_readiness/ascendtune_910c_modeling_v3
bash run_anchor_validation_v2.sh 2>&1 | tee anchor_validation_v2.log
```

（建议放在 tmux 里跑：`tmux new -s anchors`，脱离用 Ctrl+B 然后 D。）

缺权重时对应组会被跳过（`FAIL missing_ckpt`）。V2C 需要 `qwen3_mcore-2TP2DP`，
如缺失，用 `examples/mcore/qwen3/ckpt_convert_qwen3_hf2mcore.sh` 按 TP=2 PP=4 转换
（参照之前转换 8TP2DP 等权重时用的 ckpt_convert_v1.sh 参数）。

默认入口为：

```text
posttrain_gpt_lab_v3.py
```

该 wrapper 已随本包附带，脚本启动时会自动复制到 `$MSLLM_DIR`，无需手工准备。
v3 相对 v2：real_tokens.csv 按环境变量 `TOK_OUT` 落到各 run 目录（不再互相覆盖），
token 计数只在 TP rank 0 累加（不再按 TP 倍数虚增）。

## 冻结预测

本批六组的模型冻结预测值见包内 `frozen_predictions.csv`（由本地引擎在
154 条可执行空间版上生成，生成时间见文件头注释）。**跑完全部六组之前
不要打开该文件对照**，以保持盲测效力。V2E 为 t=8&b=4 外推点，预测带有
额外不确定性标注，判读时按"区间正确"而非"点值命中"评估。

## 候选列表

```text
name                       PP  TP  DP  micro_batch  SP   recompute  purpose
V2A_p1t4d4_sp1_b2          1   4   4   2            on   off        top unmeasured candidate
V2B_p2t2d4_sp1_b1          2   2   4   1            on   off        SP variant of BND-HGNN
V2C_p4t2d2_sp0_b1          4   2   2   1            off  off        PP4/TP2 high-rank candidate
V2D_p2t4d2_sp1_b2          2   4   2   2            on   off        PP2/TP4 high-rank candidate
V2E_p1t8d2_sp1_b4          1   8   2   4            on   off        TP8 b4 extrapolation check
V2F_BND_repeat             2   2   4   1            off  off        BND-HGNN 显存边界点首测（mem_pred≈54.87 GB，贴近 55.15 GB 阈值下沿；此前未实测，名称中 repeat 为历史遗留）
```

V2B 与 V2F 仅差 SP 开关，构成一组 SP 单变量对照。

所有 `DP > 1` 候选统一使用：

```bash
--use-distributed-optimizer --overlap-grad-reduce
```

## 需要的权重

```text
qwen3_mcore-4TP4DP
qwen3_mcore-2TP4DP
qwen3_mcore-2TP2DP
qwen3_mcore-4TP2DP
qwen3_mcore-8TP2DP
```

## 有效性判据

每个候选目录应包含：

```text
config_note.txt
launch.sh
train.log
exit_code.txt
step_times_raw.txt
real_tokens.csv
power_mem.csv
power_mem.csv.raw_snapshot.txt
run_status.txt
```

有效完成要求：

```text
exit_code = 0
step_times_raw.txt 有 25 行
real_tokens.csv 有 25 行且 tokens_nonpad_allranks > 0
power_mem.csv 覆盖完整训练窗口
MEMREPORT 可解析
```

## 回传

跑完后打包：

```bash
tar czf ascendtune_910c_anchor_validation_v2.tar.gz results_anchor_validation_v2 anchor_validation_v2.log
```
