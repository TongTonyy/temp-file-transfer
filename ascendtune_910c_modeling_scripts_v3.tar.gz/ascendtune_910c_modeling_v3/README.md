# AscendTune 910C 建模与标定脚本包

本目录用于在 910C 服务器上执行第二轮建模标定。目标不是继续解释旧排序，而是获得可复验的吞吐/能耗结构化模型。

v3（2026-11-12）相对 v2 的修复：锚点验证正则空匹配、real_tokens.csv 落盘与 TP 虚增、
能耗标定改 16 rank 并补全矩阵（GEMM 3 shape / copy 3 档 / norm 3 档 / P2P / 组规模 2/4/8/16）、
打包脚本补 results_anchor_validation_v2、随包附带 posttrain_gpt_lab_v3.py 与 frozen_predictions.csv。

## 推荐执行顺序

1. 将压缩包 `ascendtune_910c_modeling_scripts_v3.tar.gz` 上传到 GitHub 仓库（TongTonyy/temp-file-transfer）根目录。
2. 在 910C 服务器上下载解压（堡垒机网页端可直接粘贴）：

```bash
cd /root/hgnn_910c_readiness
wget "https://ghfast.top/https://raw.githubusercontent.com/TongTonyy/temp-file-transfer/main/ascendtune_910c_modeling_scripts_v3.tar.gz" -O ascendtune_910c_modeling_scripts_v3.tar.gz
tar -xzf ascendtune_910c_modeling_scripts_v3.tar.gz
cd ascendtune_910c_modeling_v3
conda activate llm_env    # 或 source /root/miniconda3/bin/activate llm_env
source common_env.sh      # 确认 MSLLM_DIR=/root/MindSpeed-LLM 等路径正确
```

3. ZeRO 档位探测（**可选跳过**：2026-11-07/08 已在本机跑通全部四档并留存结果；
   如需复跑，建议 `TRAIN_ITERS=10` 缩短到约 1 小时，默认 25 步约 3 小时）：

```bash
bash run_zero_stage_probe.sh 2>&1 | tee zero_probe.log
```

注意：z=2/3 是"当前框架可接受的 flag 组合"，不是语义完整的 ZeRO-2/3，
论文与报告中必须按 flag 组合表述。

4. 再跑功耗状态机标定（26 个微基准，每项已改为 ~30–40 秒持续负载以避免功耗稀释，
   总计约 50–70 分钟；**可选跳过**：同矩阵数据已于 2026-11-09/10 采齐并通过有效性检查，
   如需复跑用下面命令）：

```bash
bash run_energy_calibration.sh 2>&1 | tee energy_calibration.log
```

5. 最后跑冻结锚点验证批（V2A–V2F，六组，预测值见 frozen_predictions.csv，
   跑完前不要打开该文件对照）。

   **先检查权重**（V2C 需要 qwen3_mcore-2TP2DP，缺的话该组会被跳过并标
   FAIL missing_ckpt，转换命令见 ANCHOR_VALIDATION_V2_README.md）：

```bash
for d in qwen3_mcore-4TP4DP qwen3_mcore-2TP4DP qwen3_mcore-2TP2DP qwen3_mcore-4TP2DP qwen3_mcore-8TP2DP; do
  if [ -d "/root/MindSpeed-LLM/model_weights/$d" ]; then echo "OK      $d"; else echo "MISSING $d"; fi
done
```

   建议在 tmux 里跑（防网页端断连），六组约 6–7 小时：

```bash
tmux new -s anchors
# 会话内:
cd /root/hgnn_910c_readiness/ascendtune_910c_modeling_v3
conda activate llm_env
bash run_anchor_validation_v2.sh 2>&1 | tee anchor_validation_v2.log
# 脱离会话: Ctrl+B 然后 D；重连: tmux attach -t anchors
```

6. 打包结果（走 GitHub release + curl 上传流程）：

## 产物

- `results_zero_probe/`：ZeRO flag 组合 0/1/2/3 的可执行性、显存、吞吐、错误日志。
- `results_energy_calibration/`：idle、GEMM、vector、memory、HCCL（含 P2P 与组规模）标定结果和功耗时间序列。
- `results_anchor_validation_v2/`：冻结锚点验证批六组完整训练结果。
- `frozen_predictions.csv`：本批六组锚点的冻结预测值（盲测对照用）。
- `ascendtune_910c_modeling_results.tar.gz`：用于传回本地建模。

## 建模原则

参考 Galvatron 的结构化建模方式：先 profile 硬件和模型算子，再把策略预测拆成计算、通信、显存和调度项。能耗模型采用 Trace 状态机积分：

```text
Power_total(t) = P_idle + P_compute(t) + P_memory(t) + P_comm(t)
Energy = sum(Power_total(t) * dt)
tokens/J = effective_or_nominal_tokens / Energy
```

注意：token 计数统一走 `posttrain_gpt_lab_v3.py`（TOK_OUT 落盘 + TP rank0 去重）。
若 `real_tokens.csv` 行数不是 25 或 tokens 全 0，先检查 train.log 里的
`[TOKCOUNT]` 行（forward_hook/train_hook 是否装上、grab_fail 次数），再谈
effective tokens/J。不同 MindSpeed-LLM 版本内部函数名可能变化，hook 候选
模块列表在 wrapper 顶部，可按需扩充。
