# PWM20 六 run formal 采集执行命令

## 1. 在 910C 拉取并覆盖脚本

前提：你已经把 `full83_pwm20_formal_collection_20260903.tar.gz` 和 `.sha256` 上传到 `TongTonyy/temp-file-transfer` 仓库根目录。

```bash
cd /root/hgnn_910c_readiness

rm -rf /root/hgnn_910c_readiness/temp-file-transfer

GIT_TERMINAL_PROMPT=0 timeout 900 git -c http.version=HTTP/1.1 \
  clone --progress --depth 1 --single-branch --no-tags --filter=blob:none --sparse \
  -b main https://github.com/TongTonyy/temp-file-transfer.git \
  /root/hgnn_910c_readiness/temp-file-transfer

cd /root/hgnn_910c_readiness/temp-file-transfer
git sparse-checkout init --no-cone
git sparse-checkout set \
  full83_pwm20_formal_collection_20260903.tar.gz \
  full83_pwm20_formal_collection_20260903.tar.gz.sha256

command cp -f \
  full83_pwm20_formal_collection_20260903.tar.gz \
  full83_pwm20_formal_collection_20260903.tar.gz.sha256 \
  /root/hgnn_910c_readiness/hgnn_f01_qwen3_campaign_v0.3.4/

cd /root/hgnn_910c_readiness/hgnn_f01_qwen3_campaign_v0.3.4
sha256sum -c full83_pwm20_formal_collection_20260903.tar.gz.sha256
tar -xzf full83_pwm20_formal_collection_20260903.tar.gz

chmod +x \
  tools/offline/full83_910c/run_full83_910c_collection.sh \
  tools/offline/full83_910c/run_full83_pwm20_combined_910c_collection.sh \
  workload/full83_fan_detail_sidecar.py \
  workload/full83_extract_step_time_by_segment.py \
  app/bin/run_hsh_f01_active.py
```

## 2. 启动 PWM20 formal 六组采集

```bash
cd /root/hgnn_910c_readiness/hgnn_f01_qwen3_campaign_v0.3.4

export HGNN_CAMPAIGN_ROOT_APPROVAL=I_ACKNOWLEDGE_HARDENED_ROOT_EXECUTION
export FULL83_CAMPAIGN_ID="$(date -u +%Y%m%dT%H%M%SZ)-full83-pwm20-formal-r34"

bash tools/offline/full83_910c/run_full83_pwm20_combined_910c_collection.sh full
```

这次固定为 formal-only：即使误传 `test` 参数也会直接拒绝执行。默认时序为 `baseline=180s`、`fault_active=600s`、`release_at=780s`、`recovery=180s`、总时长 `960s`，组间 cooldown 默认 `300s`。

profiling 采用 extended thermal 采样计划，默认 9 个 segment：

```text
pre_fault_stable, pre_fault_edge, post_fault_edge,
fault_early, fault_mid, fault_late,
pre_release_edge, post_release_edge, recovery_stable
```

## 3. 续跑同一个 campaign

如果中断，需要使用同一个 `FULL83_CAMPAIGN_ID`：

```bash
cd /root/hgnn_910c_readiness/hgnn_f01_qwen3_campaign_v0.3.4

export HGNN_CAMPAIGN_ROOT_APPROVAL=I_ACKNOWLEDGE_HARDENED_ROOT_EXECUTION
export FULL83_CAMPAIGN_ID="<上一次启动时打印的FULL83_CAMPAIGN_ID>"

bash tools/offline/full83_910c/run_full83_pwm20_combined_910c_collection.sh resume
```

## 4. 新增输出位置

逐风扇 RPM / Manual Level / Actual Level：

```bash
runtime/extracted_targets_full83/${FULL83_CAMPAIGN_ID}/provenance/full83/fan_detail/<run_id>/fan_detail_timeseries.csv
runtime/extracted_targets_full83/${FULL83_CAMPAIGN_ID}/provenance/full83/fan_detail/<run_id>/drawer_fan_timeseries.csv
```

分阶段 step time：

```bash
runtime/extracted_targets_full83/${FULL83_CAMPAIGN_ID}/provenance/full83/step_time/<run_id>/step_time_by_segment.csv
runtime/extracted_targets_full83/${FULL83_CAMPAIGN_ID}/provenance/full83/step_time/<run_id>/step_time_by_rank_segment.csv
```

`step_time_by_segment.csv` 的阶段来自 profiling segment manifest 的 `segment_id/phase/start_step/stop_step`，step time 值来自训练日志中的 `elapsed time per iteration (ms)`。
