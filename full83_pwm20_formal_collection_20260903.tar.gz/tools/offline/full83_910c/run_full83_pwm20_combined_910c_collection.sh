#!/usr/bin/env bash
set -Eeuo pipefail
umask 077

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd -P)"
ACTION="${1:-full}"

if [[ "$ACTION" == "test" ]]; then
  echo "PWM20 combined collection is formal-only; test mode is disabled." >&2
  exit 2
fi

export FULL83_MODE="full"
export FULL83_GROUP_PLAN="pwm20_combined"
export FULL83_TARGET_PWM="20"
export FULL83_BASELINE_S="${FULL83_BASELINE_S:-180}"
export FULL83_RELEASE_AT_S="${FULL83_RELEASE_AT_S:-780}"
export FULL83_DURATION_S="${FULL83_DURATION_S:-960}"
export FULL83_REQUIRE_SMOKE_GATES="${FULL83_REQUIRE_SMOKE_GATES:-0}"
export FULL83_ENABLE_BMC="${FULL83_ENABLE_BMC:-auto}"
export FULL83_MAX_GROUPS="${FULL83_MAX_GROUPS:-6}"
export FULL83_EXTENDED_THERMAL_PROFILE_PLAN="${FULL83_EXTENDED_THERMAL_PROFILE_PLAN:-1}"

# New auxiliary outputs for the PWM20 formal run.
export FULL83_FAN_DETAIL_SIDECAR="${FULL83_FAN_DETAIL_SIDECAR:-1}"
export FULL83_FAN_DETAIL_INTERVAL_S="${FULL83_FAN_DETAIL_INTERVAL_S:-2}"
export FULL83_EXTRACT_STEP_TIME="${FULL83_EXTRACT_STEP_TIME:-1}"

# Four physical NPU cards 1/2/3/4 correspond to 0-based logical ids 0..7.
export HGNN_EXPECTED_NPU_IDS="${HGNN_EXPECTED_NPU_IDS:-0,1,2,3,4,5,6,7}"
export HGNN_EXPECTED_PROFILE_RANKS="${HGNN_EXPECTED_PROFILE_RANKS:-8}"
export HGNN_NPUS_PER_NODE="${HGNN_NPUS_PER_NODE:-8}"
export HGNN_TP="${HGNN_TP:-4}"
export HGNN_PP="${HGNN_PP:-2}"
export HGNN_ASCEND_RT_VISIBLE_DEVICES="${HGNN_ASCEND_RT_VISIBLE_DEVICES:-0,1,2,3,4,5,6,7}"
export HGNN_TORCH_NPU_AIC_METRIC="${HGNN_TORCH_NPU_AIC_METRIC:-ResourceConflictRatio}"

exec "$SCRIPT_DIR/run_full83_910c_collection.sh" "$ACTION"
