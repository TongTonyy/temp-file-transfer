#!/usr/bin/env python3
"""Sidecar fan-detail sampler for full83 formal campaigns.

The full83 BMC collector keeps stable aggregate metrics.  This sidecar records
per-fan RPM and manual/actual levels so later analysis can build drawer-level
cooling features without changing the 83-metric contract.
"""

from __future__ import annotations

import argparse
import base64
import csv
import json
import os
import re
import signal
import ssl
import time
import urllib.error
import urllib.request
from collections.abc import Mapping, Sequence
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import yaml

from hgnn_collect.daemon.ipmc_fan_backend import (
    ALL_FAN_IDS,
    DRAWER_TOPOLOGY,
    SshIpmcConfig,
    SshIpmcTransport,
)


DRAWER_BY_FAN_ID = {
    fan_id: drawer
    for drawer, topology in DRAWER_TOPOLOGY.items()
    for fan_id in topology.fan_ids
}

FAN_FIELDS = (
    "ts_utc",
    "elapsed_s",
    "phase",
    "fan_id",
    "drawer",
    "manual_level_pct",
    "actual_level_pct",
    "redfish_rpm",
    "redfish_pwm_pct",
    "redfish_name",
    "status",
)
DRAWER_FIELDS = (
    "ts_utc",
    "elapsed_s",
    "phase",
    "drawer",
    "fan_count",
    "rpm_mean",
    "rpm_min",
    "rpm_max",
    "actual_pwm_mean",
    "actual_pwm_min",
    "actual_pwm_max",
    "status",
)
STOP_REQUESTED = False


def request_stop(signum: int, _frame: Any) -> None:
    global STOP_REQUESTED
    STOP_REQUESTED = True


@dataclass
class FanReading:
    fan_id: int
    name: str | None = None
    rpm: float | None = None
    pwm_pct: float | None = None


def utc_now() -> str:
    return time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())


def load_credentials(path: Path) -> None:
    if not path.is_file():
        return
    for raw in path.read_text(encoding="utf-8").splitlines():
        line = raw.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        if line.startswith("export "):
            line = line[len("export ") :].strip()
        key, value = line.split("=", 1)
        os.environ.setdefault(key.strip(), value.strip().strip("'\""))
    if not os.environ.get("HGNN_IPMC_PASSWORD") and os.environ.get("HGNN_BMC_PASSWORD"):
        os.environ["HGNN_IPMC_PASSWORD"] = os.environ["HGNN_BMC_PASSWORD"]


def build_ipmc_transport(site_config: Path) -> SshIpmcTransport:
    payload = yaml.safe_load(site_config.read_text(encoding="utf-8"))
    ssh = payload["ipmc_ssh"]
    identity_file = ssh.get("identity_file")
    return SshIpmcTransport(
        SshIpmcConfig(
            host=str(ssh["host"]),
            port=int(ssh.get("port", 22)),
            username=str(ssh["username"]),
            known_hosts_path=Path(str(ssh["known_hosts_path"])),
            expected_host_key_sha256=str(ssh["expected_host_key_sha256"]),
            identity_file=Path(str(identity_file)) if identity_file else None,
            password_env=str(ssh.get("password_env") or "HGNN_IPMC_PASSWORD"),
            connect_timeout_s=int(ssh.get("connect_timeout_s", 5)),
            command_timeout_s=int(ssh.get("command_timeout_s", 10)),
        )
    )


def number(value: Any) -> float | None:
    if isinstance(value, bool) or value is None:
        return None
    if isinstance(value, (int, float)):
        return float(value)
    match = re.search(r"-?\d+(?:\.\d+)?", str(value))
    return float(match.group(0)) if match else None


def fan_id_from_payload(item: Mapping[str, Any], fallback_id: int) -> int:
    for key in ("Name", "FanName", "MemberId", "@odata.id", "PhysicalContext"):
        value = item.get(key)
        if value is None:
            continue
        match = re.search(r"\bfan\D*([0-9]{1,2})\b", str(value), re.IGNORECASE)
        if match:
            fan_id = int(match.group(1))
            if fan_id in ALL_FAN_IDS:
                return fan_id
    return fallback_id


def fan_rpm(item: Mapping[str, Any]) -> float | None:
    value = number(item.get("ReadingRPM"))
    if value is not None:
        return value
    units = str(item.get("ReadingUnits") or "").casefold()
    if "rpm" in units:
        return number(item.get("Reading"))
    return None


def fan_pwm(item: Mapping[str, Any]) -> float | None:
    for key in ("SpeedPercent", "PwmPercent", "PWM", "SpeedRatio"):
        value = number(item.get(key))
        if value is not None:
            return value
    oem = item.get("Oem")
    if isinstance(oem, Mapping):
        for vendor_payload in oem.values():
            if not isinstance(vendor_payload, Mapping):
                continue
            for key in ("SpeedPercent", "PwmPercent", "PWM", "SpeedRatio"):
                value = number(vendor_payload.get(key))
                if value is not None:
                    return value
    return None


def fetch_redfish_fans(endpoint: str, username: str, password: str, path: str) -> dict[int, FanReading]:
    token = base64.b64encode(f"{username}:{password}".encode("utf-8")).decode("ascii")
    request = urllib.request.Request(
        endpoint.rstrip("/") + path,
        headers={
            "Accept": "application/json",
            "Authorization": f"Basic {token}",
            "User-Agent": "hgnn-full83-fan-detail/1",
        },
        method="GET",
    )
    with urllib.request.urlopen(
        request,
        timeout=8,
        context=ssl._create_unverified_context(),
    ) as response:
        payload = json.loads(response.read(4 * 1024 * 1024).decode("utf-8"))
    fans = payload.get("Fans")
    if not isinstance(fans, Sequence) or isinstance(fans, (str, bytes)):
        return {}
    readings: dict[int, FanReading] = {}
    fallback_id = 1
    for item in fans:
        if not isinstance(item, Mapping):
            continue
        fan_id = fan_id_from_payload(item, fallback_id)
        fallback_id += 1
        if fan_id not in ALL_FAN_IDS:
            continue
        readings[fan_id] = FanReading(
            fan_id=fan_id,
            name=str(item.get("Name") or item.get("MemberId") or f"Fan{fan_id}"),
            rpm=fan_rpm(item),
            pwm_pct=fan_pwm(item),
        )
    return readings


def parse_level_section(text: str) -> tuple[dict[int, int], dict[int, int], str]:
    manual: dict[int, int] = {}
    actual: dict[int, int] = {}
    mode = ""
    section: str | None = None
    clean = text.replace("\r", "")
    mode_match = re.search(r"current\s+fan\s+mode\s*:\s*(auto|manual)", clean, re.IGNORECASE)
    if not mode_match:
        mode_match = re.search(r"current\s+mode\s*:\s*(auto|manual)", clean, re.IGNORECASE)
    if mode_match:
        mode = mode_match.group(1).lower()
    for raw in clean.splitlines():
        line = raw.strip()
        if re.match(r"manual\s+fan\s+level\s*:", line, re.IGNORECASE):
            section = "manual"
            continue
        if re.match(r"actual\s+fan\s+level\s*:", line, re.IGNORECASE):
            section = "actual"
            continue
        if section not in {"manual", "actual"}:
            continue
        for fan, level in re.findall(r"Fan\s*([0-9]{1,2})\s*:\s*([0-9]{1,3})", line, re.IGNORECASE):
            fan_id = int(fan)
            if fan_id not in ALL_FAN_IDS:
                continue
            target = manual if section == "manual" else actual
            target[fan_id] = int(level)
    return manual, actual, mode


def read_cooling_levels(transport: SshIpmcTransport) -> tuple[dict[int, int], dict[int, int], str]:
    return parse_level_section(
        transport._execute(("ipmcget", "-d", "coolingdeviceinfo", "-v", "fan"))
    )


def phase_for_elapsed(elapsed: float, baseline_s: float, release_at_s: float, duration_s: float) -> str:
    if elapsed < baseline_s:
        return "baseline"
    if elapsed < release_at_s:
        return "fault_active"
    if elapsed < duration_s:
        return "recovery"
    return "complete"


def mean(values: list[float]) -> float | None:
    return sum(values) / len(values) if values else None


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--run-id", required=True)
    parser.add_argument("--site-config", type=Path, required=True)
    parser.add_argument("--credentials-env-file", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--duration-s", type=float, required=True)
    parser.add_argument("--baseline-s", type=float, required=True)
    parser.add_argument("--release-at-s", type=float, required=True)
    parser.add_argument("--interval-s", type=float, default=2.0)
    parser.add_argument("--thermal-path", default="/redfish/v1/Chassis/1/Thermal")
    args = parser.parse_args()
    signal.signal(signal.SIGTERM, request_stop)
    signal.signal(signal.SIGINT, request_stop)

    load_credentials(args.credentials_env_file)
    endpoint = os.environ.get("HGNN_BMC_ENDPOINT", "").strip()
    username = os.environ.get("HGNN_BMC_USERNAME", "").strip()
    password = os.environ.get("HGNN_BMC_PASSWORD", "").strip()
    if not (endpoint and username and password):
        raise SystemExit("HGNN_BMC_ENDPOINT/HGNN_BMC_USERNAME/HGNN_BMC_PASSWORD are required")

    args.output_dir.mkdir(parents=True, exist_ok=True)
    fan_csv = args.output_dir / "fan_detail_timeseries.csv"
    drawer_csv = args.output_dir / "drawer_fan_timeseries.csv"
    events = args.output_dir / "fan_detail_events.jsonl"

    with (
        fan_csv.open("w", encoding="utf-8", newline="", buffering=1) as fan_stream,
        drawer_csv.open("w", encoding="utf-8", newline="", buffering=1) as drawer_stream,
    ):
        fan_writer = csv.DictWriter(fan_stream, fieldnames=list(FAN_FIELDS))
        drawer_writer = csv.DictWriter(drawer_stream, fieldnames=list(DRAWER_FIELDS))
        fan_writer.writeheader()
        drawer_writer.writeheader()
        start = time.monotonic()
        next_sample = start
        transport: SshIpmcTransport | None = None
        try:
            transport = build_ipmc_transport(args.site_config)
            while True:
                now = time.monotonic()
                elapsed = now - start
                if STOP_REQUESTED or elapsed > args.duration_s + 30:
                    break
                if now < next_sample:
                    time.sleep(min(0.2, next_sample - now))
                    continue
                next_sample = now + args.interval_s
                phase = phase_for_elapsed(elapsed, args.baseline_s, args.release_at_s, args.duration_s)
                ts = utc_now()
                status_parts: list[str] = []
                manual_levels: dict[int, int] = {}
                actual_levels: dict[int, int] = {}
                try:
                    manual_levels, actual_levels, mode = read_cooling_levels(transport)
                    status_parts.append("ipmc:" + (mode or "ok"))
                except Exception as error:  # noqa: BLE001
                    status_parts.append(f"ipmc_error:{type(error).__name__}:{error}")
                redfish: dict[int, FanReading] = {}
                try:
                    redfish = fetch_redfish_fans(endpoint, username, password, args.thermal_path)
                    status_parts.append("redfish:ok")
                except (urllib.error.URLError, TimeoutError, OSError, json.JSONDecodeError) as error:
                    status_parts.append(f"redfish_error:{type(error).__name__}:{error}")
                status = ";".join(status_parts)
                fan_rows: list[dict[str, Any]] = []
                for fan_id in ALL_FAN_IDS:
                    reading = redfish.get(fan_id, FanReading(fan_id=fan_id))
                    row = {
                        "ts_utc": ts,
                        "elapsed_s": round(elapsed, 3),
                        "phase": phase,
                        "fan_id": fan_id,
                        "drawer": DRAWER_BY_FAN_ID.get(fan_id, "unknown"),
                        "manual_level_pct": manual_levels.get(fan_id),
                        "actual_level_pct": actual_levels.get(fan_id),
                        "redfish_rpm": reading.rpm,
                        "redfish_pwm_pct": reading.pwm_pct,
                        "redfish_name": reading.name,
                        "status": status,
                    }
                    fan_rows.append(row)
                    fan_writer.writerow(row)
                for drawer in sorted(set(DRAWER_BY_FAN_ID.values())):
                    subset = [row for row in fan_rows if row["drawer"] == drawer]
                    rpms = [float(row["redfish_rpm"]) for row in subset if row["redfish_rpm"] is not None]
                    actuals = [
                        float(row["actual_level_pct"])
                        for row in subset
                        if row["actual_level_pct"] is not None
                    ]
                    drawer_writer.writerow(
                        {
                            "ts_utc": ts,
                            "elapsed_s": round(elapsed, 3),
                            "phase": phase,
                            "drawer": drawer,
                            "fan_count": len(subset),
                            "rpm_mean": mean(rpms),
                            "rpm_min": min(rpms) if rpms else None,
                            "rpm_max": max(rpms) if rpms else None,
                            "actual_pwm_mean": mean(actuals),
                            "actual_pwm_min": min(actuals) if actuals else None,
                            "actual_pwm_max": max(actuals) if actuals else None,
                            "status": status,
                        }
                    )
        finally:
            if transport is not None:
                transport.close()
            payload = {
                "ts_utc": utc_now(),
                "event": "fan_detail_sidecar_complete",
                "run_id": args.run_id,
                "fan_csv": str(fan_csv),
                "drawer_csv": str(drawer_csv),
            }
            events.write_text(json.dumps(payload, ensure_ascii=False, sort_keys=True) + "\n", encoding="utf-8")
            print(f"FULL83_FAN_DETAIL_OUTPUT={args.output_dir}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
