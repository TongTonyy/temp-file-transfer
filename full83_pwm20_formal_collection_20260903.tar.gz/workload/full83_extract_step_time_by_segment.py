#!/usr/bin/env python3
"""Extract training step time by profiler segment/phase.

The event-driven profiler records start_step/stop_step for every sampled
segment.  Training logs contain per-iteration step time.  Joining the two gives
phase-bound step-time metrics without a long CANN trace export.
"""

from __future__ import annotations

import argparse
import csv
import json
import re
from collections.abc import Mapping, Sequence
from collections import defaultdict
from pathlib import Path
from statistics import mean, median
from typing import Any


STEP_RE = re.compile(
    r"\biteration\s+([0-9]+)\s*/.*?"
    r"elapsed time per iteration \(ms\):\s*([0-9]+(?:\.[0-9]+)?)"
)


def load_steps(log_path: Path) -> list[dict[str, float | int]]:
    rows: list[dict[str, float | int]] = []
    if not log_path.is_file():
        return rows
    for line in log_path.read_text(encoding="utf-8", errors="replace").splitlines():
        match = STEP_RE.search(line)
        if match is None:
            continue
        rows.append(
            {
                "iteration": int(match.group(1)),
                "step_time_ms": float(match.group(2)),
            }
        )
    return rows


def iter_profile_plans(profile_root: Path) -> list[Mapping[str, Any]]:
    plans: list[Mapping[str, Any]] = []
    for path in sorted(profile_root.glob("rank_*/hgnn_profile_plan.json")):
        try:
            payload = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            continue
        if isinstance(payload, Mapping):
            plans.append(payload)
    return plans


def segment_rows(plans: Sequence[Mapping[str, Any]]) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for plan in plans:
        rank = int(plan.get("rank", -1))
        segments = plan.get("segments")
        if not isinstance(segments, Sequence) or isinstance(segments, (str, bytes)):
            continue
        for segment in segments:
            if not isinstance(segment, Mapping):
                continue
            start_step = segment.get("start_step")
            stop_step = segment.get("stop_step")
            if not isinstance(start_step, int) or not isinstance(stop_step, int):
                continue
            rows.append(
                {
                    "rank": rank,
                    "segment_id": str(segment.get("segment_id") or ""),
                    "phase": str(segment.get("phase") or ""),
                    "start_step": start_step,
                    "stop_step": stop_step,
                    "active_steps_target": segment.get("active_steps_target"),
                    "status": str(segment.get("status") or ""),
                }
            )
    return rows


def step_times_for_segment(
    steps: Sequence[Mapping[str, float | int]],
    start_step: int,
    stop_step: int,
) -> list[float]:
    return [
        float(row["step_time_ms"])
        for row in steps
        if start_step < int(row["iteration"]) <= stop_step
    ]


def summarize(values: Sequence[float]) -> Mapping[str, float | int | None]:
    if not values:
        return {
            "step_count": 0,
            "step_time_ms_mean": None,
            "step_time_ms_median": None,
            "step_time_ms_min": None,
            "step_time_ms_max": None,
        }
    return {
        "step_count": len(values),
        "step_time_ms_mean": mean(values),
        "step_time_ms_median": median(values),
        "step_time_ms_min": min(values),
        "step_time_ms_max": max(values),
    }


def write_csv(path: Path, rows: Sequence[Mapping[str, Any]], fieldnames: Sequence[str]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(fieldnames))
        writer.writeheader()
        for row in rows:
            writer.writerow({name: row.get(name) for name in fieldnames})


def main(argv: Sequence[str] | None = None) -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--run-id", required=True)
    parser.add_argument("--profile-root", type=Path, required=True)
    parser.add_argument("--training-log", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    args = parser.parse_args(argv)

    steps = load_steps(args.training_log)
    plans = iter_profile_plans(args.profile_root)
    segments = segment_rows(plans)
    segment_out: list[dict[str, Any]] = []
    phase_values: dict[tuple[str, str], list[float]] = defaultdict(list)

    for segment in segments:
        values = step_times_for_segment(
            steps,
            int(segment["start_step"]),
            int(segment["stop_step"]),
        )
        row = {
            "run_id": args.run_id,
            **segment,
            **summarize(values),
        }
        segment_out.append(row)
        phase_values[(str(segment["segment_id"]), str(segment["phase"]))].extend(values)

    phase_out: list[dict[str, Any]] = []
    for (segment_id, phase), values in sorted(phase_values.items()):
        phase_out.append(
            {
                "run_id": args.run_id,
                "segment_id": segment_id,
                "phase": phase,
                **summarize(values),
            }
        )

    args.output_dir.mkdir(parents=True, exist_ok=True)
    write_csv(
        args.output_dir / "step_time_by_rank_segment.csv",
        segment_out,
        [
            "run_id",
            "rank",
            "segment_id",
            "phase",
            "start_step",
            "stop_step",
            "active_steps_target",
            "status",
            "step_count",
            "step_time_ms_mean",
            "step_time_ms_median",
            "step_time_ms_min",
            "step_time_ms_max",
        ],
    )
    write_csv(
        args.output_dir / "step_time_by_segment.csv",
        phase_out,
        [
            "run_id",
            "segment_id",
            "phase",
            "step_count",
            "step_time_ms_mean",
            "step_time_ms_median",
            "step_time_ms_min",
            "step_time_ms_max",
        ],
    )
    report = {
        "schema_version": "full83.step_time_by_segment.v1",
        "status": "complete" if steps and phase_out else "no_data",
        "run_id": args.run_id,
        "training_log": str(args.training_log),
        "profile_root": str(args.profile_root),
        "step_log_count": len(steps),
        "profile_plan_count": len(plans),
        "segment_rank_row_count": len(segment_out),
        "segment_count": len(phase_out),
        "outputs": {
            "step_time_by_rank_segment_csv": str(args.output_dir / "step_time_by_rank_segment.csv"),
            "step_time_by_segment_csv": str(args.output_dir / "step_time_by_segment.csv"),
        },
    }
    (args.output_dir / "step_time_report.json").write_text(
        json.dumps(report, ensure_ascii=False, indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )
    print(f"FULL83_STEP_TIME_OUTPUT={args.output_dir}")
    print(f"FULL83_STEP_TIME_STATUS={report['status']}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
