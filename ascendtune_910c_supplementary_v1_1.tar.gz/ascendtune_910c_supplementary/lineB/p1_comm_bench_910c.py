#!/usr/bin/env python3
"""P1 communication microbenchmarks for Ascend 910C (line B).

Sub-commands (one torchrun invocation per sub-command; the driver script
loops over them):

  --mode q_table     independent collective timing, op x group_size x msg_size
  --mode p2p_table   adjacent-rank ring send/recv, msg_size sweep
  --mode s_overlap   GEMM + collective concurrency with per-stream events

Design rules inherited from the v1/V2 pits:
  - every rank creates EVERY group (never only its own) -> no make_group
    deadlock;
  - fixed iteration counts with barrier lockstep (no --min_seconds free-run,
    which previously caused collective desync crashes);
  - group creation cost is covered by warmup, never timed;
  - results are appended to --out by rank 0 only; repeats are medians.
"""
from __future__ import annotations

import argparse
import csv
import json
import os
import statistics
import time

import torch
import torch.distributed as dist
import torch_npu  # noqa: F401


def init_dist():
    local_rank = int(os.environ.get("LOCAL_RANK", "0"))
    torch.npu.set_device(local_rank)
    if not dist.is_initialized():
        dist.init_process_group(backend=os.environ.get("DIST_BACKEND", "hccl"))
    return local_rank


def sync():
    if dist.is_initialized():
        dist.barrier()
    torch.npu.synchronize()


def make_groups(group_size):
    """All ranks create all groups; return my group (None means WORLD)."""
    rank, world = dist.get_rank(), dist.get_world_size()
    if group_size >= world:
        return None
    mine = None
    for start in range(0, world, group_size):
        ranks = list(range(start, min(start + group_size, world)))
        g = dist.new_group(ranks=ranks)
        if rank in ranks:
            mine = g
    return mine


def make_collective(op, numel, group, group_size):
    # all_gather/reduce_scatter list arguments must match the GROUP size,
    # not the world size (hccl rejects mismatched list lengths).
    rank = dist.get_rank()
    world = group_size if group is not None else dist.get_world_size()
    x = torch.randn(numel, device="npu", dtype=torch.bfloat16)
    if op == "all_reduce":
        def step():
            dist.all_reduce(x, group=group)
        return step
    if op == "all_gather":
        outs = [torch.empty_like(x) for _ in range(world)]
        def step():
            dist.all_gather(outs, x, group=group)
        return step
    if op == "reduce_scatter":
        chunks = [torch.empty_like(x) for _ in range(world)]
        y = torch.empty_like(x)
        def step():
            dist.reduce_scatter(y, chunks, group=group)
        return step
    if op == "p2p_ring":
        dst = (rank + 1) % world
        src = (rank - 1 + world) % world
        y = torch.empty_like(x)
        def step():
            reqs = dist.batch_isend_irecv([
                dist.P2POp(dist.isend, x, dst),
                dist.P2POp(dist.irecv, y, src),
            ])
            for r in reqs:
                r.wait()
        return step
    raise ValueError(op)


def bench_reps(fn, warmup, iters, repeats):
    """Return (median_s, all_rep_seconds). Lockstep across ranks."""
    for _ in range(warmup):
        fn()
    sync()
    reps = []
    for _ in range(repeats):
        start = time.perf_counter()
        for _ in range(iters):
            fn()
        sync()
        reps.append((time.perf_counter() - start) / iters)
    return statistics.median(reps), reps


def append_row(path, row):
    exists = os.path.exists(path)
    if dist.get_rank() != 0:
        return
    with open(path, "a", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=list(row))
        if not exists:
            w.writeheader()
        w.writerow(row)


def run_q_table(args, cfg):
    q = cfg["q_table"]
    for op in q["ops"]:
        for gs in q["group_sizes"]:
            group = make_groups(gs)
            sync()  # group creation warmup, never timed
            for msg_bytes in q["msg_sizes_bytes"]:
                numel = max(1, msg_bytes // cfg["bytes_per_elem"])
                step = make_collective(op, numel, group, gs)
                med, _ = bench_reps(step, cfg["warmup"], cfg["iters_per_rep"], cfg["repeats"])
                bw = (msg_bytes / med) / 1e9 if med > 0 else 0.0
                append_row(args.out, {
                    "op": op, "group_size": gs, "msg_size_bytes": msg_bytes,
                    "numel": numel, "avg_s": med, "BW_actual_GBps": round(bw, 4),
                    "repeats": cfg["repeats"], "iters_per_rep": cfg["iters_per_rep"],
                    "world_size": dist.get_world_size(), "timestamp": int(time.time()),
                })
                if dist.get_rank() == 0:
                    print(f"[q_table] {op} g{gs} {msg_bytes}B -> {med*1e3:.4f} ms, {bw:.2f} GB/s", flush=True)


def run_p2p_table(args, cfg):
    p = cfg["p2p_table"]
    for msg_bytes in p["msg_sizes_bytes"]:
        numel = max(1, msg_bytes // cfg["bytes_per_elem"])
        step = make_collective("p2p_ring", numel, None, dist.get_world_size())
        med, _ = bench_reps(step, cfg["warmup"], cfg["iters_per_rep"], cfg["repeats"])
        bw = (msg_bytes / med) / 1e9 if med > 0 else 0.0
        append_row(args.out, {
            "msg_size_bytes": msg_bytes, "numel": numel,
            "avg_s": med, "BW_actual_GBps": round(bw, 4),
            "repeats": cfg["repeats"], "iters_per_rep": cfg["iters_per_rep"],
            "world_size": dist.get_world_size(), "timestamp": int(time.time()),
        })
        if dist.get_rank() == 0:
            print(f"[p2p_table] {msg_bytes}B -> {med*1e3:.4f} ms, {bw:.2f} GB/s", flush=True)


def run_s_overlap(args, cfg):
    s = cfg["s_overlap"]
    m, n, k = s["gemm"]["m"], s["gemm"]["n"], s["gemm"]["k"]
    a = torch.randn(m, k, device="npu", dtype=torch.bfloat16)
    b = torch.randn(k, n, device="npu", dtype=torch.bfloat16)

    def gemm_step():
        torch.matmul(a, b)

    t_gemm_alone, _ = bench_reps(gemm_step, cfg["warmup"], cfg["iters_per_rep"], cfg["repeats"])
    if dist.get_rank() == 0:
        print(f"[s_overlap] gemm {m}x{k}x{n} alone: {t_gemm_alone*1e3:.4f} ms", flush=True)

    compute_stream = torch.npu.Stream()
    comm_stream = torch.npu.Stream()

    for op in s["collectives"]:
        for gs in s["group_sizes"]:
            group = make_groups(gs)
            sync()
            comm_step = make_collective(op, s["comm_numel"], group, gs)
            t_comm_alone, _ = bench_reps(comm_step, cfg["warmup"], cfg["iters_per_rep"], cfg["repeats"])

            # concurrent measurement with per-stream events
            tg_list, tc_list = [], []
            for _ in range(cfg["warmup"]):
                with torch.npu.stream(compute_stream):
                    gemm_step()
                with torch.npu.stream(comm_stream):
                    comm_step()
                torch.npu.synchronize()
            sync()
            for _ in range(cfg["repeats"]):
                ev_g0, ev_g1 = torch.npu.Event(enable_timing=True), torch.npu.Event(enable_timing=True)
                ev_c0, ev_c1 = torch.npu.Event(enable_timing=True), torch.npu.Event(enable_timing=True)
                ev_g0.record(compute_stream)
                with torch.npu.stream(compute_stream):
                    for _ in range(cfg["iters_per_rep"]):
                        gemm_step()
                ev_g1.record(compute_stream)
                ev_c0.record(comm_stream)
                with torch.npu.stream(comm_stream):
                    for _ in range(cfg["iters_per_rep"]):
                        comm_step()
                ev_c1.record(comm_stream)
                torch.npu.synchronize()
                tg_list.append(ev_g0.elapsed_time(ev_g1) / cfg["iters_per_rep"])  # ms
                tc_list.append(ev_c0.elapsed_time(ev_c1) / cfg["iters_per_rep"])
            t_gemm_conc_ms = statistics.median(tg_list)
            t_comm_conc_ms = statistics.median(tc_list)
            s_compute = (t_gemm_conc_ms / 1e3) / t_gemm_alone if t_gemm_alone > 0 else 0.0
            s_comm = (t_comm_conc_ms / 1e3) / t_comm_alone if t_comm_alone > 0 else 0.0
            # serialization heuristic: concurrent durations ~= sequential sum
            serial = 1 if (t_gemm_conc_ms / 1e3) > 0.9 * (t_gemm_alone + t_comm_alone) else 0
            append_row(args.out, {
                "collective_type": op, "group_size": gs,
                "gemm_shape": f"{m}x{k}x{n}", "comm_numel": s["comm_numel"],
                "T_gemm_alone_ms": round(t_gemm_alone * 1e3, 6),
                "T_comm_alone_ms": round(t_comm_alone * 1e3, 6),
                "T_gemm_concurrent_ms": round(t_gemm_conc_ms, 6),
                "T_comm_concurrent_ms": round(t_comm_conc_ms, 6),
                "s_overlap_compute": round(s_compute, 6),
                "s_overlap_comm": round(s_comm, 6),
                "serialized_suspect": serial,
                "repeats": cfg["repeats"], "iters_per_rep": cfg["iters_per_rep"],
                "world_size": dist.get_world_size(), "timestamp": int(time.time()),
            })
            if dist.get_rank() == 0:
                print(f"[s_overlap] {op} g{gs}: s_compute={s_compute:.3f} s_comm={s_comm:.3f} "
                      f"serial_suspect={serial}", flush=True)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--mode", required=True, choices=["q_table", "p2p_table", "s_overlap"])
    ap.add_argument("--config", required=True, help="configs/lineB_comm.json")
    ap.add_argument("--out", required=True)
    args = ap.parse_args()

    with open(args.config, encoding="utf-8") as f:
        cfg = json.load(f)

    init_dist()
    if args.mode == "q_table":
        run_q_table(args, cfg)
    elif args.mode == "p2p_table":
        run_p2p_table(args, cfg)
    else:
        run_s_overlap(args, cfg)
    sync()
    if dist.get_rank() == 0:
        print(f"[done] mode={args.mode} -> {args.out}", flush=True)


if __name__ == "__main__":
    main()
