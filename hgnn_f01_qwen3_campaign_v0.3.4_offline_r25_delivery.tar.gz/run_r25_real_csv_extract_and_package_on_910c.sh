#!/usr/bin/env bash
set -Eeuo pipefail
umask 077

ROOT="${HGNN_ROOT:-/root/hgnn_910c_readiness/hgnn_f01_qwen3_campaign_v0.3.4}"
PACKAGE="hgnn_f01_qwen3_campaign_v0.3.4_offline_r25.tar.gz"
CAMPAIGN_ID="${HGNN_R25_CAMPAIGN_ID:-20260814T041544Z-r13-full-dataset}"
DATASET_MANIFEST="${HGNN_R25_DATASET_MANIFEST:-$ROOT/runtime/manifests/$CAMPAIGN_ID/r13_dataset_manifest.json}"
R23_ROOT="${HGNN_R25_R23_ROOT:-$ROOT/runtime/extracted_targets_r23/$CAMPAIGN_ID}"
EXTRACT_ROOT="${HGNN_R25_EXTRACT_ROOT:-$ROOT/runtime/extracted_targets_r25/$CAMPAIGN_ID}"
OUTPUT_DIR="${HGNN_R25_OUTPUT_DIR:-$ROOT/runtime/return_bundles}"
MAX_WORKERS="${HGNN_R25_MAX_WORKERS:-8}"

[[ -d "$ROOT" ]] || { echo "campaign目录不存在: $ROOT" >&2; exit 2; }
cd "$ROOT"
mkdir -p runtime/logs "$EXTRACT_ROOT" "$OUTPUT_DIR"
STAMP="$(date -u +%Y%m%dT%H%M%SZ)"
LOG="$ROOT/runtime/logs/r25_real_csv_extract_${STAMP}.log"
PID_FILE="$ROOT/runtime/logs/r25_real_csv_extract.pid"
exec > >(tee -a "$LOG") 2>&1

r25_stage() {
  echo "============================================================"
  echo "R25_STAGE=$1/10"
  echo "R25_STAGE_NAME=$2"
  echo "R25_STAGE_UTC=$(date -u +%Y%m%dT%H%M%SZ)"
  echo "============================================================"
}

cleanup_pid() {
  [[ -f "$PID_FILE" ]] || return 0
  [[ "$(cat "$PID_FILE")" == "$$" ]] && rm -f "$PID_FILE"
}
trap cleanup_pid EXIT

r25_stage 1 "启动与CANN遗留进程检查"
echo "R25_STARTED=$STAMP"
echo "R25_LOG=$LOG"
echo "EXTRACT_ROOT=$EXTRACT_ROOT"
echo "MAX_WORKERS=$MAX_WORKERS"
[[ "$MAX_WORKERS" =~ ^[0-9]+$ ]] &&
  ((MAX_WORKERS >= 8 && MAX_WORKERS <= 16)) || {
  echo "HGNN_R25_MAX_WORKERS必须在8到16之间" >&2
  exit 2
}
if [[ -f "$PID_FILE" ]]; then
  OLD_PID="$(cat "$PID_FILE" 2>/dev/null || true)"
  if [[ "$OLD_PID" =~ ^[0-9]+$ ]] && kill -0 "$OLD_PID" 2>/dev/null; then
    echo "r25仍在运行: pid=$OLD_PID" >&2
    exit 2
  fi
  rm -f "$PID_FILE"
fi
echo "$$" >"$PID_FILE"
if pgrep -af \
  'extract_r23_profiler_targets|extract_r25_real_csv_metrics|msprof.py.*export|analyse_torch_npu_profiles' \
  >runtime/logs/r25_process_check.txt; then
  echo "检测到解析进程，拒绝叠加启动：" >&2
  while IFS= read -r process; do echo "$process" >&2; done \
    <runtime/logs/r25_process_check.txt
  exit 2
fi

r25_stage 2 "r25工具包完整性校验与部署"
[[ -f "$PACKAGE" && -f "$PACKAGE.sha256" ]] || {
  echo "缺少r25工具包或SHA256" >&2
  exit 2
}
sha256sum -c "$PACKAGE.sha256"
tar -xzf "$PACKAGE"
sha256sum -c r25_SHA256SUMS

r25_stage 3 "Python与轻量依赖初始化"
if [[ -f /root/miniconda3/etc/profile.d/conda.sh ]]; then
  # shellcheck disable=SC1091
  source /root/miniconda3/etc/profile.d/conda.sh
elif command -v conda >/dev/null 2>&1; then
  eval "$(conda shell.bash hook)"
else
  echo "未找到conda" >&2
  exit 2
fi
conda activate llm_env
python - <<'PY'
import pyarrow
import yaml
print(
    "R25_DEPENDENCY_PREFLIGHT=PASS "
    f"pyarrow={pyarrow.__version__} yaml={yaml.__version__}"
)
PY

r25_stage 4 "四Run、64 Session与83指标合同生成"
python workload/prepare_r23_extraction_contract.py \
  --dataset-manifest "$DATASET_MANIFEST" \
  --node-schema "$ROOT/app/schemas/node_features.yaml" \
  --output-root "$EXTRACT_ROOT"

r25_stage 5 "已有CSV、r23结果与SQLite恢复源清点"
python - "$EXTRACT_ROOT/r23_selection_manifest.json" "$R23_ROOT" <<'PY'
import json
import sys
from pathlib import Path

selection = json.loads(Path(sys.argv[1]).read_text())
r23_root = Path(sys.argv[2])
counts = {"csv": 0, "r23_report": 0, "needs_sqlite_probe": 0}
for entry in selection["entries"]:
    run_id = entry["run_id"]
    for rank, session_text in entry["rank_sessions"].items():
        session = Path(session_text)
        if any(session.rglob("op_summary_slice_*.csv")):
            counts["csv"] += 1
        elif (r23_root / run_id / f"rank_{rank}" / "r23_session_report.json").is_file():
            counts["r23_report"] += 1
        else:
            counts["needs_sqlite_probe"] += 1
print("R25_SOURCE_COUNTS=" + json.dumps(counts, sort_keys=True))
PY

r25_stage 6 "8至16路并行流式提取真实CSV与SQLite"
python workload/extract_r25_real_csv_metrics.py \
  --selection-manifest "$EXTRACT_ROOT/r23_selection_manifest.json" \
  --metric-coverage "$EXTRACT_ROOT/metric_coverage_83.json" \
  --output-root "$EXTRACT_ROOT" \
  --r23-output-root "$R23_ROOT" \
  --max-workers "$MAX_WORKERS"

r25_stage 7 "四Run与64 Session完整覆盖验收"
python - "$EXTRACT_ROOT/dataset_extraction_manifest.json" <<'PY'
import json
import sys
from pathlib import Path
data = json.loads(Path(sys.argv[1]).read_text())
if data.get("status") != "complete":
    raise SystemExit("r25 extraction is not complete")
if data.get("complete_session_count") != 64:
    raise SystemExit(
        f"r25 covers only {data.get('complete_session_count')}/64 sessions"
    )
if not data.get("coverage", {}).get("all_64_sessions"):
    raise SystemExit("r25 all-session coverage flag is false")
print("R25_SESSION_VALIDATED=PASS complete=64")
PY

r25_stage 8 "真实字段、代理语义与83指标覆盖验收"
python - "$EXTRACT_ROOT/metric_coverage_83.json" <<'PY'
import json
import sys
from pathlib import Path
data = json.loads(Path(sys.argv[1]).read_text())
if data.get("metric_count") != 83 or len(data.get("metrics", [])) != 83:
    raise SystemExit("metric contract is not exactly 83")
present = set(data.get("profiler_metrics_present", []))
required = {
    "npu.aicore_stall_ratio",
    "hbm.read_gbps",
    "hbm.write_gbps",
    "global_task.comm_compute_overlap_pct",
}
if not required.issubset(present):
    raise SystemExit(f"missing real/proxy profiler metrics: {required - present}")
print(f"R25_METRIC_VALIDATED=PASS present={sorted(present)}")
PY

r25_stage 9 "四Run轻量数据集单包打包"
PACKAGE_OUTPUT="$(
  python workload/package_extracted_dataset.py \
    --dataset-manifest "$DATASET_MANIFEST" \
    --extraction-root "$EXTRACT_ROOT" \
    --output-dir "$OUTPUT_DIR" \
    --bundle-label r25-real-csv-metrics-dataset
)"
echo "$PACKAGE_OUTPUT"
BUNDLE="$(printf '%s\n' "$PACKAGE_OUTPUT" | awk -F= '$1=="DATASET_BUNDLE"{print substr($0,index($0,"=")+1)}')"
BUNDLE_SUM="$(printf '%s\n' "$PACKAGE_OUTPUT" | awk -F= '$1=="DATASET_BUNDLE_SHA256"{print substr($0,index($0,"=")+1)}')"
[[ -f "$BUNDLE" && -f "$BUNDLE_SUM" ]] || {
  echo "最终数据包缺失" >&2
  exit 2
}
(cd "$(dirname "$BUNDLE")" && sha256sum -c "$(basename "$BUNDLE_SUM")")

r25_stage 10 "无原始Trace泄漏与最终完成"
python - "$BUNDLE" <<'PY'
import sys
import tarfile
with tarfile.open(sys.argv[1], "r:gz") as archive:
    names = archive.getnames()
for name in names:
    lowered = name.lower()
    if "_ascend_pt/" in lowered or "/prof_" in lowered:
        raise SystemExit(f"raw profiler member leaked: {name}")
print(f"R25_BUNDLE_VALIDATED=PASS members={len(names)}")
PY
echo "R25_COMPLETE=$STAMP"
echo "R25_DATASET_BUNDLE=$BUNDLE"
echo "R25_DATASET_BUNDLE_SHA256=$BUNDLE_SUM"
