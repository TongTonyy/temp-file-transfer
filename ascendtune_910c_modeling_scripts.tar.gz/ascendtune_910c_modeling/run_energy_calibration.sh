#!/bin/bash
# Run energy-state calibration on a 910C server.

set -u
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
# shellcheck disable=SC1091
source "$SCRIPT_DIR/common_env.sh"

OUT_ROOT=${OUT_ROOT:-$SCRIPT_DIR/results_energy_calibration}
mkdir -p "$OUT_ROOT"

run_with_sampler() {
  local name=$1
  shift
  local dir="$OUT_ROOT/$name"
  mkdir -p "$dir"
  echo "======================================================================"
  echo "[$(date '+%F %T')] $name"
  echo "command: $*"
  echo "======================================================================"
  SAMPLE_INTERVAL_SEC=${SAMPLE_INTERVAL_SEC:-1} bash "$SCRIPT_DIR/sampler_power_mem.sh" "$dir/power_mem.csv" &
  local sampler_pid=$!
  sleep 5
  ( "$@" ) > "$dir/run.log" 2>&1
  local rc=$?
  sleep 3
  kill "$sampler_pid" 2>/dev/null || true
  wait "$sampler_pid" 2>/dev/null || true
  echo "$rc" > "$dir/exit_code.txt"
  return "$rc"
}

cd "$SCRIPT_DIR" || exit 1

echo "[idle] sampling idle power for 180 seconds"
mkdir -p "$OUT_ROOT/idle"
SAMPLE_INTERVAL_SEC=${SAMPLE_INTERVAL_SEC:-1} bash "$SCRIPT_DIR/sampler_power_mem.sh" "$OUT_ROOT/idle/power_mem.csv" &
idle_pid=$!
sleep "${IDLE_SECONDS:-180}"
kill "$idle_pid" 2>/dev/null || true
wait "$idle_pid" 2>/dev/null || true

run_with_sampler compute_gemm python3 "$SCRIPT_DIR/energy_microbench_910c.py" \
  --mode compute_gemm --out "$OUT_ROOT/bench_metrics.csv" --iters 80 --m 4096 --n 4096 --k 4096

run_with_sampler vector_norm python3 "$SCRIPT_DIR/energy_microbench_910c.py" \
  --mode vector_norm --out "$OUT_ROOT/bench_metrics.csv" --iters 120 --rows 8192 --cols 5120

run_with_sampler memory_copy python3 "$SCRIPT_DIR/energy_microbench_910c.py" \
  --mode memory_copy --out "$OUT_ROOT/bench_metrics.csv" --iters 120 --numel 134217728

port=${MASTER_PORT:-7920}
for mode in all_reduce all_gather reduce_scatter; do
  for numel in 16777216 67108864 134217728; do
    run_with_sampler "${mode}_${numel}" torchrun \
      --nproc_per_node "$NPUS_PER_NODE" \
      --nnodes 1 \
      --node_rank 0 \
      --master_addr "$MASTER_ADDR" \
      --master_port "$port" \
      "$SCRIPT_DIR/energy_microbench_910c.py" \
      --mode "$mode" \
      --out "$OUT_ROOT/bench_metrics.csv" \
      --iters 80 \
      --numel "$numel"
    port=$((port + 1))
  done
done

echo "[done] results in $OUT_ROOT"
