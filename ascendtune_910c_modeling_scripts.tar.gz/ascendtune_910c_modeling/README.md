# AscendTune 910C 建模与标定脚本包

本目录用于在 910C 服务器上执行第二轮建模标定。目标不是继续解释旧排序，而是获得可复验的吞吐/能耗结构化模型。

## 部署位置

本包在 910C 服务器上的部署路径为：

```text
/root/hgnn_910c_readiness/ascendtune_910c_modeling/
```

通过堡垒机网页端执行以下命令拉取并解压（压缩包托管在 GitHub 仓库 TongTonyy/temp-file-transfer，经 ghfast.top 代理下载）：

```bash
cd /root/hgnn_910c_readiness
wget "https://ghfast.top/https://raw.githubusercontent.com/TongTonyy/temp-file-transfer/main/ascendtune_910c_modeling_scripts.tar.gz" -O ascendtune_910c_modeling_scripts.tar.gz
tar -xzf ascendtune_910c_modeling_scripts.tar.gz
cd ascendtune_910c_modeling
```

## 执行步骤

1. 按上面的命令解压并进入 `/root/hgnn_910c_readiness/ascendtune_910c_modeling`。
2. 激活 910C 上的 Python 虚拟环境（需已安装 torch / torch_npu）。
3. 检查 `common_env.sh` 中的路径，确认 `MSLLM_DIR`（默认 `/root/MindSpeed-LLM`）、权重目录、数据目录正确；如不一致可 `export MSLLM_DIR=实际路径` 覆盖。
4. 先跑 ZeRO 档位探测：

```bash
bash run_zero_stage_probe.sh 2>&1 | tee zero_probe.log
```

5. 再跑功耗状态机标定：

```bash
bash run_energy_calibration.sh 2>&1 | tee energy_calibration.log
```

6. 打包结果并推送到 GitHub：

```bash
bash pack_and_push_results.sh
```

## 产物

- `results_zero_probe/`：ZeRO 0/1/2/3 的可执行性、显存、吞吐、错误日志。
- `results_energy_calibration/`：idle、GEMM、vector、memory、HCCL 标定结果和功耗时间序列。
- `ascendtune_910c_modeling_results.tar.gz`：用于传回本地建模。

## 建模原则

参考 Galvatron 的结构化建模方式：先 profile 硬件和模型算子，再把策略预测拆成计算、通信、显存和调度项。能耗模型采用 Trace 状态机积分：

```text
Power_total(t) = P_idle + P_compute(t) + P_memory(t) + P_comm(t)
Energy = sum(Power_total(t) * dt)
tokens/J = effective_or_nominal_tokens / Energy
```

注意：`posttrain_gpt_lab_v2.py` 仍保留真实 token 计数钩子，但不同 MindSpeed-LLM 版本内部函数名可能变化。若 `real_tokens.csv` 行数不是 25，需要先修 token 计数入口，再谈 effective tokens/J。
