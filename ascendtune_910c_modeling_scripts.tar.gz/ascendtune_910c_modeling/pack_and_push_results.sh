#!/bin/bash
# Pack calibration results and optionally push them through a GitHub repo.

set -u
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
ARCHIVE=${ARCHIVE:-ascendtune_910c_modeling_results.tar.gz}

cd "$SCRIPT_DIR" || exit 1
tar czf "$ARCHIVE" results_zero_probe results_energy_calibration 2>/dev/null || tar czf "$ARCHIVE" ./*.log ./*.csv 2>/dev/null || true
echo "[pack] wrote $SCRIPT_DIR/$ARCHIVE"

if git rev-parse --is-inside-work-tree >/dev/null 2>&1; then
  git add "$ARCHIVE" results_zero_probe results_energy_calibration 2>/dev/null || true
  git commit -m "Add AscendTune 910C calibration results" || true
  git push || true
  echo "[git] attempted commit and push"
else
  echo "[git] not inside a git repo; move $ARCHIVE into your GitHub project and push manually"
fi
