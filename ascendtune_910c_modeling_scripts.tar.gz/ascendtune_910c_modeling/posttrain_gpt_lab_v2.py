# -*- coding: utf-8 -*-
"""MindSpeed-LLM training wrapper for memory report and real token counting.

Place this file in $MSLLM_DIR and launch it instead of posttrain_gpt.py.
It keeps the original training code untouched.
"""
import atexit
import csv
import os
import runpy
import sys

_tok = {"all": 0, "real": 0, "step": 0, "rows": 0}
_state = {"file": None, "writer": None, "forward_hook": False, "train_hook": False, "grab_fail": 0}


def _rank0():
    return os.environ.get("RANK", "0") == "0"


def _writer():
    if _state["writer"] is None:
        _state["file"] = open("real_tokens.csv", "w", newline="", encoding="utf-8")
        _state["writer"] = csv.writer(_state["file"])
        _state["writer"].writerow(["iteration", "tokens_numel_allranks", "tokens_nonpad_allranks"])
    return _state["writer"]


def _grab_loss_mask_from_loss_func(loss_func):
    try:
        freevars = loss_func.__code__.co_freevars
        if "loss_mask" not in freevars:
            return
        loss_mask = loss_func.__closure__[freevars.index("loss_mask")].cell_contents
        _tok["all"] += int(loss_mask.numel())
        _tok["real"] += int(loss_mask.sum())
    except Exception:
        _state["grab_fail"] += 1


def _install_forward_hook():
    candidates = [
        "mindspeed_llm.tasks.posttrain.sft.sft_trainer",
        "mindspeed_llm.tasks.posttrain.sft.trainer",
    ]
    for module_name in candidates:
        try:
            module = __import__(module_name, fromlist=["forward_step"])
            orig = getattr(module, "forward_step")
        except Exception:
            continue

        def wrapped_forward_step(*args, __orig=orig, **kwargs):
            out = __orig(*args, **kwargs)
            loss_func = out[1] if isinstance(out, (tuple, list)) and len(out) > 1 else out
            _grab_loss_mask_from_loss_func(loss_func)
            return out

        setattr(module, "forward_step", wrapped_forward_step)
        _state["forward_hook"] = True
        if _rank0():
            print(f"[TOKCOUNT] installed forward hook on {module_name}", flush=True)
        return


def _install_train_step_hook():
    candidates = [
        "mindspeed_llm.training.training",
        "megatron.training.training",
    ]
    for module_name in candidates:
        try:
            module = __import__(module_name, fromlist=["train_step"])
            orig = getattr(module, "train_step")
        except Exception:
            continue

        def wrapped_train_step(*args, __orig=orig, **kwargs):
            _tok["all"] = 0
            _tok["real"] = 0
            ret = __orig(*args, **kwargs)
            try:
                import torch
                import torch.distributed as dist
                _tok["step"] += 1
                t = torch.tensor([_tok["all"], _tok["real"]], dtype=torch.long).npu()
                dist.all_reduce(t, group=dist.group.WORLD)
                if dist.get_rank() == 0:
                    _writer().writerow([_tok["step"], int(t[0]), int(t[1])])
                    _state["file"].flush()
                    _tok["rows"] += 1
            except Exception:
                _state["grab_fail"] += 1
            return ret

        setattr(module, "train_step", wrapped_train_step)
        _state["train_hook"] = True
        if _rank0():
            print(f"[TOKCOUNT] installed train_step hook on {module_name}", flush=True)
        return


def _install_token_counter():
    _install_forward_hook()
    _install_train_step_hook()
    if _rank0():
        print(
            f"[TOKCOUNT] forward_hook={_state['forward_hook']} "
            f"train_hook={_state['train_hook']} metric=loss_mask.sum",
            flush=True,
        )


@atexit.register
def _report_memory_and_tokens():
    try:
        import torch
        import torch_npu  # noqa: F401
        rank = os.environ.get("RANK", "?")
        alloc = torch.npu.max_memory_allocated() / 1024**3
        reserved = torch.npu.max_memory_reserved() / 1024**3
        print(
            f"[MEMREPORT rank {rank}] max_allocated={alloc:.2f} GiB "
            f"max_reserved={reserved:.2f} GiB capacity=61.28 GiB",
            flush=True,
        )
    except Exception as exc:
        print(f"[MEMREPORT] failed: {exc}", flush=True)
    if _rank0():
        print(
            f"[TOKCOUNT] rows={_tok['rows']} grab_fail={_state['grab_fail']} "
            f"forward_hook={_state['forward_hook']} train_hook={_state['train_hook']}",
            flush=True,
        )
    if _state["file"]:
        _state["file"].close()


_install_token_counter()

_here = os.path.dirname(os.path.abspath(__file__))
sys.argv[0] = os.path.join(_here, "posttrain_gpt.py")
runpy.run_path(sys.argv[0], run_name="__main__")
