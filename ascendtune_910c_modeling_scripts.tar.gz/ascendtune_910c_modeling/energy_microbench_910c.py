#!/usr/bin/env python3
"""Microbenchmarks for 910C energy-state calibration."""
import argparse
import csv
import os
import time

import torch
import torch.distributed as dist
import torch_npu  # noqa: F401


def set_device():
    local_rank = int(os.environ.get("LOCAL_RANK", "0"))
    torch.npu.set_device(local_rank)
    return local_rank


def maybe_init_dist():
    if int(os.environ.get("WORLD_SIZE", "1")) > 1 and not dist.is_initialized():
        dist.init_process_group(backend=os.environ.get("DIST_BACKEND", "hccl"))


def sync():
    if dist.is_initialized():
        dist.barrier()
    torch.npu.synchronize()


def bench_loop(fn, warmup, iters):
    for _ in range(warmup):
        fn()
    sync()
    start = time.time()
    for _ in range(iters):
        fn()
    sync()
    return (time.time() - start) / iters


def make_tensor(numel, dtype):
    return torch.randn(numel, device="npu", dtype=dtype)


def run_compute_gemm(args):
    a = torch.randn(args.m, args.k, device="npu", dtype=torch.bfloat16)
    b = torch.randn(args.k, args.n, device="npu", dtype=torch.bfloat16)
    c = None

    def step():
        nonlocal c
        c = torch.matmul(a, b)
        return c

    avg = bench_loop(step, args.warmup, args.iters)
    flops = 2 * args.m * args.n * args.k
    return {"metric": "gemm", "avg_s": avg, "work": flops, "unit": "flop"}


def run_memory_copy(args):
    x = make_tensor(args.numel, torch.bfloat16)
    y = torch.empty_like(x)

    def step():
        y.copy_(x)

    avg = bench_loop(step, args.warmup, args.iters)
    bytes_moved = x.numel() * x.element_size()
    return {"metric": "memory_copy", "avg_s": avg, "work": bytes_moved, "unit": "byte"}


def run_vector_norm(args):
    x = torch.randn(args.rows, args.cols, device="npu", dtype=torch.bfloat16)
    y = None

    def step():
        nonlocal y
        y = torch.nn.functional.rms_norm(x, (args.cols,))
        return y

    avg = bench_loop(step, args.warmup, args.iters)
    return {"metric": "vector_rms_norm", "avg_s": avg, "work": x.numel(), "unit": "element"}


def run_collective(args):
    maybe_init_dist()
    x = make_tensor(args.numel, torch.bfloat16)
    world = dist.get_world_size()
    op = args.mode

    if op == "all_gather":
        out = [torch.empty_like(x) for _ in range(world)]

        def step():
            dist.all_gather(out, x)
    elif op == "reduce_scatter":
        chunks = [torch.empty_like(x) for _ in range(world)]
        out = torch.empty_like(x)

        def step():
            dist.reduce_scatter(out, chunks)
    elif op == "all_reduce":
        def step():
            dist.all_reduce(x)
    else:
        raise ValueError(op)

    avg = bench_loop(step, args.warmup, args.iters)
    bytes_moved = args.numel * x.element_size()
    return {"metric": op, "avg_s": avg, "work": bytes_moved, "unit": "byte_per_rank"}


def write_row(args, row):
    rank = int(os.environ.get("RANK", "0"))
    if rank != 0:
        return
    path = args.out
    exists = os.path.exists(path)
    fields = ["mode", "metric", "avg_s", "work", "unit", "world_size", "local_rank", "timestamp"]
    with open(path, "a", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fields)
        if not exists:
            writer.writeheader()
        row = dict(row)
        row.update({
            "mode": args.mode,
            "world_size": int(os.environ.get("WORLD_SIZE", "1")),
            "local_rank": int(os.environ.get("LOCAL_RANK", "0")),
            "timestamp": int(time.time()),
        })
        writer.writerow(row)
    print(row, flush=True)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--mode", required=True,
                        choices=["compute_gemm", "memory_copy", "vector_norm",
                                 "all_reduce", "all_gather", "reduce_scatter"])
    parser.add_argument("--out", default="bench_metrics.csv")
    parser.add_argument("--warmup", type=int, default=10)
    parser.add_argument("--iters", type=int, default=50)
    parser.add_argument("--m", type=int, default=4096)
    parser.add_argument("--n", type=int, default=4096)
    parser.add_argument("--k", type=int, default=4096)
    parser.add_argument("--numel", type=int, default=134217728)
    parser.add_argument("--rows", type=int, default=8192)
    parser.add_argument("--cols", type=int, default=5120)
    args = parser.parse_args()

    set_device()
    if args.mode in ("all_reduce", "all_gather", "reduce_scatter"):
        row = run_collective(args)
    elif args.mode == "compute_gemm":
        row = run_compute_gemm(args)
    elif args.mode == "memory_copy":
        row = run_memory_copy(args)
    elif args.mode == "vector_norm":
        row = run_vector_norm(args)
    else:
        raise ValueError(args.mode)
    write_row(args, row)


if __name__ == "__main__":
    main()
