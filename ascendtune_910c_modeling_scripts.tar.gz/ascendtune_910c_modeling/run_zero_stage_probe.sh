#!/bin/bash
# Probe ZeRO-stage executability on the current MindSpeed-LLM stack.

set -u
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
# shellcheck disable=SC1091
source "$SCRIPT_DIR/common_env.sh"

OUT_ROOT=${OUT_ROOT:-$SCRIPT_DIR/results_zero_probe}
ENTRY=${ENTRY:-posttrain_gpt_lab_v2.py}
PP=${PP:-1}
TP=${TP:-4}
MICRO_BATCH=${MICRO_BATCH:-1}
BASE_PORT=${BASE_PORT:-7800}
mkdir -p "$OUT_ROOT"

cp "$SCRIPT_DIR/posttrain_gpt_lab_v2.py" "$MSLLM_DIR/$ENTRY"

HELP_FILE="$OUT_ROOT/posttrain_help.txt"
(cd "$MSLLM_DIR" && python3 posttrain_gpt.py --help > "$HELP_FILE" 2>&1) || true

has_flag() {
  grep -q -- "$1" "$HELP_FILE"
}

zero_args() {
  local z=$1
  case "$z" in
    0)
      echo ""
      ;;
    1)
      if has_flag "--use-distributed-optimizer"; then
        echo "--use-distributed-optimizer"
      else
        echo ""
      fi
      ;;
    2)
      if has_flag "--zero-stage"; then
        echo "--zero-stage 2"
      elif has_flag "--use-zero2-for-dp"; then
        echo "--use-zero2-for-dp"
      elif has_flag "--use-distributed-optimizer"; then
        echo "--use-distributed-optimizer --overlap-grad-reduce"
      else
        echo ""
      fi
      ;;
    3)
      if has_flag "--zero-stage"; then
        echo "--zero-stage 3"
      elif has_flag "--use-zero3-for-embed"; then
        echo "--use-zero3-for-embed --use-distributed-optimizer"
      elif has_flag "--use-distributed-optimizer"; then
        echo "--use-distributed-optimizer --overlap-grad-reduce --overlap-param-gather"
      else
        echo ""
      fi
      ;;
  esac
}

run_one() {
  local z=$1
  local port=$2
  local dir="$OUT_ROOT/zero${z}"
  local dp=$(( NPUS_PER_NODE / (PP * TP) ))
  local ckpt="$CKPT_WEIGHTS_DIR/$(ckpt_name "$TP" "$PP" "$dp")"
  local args_file="$dir/zero_args.txt"
  local status_file="$dir/run_status.txt"
  local extra
  extra="$(zero_args "$z")"

  mkdir -p "$dir"
  echo "$extra" > "$args_file"
  echo "p=$PP t=$TP d=$dp z=$z b=$MICRO_BATCH entry=$ENTRY" > "$dir/config_note.txt"

  cat > "$dir/launch.sh" <<EOF
#!/bin/bash
source "$SCRIPT_DIR/common_env.sh"
cd "$MSLLM_DIR"
torchrun \\
  --nproc_per_node "$NPUS_PER_NODE" \\
  --nnodes 1 \\
  --node_rank 0 \\
  --master_addr "$MASTER_ADDR" \\
  --master_port "$port" \\
  "$ENTRY" \\
  \$(base_qwen_args "$PP" "$TP" "$MICRO_BATCH" "$ckpt") \\
  --sequence-parallel \\
  $extra
EOF
  chmod +x "$dir/launch.sh"

  echo "======================================================================"
  echo "[$(date '+%F %T')] probing zero=$z args: $extra"
  echo "======================================================================"
  SAMPLE_INTERVAL_SEC=${SAMPLE_INTERVAL_SEC:-1} bash "$SCRIPT_DIR/sampler_power_mem.sh" "$dir/power_mem.csv" &
  local sampler_pid=$!
  sleep 5
  (cd "$dir" && bash launch.sh > train.log 2>&1)
  local rc=$?
  sleep 3
  kill "$sampler_pid" 2>/dev/null || true
  wait "$sampler_pid" 2>/dev/null || true
  if grep -qi "out of memory\\|NPU out of memory\\|RuntimeError" "$dir/train.log"; then
    echo "FAIL rc=$rc" > "$status_file"
  elif [ "$rc" = "0" ]; then
    echo "PASS rc=0" > "$status_file"
  else
    echo "FAIL rc=$rc" > "$status_file"
  fi
}

for z in 0 1 2 3; do
  run_one "$z" $(( BASE_PORT + z ))
done

python3 "$SCRIPT_DIR/summarize_zero_probe.py" "$OUT_ROOT" > "$OUT_ROOT/zero_probe_summary.csv"
echo "[done] summary: $OUT_ROOT/zero_probe_summary.csv"
