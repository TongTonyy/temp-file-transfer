# AscendTune 910C 建模与标定脚本包

本目录用于在 910C 服务器上执行第二轮建模标定。目标不是继续解释旧排序，而是获得可复验的吞吐/能耗结构化模型。

## 推荐执行顺序

1. 将本目录提交到你的 GitHub 项目。
2. 在 910C 服务器上 `git pull` 到可访问目录。
3. 修改 `common_env.sh` 中的路径，确认 `MSLLM_DIR`、权重目录、数据目录正确。
4. 先跑 ZeRO 档位探测：

```bash
bash run_zero_stage_probe.sh 2>&1 | tee zero_probe.log
```

5. 再跑功耗状态机标定：

```bash
bash run_energy_calibration.sh 2>&1 | tee energy_calibration.log
```

6. 打包结果并推送到 GitHub：

```bash
bash pack_and_push_results.sh
```

## 产物

- `results_zero_probe/`：ZeRO 0/1/2/3 的可执行性、显存、吞吐、错误日志。
- `results_energy_calibration/`：idle、GEMM、vector、memory、HCCL 标定结果和功耗时间序列。
- `energy_calibration_results.tar.gz`：用于传回本地建模。

## 建模原则

参考 Galvatron 的结构化建模方式：先 profile 硬件和模型算子，再把策略预测拆成计算、通信、显存和调度项。能耗模型采用 Trace 状态机积分：

```text
Power_total(t) = P_idle + P_compute(t) + P_memory(t) + P_comm(t)
Energy = sum(Power_total(t) * dt)
tokens/J = effective_or_nominal_tokens / Energy
```

注意：`posttrain_gpt_lab_v2.py` 仍保留真实 token 计数钩子，但不同 MindSpeed-LLM 版本内部函数名可能变化。若 `real_tokens.csv` 行数不是 25，需要先修 token 计数入口，再谈 effective tokens/J。
