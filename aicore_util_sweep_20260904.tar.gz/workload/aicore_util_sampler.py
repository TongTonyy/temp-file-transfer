#!/usr/bin/env python3
"""Sample npu-smi during a short training utilization sweep."""

from __future__ import annotations

import argparse
import csv
import json
import re
import subprocess
import time
from collections import defaultdict
from pathlib import Path
from statistics import mean
from typing import Any, Sequence


FIELDS = (
    "ts_utc",
    "elapsed_s",
    "npu",
    "chip",
    "power_w",
    "temperature_c",
    "aicore_pct",
    "hbm_used_mb",
    "hbm_total_mb",
    "status",
)


def utc_now() -> str:
    return time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())


def number(value: str) -> float | None:
    if value.strip() == "-":
        return None
    match = re.search(r"-?\d+(?:\.\d+)?", value)
    return float(match.group(0)) if match else None


def parse_npu_smi(text: str) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    pending_power: float | None = None
    pending_temp: float | None = None
    for raw in text.splitlines():
        if not raw.startswith("|"):
            continue
        parts = [part.strip() for part in raw.split("|")[1:-1]]
        if len(parts) != 3:
            continue
        left, middle, right = parts
        left_tokens = left.split()
        if len(left_tokens) < 2:
            continue
        if middle == "OK":
            right_tokens = right.split()
            pending_power = number(right_tokens[0]) if right_tokens else None
            pending_temp = number(right_tokens[1]) if len(right_tokens) > 1 else None
            continue
        if ":" not in middle:
            continue
        right_tokens = right.replace("/", " / ").split()
        if not right_tokens:
            continue
        try:
            npu = int(left_tokens[0])
            chip = int(left_tokens[1])
        except ValueError:
            continue
        aicore = number(right_tokens[0])
        hbm_used = None
        hbm_total = None
        for index, token in enumerate(right_tokens):
            if token == "/" and index > 0 and index + 1 < len(right_tokens):
                previous = number(right_tokens[index - 1])
                following = number(right_tokens[index + 1])
                if previous is not None and following is not None:
                    hbm_used = previous
                    hbm_total = following
        rows.append(
            {
                "npu": npu,
                "chip": chip,
                "power_w": pending_power,
                "temperature_c": pending_temp,
                "aicore_pct": aicore,
                "hbm_used_mb": hbm_used,
                "hbm_total_mb": hbm_total,
                "status": "ok",
            }
        )
    return rows


def summarize(csv_path: Path, warmup_s: float) -> dict[str, Any]:
    by_die: dict[tuple[int, int], list[dict[str, float]]] = defaultdict(list)
    with csv_path.open("r", encoding="utf-8", newline="") as stream:
        for row in csv.DictReader(stream):
            try:
                elapsed = float(row["elapsed_s"])
                npu = int(row["npu"])
                chip = int(row["chip"])
                aicore = float(row["aicore_pct"])
            except (KeyError, TypeError, ValueError):
                continue
            if elapsed < warmup_s:
                continue
            parsed = {"elapsed_s": elapsed, "aicore_pct": aicore}
            for key in ("temperature_c", "power_w", "hbm_used_mb", "hbm_total_mb"):
                try:
                    parsed[key] = float(row[key])
                except (KeyError, TypeError, ValueError):
                    pass
            by_die[(npu, chip)].append(parsed)
    die_rows = []
    all_aicore = []
    for (npu, chip), rows in sorted(by_die.items()):
        aicores = [row["aicore_pct"] for row in rows]
        all_aicore.extend(aicores)
        die_rows.append(
            {
                "npu": npu,
                "chip": chip,
                "samples": len(rows),
                "aicore_mean": mean(aicores) if aicores else None,
                "aicore_min": min(aicores) if aicores else None,
                "aicore_max": max(aicores) if aicores else None,
                "aicore_high_sample_pct": (
                    100.0 * sum(1 for value in aicores if value >= 80.0) / len(aicores)
                    if aicores
                    else None
                ),
            }
        )
    return {
        "warmup_s": warmup_s,
        "die_count": len(die_rows),
        "aicore_mean_all_dies": mean(all_aicore) if all_aicore else None,
        "aicore_min_all_dies": min(all_aicore) if all_aicore else None,
        "aicore_max_all_dies": max(all_aicore) if all_aicore else None,
        "aicore_high_sample_pct_all_dies": (
            100.0 * sum(1 for value in all_aicore if value >= 80.0) / len(all_aicore)
            if all_aicore
            else None
        ),
        "dies": die_rows,
    }


def main(argv: Sequence[str] | None = None) -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output-csv", type=Path, required=True)
    parser.add_argument("--summary-json", type=Path, required=True)
    parser.add_argument("--stop-file", type=Path, required=True)
    parser.add_argument("--interval-s", type=float, default=2.0)
    parser.add_argument("--max-duration-s", type=float, default=900.0)
    parser.add_argument("--warmup-s", type=float, default=60.0)
    args = parser.parse_args(argv)

    args.output_csv.parent.mkdir(parents=True, exist_ok=True)
    start = time.monotonic()
    next_sample = start
    with args.output_csv.open("w", encoding="utf-8", newline="", buffering=1) as stream:
        writer = csv.DictWriter(stream, fieldnames=list(FIELDS))
        writer.writeheader()
        while True:
            now = time.monotonic()
            elapsed = now - start
            if args.stop_file.exists() or elapsed > args.max_duration_s:
                break
            if now < next_sample:
                time.sleep(min(0.2, next_sample - now))
                continue
            next_sample = now + args.interval_s
            ts = utc_now()
            try:
                completed = subprocess.run(
                    ["npu-smi", "info"],
                    check=False,
                    text=True,
                    stdout=subprocess.PIPE,
                    stderr=subprocess.STDOUT,
                    timeout=10,
                )
                rows = parse_npu_smi(completed.stdout)
                status = "ok" if completed.returncode == 0 else f"npu_smi_rc_{completed.returncode}"
            except (OSError, subprocess.SubprocessError) as error:
                rows = []
                status = f"npu_smi_error:{type(error).__name__}:{error}"
            for row in rows:
                writer.writerow(
                    {
                        "ts_utc": ts,
                        "elapsed_s": round(elapsed, 3),
                        **row,
                        "status": status if row.get("status") == "ok" else row.get("status"),
                    }
                )
    summary = summarize(args.output_csv, args.warmup_s)
    args.summary_json.write_text(
        json.dumps(summary, ensure_ascii=False, indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )
    print(f"AICORE_SWEEP_SAMPLER_SUMMARY={args.summary_json}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
