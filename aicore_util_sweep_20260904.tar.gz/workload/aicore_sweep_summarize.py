#!/usr/bin/env python3
"""Summarize short AICore utilization sweep outputs."""

from __future__ import annotations

import argparse
import csv
import json
import re
from pathlib import Path
from statistics import mean, median
from typing import Any, Sequence


STEP_RE = re.compile(
    r"\biteration\s+([0-9]+)\s*/.*?"
    r"elapsed time per iteration \(ms\):\s*([0-9]+(?:\.[0-9]+)?)"
)


def load_json(path: Path) -> dict[str, Any]:
    if not path.is_file():
        return {}
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except json.JSONDecodeError:
        return {}
    return payload if isinstance(payload, dict) else {}


def step_summary(log_path: Path, warmup_steps: int) -> dict[str, Any]:
    values: list[float] = []
    if not log_path.is_file():
        return {"step_count": 0}
    for line in log_path.read_text(encoding="utf-8", errors="replace").splitlines():
        match = STEP_RE.search(line)
        if match is None:
            continue
        iteration = int(match.group(1))
        if iteration <= warmup_steps:
            continue
        values.append(float(match.group(2)))
    if not values:
        return {"step_count": 0}
    return {
        "step_count": len(values),
        "step_time_ms_mean": mean(values),
        "step_time_ms_median": median(values),
        "step_time_ms_min": min(values),
        "step_time_ms_max": max(values),
    }


def main(argv: Sequence[str] | None = None) -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--sweep-root", type=Path, required=True)
    parser.add_argument("--output-csv", type=Path, required=True)
    parser.add_argument("--warmup-steps", type=int, default=10)
    args = parser.parse_args(argv)

    fieldnames = [
        "label",
        "status",
        "rc",
        "micro_batch_size",
        "global_batch_size",
        "seq_length",
        "train_iters",
        "aicore_mean_all_dies",
        "aicore_min_all_dies",
        "aicore_max_all_dies",
        "aicore_high_sample_pct_all_dies",
        "die_count",
        "step_count",
        "step_time_ms_mean",
        "step_time_ms_median",
        "step_time_ms_min",
        "step_time_ms_max",
        "run_dir",
    ]
    rows: list[dict[str, Any]] = []
    for run_dir in sorted(path for path in args.sweep_root.iterdir() if path.is_dir()):
        config = load_json(run_dir / "config.json")
        summary = load_json(run_dir / "aicore_summary.json")
        steps = step_summary(run_dir / "training.log", args.warmup_steps)
        rows.append(
            {
                "label": config.get("label", run_dir.name),
                "status": config.get("status"),
                "rc": config.get("rc"),
                "micro_batch_size": config.get("micro_batch_size"),
                "global_batch_size": config.get("global_batch_size"),
                "seq_length": config.get("seq_length"),
                "train_iters": config.get("train_iters"),
                "aicore_mean_all_dies": summary.get("aicore_mean_all_dies"),
                "aicore_min_all_dies": summary.get("aicore_min_all_dies"),
                "aicore_max_all_dies": summary.get("aicore_max_all_dies"),
                "aicore_high_sample_pct_all_dies": summary.get("aicore_high_sample_pct_all_dies"),
                "die_count": summary.get("die_count"),
                **steps,
                "run_dir": str(run_dir),
            }
        )
    args.output_csv.parent.mkdir(parents=True, exist_ok=True)
    with args.output_csv.open("w", encoding="utf-8", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=fieldnames)
        writer.writeheader()
        for row in rows:
            writer.writerow({name: row.get(name) for name in fieldnames})
    print(f"AICORE_SWEEP_SUMMARY_CSV={args.output_csv}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
