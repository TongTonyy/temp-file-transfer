# AICore 高占用训练配置短测命令

## 目标

用正常 Qwen3 训练任务短时 sweep `micro_batch_size` 和 `seq_length`，找到能让 4 卡 8 rank 训练中 AICore 使用率持续处于高位的配置。该测试不做风扇故障注入，不插入无效张量计算。

默认每组训练 `80` 个 iteration，并每 `2s` 采集一次 `npu-smi info`，输出 AICore、温度、功耗和 HBM 使用量曲线。

默认配置：

```text
mbs1_seq2048_gbs16
mbs2_seq2048_gbs16
mbs1_seq4096_gbs16
mbs2_seq4096_gbs16
```

## 1. 在 910C 拉取并覆盖脚本

前提：你已经把 `aicore_util_sweep_20260904.tar.gz` 和 `.sha256` 上传到 `TongTonyy/temp-file-transfer` 仓库根目录。

```bash
cd /root/hgnn_910c_readiness

rm -rf /root/hgnn_910c_readiness/temp-file-transfer

GIT_TERMINAL_PROMPT=0 timeout 900 git -c http.version=HTTP/1.1 \
  clone --progress --depth 1 --single-branch --no-tags --filter=blob:none --sparse \
  -b main https://github.com/TongTonyy/temp-file-transfer.git \
  /root/hgnn_910c_readiness/temp-file-transfer

cd /root/hgnn_910c_readiness/temp-file-transfer
git sparse-checkout init --no-cone
git sparse-checkout set \
  aicore_util_sweep_20260904.tar.gz \
  aicore_util_sweep_20260904.tar.gz.sha256

command cp -f \
  aicore_util_sweep_20260904.tar.gz \
  aicore_util_sweep_20260904.tar.gz.sha256 \
  /root/hgnn_910c_readiness/hgnn_f01_qwen3_campaign_v0.3.4/

cd /root/hgnn_910c_readiness/hgnn_f01_qwen3_campaign_v0.3.4
sha256sum -c aicore_util_sweep_20260904.tar.gz.sha256
tar -xzf aicore_util_sweep_20260904.tar.gz

chmod +x \
  tools/offline/full83_910c/run_aicore_util_sweep_910c.sh \
  workload/aicore_util_sampler.py \
  workload/aicore_sweep_summarize.py \
  workload/reference/tune_qwen3_14b_4K_full_ptd.sh
```

## 2. 执行默认短测

```bash
cd /root/hgnn_910c_readiness/hgnn_f01_qwen3_campaign_v0.3.4

bash tools/offline/full83_910c/run_aicore_util_sweep_910c.sh
```

## 3. 可选：缩短或延长每组 iteration

```bash
cd /root/hgnn_910c_readiness/hgnn_f01_qwen3_campaign_v0.3.4

export AICORE_SWEEP_TRAIN_ITERS=60
bash tools/offline/full83_910c/run_aicore_util_sweep_910c.sh
```

## 4. 可选：自定义 sweep 配置

格式为 `label:micro_batch_size:seq_length:global_batch_size`，多个配置用空格分隔。

```bash
cd /root/hgnn_910c_readiness/hgnn_f01_qwen3_campaign_v0.3.4

export AICORE_SWEEP_CONFIGS='mbs1_seq2048_gbs16:1:2048:16 mbs2_seq2048_gbs16:2:2048:16 mbs1_seq4096_gbs16:1:4096:16'

bash tools/offline/full83_910c/run_aicore_util_sweep_910c.sh
```

## 5. 输出位置

脚本结束时会打印：

```text
AICORE_SWEEP_SUMMARY=...
```

主要文件：

```text
runtime/outputs/aicore_sweep/<sweep_id>/aicore_sweep_summary.csv
runtime/outputs/aicore_sweep/<sweep_id>/<config_label>/aicore_timeseries.csv
runtime/outputs/aicore_sweep/<sweep_id>/<config_label>/aicore_summary.json
runtime/outputs/aicore_sweep/<sweep_id>/<config_label>/training.log
```

优先选择 `aicore_mean_all_dies` 高、`aicore_high_sample_pct_all_dies` 高，同时 `step_time_ms_mean` 稳定且没有 OOM 的配置。
